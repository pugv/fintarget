using System;
using System.Reflection;
using System.Threading.Tasks;
using Mb.Configuration.Vault;
using Mb.Tracing;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using NLib.Extensions.AspNet;
using Serilog;
using NLib.Migrations;

namespace fin_expert
{
    public class Program
    {
        private static string _serilogConfigPath = "appsettings.serilog.json";
        /// <summary>
        ///     Main
        /// </summary>
        /// <param name="args"></param>
        private static async Task<int> Main(string[] args)
        {
            using var logger = SerilogHelpers.SetupBootstrapLogger("expert", _serilogConfigPath);
            try
            {
                var host = CreateHostBuilder(args).Build();
                host.RegisterNLibLoggerWrapper();
                host.RunMigrations();
                await host.RunAsync();
                return 0;
            }
            catch (Exception e)
            {
                logger?.Fatal(e, "Fatal error in Expert service");
                return 1;
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>()
                        .UseConfigurableLogging("expert", ctx => ctx.Configuration.GetValue<bool>("UseDefaultLoggingSinks"))
                        .UseTracing(options =>
                        {
                            options.LocalServiceName = Assembly.GetExecutingAssembly().GetName().Name;
                            options.UseTraceIdResponseHeaderMiddleware = true;
                        })
                        .UseVaultSecrets(HttpClientDelegateFactory.CreateWithoutCertValidation());
                })
                .ConfigureHostConfiguration(config =>
                   config.AddJsonFile(_serilogConfigPath)); 
        }
    }
}