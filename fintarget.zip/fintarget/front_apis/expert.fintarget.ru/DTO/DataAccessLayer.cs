﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.Models;
using fin_expert.Interfaces;
using Expert.Models;
using LCS.Models;
using LinqToDB;
using NLib.Linq2dbExtensions;
using SignalDTO = LCS.Models.SignalDTO;

namespace fin_expert.DTO
{
    public class DataAccessLayer : IDataAccessLayer
    {
        public int GetManagerId(string Login)
        {
            using (var cbdb = new Expert.Models.Database())
            {
                return cbdb.Users.FirstOrDefault(u => u.Login == Login)?.Id ?? 0;
            }
        }

        public async Task<(string ApiKey, int? AuthorId)> GetStrategyApiKey(Guid guid)
        {
            using (var db = new Api.Models.Database())
            {
                var st = await db
                    .Strategies
                    .FirstOrDefaultAsync(s => s.Id == guid);

                return (st?.ApiKey, st?.AuthorId);
            }
        }

        public async Task<Api.Models.Strategy[]> GetApiStrategies()
        {
            using (var db = new Api.Models.Database())
            {
                return await db
                    .Strategies.ToArrayAsync();
            }
        }

        public async Task<Api.Models.Strategy> GetApiStrategy(Guid id)
        {
            using (var db = new Api.Models.Database())
            {
                return await db
                    .Strategies.LoadWith(s => s.PriceCategory).FirstOrDefaultAsync(s => s.Id == id);
            }
        }

        public async Task<SignalDTO> GetStrategyLastSignal(Guid strategyId, DateTime? date = null)
        {
            using (var db = new LCS.Models.Database())
            {
                return await db
                    .Signals
                    .Where(s => s.StrategyId == strategyId && s.State != null &&
                                (date == null || s.OpenTime.Date <= date))
                    .OrderByDescending(s => s.Id)
                    .FirstOrDefaultAsync();
            }
        }

        public async Task<DelayedSignalDTO> GetDelayedSignal(long signalId)
        {
            using (var db = new LCS.Models.Database())
            {
                return await db
                    .DelayedSignals
                    .Where(s => s.Id == signalId)
                    .FirstOrDefaultAsync();
            }
        }

        public async Task<bool> SetStrategyStatus(Guid strategyId, StrategyStatus status)
        {
            using (var db = new Expert.Models.Database())
            {
                var query = db
                    .Strategies
                    .Where(s => s.Id == strategyId).Set(s => s.Status, status);

                if (status is StrategyStatus.Moderate or StrategyStatus.Standard)
                    query = query.Set(s => s.ForReport, true);
                else
                    query = query.Set(s => s.ForReport, false);

                var result = await query.UpdateAsync() != 0;

                return result;
            }
        }


        public async Task<(int total, IEnumerable<SignalDTO> signals)> GetStrategyTradesAsync(Guid strategyId,
            Func<IQueryable<SignalDTO>, IQueryable<SignalDTO>> sortFunc)
        {
            using (var db = new LCS.Models.Database())
            {
                var total = await db.GetTable<SignalDTO>()
                    .Where(s => s.StrategyId == strategyId)
                    .CountAsync();

                var query = db.GetTable<SignalDTO>()
                    .Where(s => s.StrategyId == strategyId);

                return (total, await sortFunc(query).ToArrayAsync());
            }
        }

        public async Task<(int total, IEnumerable<DelayedSignalDTO>)> GetStrategyDelayedSignals(Guid strategyId,
            Func<IQueryable<DelayedSignalDTO>, IQueryable<DelayedSignalDTO>> sortFunc)
        {
            using (var db = new LCS.Models.Database())
            {
                var total = await db
                    .DelayedSignals
                    .Where(s => s.StrategyId == strategyId && s.Executed == null)
                    .CountAsync();

                var query = db
                    .DelayedSignals
                    .Where(s => s.StrategyId == strategyId && s.Executed == null);

                return (total, await sortFunc(query).ToArrayAsync());
            }
        }

        public async Task<StrategyPL> GetStrategyHistory(Guid strategyId)
        {
            using (var db = new Api.Models.Database())
            {
                return await db
                    .StrategyHistory
                    .FirstOrDefaultAsync(sh => sh.StrategyId == strategyId);
            }
        }

        public async Task<Expert.Models.Strategy> GetStrategy(Guid strategyId)
        {
            using (var db = new Expert.Models.Database())
            {
                return await db
                    .Strategies
                    .LoadWith(s => s.Comiss)
                    .FirstOrDefaultAsync(s => s.Id == strategyId);
            }
        }

        public async Task<SignalDTO[]> GetSnaboxSignals(Guid stratId)
        {
            using (var sbdb = new SandboxDatabase())
            {
                return await sbdb.Signals.Where(s => s.StrategyId == stratId).OrderBy(s => s.Id).ToArrayAsync();
            }
        }

        public async Task CopyStrategySignalsFromSandbox(Guid stratId)
        {
            using (var db = new LCS.Models.Database())
            using (var sbdb = new SandboxDatabase())
            using (var cabDB = new Expert.Models.Database())
            {
                var arr = await sbdb
                    .Signals
                    .Where(s => s.StrategyId == stratId).OrderBy(s => s.Id).ToArrayAsync();

                await db.Signals.Where(s => s.StrategyId == stratId).DeleteAsync();

                foreach (var sig in arr)
                {
                    sig.Id = 0;
                    await db.InsertWithInt32IdentityAsync((SignalDTO)sig);
                }

                var strat = await cabDB.Strategies.FirstOrDefaultAsync(s => s.Id == stratId);

                await cabDB.CalcTypeHistories.Where(s => s.StrategyId == stratId).DeleteAsync();
                foreach (var c in await sbdb.CalcTypeHistories.Where(s => s.StrategyId == stratId).ToArrayAsync())
                    await cabDB.InsertAsync(c);
                await cabDB.InsertAsync(new CalcTypeHistory
                {
                    StrategyId = stratId,
                    Date = DateTime.Now,
                    Type = strat?.RecalcMode ?? 2
                });
            }
        }

        public async Task SaveSandboxRecalcMode(Expert.Models.Strategy strategy)
        {
            using (var db = new SandboxDatabase())
            {
                await db
                    .CalcTypeHistories
                    .Where(s => s.StrategyId == strategy.Id)
                    .DeleteAsync();
                await db.InsertAsync(new CalcTypeHistory
                {
                    StrategyId = strategy.Id,
                    Date = null,
                    Type = strategy.RecalcMode
                });
            }
        }

        public async Task<Dictionary<string, (decimal, decimal)>> GetGammaTheta()
        {
            using (var db = new RiskAnalysisDatabase())
            {
                return await db.GammaTheta.ToDictionaryAsync(g => g.ClassCode, g => (g.Gamma, g.Theta));
            }
        }

        public async Task<InvestProfile[]> GetInvestProfiles()
        {
            using (var db = new Api.Models.Database())
            {
                return await db.InvestProfiles.ToArrayAsync();
            }
        }

        public async Task<Expert.Models.IIR[]> GetIIRs(string clientLastName, string clientFirstName,
            string clientMiddleName, string agreementNumber, DateTime? iirStartDate, DateTime? iirEndDate,
            long? iirNumber, string strategyName, string symbol, string classCode)
        {
            using (var db = new Expert.Models.Database())
            {
                IQueryable<Expert.Models.IIR> query = db
                    .IIRs
                    .LoadWith(iir => iir.Instruments)
                    .LoadWith(iir => iir.Orders);

                if (clientLastName != null)
                    query = query.Where(iir => iir.LastName.ToUpper() == clientLastName.ToUpper());
                if (clientFirstName != null)
                    query = query.Where(iir => iir.FirstName.ToUpper() == clientFirstName.ToUpper());
                if (clientMiddleName != null)
                    query = query.Where(iir => iir.MiddleName.ToUpper() == clientMiddleName.ToUpper());

                if (agreementNumber != null)
                    query = query.Where(iir => iir.Agreement.ToUpper() == agreementNumber.ToUpper());

                if (iirStartDate != null)
                    query = query.Where(iir => iir.SignalDate >= iirStartDate.Value.Date);
                if (iirEndDate != null)
                    query = query.Where(iir => iir.SignalDate < iirEndDate.Value.Date.AddDays(1));

                if (iirNumber != null)
                    query = query.Where(iir => iir.SignalId == iirNumber);

                if (strategyName != null)
                    query = query.Where(iir => iir.StrategyName.ToUpper() == strategyName.ToUpper());

                if (symbol != null)
                    query = query.Where(iir =>
                        iir.Instruments.Any(i => i.Symbol == symbol && i.ClassCode == classCode));

                query = query.OrderByDescending(iir => iir.SignalDate).Take(1000);

                var iirs = await query.ToArrayAsync();

                if (symbol != null)
                    foreach (var iir in iirs)
                        iir.Instruments = iir.Instruments.Where(i => i.Symbol == symbol && i.ClassCode == classCode)
                            .ToList();

                return iirs;
            }
        }

        public async Task<Expert.Models.IIR[]> GetOrders(string clientLastName, string clientFirstName,
            string clientMiddleName, string agreementNumber, string orderNumber, DateTime? iirStartDate,
            DateTime? iirEndDate, long? iirNumber, string strategyName, string symbol, string classCode)
        {
            using (var db = new Expert.Models.Database())
            {
                var query = db.Orders.OrderByDescending(o => o.OrderId)
                    .Join(db.IIRs, o => o.SignalId, i => i.SignalId, (o, i) => new { o, i })
                    .Join(db.IirInstruments, o => $"{o.o.SignalId} {o.o.Security}",
                        i => $"{i.SignalId} {i.Symbol} {i.ClassCode} QUIK",
                        (o, i) => new { order = o.o, iir = o.i, instrument = i });

                if (clientLastName != null)
                    query = query.Where(o => o.iir.LastName.ToUpper() == clientLastName.ToUpper());
                if (clientFirstName != null)
                    query = query.Where(o => o.iir.FirstName.ToUpper() == clientFirstName.ToUpper());
                if (clientMiddleName != null)
                    query = query.Where(o => o.iir.MiddleName.ToUpper() == clientMiddleName.ToUpper());

                if (agreementNumber != null)
                    query = query.Where(o => o.iir.Agreement.ToUpper() == agreementNumber.ToUpper());

                if (orderNumber != null)
                    query = query.Where(o => o.order.BrokerOrderId == orderNumber);

                if (iirNumber != null)
                    query = query.Where(o => o.iir.SignalId == iirNumber);

                if (iirStartDate != null)
                    query = query.Where(o => o.iir.SignalDate >= iirStartDate.Value.Date);
                if (iirEndDate != null)
                    query = query.Where(o => o.iir.SignalDate < iirEndDate.Value.Date.AddDays(1));

                if (strategyName != null)
                    query = query.Where(o => o.iir.StrategyName.ToUpper() == strategyName.ToUpper());

                if (symbol != null)
                    query = query.Where(o => o.instrument.Symbol == symbol && o.instrument.ClassCode == classCode);

                query = query.Take(1000);

                var materialized = await query.ToArrayAsync();

                return materialized
                    .GroupBy(o => o.iir.SignalId)
                    .Select(g =>
                    {
                        var iir = g.First().iir;
                        iir.Instruments = g.GroupBy(e => $"{e.instrument.Symbol} {e.instrument.ClassCode}")
                            .Select(g => g.First().instrument).ToList();
                        iir.Orders = g.Select(o => o.order).ToList();
                        return iir;
                    }).ToArray();
            }
        }
    }
}