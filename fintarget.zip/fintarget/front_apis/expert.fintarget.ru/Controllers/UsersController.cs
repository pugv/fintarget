﻿using System;
using System.Linq;
using System.Threading.Tasks;
using fin_expert.Models;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceBase;
using Database = Api.Models.Database;

namespace fin_expert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator,ContentManager,DigitalExpert")]
    public class UsersController
        : WebCabinetController<UsersController>
    {
        public UsersController(IServiceProvider serviceProvider, ILogger<UsersController> logger)
            : base(serviceProvider, logger)
        {
        }

        // GET: api/users
        [HttpGet]
        public async Task<ActionResult<RequestResult<UserDirectoryItem[]>>> Get()
        {
            try
            {
                using (var db = new Database())
                {
                    var users = await
                        db
                            .Authors
                            .OrderBy(u => u.DisplayName)
                            .Select(u => new UserDirectoryItem
                            {
                                Id = u.Id,
                                Name = u.DisplayName
                            })
                            .ToArrayAsync();

                    return Success(users);
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }
    }
}