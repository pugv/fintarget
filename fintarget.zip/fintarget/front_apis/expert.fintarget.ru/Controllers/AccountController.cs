﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Api.Models;
using ExchangeHelpers;
using fin_expert.Models;
using fin_expert.Utilities;
using Expert.Models;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceBase;


namespace fin_expert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController
        : WebCabinetController<AccountController>
    {
        private readonly SMS.ApiClient.Api _smsApi;

        public AccountController(IServiceProvider serviceProvider, SMS.ApiClient.Api smsApi, ILogger<AccountController> logger)
            : base(serviceProvider, logger)
        {
            _smsApi = smsApi;
        }

        // POST: api/account/signinstage
        [HttpPost("signinstage")]
        public async Task<ActionResult<RequestResult<User>>> SignInStage(SignInData signInData)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var userManager = new UserManager(db);
                    var user = await userManager.ValidateCredentials(signInData.UserId, signInData.Password);

                    var ip = HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();

                    if (!string.IsNullOrEmpty(user.Phone) && Config.AuthTwoFactor && !Config.AuthNoSmsWhiteList.Contains(ip))
                    {
                        await CheckOtpLimitAsync(user.Id);
                        var smsCode = SendConfirmationSms(user.Phone);
                        await StoreAuditActionAsync(AuditRecord.Actions.SentOtp, new { Info = "Sent Otp" }, user.Id);

                        HttpContext.Session.SetInt32("PasswordCheckedUserId", user.Id);
                        HttpContext.Session.SetInt32("PasswordCheckedSmsCode", smsCode);
                        HttpContext.Session.SetString("PasswordCheckedDate", DateTime.UtcNow.ToString());

                        return Error(DecoratePhone(user.Phone), (int)Errors.SmsCodeRequired);
                    }

                    if (user.DraftPassword != 0)
                        return Error("Необходима смена пароля при первом входе", (int)Errors.DraftPassword);

                    await StoreAuditActionAsync(AuditRecord.Actions.Login, new { Info = "User password validated", Login = signInData.UserId }, user.Id);
                    await userManager.SignIn(HttpContext, user, Config.AuthSessionExpiration);
                    await StoreAuditActionAsync(AuditRecord.Actions.Login, new { Info = "User logged in", user.Login }, user.Id);
                    return Success(user); // Сразу возвращаем информацию по клиенту, 2-факторная авторизация не требуется
                }
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.Login, new { Info = "User sign in failed", Login = signInData.UserId });
                return Error(ex);
            }
        }

        private async Task CheckOtpLimitAsync(int userId)
        {
            using var db = new Expert.Models.Database();
            var recentSmsCnt = await db.Audit
                .Where(c => c.UserId == userId && c.Action == AuditRecord.Actions.SentOtp && c.Date > DateTime.Now - Config.AuthMaxOtpsInterval).CountAsync();
            if (recentSmsCnt > Config.AuthMaxOtpsPerInterval) throw BindingProhibitionReason.TooManySms.ToUserVisibleException(false);
        }

        private string DecoratePhone(string phone)
        {
            var result = new StringBuilder(phone.Length);
            var cnt = 0;
            foreach (var c in phone)
            {
                if (!char.IsDigit(c))
                {
                    result.Append(c);
                    continue;
                }

                if (cnt < 4 || cnt > 7)
                    result.Append(c);
                else
                    result.Append('*');
                cnt++;
            }

            return result.ToString();
        }

        private int SendConfirmationSms(string phone)
        {
            var code = new Random(Environment.TickCount).Next(1000, 9999);

            _smsApi.SendMessages(new[] { new Message { Address = phone, Text = $"Код: {code}. Вход в {DateTime.Now.ToString("HH:mm dd.MM.yyyy")}" } });
            return code;
        }

        // POST: api/account/signin
        [HttpPost("signin")]
        public async Task<ActionResult<RequestResult<User>>> SignIn(LoginSmsCode signInData)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var passwordCheckedDate = HttpContext.Session.GetString("PasswordCheckedDate");
                    var passwordCheckedUserId = HttpContext.Session.GetInt32("PasswordCheckedUserId");
                    var passwordCheckedSmsCode = HttpContext.Session.GetInt32("PasswordCheckedSmsCode");

                    if (!DateTime.TryParse(passwordCheckedDate, out var pcd)
                        || DateTime.UtcNow > pcd + Config.AuthSmsExpiration
                        || !passwordCheckedUserId.HasValue
                        || !passwordCheckedSmsCode.HasValue)
                    {
                        await StoreAuditActionAsync(AuditRecord.Actions.Login, new { Info = "Sms code expired", Login = passwordCheckedUserId }, passwordCheckedUserId);
                        return Error("SMS код устарел", (int)Errors.SmsCodeExpired);
                    }

                    var userManager = new UserManager(db);
                    var user = await userManager.GetUser(passwordCheckedUserId.Value);

                    if (!await userManager.ValidateCredentials(user, () => signInData.SmsCode == passwordCheckedSmsCode.ToString()))
                    {
                        await StoreAuditActionAsync(AuditRecord.Actions.Login, new { Info = "Sms validation failed", Expected = passwordCheckedSmsCode, Received = signInData.SmsCode }, passwordCheckedUserId);
                        return Error("Указан неверный код", (int)Errors.IncorrectConfirmationCode);
                    }

                    HttpContext.Session.Remove("PasswordCheckedDate");
                    HttpContext.Session.Remove("PasswordCheckedUserId");
                    HttpContext.Session.Remove("PasswordCheckedSmsCode");

                    if (user.DraftPassword != 0) return Error("Необходима смена пароля при первом входе", (int)Errors.DraftPassword);

                    await userManager.SignIn(HttpContext, user, Config.AuthSessionExpiration);
                    await StoreAuditActionAsync(AuditRecord.Actions.Login, new { Info = "User logged in", user.Login }, user.Id);
                    return Success(user);
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // POST: api/account/changepwd
        [HttpPost("changepwd")]
        public async Task<ActionResult<RequestResult<User>>> ChangePassword(ChangePasswordData chPwdData)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var userManager = new UserManager(db);
                    var user = await userManager.ChangePassword(HttpContext, chPwdData.UserId, chPwdData.OldPassword, chPwdData.NewPassword,
                        chPwdData.ConfirmNewPassword, Config.AuthSessionExpiration);

                    await StoreAuditActionAsync(AuditRecord.Actions.ChangePassword, new { Info = "User password changed", Login = chPwdData.UserId });
                    await userManager.SignIn(HttpContext, user, Config.AuthSessionExpiration);
                    await StoreAuditActionAsync(AuditRecord.Actions.Login, new { Info = "User logged in", user.Login });
                    return Success(user);
                }
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.ChangePassword, new { Info = "User change password failed", Login = chPwdData.UserId });
                return Error(ex);
            }
        }

        // GET: api/account/current
        [HttpGet("current")]
        [Authorize]
        public async Task<ActionResult<RequestResult<User>>> GetCurrentUser()
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var userManager = new UserManager(db);

                    return Success(await userManager.GetUser(User));
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: api/account/signout
        [HttpGet("signout")]
        public async Task<ActionResult<RequestResult<User>>> SignOutUser()
        {
            var userLogin = string.Empty;

            try
            {
                var userManager = new UserManager(null);

                userLogin = UserManager.GetUserLogin(User);

                await userManager.SignOut(HttpContext);

                await StoreAuditActionAsync(AuditRecord.Actions.Logout, new { Info = "Manual sign out", Login = userLogin });

                return Success();
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.Logout, new { Info = "Sign out failed", Login = userLogin });
                return Error(ex);
            }
        }
    }
}