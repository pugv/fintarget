﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading.Tasks;
using Api.Models;
using ExchangeHelpers.HS;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using Expert.Models;
using LCS.Models;
using LinqToDB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLib.AuxTypes;
using NLib.MathUtils;
using NLib.ParsersFormatters;
using NLib.ParsersFormatters.DateTime;
using PositionCalculator;
using ServiceBase;

namespace fin_expert.Controllers
{
    public abstract class WebCabinetController<T> : WebCabinetController
    {
        public WebCabinetController(IServiceProvider serviceProvider, ILogger<T> logger) : base(serviceProvider, logger)
        {
        }
    }

    public abstract class WebCabinetController
        : BaseController
    {
        public enum Errors
        {
            Unknown = 0,
            DraftPassword = 1, // Необходима смена пароля
            InsufficientRights = 2, // Недостаточно прав
            SecurityNotFound = 3, // Инструмент не найден
            IncorrectConfirmationCode = 4, // Введён неверный код подтверждения
            SmsCodeRequired = 5, // Необходимо ввести смс код
            SmsCodeExpired = 6,

            UserOrCompanyName = 16 // не указаны имя/фамилия или название организации
        }

        private static readonly IFormatProvider dotFormatProvider;


        private readonly Random rnd = new Random();

        static WebCabinetController()
        {
            dotFormatProvider = (IFormatProvider)CultureInfo.InvariantCulture.Clone();
            ((CultureInfo)dotFormatProvider).NumberFormat.NumberDecimalSeparator = ".";
            ((CultureInfo)dotFormatProvider).NumberFormat.NumberGroupSeparator = " ";
        }

        public WebCabinetController(IServiceProvider serviceProvider, ILogger logger)
            : base(serviceProvider, logger)
        {
            Config = GetService<AppConfig>();
            dataAccessLayer = GetService<IDataAccessLayer>();
        }

        protected AppConfig Config { get; }
        protected IDataAccessLayer dataAccessLayer { get; set; }

        protected async Task StoreAuditActionAsync(string action, object info, int? userId = null)
        {
            try
            {
                var ip = HttpContext?.Request?.Headers["X-Forwarded-For"].FirstOrDefault();

                var record = new AuditRecord(userId ?? (int)UserManager.GetUserId(User),
                    ip != null ? IPAddress.Parse(ip) : null, action, info);

                using var db = new Expert.Models.Database();
                await db.InsertAsync(record);
            }
            catch (Exception ex)
            {
                LogError(ex);
            }
        }

        protected async Task<Expert.Models.Strategy> GetStrategy(Guid id)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    return await db.Strategies.FirstOrDefaultAsync(s => s.Id == id);
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                return null;
            }
        }

        protected virtual async Task<Expert.Models.Strategy[]> GetStrategies()
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    return await db.Strategies.ToArrayAsync();
                }
            }
            catch (Exception ex)
            {
                LogError(ex);
                return null;
            }
        }

        protected virtual async Task<SignalProcessor.State> GetStrategyOpenPositions(Guid strategyId)
        {
            var lastSignal = await dataAccessLayer.GetStrategyLastSignal(strategyId);

            if (lastSignal != null)
                return SignalDTO.StateFromJson(lastSignal.State, lastSignal.Id);

            return null;
        }

        internal Task<DelayedSignalDTO> GetDelayedSignal(long signalId)
        {
            return dataAccessLayer.GetDelayedSignal(signalId);
        }

        protected string ConvertPriceToString(decimal? Price, SecurityRecord sec)
        {
            return ConvertPriceToString(Price, sec?.PriceStep);
        }

        protected string ConvertPriceToString(decimal? Price, decimal? PriceStep)
        {
            return Price?.ToStdString(PriceStep?.GetLeastSignificantDigit() ?? 0);
        }

        protected decimal ConvertPriceToDecimal(decimal? Price, SecurityRecord sec)
        {
            if (Price == null) return 0;
            return Price.Value.RoundTo(sec.PriceStep?.GetLeastSignificantDigit() ?? 0);
        }


        internal virtual async Task<(int, SignalDTO[])> GetStrategyTrades(Guid strategyId, PaginationAndSort paginationAndSort)
        {
            var res = await dataAccessLayer.GetStrategyTradesAsync(strategyId, query =>


            {
                query = OrderTradesQuery(query, paginationAndSort);

                if (paginationAndSort.PageSize != 0)
                    query = query
                        .Skip(paginationAndSort.PageSize * paginationAndSort.PageNumber)
                        .Take(paginationAndSort.PageSize);

                return query;
            });

            return (res.total, res.signals.ToArray());
        }

        internal async Task<(int, DelayedSignalDTO[])> GetStrategyDelayedSignals(Guid strategyId, PaginationAndSort paginationAndSort)
        {
            var (total, res) = await dataAccessLayer.GetStrategyDelayedSignals(strategyId, query =>
            {
                query = OrderDelayedSignalsQuery(query, paginationAndSort);

                return
                    query
                        .Skip(paginationAndSort.PageSize * paginationAndSort.PageNumber)
                        .Take(paginationAndSort.PageSize);
            });


            var state = await GetStrategyOpenPositions(strategyId);

            return (total, res
                .Select(ds =>
                {
                    if (ds.Weight == 0)
                        ds.Weight = -state.ActivePositions.FirstOrDefault(p => p.Key.GetKey() == ds.SecurityKey).Value?.Weight ?? 0;
                    return ds;
                }).ToArray());
        }

        protected static IQueryable<SignalDTO> OrderTradesQuery(IQueryable<SignalDTO> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName?.ToLower())
            {
                case "symbol":
                case "name":
                    return OrderQueryBy(query, t => t.SecurityKey, paginationAndSort.SortDirection);
                case "comment":
                    return OrderQueryBy(query, t => t.Comment, paginationAndSort.SortDirection);
                case "weight":
                    return OrderQueryBy(query, t => t.Weight, paginationAndSort.SortDirection);
                case "price":
                    return OrderQueryBy(query, t => t.OpenPrice, paginationAndSort.SortDirection);
                case "time":
                    return OrderQueryBy(query, t => t.OpenTime, paginationAndSort.SortDirection);
                case "realizedpl":
                    return OrderQueryBy(query, t => t.RealizedPnl, paginationAndSort.SortDirection);
                default:
                    return query.OrderByDescending(t => t.OpenTime);
            }
        }

        private static IQueryable<DelayedSignalDTO> OrderDelayedSignalsQuery(IQueryable<DelayedSignalDTO> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName?.ToLower())
            {
                case "symbol":
                case "name":
                    return OrderQueryBy(query, s => s.SecurityKey, paginationAndSort.SortDirection);
                case "comment":
                    return OrderQueryBy(query, s => s.Comment, paginationAndSort.SortDirection);
                case "weight":
                    return OrderQueryBy(query, s => s.Weight, paginationAndSort.SortDirection);
                case "execPrice":
                    return OrderQueryBy(query, s => s.ExecQuotation, paginationAndSort.SortDirection);
                case "filingTime":
                    return OrderQueryBy(query, s => s.OpenTime, paginationAndSort.SortDirection);
                case "stopLoss":
                    return OrderQueryBy(query, s => s.StopLoss, paginationAndSort.SortDirection);
                case "takeProfit":
                    return OrderQueryBy(query, s => s.TakeProfit, paginationAndSort.SortDirection);
                default:
                    return query.OrderByDescending(s => s.OpenTime);
            }
        }

        protected static IQueryable<T> OrderQueryBy<T, R>(IQueryable<T> query, Expression<Func<T, R>> selector, int direction)
        {
            return direction > 0 ? query.OrderBy(selector) : query.OrderByDescending(selector);
        }

        internal static IReadOnlyDictionary<Guid, SignalProcessor.State> GetAllOpenPositions()
        {
            using (var db = new LCS.Models.Database())
            {
                var strats = db.Strategies.ToArray();

                var result = new Dictionary<Guid, SignalProcessor.State>();

                foreach (var strategy in strats)
                {
                    var lastSignal = db
                        .Signals
                        .Where(s => s.StrategyId == strategy.Id && s.State != null)
                        .OrderByDescending(s => s.Id)
                        .FirstOrDefault();

                    if (lastSignal != null)
                        result.Add(strategy.Id, SignalDTO.StateFromJson(lastSignal.State, lastSignal.Id));
                }

                return result;
            }
        }

        protected virtual async Task<StrategyHistory.HistoryPoint[]> GetStrategyHistory(Guid strategyId, DateTime? startDate, bool reduce = true)
        {
            var history = await dataAccessLayer.GetStrategyHistory(strategyId);

            if (history != null)
            {
                var data = JsonConvert.DeserializeObject<StrategyHistory.HistoryPoint[]>(history.HistoryJson);

                return ReduceDataset(
                    startDate,
                    data,
                    reduce ? Config.MaxHistoryPoints : data.Length);
            }

            return null;
        }

        protected async Task<(StrategyHistory.HistoryPoint[], string)> GetIndexHistory(Guid strategyId, DateTime? startDate)
        {
            IndexHistoryPoint[] history = null;
            string indexName = null;

            using (var db = new Api.Models.Database())
            {
                var indexId = db
                    .Strategies
                    .FirstOrDefault(s => s.Id == strategyId)
                    ?.IndexId;

                if (indexId != null)
                {
                    indexName = (await db
                        .Indices
                        .FirstOrDefaultAsync(i => i.Id == indexId))?.Name;

                    history = await db
                        .IndexHistory
                        .Where(i => i.IndexId == indexId && i.Date >= startDate)
                        .OrderBy(i => i.Date)
                        .ToArrayAsync();
                }
            }

            if (history != null && history.Length > 0)
            {
                var first = history.First().Value;

                return (ReduceDataset(
                        startDate,
                        history.Select(p => new StrategyHistory.HistoryPoint
                        {
                            t = p.Date.ToJsonTime(),
                            v = p.Value
                        }).ToArray(),
                        Config.MaxHistoryPoints),
                    indexName);
            }

            return (null, null);
        }

        internal static StrategyHistory.HistoryPoint[] ReduceDataset(DateTime? startDate, StrategyHistory.HistoryPoint[] points, int maxCount)
        {
            if (startDate != null)
                points = points.SkipWhile(p => p.t.FromJsonTime() < startDate).ToArray();

            if (points.Length <= maxCount)
                return points;

            var result = new List<StrategyHistory.HistoryPoint>(maxCount);

            var factor = 1.0 * (points.Length - 1) / (maxCount - 1);

            for (var i = 0; i < maxCount - 1; i++)
                result.Add(points[(int)(i * factor)]);

            // always include last point
            result.Add(points[points.Length - 1]);

            return result.ToArray();
        }

        protected virtual Task<SignalDTO> GetStrategyLastSignal(Guid strategyId, DateTime? date = null)
        {
            return dataAccessLayer.GetStrategyLastSignal(strategyId, date);
        }

        protected decimal? GetUnrealizedPositionPL(Position position, SecurityRecord security)
        {
            if (Config.MockUnrealizedPL)
                return (decimal)rnd.NextDouble() / 100m;

            if (security == null || security.LastPrice == null)
                return null;

            if (position.OpenPrice == 0) return null;

            if (position.OpenQuotation!=0)
             return position.Weight.Sign() * (security.LastQuotation - position.OpenQuotation) / security.LastQuotation / position.OpenPrice * security.LastPrice;
            
            return position.Weight.Sign() * (security.LastPrice - position.OpenPrice) / position.OpenPrice;
        }

        protected virtual async Task<Expert.Models.Strategy> CheckStrategyAccessRights(Guid strategyId, bool denyExpert = false)
        {
            var id = UserManager.GetUserId(User);
            var role = UserManager.GetUserRole(User);

            var strategy = await dataAccessLayer.GetStrategy(strategyId);

            if (strategy == null)
                throw new UserVisibleException("Стратегия не найдена");

            if (!CheckUserStrategyRights(id, role, strategy, denyExpert))
                throw new UserVisibleException("Недостаточно прав для получения запрошенной информации", (int)Errors.InsufficientRights);

            return strategy;
        }

        protected virtual async Task<Expert.Models.Strategy> CheckStrategyWriteRights(Guid strategyId)
        {
            var id = UserManager.GetUserId(User);
            var role = UserManager.GetUserRole(User);

            var strategy = await dataAccessLayer.GetStrategy(strategyId);

            if (strategy == null)
                throw new UserVisibleException("Стратегия не найдена");

            if (!CheckUserStrategyWriteRights(id, role, strategy))
                throw new UserVisibleException("Недостаточно прав для внесения изменений в эту стратегию", (int)Errors.InsufficientRights);

            return strategy;
        }

        private bool CheckUserStrategyRights(long authorId, UserRole role, Expert.Models.Strategy strategy, bool denyExpert)
        {
            switch (role)
            {
                case UserRole.Administrator:
                case UserRole.RiskManager:
                case UserRole.Support:
                case UserRole.DigitalExpert:
                case UserRole.ContentManager:
                case UserRole.Developer:
                    return true;
                case UserRole.Expert:
                    return !denyExpert;
                case UserRole.Manager:
                    return strategy.ManagerId == authorId || IsStrategyManager(strategy.Id, authorId);
                default:
                    return false;
            }
        }

        private bool IsStrategyManager(Guid strategyId, long authorId)
        {
            using (var db = new Expert.Models.Database())
            {
                return db.StrategyManagers.Any(sm => sm.StrategyId == strategyId && sm.ManagerId == authorId);
            }
        }

        private bool CheckUserStrategyWriteRights(long authorId, UserRole role, Expert.Models.Strategy strategy)
        {
            switch (role)
            {
                case UserRole.Administrator:
                    return true;
                case UserRole.Manager:
                    return strategy.ManagerId == authorId || IsStrategyManager(strategy.Id, authorId);
                default:
                    return false;
            }
        }

        protected ActionResult StatusError(HttpStatusCode code, string err)
        {
            var res = Error(err);

            res.StatusCode = (int)code;

            return res;
        }

        protected ActionResult StatusError(HttpStatusCode code, string err, int errCode)
        {
            var res = Error(err, errCode);

            res.StatusCode = (int)code;

            return res;
        }

        protected ActionResult StatusError(HttpStatusCode code, Exception ex)
        {
            var res = Error(ex);

            res.StatusCode = (int)code;

            return res;
        }

        public static string GetSecuritySymbolName(SecurityRecord security)
        {
            if (security == null) return null;
            return security.ClassCode.StartsWith('N') ? security.ShortName : security.Symbol;
        }

        public static string FormatInt(int value)
        {
            if (value == 0)
                return string.Empty;

            var format = "#,0";
            return value.ToString(format, dotFormatProvider).Replace(" ", "&nbsp;");
        }

        public static string FormatDecimal(decimal value, int decimalPlaces = 2)
        {
            if (value == 0)
                return string.Empty;

            var decimals = new string('0', decimalPlaces);
            var format = "#,0." + decimals;
            return value.ToString(format, dotFormatProvider).Replace(" ", "&nbsp;");
        }
    }
}