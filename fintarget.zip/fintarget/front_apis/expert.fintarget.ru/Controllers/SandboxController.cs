﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Expert.Models;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LCS.Models;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLib.ParsersFormatters.DateTime;
using PositionCalculator;
using ServiceBase;

namespace fin_expert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SandboxController : StrategiesController
    {
        public static string SandboxFolder = "Sandbox";


        public static long MaxFileSize = 2000000;

        /* TEST */

        private static readonly Guid G = new Guid();

        private readonly IStrategySandbox sandbox;

        public SandboxController(IStrategySandbox sandbox, IServiceProvider sv, ILogger<StrategiesController> logger, ISecurityCache cache) : base(sv, logger,
            cache, null, null)
        {
            this.sandbox = sandbox;
        }


        protected override async Task<StrategyHistory.HistoryPoint[]> GetStrategyHistory(Guid strategyId, DateTime? startDate, bool reduce = true)
        {
            using (var db = new SandboxDatabase())
            {
                var history = await db
                    .StrategyHistory
                    .FirstOrDefaultAsync(sh => sh.StrategyId == strategyId);

                if (history != null)
                {
                    var data = JsonConvert.DeserializeObject<StrategyHistory.HistoryPoint[]>(history.HistoryJson);

                    return ReduceDataset(
                        startDate,
                        data,
                        reduce ? Config.MaxHistoryPoints : data.Length);
                }

                return null;
            }
        }

        protected override async Task<SignalDTO> GetStrategyLastSignal(Guid strategyId, DateTime? date = null)
        {
            using (var db = new SandboxDatabase())
            {
                return await db.Signals.OrderByDescending(s => s.Id)
                    .FirstOrDefaultAsync(s => s.StrategyId == strategyId && (date == null || s.OpenTime.Date <= date));
            }
        }

        protected override async Task<SignalProcessor.State> GetStrategyOpenPositions(Guid strategyId)
        {
            using (var db = new SandboxDatabase())
            {
                var lastSignal = await db.Signals.OrderByDescending(s => s.Id).FirstOrDefaultAsync(s => s.StrategyId == strategyId);

                if (lastSignal != null)
                    return SignalDTO.StateFromJson(lastSignal.State, lastSignal.Id);
            }

            return null;
        }

        [Authorize]
        [HttpDelete("{stratId}")]
        public async Task<ActionResult<RequestResult>> Delete(Guid stratId)
        {
            var strat = await CheckStrategyWriteRights(stratId);
            if (strat != null)
            {
                await sandbox.Clear(stratId);

                return RequestResult.CreateSuccess();
            }

            return RequestResult.CreateError("Access denied");
        }

        [Authorize]
        [ProducesResponseType(typeof(ActionResult<RequestResult<UploadedFile>>), 200)]
        [ProducesResponseType(500)]
        [HttpPost("uploadfile")]
        public async Task<ActionResult<RequestResult>> UploadFile(IFormFile file)
        {
            try
            {
                if (file.ContentType != "text/plain") return RequestResult.CreateError("Format not supported");
                if (file.Length > MaxFileSize) return RequestResult.CreateError($"File exeeds {MaxFileSize} bytes");
                byte[] content;
                using (var stream = file.OpenReadStream())
                {
                    content = new byte[file.Length];
                    await stream.ReadAsync(content, 0, (int)file.Length);
                }

                var fname = Guid.NewGuid() + ".txt";

                var destination = Path.Combine(SandboxFolder, fname);

                if (!Directory.Exists(SandboxFolder))
                    Directory.CreateDirectory(SandboxFolder);
                try
                {
                    Directory.GetFiles(SandboxFolder, "*.*").Where(f => (DateTime.Now - System.IO.File.GetLastWriteTime(f)).TotalDays > 1).ToList()
                        .ForEach(f => System.IO.File.Delete(f));
                }
                catch (Exception)
                {
                }

                System.IO.File.WriteAllBytes(destination, content);

                return Success(new UploadedFile
                {
                    Name = fname
                });
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }


        [Authorize]
        [HttpPost("uploadtrackfile")]
        public async Task<ActionResult<RequestResult>> UploadFile([FromForm] IFormFile file, [FromForm] IStrategySandbox.UploadDataRequest req)
        {
            if (file == null) return RequestResult.CreateError("No file");
            if (file.ContentType != "text/plain") return RequestResult.CreateError("Format not supported");
            if (file.Length > MaxFileSize) return RequestResult.CreateError($"File exeeds {MaxFileSize} bytes");

            var strat = await CheckStrategyWriteRights(req.StratId);
            if (strat != null)
            {
                var lines = new List<string>();
                using (var s = new StreamReader(file.OpenReadStream(), Encoding.UTF8))
                {
                    do
                    {
                        var str = await s.ReadLineAsync();
                        if (str != null)
                            lines.Add(str);
                        else break;
                    } while (true);
                }

                if (req.Type == IStrategySandbox.TrackType.Numbers) req.IsAlgo = false;
                strat.RecalcMode = req.IsAlgo ? 1 : 0;
                await dataAccessLayer.SaveSandboxRecalcMode(strat);

                req.Lines = lines.ToArray();

                await sandbox.UploadData(req.StratId, req);


                return RequestResult.CreateSuccess();
            }

            return RequestResult.CreateError("Access denied");
        }


        [Authorize]
        [HttpPost("uploadtrack")]
        public async Task<ActionResult<RequestResult>> UploadTrack(UploadTrackRequest req)
        {
            var strat = await CheckStrategyWriteRights(req.StratId);
            if (strat != null)
            {
                try
                {
                    var lines = new List<string>();
                    using (var s = new StreamReader(System.IO.File.OpenRead(Path.Combine(SandboxFolder, req.FileName)), Encoding.UTF8))
                    {
                        do
                        {
                            var str = await s.ReadLineAsync();
                            if (str != null)
                                lines.Add(str);
                            else break;
                        } while (true);
                    }

                    if (req.Type == IStrategySandbox.TrackType.Numbers) req.IsAlgo = false;
                    strat.RecalcMode = req.IsAlgo ? 1 : 0;
                    await dataAccessLayer.SaveSandboxRecalcMode(strat);

                    req.Lines = lines.ToArray();

                    await sandbox.UploadData(req.StratId, req);
                }
                catch (IOException e)
                {
                    Logger?.LogError(e, "Upload Track");
                    return RequestResult.CreateError("Внутренняя ошибка");
                }
                catch (Exception e)
                {
                    Logger?.LogError(e, "Upload Track");
                    return RequestResult.CreateError(e.Message);
                }

                return RequestResult.CreateSuccess();
            }

            return RequestResult.CreateError("Access denied");
        }


        [HttpPost("testuploadtrack")]
        public async Task<ActionResult<RequestResult>> TestUploadTrack(UploadTrackRequest req)
        {
            var strat = await CheckStrategyWriteRights(req.StratId);
            if (strat != null)
            {
                try
                {
                    var lines = new List<string>();
                    using (var s = new StreamReader(System.IO.File.OpenRead(Path.Combine(SandboxFolder, req.FileName)), Encoding.UTF8))
                    {
                        do
                        {
                            var str = await s.ReadLineAsync();
                            if (str != null)
                                lines.Add(str);
                            else break;
                        } while (true);
                    }

                    req.Lines = lines.ToArray();
                    await (sandbox as StrategySandbox).TestUploadData(req.StratId, req);
                }
                catch (IOException)
                {
                    return RequestResult.CreateError("Внутренняя ошибка");
                }
                catch (Exception e)
                {
                    return RequestResult.CreateError(e.Message);
                }

                return RequestResult.CreateSuccess();
            }

            return RequestResult.CreateError("Доступ запрещён");
        }


        protected override async Task<Expert.Models.Strategy> CheckStrategyWriteRights(Guid strategyId)
        {
            if (strategyId == G)
                return new Expert.Models.Strategy
                {
                    Id = G
                };
            return await base.CheckStrategyWriteRights(strategyId);
        }

        protected override async Task<Expert.Models.Strategy> CheckStrategyAccessRights(Guid strategyId, bool denyExpert = false)
        {
            if (strategyId == G)
                return new Expert.Models.Strategy
                {
                    Id = G
                };

            return await base.CheckStrategyAccessRights(strategyId, denyExpert);
        }

        internal override async Task<(int, SignalDTO[])> GetStrategyTrades(Guid strategyId, PaginationAndSort paginationAndSort)
        {
            using (var db = new SandboxDatabase())
            {
                var total = await db.Signals.CountAsync(s => s.StrategyId == strategyId);


                var query = db.Signals.Where(s => s.StrategyId == strategyId);


                query = OrderTradesQuery(query, paginationAndSort);

                if (paginationAndSort.PageSize != 0)
                    query = query
                        .Skip(paginationAndSort.PageSize * paginationAndSort.PageNumber)
                        .Take(paginationAndSort.PageSize);

                return (total, await query.ToArrayAsync());
            }
        }

        [Authorize]
        [HttpPost("uploaddata")]
        public async Task<ActionResult<RequestResult>> UploaData(IStrategySandbox.UploadDataRequest req)
        {
            var strat = await CheckStrategyWriteRights(req.StratId);
            if (strat != null)
            {
                try
                {
                    if (req.Type == IStrategySandbox.TrackType.Numbers) req.IsAlgo = false;
                    strat.RecalcMode = req.IsAlgo ? 1 : 0;
                    await dataAccessLayer.SaveSandboxRecalcMode(strat);
                    await sandbox.UploadData(req.StratId, req);
                }
                catch (Exception e)
                {
                    return RequestResult.CreateError(e, true);
                }

                return RequestResult.CreateSuccess();
            }

            return RequestResult.CreateError("Access denied");
        }


        [HttpGet("status/{StrategyId}")]
        public ActionResult<RequestResult<IStrategySandbox.Status>> Status(Guid StrategyId)
        {
            return SuccessValue(sandbox.GetStatus(StrategyId));
        }

        [HttpGet("teststatus")]
        public ActionResult TestStatus()
        {
            var status = sandbox.GetStatus(G);
            var html = "Loaded";
            if (status.Loading)
                if (status.Error != null)
                    html = $"<div><b>{status.Error}!</b><div>";
                else
                    html = $"<div>Loading {status.PercentsDone}%</div>";

            return Content($"<html><head><meta http-equiv='refresh' content='1'></head><body>{html}</body></html>", "text/html");
        }

        [HttpGet("test")]
        public async Task<ActionResult> Test()
        {
            var sb = new StringBuilder($"<html><head><meta http-equiv='Content-Type' content='text/html; charset=utf-8'></head><body><h1>Sandbox for {G}</h1>");

            sb.AppendLine("<iframe src='teststatus' width='100%' height='30' border='no'></iframe>");

            sb.AppendLine(
                $"<form enctype='multipart/form-data' action='uploadFile' method='post' target='_blank'><input type='hidden' name='StratId' value='{G}'>");
            sb.AppendLine("<input type='file' name='file'><br>");
            sb.AppendLine("<input type='radio' name='type' value='0'>Numbers");
            sb.AppendLine("<input type='radio' name='type' value='1'>Percents");
            sb.AppendLine("<br>Стартовая сумма <input type='text' name='startingfunds' value='0'><br>");
            sb.AppendLine("<br>Выберите рынки:<br>");
            sb.AppendLine("<br><input type='checkbox' name='Markets' value='1'/>MOEX");
            sb.AppendLine("<br><input type='checkbox' name='Markets' value='2'/>Bonds");
            sb.AppendLine("<br><input type='checkbox' name='Markets' value='3'/>Spb");
            sb.AppendLine("<br><input type='checkbox' name='Markets' value='4'/>Futures");
            sb.AppendLine("<br><input type='checkbox' name='Markets' value='5'/>USA");

            sb.AppendLine("<br><br><input type='checkbox' name='CalcNkd'/>Цены облигаций указаны в %");

            sb.AppendLine("<br><input type='submit' value='Upload'></form>");
            sb.AppendLine("<br>");

            var res = await OpenPositions(G);
            sb.AppendLine("<h2>Positions</h2><ul>");
            foreach (var pos in res.Value.Result) sb.AppendLine($"<li>{pos.SecurityKey} {pos.Weight} х {pos.OpenPrice} </li>");
            sb.AppendLine("</ul><h2>PL</h2><table>");

            var pl = await StrategyHistory(G, "");

            if (pl.Value.Result.History != null)
                foreach (var p in pl.Value.Result.History)
                    sb.AppendLine($"<tr><td>{p.t.FromJsonTime()}</td><td>{p.v}</td></tr>");

            sb.AppendLine("</table>");

            sb.AppendLine("<h2>Signals</h2><table>");

            var sigs = await AllTrades(G, new PaginationAndSort { PageSize = 1000, PageNumber = 0, SortDirection = -1, SortFieldName = "Id" });

            if (sigs.Value.Result?.PageTrades != null)
                foreach (var p in sigs.Value.Result.PageTrades)
                    sb.AppendLine($"<tr><td>{p.Time}</td><td>{p.Symbol}</td><td>{p.Weight}%</td><td>{p.Price}</td><td>{p.RealizedPL}%</td></tr>");
            sb.Append("</body></html>");
            return Content(sb.ToString(), "text/html");
        }

        public class UploadTrackRequest : IStrategySandbox.UploadDataRequest
        {
            public string FileName { get; set; }
        }
    }
}