﻿using System;
using System.Net;
using System.Threading.Tasks;
using Expert.Models;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LCS.Kernel.BusinessModel;
using LCS.Models;
using LifeCycleService.ApiClient;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLib.AuxTypes;
using NLib.ParsersFormatters;
using ServiceBase;
using DelayedSignal = fin_expert.Models.DelayedSignal;

namespace fin_expert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SignalController
        : WebCabinetController<SignalController>
    {
        private readonly ILCS _lcsApi;
        private readonly ISecurityCache _securityCache;
        private readonly SignalsTimer _signalsTimer;

        public SignalController(IServiceProvider serviceProvider, ILogger<SignalController> logger, ISecurityCache securityCache, ILCS lcsApi,
            SignalsTimer timer)
            : base(serviceProvider, logger)
        {
            _securityCache = securityCache;
            _signalsTimer = timer;
            _lcsApi = lcsApi;
        }

        // POST: api/signal/new
        [Authorize(Roles = "Administrator,Manager")]
        [HttpPost("new")]
        public async Task<ActionResult<RequestResult<OpenPosition>>> NewSignal(MarketSignal signal)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(signal.StrategyId);

                if (strategy.ParentStrategy != null)
                    throw new UserVisibleException(
                        $"Сделки в данной стратегии дублируют сделки из стратегии {(await GetStrategy(strategy.ParentStrategy.Value)).Name}");

                var t = _signalsTimer.IsReady(signal.StrategyId);
                if (t != null)
                    throw new UserVisibleException($"Подача сигнала возможна через {t}");

                signal.ManagerId = (int)UserManager.GetUserId(User);
                signal.Weight /= 100m;

                var key = $"{signal.Symbol} {signal.ClassCode} {signal.Board}";
                Signal sig;
                try
                {
                    sig = await _lcsApi.NewSignal(signal);
                    _signalsTimer.SetTimer(signal.StrategyId);
                }
                catch (Exception e)
                {
                    throw new UserVisibleException(e.Message);
                }

                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New signal placed", Signal = signal});

                var security = _securityCache.GetSecuritiy(key);
                await _securityCache.AddSecurities(new[] { key });

                return Success(new OpenPosition
                {
                    ClassCode = signal.ClassCode,
                    SecurityKey = key,
                    Comment = signal.Comment,
                    CurrentPrice = ConvertPriceToString(security?.LastPrice ?? 0, security),
                    OpenPrice = ConvertPriceToString(sig.OpenPrice, security),
                    StopLoss = ConvertPriceToString(signal.StopLoss, security),
                    TakeProfit = ConvertPriceToString(signal.TakeProfit, security),
                    Symbol = signal.Symbol,
                    Name = security?.Name,
                    OpenTime = sig.OpenTime,
                    RealizedPL = sig.PercentPnl?.ToStdString(2),
                    UnrealizedPL = "0",
                    UnrealizedPLPortfolio = "0",
                    Weight = (sig.Weight * 100).ToStdString(2)
                });
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New signal failed", Signal = signal, Error = ex.Message});
                return Error(ex);
            }
        }


        // POST: api/signal/multiple
        [Authorize(Roles = "Administrator,Manager")]
        [HttpPost("multiple")]
        public async Task<ActionResult<RequestResult<OpenPosition>>> NewSignals(MarketSignal[] signals)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(signals[0].StrategyId);

                if (strategy.ParentStrategy != null)
                    throw new UserVisibleException(
                        $"Сделки в данной стратегии дублируют сделки из стратегии {(await GetStrategy(strategy.ParentStrategy.Value)).Name}");

                var t = _signalsTimer.IsReady(signals[0].StrategyId);
                if (t != null)
                    throw new UserVisibleException($"Подача сигнала возможна через {t}");

                foreach (var signal in signals)
                {
                    signal.ManagerId = (int)UserManager.GetUserId(User);
                    signal.Weight /= 100m;
                }

                try
                {
                    await _lcsApi.NewSignals(signals);
                    _signalsTimer.SetTimer(strategy.Id);
                }
                catch (Exception e)
                {
                    throw new UserVisibleException(e.Message);
                }

                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New signals placed", Signals = signals });
                return Success();
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New signals failed", Signals = signals, Error = ex.Message });
                return Error(ex);
            }
        }

        [Authorize(Roles = "Administrator,Manager")]
        [HttpPost("construct")]
        public async Task<ActionResult<RequestResult<OpenPosition>>> Construct(ConstructStrategy construct)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(construct.StratId);
                construct.ManagerId = (int)UserManager.GetUserId(User);
                if (strategy.ParentStrategy != null)
                    throw new UserVisibleException(
                        $"Сделки в данной стратегии дублируют сделки из стратегии {(await GetStrategy(strategy.ParentStrategy.Value)).Name}");

                foreach (var p in construct.Positions) p.Weight /= 100m;
                try
                {
                    await _lcsApi.ConstructStrategy(construct);
                    await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "Strategy constructed", Construct = construct });
                }
                catch (Exception e)
                {
                    await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "Failed to construct strategy", Construct = construct, Error = e.Message });
                    throw new UserVisibleException(e.Message);
                }

                return Success();
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [Authorize(Roles = "Administrator,Manager")]
        [HttpPost("change")]
        public async Task<ActionResult<RequestResult<OpenPosition>>> NewChangeSignal(ChangeSignal signal)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(signal.StrategyId);

                if (strategy.ParentStrategy != null)
                    throw new UserVisibleException(
                        $"Сделки в данной стратегии дублируют сделки из стратегии {(await GetStrategy(strategy.ParentStrategy.Value)).Name}");

                signal.ManagerId = (int)UserManager.GetUserId(User);


                var key = $"{signal.Symbol} {signal.ClassCode} {signal.Board}";
                Signal sig;
                try
                {
                    sig = await _lcsApi.NewChangeSignal(signal);
                }
                catch (Exception e)
                {
                    throw new UserVisibleException(e.Message);
                }
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New change signal placed", Signal = signal });

                var security = _securityCache.GetSecuritiy(key);
                await _securityCache.AddSecurities(new[] { key });

                return Success(new OpenPosition
                {
                    ClassCode = signal.ClassCode,
                    SecurityKey = key,
                    Comment = signal.Comment,
                    CurrentPrice = ConvertPriceToString(security?.LastPrice ?? 0, security),
                    OpenPrice = ConvertPriceToString(sig.OpenPrice, security),
                    StopLoss = ConvertPriceToString(signal.StopLoss, security),
                    TakeProfit = ConvertPriceToString(signal.TakeProfit, security),
                    Symbol = signal.Symbol,
                    Name = security?.Name,
                    OpenTime = sig.OpenTime,
                    RealizedPL = sig.PercentPnl?.ToStdString(2),
                    UnrealizedPL = "0",
                    UnrealizedPLPortfolio = "0",
                    Weight = (sig.Weight * 100).ToStdString(2)
                });
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New change signal failed", Signal = signal, Error = ex.Message });
                return Error(ex);
            }
        }

        [Authorize(Roles = "Administrator,Manager")]
        [HttpPost("replaceposition")]
        public async Task<ActionResult<RequestResult<OpenPosition>>> NewReplacePositionSignal(ChangeSignal signal)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(signal.StrategyId);

                if (strategy.ParentStrategy != null)
                    throw new UserVisibleException(
                        $"Сделки в данной стратегии дублируют сделки из стратегии {(await GetStrategy(strategy.ParentStrategy.Value)).Name}");

                var t = _signalsTimer.IsReady(signal.StrategyId);
                if (t != null)
                    throw new UserVisibleException($"Подача сигнала возможна через {t}");

                signal.ManagerId = (int)UserManager.GetUserId(User);


                var key = $"{signal.Symbol} {signal.ClassCode} {signal.Board}";
                Signal sig;
                try
                {
                    sig = await _lcsApi.NewReplaceSignal(signal);
                    _signalsTimer.SetTimer(signal.StrategyId);
                }
                catch (Exception e)
                {
                    throw new UserVisibleException(e.Message);
                }
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New replace signal placed", Signal = signal });

                var security = _securityCache.GetSecuritiy(key);
                await _securityCache.AddSecurities(new[] { key });

                return Success(new OpenPosition
                {
                    ClassCode = signal.ClassCode,
                    SecurityKey = key,
                    Comment = signal.Comment,
                    CurrentPrice = ConvertPriceToString(security?.LastPrice ?? 0, security),
                    OpenPrice = ConvertPriceToString(sig.OpenPrice, security),
                    StopLoss = ConvertPriceToString(signal.StopLoss, security),
                    TakeProfit = ConvertPriceToString(signal.TakeProfit, security),
                    Symbol = signal.Symbol,
                    Name = security?.Name,
                    OpenTime = sig.OpenTime,
                    RealizedPL = sig.PercentPnl?.ToStdString(2),
                    UnrealizedPL = "0",
                    UnrealizedPLPortfolio = "0",
                    Weight = (sig.Weight * 100).ToStdString(2)
                });
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New replace signal failed", Signal = signal, Error = ex.Message });
                return Error(ex);
            }
        }

        [HttpPost("external")]
        public async Task<ActionResult<RequestResult<object>>> External(MarketSignalExt signal)
        {
            try
            {
                var (apiKey, managerId) = await dataAccessLayer.GetStrategyApiKey(signal.StrategyId);

                if (apiKey == null)
                    return StatusError(HttpStatusCode.BadRequest, $"На стратегии {signal.StrategyId} запрещён приём внешних сигналов");

                if (signal.ApiKey != apiKey) return StatusError(HttpStatusCode.Unauthorized, "Ошибка авторизации");

                signal.ManagerId = managerId.Value;


                var key = $"{signal.Symbol} {signal.ClassCode} {signal.Board}";


                Signal sig;
                try
                {
                    sig = await _lcsApi.NewSignal(signal);
                }
                catch (Exception e)
                {
                    throw new UserVisibleException(e.Message);
                }
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New external signal placed", Signal = signal.HideSensitiveClone() });

                await _securityCache.AddSecurities(new[] { key });

                return Success(JsonConvert.DeserializeObject(sig.State));
            }
            catch (Exception e)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New external signal failed", Signal = signal.HideSensitiveClone(), Error = e.Message });
                return StatusError(HttpStatusCode.BadRequest, e);
            }
        }

        [HttpPost("externaldelayed")]
        public async Task<ActionResult<RequestResult<DelayedSignal>>> ExternalDelayed(DelayedSignalExt signal)
        {
            try
            {
                var (apiKey, managerId) = await dataAccessLayer.GetStrategyApiKey(signal.StrategyId);

                if (apiKey == null)
                    return Error($"На стратегии {signal.StrategyId} запрещён приём внешних сигналов");

                if (signal.ApiKey != apiKey)
                    return Error("Ошибка авторизации");

                /*
                if (signal.ManagerId == 0)
                    signal.ManagerId = dataAccessLayer.GetManagerId(signal.Manager);

                if (signal.ManagerId == 0)
                    return Error("Ошибка авторизации");
                    */
                signal.ManagerId = managerId.Value;

                var key = $"{signal.Symbol} {signal.ClassCode} {signal.Board}";
                var sec = _securityCache.GetSecuritiy(key);
                var sig = await _lcsApi.NewDelayedSignal(signal);
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New external delayed signal placed", Signal = signal });

                return Success(new DelayedSignal
                {
                    Symbol = signal.Symbol,
                    Id = sig.Id,
                    Comment = signal.Comment,
                    CurrentPrice = ConvertPriceToString(sec?.LastPrice ?? 0, sec),
                    OpenPrice = ConvertPriceToString(signal.OpenQuotation, sec),
                    ExecPrice = ConvertPriceToString(signal.ExecQuotation, sec),
                    Direction = signal.ExecQuotation > signal.OpenQuotation ? 1 : -1,
                    StopLoss = ConvertPriceToString(signal.StopLoss, sec),
                    TakeProfit = ConvertPriceToString(signal.TakeProfit, sec),
                    FillingTime = sig.OpenTime,
                    Name = sec?.Name,
                    Weight = signal.Weight.ToStdString(2),
                    Type = (DelayedSignalType) (int) signal.Type
                });
            }
            catch (Exception e)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "Failed to place external delayed signal", Signal = signal, Error = e.Message });
                return Error(e);
            }
        }

        // POST: api/signal/close
        [Authorize(Roles = "Administrator,Manager")]
        [HttpPost("close")]
        public async Task<ActionResult<RequestResult>> CloseSignal(ClosingSignal signal)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(signal.StrategyId);

                if (strategy.ParentStrategy != null)
                    throw new UserVisibleException(
                        $"Сделки в данной стратегии дублируют сделки из стратегии {(await GetStrategy(strategy.ParentStrategy.Value)).Name}");

                var t = _signalsTimer.IsReady(signal.StrategyId);
                if (t != null)
                    throw new UserVisibleException($"Подача сигнала возможна через {t}");

                signal.ManagerId = (int)UserManager.GetUserId(User);

                Logger.LogTrace($"{signal.StrategyId} : {signal.SecurityKey}");

                await _lcsApi.CloseSignal(signal);
                _signalsTimer.SetTimer(signal.StrategyId);
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "Signal closed", CloseSignal = signal });

                return Success();
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "Failed to close signal", CloseSignal = signal, Error = ex.Message });
                return Error(ex);
            }
        }

        [HttpGet("canregistersignal/{strategy}")]
        public ActionResult CanRegisterSignal(Guid strategy)
        {
            var t = _signalsTimer.IsReady(strategy);
            return Success(new
            {
                CanRegister = t == null,
                SecondsLeft = t != null ? (int?)(Math.Ceiling(t.Value!.TotalSeconds) + 1) : null
            });
        }

        // POST: api/signal/delayed
        [Authorize(Roles = "Administrator,Manager")]
        [HttpPost("delayed")]
        public async Task<ActionResult<RequestResult<DelayedSignal>>> DelayedSignal(ExchangeHelpers.LCS.DelayedSignal signal)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(signal.StrategyId);
                /*
                using (var db = new Api.Models.Database())
                {
                    var astr = await db.Strategies.FirstOrDefaultAsync(s => s.Id == strategy.Id);
                    if (!(astr?.TestMode ?? false) && signal.Type == LCS.Models.DelayedSignalType.Activate)
                        throw new UserVisibleException($"Активируемые отложенные сигналы доступны только в тестовом режиме");
                }
                */

                if (strategy.ParentStrategy != null)
                    throw new UserVisibleException(
                        $"Сделки в данной стратегии дублируют сделки из стратегии {(await GetStrategy(strategy.ParentStrategy.Value)).Name}");

                signal.ManagerId = (int)UserManager.GetUserId(User);
                signal.Weight /= 100m;
                signal.ExecPrice = 0;
                signal.OpenPrice = 0;

                var key = $"{signal.Symbol} {signal.ClassCode} {signal.Board}";
                var sec = _securityCache.GetSecuritiy(key);
                var sig = await _lcsApi.NewDelayedSignal(signal);

                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "New delayed signal placed", Signal = signal });

                return Success(new DelayedSignal
                {
                    Symbol = signal.Symbol,
                    Id = sig.Id,
                    Comment = signal.Comment,
                    CurrentPrice = ConvertPriceToString(sig.OpenQuotation, sec),
                    OpenPrice = ConvertPriceToString(sig.OpenQuotation, sec),
                    ExecPrice = ConvertPriceToString(signal.ExecQuotation, sec),
                    Direction = signal.ExecQuotation > signal.OpenQuotation ? 1 : -1,
                    StopLoss = ConvertPriceToString(signal.StopLoss, sec),
                    TakeProfit = ConvertPriceToString(signal.TakeProfit, sec),
                    FillingTime = sig.OpenTime,
                    Name = sec.Name,
                    Weight = (signal.Weight * 100).ToStdString(2),
                    Type = (DelayedSignalType) (int) signal.Type
                });
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "Failed to place delayed signal", Signal = signal, Error = ex.Message });
                return Error(ex);
            }
        }

        // POST: api/signal/canceldelayed/{signalId}
        [Authorize(Roles = "Administrator,Manager")]
        [HttpGet("canceldelayed/{signalId}")]
        public async Task<ActionResult<RequestResult>> CancelDelayedSignal(long signalId)
        {
            try
            {
                var signal = await GetDelayedSignal(signalId);

                if (signal == null)
                    return Error("Сигнал не найден");

                var strategy = await CheckStrategyWriteRights(signal.StrategyId);

                if (strategy.ParentStrategy != null)
                    throw new UserVisibleException(
                        $"Сделки в данной стратегии дублируют сделки из стратегии {(await GetStrategy(strategy.ParentStrategy.Value)).Name}");

                await _lcsApi.CloseDelayedSignal(signal.Id);

                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "Delayed signal canceled", SignalId = signalId });

                return Success();
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.NewSignal, new { Info = "Failed to cancel delayed signal", SignalId = signalId, Error = ex.Message });
                return Error(ex);
            }
        }
    }
}