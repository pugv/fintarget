﻿using fin_expert.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NLib.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using fin_expert.Models;
using System.ComponentModel;

namespace fin_expert.Controllers.Audit
{
    [Route("api/audit/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator,Auditor")]
    public class OrdersController : WebCabinetController<OrdersController>
    {
        private IDataAccessLayer _dataAccessLayer;
        private readonly IMapper _mapper;

        public OrdersController(IServiceProvider serviceProvider, ILogger<OrdersController> logger, IDataAccessLayer dataAccessLayer, IMapper mapper)
            : base(serviceProvider, logger)
        {
            _dataAccessLayer = dataAccessLayer;
            _mapper = mapper;
        }

        // GET: api/audit/Orders[?...]
        [HttpGet]
        public async Task<ActionResult> GetOrders(
            [FromQuery] string clientLastName = null,
            [FromQuery] string clientFirstName = null,
            [FromQuery] string clientMiddleName = null,
            [FromQuery] string agreementNumber = null,
            [FromQuery] string orderNumber = null,
            [FromQuery] long? iirNumber = null,
            [FromQuery] [TypeConverter(typeof(NLib.ParsersFormatters.StandartDateTimeConverter))] DateTime? iirStartDate = null,
            [FromQuery] [TypeConverter(typeof(NLib.ParsersFormatters.StandartDateTimeConverter))] DateTime? iirEndDate = null,
            [FromQuery] string strategyName = null,
            [FromQuery] string securityKey = null,
            [FromQuery] string format = "xls")
        {
            string symbol = null;
            string classCode = null;

            if (securityKey != null)
            {
                var items = securityKey.Split(' ');
                if (items.Length < 3)
                    return BadRequest("Некорректный формат фильтра по инструменту");
                symbol = string.Join(' ', items.SkipLast(2));
                classCode = items.SkipLast(1).TakeLast(1).First();
            }

            var orders = (await _dataAccessLayer.GetOrders(
                    clientLastName,
                    clientFirstName,
                    clientMiddleName,
                    agreementNumber,
                    orderNumber,
                    iirStartDate,
                    iirEndDate,
                    iirNumber,
                    strategyName,
                    symbol,
                    classCode))
                .SelectMany(i => i.Orders.Join(i.Instruments, oo => (oo.SignalId, oo.Security), ii => (ii.SignalId, $"{ii.Symbol} {ii.ClassCode} QUIK"),
                    (oo, ii) => _mapper.Map(i, _mapper.Map(ii, _mapper.Map<Order>(oo)))))
                .OrderByDescending(o => o.OrderId).ToArray();

            if (format == "xls")
            {
                var content = SimpleExcelTable<Order>
                    .Create(orders)
                    .SetSheetName("Список исходящих поручений")
                    .GetBytes();

                return File(content, MimeTypes.Xlsx, $"Orders_{DateTime.Now:yyyy-MM-dd-HH-mm-ss}.xlsx");
            }
            else
                return Ok(orders);
        }
    }
}