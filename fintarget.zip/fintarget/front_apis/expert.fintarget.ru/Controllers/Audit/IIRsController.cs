﻿using AutoMapper;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NLib.Excel;
using ServiceBase;
using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace fin_expert.Controllers.Audit
{
    [Route("api/audit/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator,Auditor")]
    public class IIRsController
        : WebCabinetController<IIRsController>
    {
        private readonly IDataAccessLayer _dataAccessLayer;
        private readonly IMapper _mapper;

        public IIRsController(IServiceProvider serviceProvider, ILogger<IIRsController> logger, IDataAccessLayer dataAccessLayer, IMapper mapper)
            : base(serviceProvider, logger)
        {
            _dataAccessLayer = dataAccessLayer;
            _mapper = mapper;
        }

        // GET: api/audit/IIR[?...]
        [HttpGet]
        public async Task<ActionResult> GetIIRs(
            [FromQuery] string clientLastName = null,
            [FromQuery] string clientFirstName = null,
            [FromQuery] string clientMiddleName = null,
            [FromQuery] string agreementNumber = null,
            [FromQuery] [TypeConverter(typeof(NLib.ParsersFormatters.StandartDateTimeConverter))] DateTime? iirStartDate = null,
            [FromQuery] [TypeConverter(typeof(NLib.ParsersFormatters.StandartDateTimeConverter))] DateTime? iirEndDate = null,
            [FromQuery] long? iirNumber = null,
            [FromQuery] string strategyName = null,
            [FromQuery] string securityKey = null,
            [FromQuery] string format="xls")
        {
            string symbol = null;
            string classCode = null;

            if (securityKey != null)
            {
                var items = securityKey.Split(' ');
                if (items.Length < 3)
                    return BadRequest("Некорректный формат фильтра по инструменту");
                symbol = string.Join(' ', items.SkipLast(2));
                classCode = items.SkipLast(1).TakeLast(1).First();
            }

            var iirs = (await _dataAccessLayer.GetIIRs(
                clientLastName,
                clientFirstName,
                clientMiddleName,
                agreementNumber,
                iirStartDate,
                iirEndDate,
                iirNumber,
                strategyName,
                symbol,
                classCode))
                .Select(iir => _mapper.Map<Expert.Models.IIR,IIR>(iir));

            if (format == "xls")
            {

                var content = SimpleExcelTable<IIR>
                    .Create(iirs)
                    .SetSheetName("Список ИИР")
                    .GetBytes();

                return File(content, MimeTypes.Xlsx, $"IIRS_{DateTime.Now:yyyy-MM-dd-HH-mm-ss}.xlsx");
            }

            return Ok(iirs);
        }
    }
}
