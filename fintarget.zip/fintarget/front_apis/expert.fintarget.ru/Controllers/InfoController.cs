﻿using System;
using System.Linq;
using fin_expert.Models;
using LinqToDB.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceBase;

namespace fin_expert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class infoController
        : WebCabinetController<infoController>
    {
        public infoController(IServiceProvider serviceProvider, ILogger<infoController> logger)
            : base(serviceProvider, logger)
        {
        }

        // GET: api/info
        [HttpGet]
        public ActionResult<RequestResult<Info>> Get()
        {
            Logger.LogInformation("GetInfo called");

            try
            {
                return Success(new Info
                {
                    Version = Config.BuildVersion,
                    BuildDate = Config.BuildDate,
                    RcKey = Config.RecaptchaClientKey,
                    FriendlyUrl = Config.FintargetHostAddress
                });
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: api/info/services
        [HttpGet("services")]
        public ActionResult<RequestResult<ServiceInfo>> GetServices()
        {
            Logger.LogInformation("GetServicesInfo called");

            try
            {
                return Success(new ServiceInfo
                {
                    IsEsDb = !string.IsNullOrEmpty(DataConnection.GetConnectionString(ES.Models.Database.ConfigurationName)),
                    IsEsAvailable = false
                });
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        public class ServiceInfo
        {
            public bool IsEsDb { get; set; }
            public bool IsEsAvailable { get; set; }
        }
    }
}