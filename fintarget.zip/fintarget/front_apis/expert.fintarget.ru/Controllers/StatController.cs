﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using fin_expert.Models;
using LinqToDB;
using LinqToDB.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MS.Models;
using ServiceBase;
using Database = MS.Models.Database;

namespace fin_expert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
    public class StatController
        : WebCabinetController<StatController>
    {
        private static readonly RegistryItem[] services =
        {
            new RegistryItem { Id = 1, Name = "АС" },
            new RegistryItem { Id = 2, Name = "АК" }
        };

        public StatController(IServiceProvider serviceProvider, ILogger<StatController> logger)
            : base(serviceProvider, logger)
        {
        }

        // POST: api/stat/errors
        [HttpPost("errors")]
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        public async Task<ActionResult<RequestResult<ErrorsStatPage>>> ErrorsStat(ErrorsStatFilter filter)
        {
            try
            {
                DateTime startDate, endDate;
                switch (filter.ErrorsStatMode)
                {
                    case ErrorsStatMode.ByWeeks:
                        var diff1 = (7 + (filter.From.DayOfWeek - DayOfWeek.Monday)) % 7;
                        startDate = filter.From.Date.AddDays(-diff1);
                        var diff2 = (7 + (filter.To.DayOfWeek - DayOfWeek.Monday)) % 7;
                        endDate = filter.To.Date.AddDays(-diff2 + 7);
                        break;
                    case ErrorsStatMode.ByMonths:
                        startDate = new DateTime(filter.From.Year, filter.From.Month, 1);
                        endDate = new DateTime(filter.To.Year, filter.To.Month, 1).AddMonths(1);
                        break;
                    default:
                        throw new Exception($"Unknown ErrorsStatMode {filter.ErrorsStatMode}");
                }

                DataRow[] rows;
                using (var db = new Database())
                {
                    var data = db.Messages
                        .LoadWith(c => c.ErrorCodeInfo)
                        .LoadWith(c => c.SourceInfo)
                        .Where(c => c.DateTime >= startDate && c.DateTime < endDate && c.SourceInfo.SourceId != null /*&& c.IsSentToRc*/);
                    if (filter.StrategyId != null) data = data.Where(c => c.StrategyId == filter.StrategyId);
                    var datesIdx = new Dictionary<DateTime, int>();
                    switch (filter.ErrorsStatMode)
                    {
                        case ErrorsStatMode.ByWeeks:
                            rows = await data.GroupBy(c => new
                                {
                                    c.SourceInfo,
                                    c.ErrorCodeInfo,
                                    Date = Sql.DateAdd(Sql.DateParts.Day, Sql.DateDiff(Sql.DateParts.Day, new DateTime(1900, 1, 1), c.DateTime) / 7 * 7,
                                        new DateTime(1900, 1, 1))
                                })
                                .OrderBy(c => c.Key.SourceInfo.Name).ThenBy(c => c.Key.ErrorCodeInfo.OrderNum)
                                .Select(c => new DataRow { Source = c.Key.SourceInfo, ErrorCode = c.Key.ErrorCodeInfo, Date = c.Key.Date, Count = c.Count() })
                                .ToArrayAsync();
                            datesIdx = Enumerable.Range(0, (int)(endDate - startDate).TotalDays / 7).ToDictionary(c => startDate.AddDays(c * 7), c => c);
                            break;
                        case ErrorsStatMode.ByMonths:
                            rows = await data.GroupBy(c => new
                                {
                                    c.SourceInfo,
                                    c.ErrorCodeInfo,
                                    Date = new DateTime(c.DateTime.Year, c.DateTime.Month, 1)
                                })
                                .OrderBy(c => c.Key.SourceInfo.Name).ThenBy(c => c.Key.ErrorCodeInfo.OrderNum)
                                .Select(c => new DataRow { Source = c.Key.SourceInfo, ErrorCode = c.Key.ErrorCodeInfo, Date = c.Key.Date, Count = c.Count() })
                                .ToArrayAsync();
                            datesIdx = Enumerable.Range(0, (endDate.Year - startDate.Year) * 12 + endDate.Month - startDate.Month)
                                .ToDictionary(c => new DateTime(startDate.Year, startDate.Month, 1).AddMonths(c), c => c);
                            break;
                        default:
                            throw new Exception($"Unknown ErrorsStatMode {filter.ErrorsStatMode}");
                    }

                    var ret = new ErrorsStatPage();
                    ret.Dates = datesIdx.Keys.ToArray();
                    foreach (var row in rows)
                    {
                        ErrorStatsRow pageRow;
                        if (ret.ErrorStatsRows.Count == 0
                            || ret.ErrorStatsRows.Last().Source != row.Source.Name
                            || ret.ErrorStatsRows.Last().Error != (row.ErrorCode?.Description ?? "Прочее"))
                            ret.ErrorStatsRows.Add(new ErrorStatsRow
                                { Error = row.ErrorCode?.Description ?? "Прочее", Source = row.Source.Name, Occurrences = new int[datesIdx.Count] });
                        pageRow = ret.ErrorStatsRows.Last();
                        pageRow.Occurrences[datesIdx[row.Date.Value]] = row.Count;
                    }

                    return Success(ret);
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // POST: api/stat/errorsByStrategy
        [HttpPost("errorsByStrategy")]
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        public async Task<ActionResult<RequestResult<StrategyErrorsStatPage>>> ErrorsByStrategyStat(StrategyErrorsStatFilter filter)
        {
            try
            {
                DateTime startDate, endDate;
                switch (filter.ErrorsStatMode)
                {
                    case ErrorsStatMode.ByWeeks:
                        var diff1 = (7 + (filter.From.DayOfWeek - DayOfWeek.Monday)) % 7;
                        startDate = filter.From.Date.AddDays(-diff1);
                        var diff2 = (7 + (filter.To.DayOfWeek - DayOfWeek.Monday)) % 7;
                        endDate = filter.To.Date.AddDays(-diff2 + 7);
                        break;
                    case ErrorsStatMode.ByMonths:
                        startDate = new DateTime(filter.From.Year, filter.From.Month, 1);
                        endDate = new DateTime(filter.To.Year, filter.To.Month, 1).AddMonths(1);
                        break;
                    default:
                        throw new Exception($"Unknown ErrorsStatMode {filter.ErrorsStatMode}");
                }

                StrategyDataRow[] rows;
                using (var db = new Database())
                using (var apiDb = new Api.Models.Database())
                {
                    var activeStrategies = await apiDb.Strategies.Where(c => c.Open && !c.TestMode).Select(c => new { c.Id, c.Name })
                        .ToDictionaryAsync(c => c.Id, c => c.Name);
                    var data = db.Messages
                        .LoadWith(c => c.ErrorCodeInfo)
                        .LoadWith(c => c.SourceInfo)
                        .Where(c => c.DateTime >= startDate && c.DateTime < endDate && c.SourceInfo.SourceId != null && c.IsSentToRc &&
                                    activeStrategies.Keys.Contains(c.StrategyId.Value));
                    var datesIdx = new Dictionary<DateTime, int>();
                    switch (filter.ErrorsStatMode)
                    {
                        case ErrorsStatMode.ByWeeks:
                            rows = await data.GroupBy(c => new
                                {
                                    c.StrategyId,
                                    c.SourceInfo,
                                    c.ErrorCodeInfo,
                                    Date = Sql.DateAdd(Sql.DateParts.Day, Sql.DateDiff(Sql.DateParts.Day, new DateTime(1900, 1, 1), c.DateTime) / 7 * 7,
                                        new DateTime(1900, 1, 1))
                                })
                                .OrderBy(c => c.Key.StrategyId).ThenBy(c => c.Key.SourceInfo.Name).ThenBy(c => c.Key.ErrorCodeInfo.OrderNum)
                                .Select(c => new StrategyDataRow
                                {
                                    StrategyId = c.Key.StrategyId.Value, Source = c.Key.SourceInfo, ErrorCode = c.Key.ErrorCodeInfo, Date = c.Key.Date,
                                    Count = c.Count()
                                }).ToArrayAsync();
                            datesIdx = Enumerable.Range(0, (int)(endDate - startDate).TotalDays / 7).ToDictionary(c => startDate.AddDays(c * 7), c => c);
                            break;
                        case ErrorsStatMode.ByMonths:
                            rows = await data.GroupBy(c => new
                                {
                                    c.StrategyId,
                                    c.SourceInfo,
                                    c.ErrorCodeInfo,
                                    Date = new DateTime(c.DateTime.Year, c.DateTime.Month, 1)
                                })
                                .OrderBy(c => c.Key.StrategyId).ThenBy(c => c.Key.SourceInfo.Name).ThenBy(c => c.Key.ErrorCodeInfo.OrderNum)
                                .Select(c => new StrategyDataRow
                                {
                                    StrategyId = c.Key.StrategyId.Value, Source = c.Key.SourceInfo, ErrorCode = c.Key.ErrorCodeInfo, Date = c.Key.Date,
                                    Count = c.Count()
                                }).ToArrayAsync();
                            datesIdx = Enumerable.Range(0, (endDate.Year - startDate.Year) * 12 + endDate.Month - startDate.Month)
                                .ToDictionary(c => new DateTime(startDate.Year, startDate.Month, 1).AddMonths(c), c => c);
                            break;
                        default:
                            throw new Exception($"Unknown ErrorsStatMode {filter.ErrorsStatMode}");
                    }

                    var ret = new StrategyErrorsStatPage();
                    ret.Dates = datesIdx.Keys.ToArray();
                    foreach (var row in rows)
                    {
                        StrategyErrorStatsRow pageRow;
                        if (ret.ErrorStatsRows.Count == 0
                            || ret.ErrorStatsRows.Last().StrategyId != row.StrategyId
                            || ret.ErrorStatsRows.Last().Source != row.Source.Name
                            || ret.ErrorStatsRows.Last().Error != (row.ErrorCode?.Description ?? "Прочее"))
                            ret.ErrorStatsRows.Add(new StrategyErrorStatsRow
                            {
                                StrategyId = row.StrategyId, Strategy = activeStrategies[row.StrategyId], Error = row.ErrorCode?.Description ?? "Прочее",
                                Source = row.Source.Name, Occurrences = new int[datesIdx.Count]
                            });
                        pageRow = ret.ErrorStatsRows.Last();
                        pageRow.Occurrences[datesIdx[row.Date.Value]] = row.Count;
                    }

                    return Success(ret);
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // POST: api/stat/clients
        [HttpPost("clients")]
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        //[ServiceFilter(typeof(ServiceBase.LogHeadersActionFilter))]
        [ServiceFilter(typeof(ClientIpCheckActionFilter))]
        public async Task<ActionResult<RequestResult<ClientStatPage>>> ClientStat(PaginationAndSortAndFilter paginationAndSortAndFilter)
        {
            try
            {
                paginationAndSortAndFilter.PageSize = Math.Min(50, paginationAndSortAndFilter.PageSize);
                switch (paginationAndSortAndFilter.SortFieldName)
                {
                    case "portfolio":
                        paginationAndSortAndFilter.SortFieldName = "dPortfolio";
                        break;
                    case "positions":
                        paginationAndSortAndFilter.SortFieldName = "dPositions";
                        break;
                    case "free":
                        paginationAndSortAndFilter.SortFieldName = "dFree";
                        break;
                    case "deviation":
                        paginationAndSortAndFilter.SortFieldName = "dDeviation";
                        break;
                    case "mindiff":
                        paginationAndSortAndFilter.SortFieldName = "dMinDiff";
                        break;
                }

                var fn = paginationAndSortAndFilter.SortFieldName.ToLower();

                if (fn != "agreement" &&
                    fn != "dpositions" &&
                    fn != "clientcode" &&
                    fn != "binddate" &&
                    fn != "ddeviation" &&
                    fn != "dmindiff" &&
                    fn != "dfree" &&
                    fn != "name" &&
                    fn != "dportfolio" &&
                    fn != "service" &&
                    fn != "strategy" &&
                    fn != "currency" &&
                    fn != "clientcode")
                    paginationAndSortAndFilter.SortFieldName = "agreement";

                if (paginationAndSortAndFilter.SortDirection == 0)
                    paginationAndSortAndFilter.SortDirection = 1;

                using (var db = new Api.Models.Database())
                {
                    var sql = @"
   select ca.Id Id,
          ca.agreement Agreement,
          coalesce(sum(p.current_price * p.quantity), 0) dPositions,
	      ca.client_code ClientCode,
	      ca.service_date BindDate,
	      coalesce(ca.diff_from_strategy,0) dDeviation,
          ca.min_diff dMinDiff,
		  coalesce(ap.free_funds, 0) dFree,
		  c.last_name + ' ' + c.first_name + ' ' + coalesce(c.middle_name, '') Name,
		  coalesce(ap.liquid_price, 0) dPortfolio,
		  case ca.status 
		      when 1 then 'АС'
			  else 'АК'
		  end Service,
		  s.name Strategy,
		  '/api/system/history/' + ca.client_code HistoryUrl,
		  s.currency_id Currency
     from client_accounts ca WITH (NOLOCK)
full join account_positions p on p.account_id = ca.id
full join account_portfolio ap on ap.account_id = ca.id
     join strategies s on s.id = ca.strategy_id
	 join clients c on c.id = ca.client_id
    where ca.strategy_id is not null
      and ca.status is not null
      and ca.status <> 0
	  and ap.currency = s.currency_id";

                    foreach (var filter in paginationAndSortAndFilter.Filters)
                        switch (filter.FieldName.ToLower())
                        {
                            case "strategy":
                                sql += $" and s.name in ('{string.Join("','", filter.Matches)}') ";
                                break;
                            case "service":
                                sql += $" and ca.status in ({string.Join(",", filter.Matches)}) ";
                                break;
                            case "agreement":
                                sql += $" and upper(ca.agreement) like '%{filter.Matches[0].ToString().ToUpper()}%' ";
                                break;
                        }

                    sql += @$" group by ca.id,
          ca.agreement,
          ca.client_code,
		  ca.service_date,
		  ca.diff_from_strategy,
          ca.min_diff,
		  ap.free_funds,
		  c.last_name,
		  c.first_name,
		  c.middle_name,
		  ap.liquid_price,
		  ca.status,
		  s.name,
		  s.currency_id
 order by {paginationAndSortAndFilter.SortFieldName} {(paginationAndSortAndFilter.SortDirection > 0 ? "asc" : "desc")}
   offset {paginationAndSortAndFilter.PageSize * paginationAndSortAndFilter.PageNumber} rows
    fetch 
	 next {paginationAndSortAndFilter.PageSize} rows only";

                    var query = await db.QueryToArrayAsync<ClientStat>(sql);

                    var countSql = @"
   select count(*) from 
(select ca.agreement Agreement,
	      ca.client_code ClientCode,
		  c.last_name + ' ' + c.first_name + ' ' + coalesce(c.middle_name, '') Name,
		  case ca.status 
		      when 1 then 'АС'
			  else 'АК'
		  end Service,
		  s.name Strategy
     from client_accounts ca WITH (NOLOCK)
     join strategies s on s.id = ca.strategy_id
	 join clients c on c.id = ca.client_id
    where ca.strategy_id is not null
      and ca.status is not null
      and ca.status <> 0";

                    foreach (var filter in paginationAndSortAndFilter.Filters)
                        switch (filter.FieldName.ToLower())
                        {
                            case "strategy":
                                countSql += $" and s.name in ('{string.Join("','", filter.Matches)}') ";
                                break;
                            case "service":
                                countSql += $" and ca.status in ({string.Join(",", filter.Matches)}) ";
                                break;
                            case "name":
                                countSql +=
                                    $" and upper(c.last_name + ' ' + c.first_name + ' ' + coalesce(c.middle_name, '')) like '%{filter.Matches[0].ToString().ToUpper()}%' ";
                                break;
                            case "agreement":
                                countSql += $" and upper(ca.agreement) like '%{filter.Matches[0].ToString().ToUpper()}%' ";
                                break;
                        }

                    countSql += ") _";

                    var total = (await db.QueryToArrayAsync<int>(countSql)).FirstOrDefault();

                    return Success(new ClientStatPage
                    {
                        Total = total,
                        PageStats = RoundAndFormatClientStat(query)
                    });
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private ClientStat[] RoundAndFormatClientStat(ClientStat[] stats)
        {
            foreach (var stat in stats)
            {
                stat.Deviation = FormatDecimal(stat.dDeviation * 100);
                stat.MinDiff = FormatDecimal(stat.dMinDiff * 100);
                stat.Portfolio = $"{FormatDecimal(stat.dPortfolio)} {(stat.dPortfolio != 0 ? GetCurrencySymbol(stat.Currency) : string.Empty)}";
                stat.Free = $"{FormatDecimal(stat.dFree)} {(stat.dFree != 0 ? GetCurrencySymbol(stat.Currency) : string.Empty)}";
                stat.Positions = $"{FormatDecimal(stat.dPositions)} {(stat.dPositions != 0 ? GetCurrencySymbol(stat.Currency) : string.Empty)}";
            }

            return stats;
        }

        private object GetCurrencySymbol(string currency)
        {
            return currency switch
            {
                "USD" => "&dollar;",
                "HKD" => "HK&dollar;",
                "EUR" => "&euro;",
                _ => "&#8381;"
            };
        }

        // POST: api/stat/strategies
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpPost("strategies")]
        public async Task<ActionResult<RequestResult<Dictionary<ProductType, ProductStatPage>>>> StrategyStat(PaginationAndSortAndFilter request)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var autofollowProducts =
                        db.Strategies
                            .Where(s => s.Autofollow && !s.IsPortfolio && !s.IsInvestbox)
                            .Select(s => new ProductStat
                            {
                                iProductType = ProductType.StrategyAutoFollow,
                                Author = db.Users.FirstOrDefault(u => u.Id == s.ManagerId).FullName ?? string.Empty,
                                Name = s.Name,
                                iClientCount = s.AfClientCount,
                                dValueSUR = s.AfValueSUR,
                                dValueUSD = s.AfValueUSD
                            });
                    var autoconsultProducts =
                        db.Strategies
                            .Where(s => s.Autoconsult && !s.IsPortfolio && !s.IsInvestbox)
                            .Select(s => new ProductStat
                            {
                                iProductType = ProductType.StrategyAutoConsult,
                                Author = db.Users.FirstOrDefault(u => u.Id == s.ManagerId).FullName ?? string.Empty,
                                Name = s.Name,
                                iClientCount = s.AcClientCount,
                                dValueSUR = s.AcValueSUR,
                                dValueUSD = s.AcValueUSD
                            });
                    var moneyboxProducts =
                        db.Strategies
                            .Where(s => !s.IsPortfolio && s.IsInvestbox)
                            .Select(s => new ProductStat
                            {
                                iProductType = ProductType.Moneybox,
                                Author = db.Users.FirstOrDefault(u => u.Id == s.ManagerId).FullName ?? string.Empty,
                                Name = s.Name,
                                iClientCount = s.AfClientCount,
                                dValueSUR = s.AfValueSUR,
                                dValueUSD = s.AfValueUSD
                            });

                    var query =
                        autofollowProducts
                        .Union(autoconsultProducts)
                        .Union(moneyboxProducts);

                    query = OrderAndFilterStratStatQuery(query, request);

                    var mat = await query.ToArrayAsync();

                    var total = mat.Length;

                    var totalClients = mat.Sum(s => s.iClientCount ?? 0);
                    var totalSUR = mat.Sum(s => s.dValueSUR ?? 0);
                    var totalUSD = mat.Sum(s => s.dValueUSD ?? 0);

                    mat = mat
                        .Skip(request.PageSize * request.PageNumber)
                        .Take(request.PageSize)
                        .ToArray();

                    return Success(new ProductStatPage
                    {
                        Total = total,
                        PageStats = ConvertStratStats(mat),

                        TotalClients = FormatInt(totalClients),
                        TotalSUR = FormatDecimal(totalSUR),
                        TotalUSD = FormatDecimal(totalUSD),
                    });
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: api/stat/registry/authors
        [HttpGet("registry/authors")]
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        public async Task<ActionResult<RequestResult<RegistryItem[]>>> UniqueAuthors()
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var query =
                        db.Strategies
                            .Select(s => db.Users.FirstOrDefault(u => u.Id == s.ManagerId).FullName).Distinct()
                            .Select(s => new RegistryItem
                            {
                                Id = s,
                                Name = s
                            });

                    return Success(await query.ToArrayAsync());
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: api/stat/registry/strategies
        [HttpGet("registry/strategies")]
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        public async Task<ActionResult<RequestResult<RegistryItem[]>>> UniqueStrategies()
        {
            try
            {
                using (var db = new Api.Models.Database())
                {
                    var query =
                        db.Strategies
                            .Select(s => new RegistryItem { Id = s.Name, Name = s.Name });

                    return Success(await query.ToArrayAsync());
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: api/stat/registry/services
        [HttpGet("registry/services")]
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        public ActionResult<RequestResult<RegistryItem[]>> UniqueServices()
        {
            try
            {
                return Success(services);
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private ProductStat[] ConvertStratStats(ProductStat[] stats)
        {
            foreach (var stat in stats)
            {
                stat.ProductType = GetProductType(stat.iProductType);
                stat.ClientCount = FormatInt(stat.iClientCount ?? 0);
                stat.ValueSUR = FormatDecimal(stat.dValueSUR ?? 0);
                stat.ValueUSD = FormatDecimal(stat.dValueUSD ?? 0);
            }

            return stats;
        }

        private static string GetProductType(ProductType productType)
        {
            switch (productType)
            {
                case ProductType.Moneybox:
                    return "Накопилка";
                case ProductType.StrategyAutoConsult:
                    return "Стратегия АК";
                case ProductType.StrategyAutoFollow:
                    return "Стратегия АС";
                default:
                    return string.Empty;
            }
        }

        private static IQueryable<ClientStat> OrderAndFilterStatQuery(IQueryable<ClientStat> query, PaginationAndSortAndFilter paginationAndSortAndFilter)
        {
            var result = query;

            foreach (var filter in paginationAndSortAndFilter.Filters)
                switch (filter.FieldName.ToLower())
                {
                    case "strategy":
                        if (filter.FilterCriteria == PaginationAndSortAndFilter.Filter.Criteria.Equals)
                            if (filter.Matches != null)
                                result = result.Where(c => filter.Matches.Contains(c.Strategy));
                        break;
                    case "service":
                        if (filter.FilterCriteria == PaginationAndSortAndFilter.Filter.Criteria.Equals)
                            if (filter.Matches != null)
                                result = result.Where(c => filter.Matches.Contains(c.Service));
                        break;

                    case "agreement":
                        if (filter.FilterCriteria == PaginationAndSortAndFilter.Filter.Criteria.Equals)
                        {
                            if (filter.Matches != null)
                                result = result.Where(c => filter.Matches.Contains(c.Agreement));
                        }
                        else if (filter.Matches != null && filter.Matches.Length > 0)
                        {
                            result = result.Where(c => c.Agreement.Contains(filter.Matches[0] as string));
                        }

                        break;
                }

            return OrderStatQuery(result, paginationAndSortAndFilter);
        }

        private static IQueryable<ClientStat> OrderStatQuery(IQueryable<ClientStat> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName.ToLower())
            {
                case "agreement":
                    return OrderQueryBy(query, s => s.Agreement, paginationAndSort.SortDirection);
                case "binddate":
                    return OrderQueryBy(query, s => s.BindDate, paginationAndSort.SortDirection);
                case "deviation":
                    return OrderQueryBy(query, s => s.Deviation, paginationAndSort.SortDirection);
                case "free":
                    return OrderQueryBy(query, s => s.Free, paginationAndSort.SortDirection);
                case "portfolio":
                    return OrderQueryBy(query, s => s.Portfolio, paginationAndSort.SortDirection);
                case "positions":
                    return OrderQueryBy(query, s => s.Positions, paginationAndSort.SortDirection);
                case "service":
                    return OrderQueryBy(query, s => s.Service, paginationAndSort.SortDirection);
                case "strategy":
                    return OrderQueryBy(query, s => s.Strategy, paginationAndSort.SortDirection);
                default:
                    return query;
            }
        }

        private static IQueryable<ProductStat> OrderAndFilterStratStatQuery(IQueryable<ProductStat> query,
            PaginationAndSortAndFilter paginationAndSortAndFilter)
        {
            var filtered = query;

            if (paginationAndSortAndFilter.SortFieldName != null)
                foreach (var filter in paginationAndSortAndFilter.Filters)
                    switch (filter.FieldName.ToLower())
                    {
                        case "name":
                            filtered = filtered.Where(s => filter.Matches.Contains(s.Name));
                            break;
                        case "author":
                            filtered = filtered.Where(s => filter.Matches.Select(m => m.ToString()).Contains(s.Author));
                            break;
                        case "producttype":
                            filtered = filtered.Where(s => (int)filter.Matches.FirstOrDefault() == (int) s.iProductType);
                            break;
                    }

            return OrderStratStatQuery(filtered, paginationAndSortAndFilter);
        }

        private static IQueryable<ProductStat> OrderStratStatQuery(IQueryable<ProductStat> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName.ToLower())
            {
                case "name":
                    return OrderQueryBy(query, s => s.Name, paginationAndSort.SortDirection);
                case "clientcount":
                    return OrderQueryBy(query, s => s.iClientCount ?? 0, paginationAndSort.SortDirection);
                case "valuesur":
                    return OrderQueryBy(query, s => s.dValueSUR, paginationAndSort.SortDirection);
                case "valueusd":
                    return OrderQueryBy(query, s => s.dValueUSD, paginationAndSort.SortDirection);
                case "author":
                    return OrderQueryBy(query, s => s.Author, paginationAndSort.SortDirection);
                default:
                    return query;
            }
        }

        private class DataRow
        {
            public Source Source { get; set; }
            public ErrorCode ErrorCode { get; set; }
            public int Count { get; set; }
            public DateTime? Date { get; set; }
        }

        private class StrategyDataRow
        {
            public Guid StrategyId { get; set; }
            public Source Source { get; set; }
            public ErrorCode ErrorCode { get; set; }
            public int Count { get; set; }
            public DateTime? Date { get; set; }
        }
    }
}