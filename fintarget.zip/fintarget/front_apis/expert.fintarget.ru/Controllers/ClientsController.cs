﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using CS.Kernel.DBO;
using CS.Kernel.Model;
using ExchangeHelpers;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LCS.Models;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLib.Helpers;
using NLib.ParsersFormatters;
using NLib.ParsersFormatters.DateTime;
using NLib.Caching;
using PositionCalculator;
using Database = CS.Kernel.Functionality.Database;
using Microsoft.AspNetCore.Http;
using System.IO.Compression;

namespace fin_expert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ClientsController : WebCabinetController<ClientsController>
    {
        private readonly ISecurityCache _securityCache;
        private readonly ICS _cs;
        private readonly ICache _cache;

        public ClientsController(IServiceProvider sp, ILogger<ClientsController> logger, ISecurityCache cache, ICS cs,
            ICacheService cacheService)
            : base(sp, logger)
        {
            _securityCache = cache;
            _cs = cs;
            _cache = cacheService.Cache;
        }

        [HttpPost("find")]
        public async Task<ActionResult<ClientAccountInfo[]>> Find([FromBody] string agreementOrCode)
        {
            try
            {
                var role = UserManager.GetUserRole(User);

                if (!new[] { UserRole.Administrator, UserRole.Support, UserRole.DigitalExpert, UserRole.Developer }
                        .Contains(role))
                {
                    return Error("Недостаточно прав");
                }

                using (var db = new Database())
                {
                    ClientAccount ca;

                    if (agreementOrCode.Contains('/'))
                        ca = await db.ClientAccounts.LoadWith(c => c.Client).LoadWith(c => c.Signals)
                            .LoadWith(c => c.Exams).LoadWith(c => c.SavedPortfolios)
                            .LoadWith(c => c.Checks).LoadWith(c => c.Positions)
                            .Where(c => c.Client.Agreement.Equals(agreementOrCode)).FirstOrDefaultAsync();
                    else
                        ca = await db.ClientAccounts.LoadWith(c => c.Client).LoadWith(c => c.Signals)
                            .LoadWith(c => c.Exams).LoadWith(c => c.SavedPortfolios)
                            .LoadWith(c => c.Checks).LoadWith(c => c.Positions)
                            .Where(c => c.ClientCode.Equals(agreementOrCode)).FirstOrDefaultAsync();

                    if (ca == null) return Error("Клиент не найден");

                    string cur = null;
                    if (ca.StrategyId != null)
                        cur = (await GetStrategy(ca.StrategyId.Value))?.Currency;

                    ca.Portfolios = ca.SavedPortfolios?.Where(p => p.Currency == cur).Select(p =>
                        new ClientAccount.Portfolio()
                        {
                            Currency = p.Currency,
                            FreeFunds = p.FreeFunds,
                            LiquidPrice = p.LiquidPrice,
                            PositionsCost = p.PositionsCost,
                            PortfolioPrice = p.Price
                        }).ToArray();

                    if (ca?.IsAttached == false) ca.Client = null;
                    return Success(ca != null ? new[] { new ClientAccountInfo(ca) } : new ClientAccountInfo[0]);
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [HttpGet("positions/{id}")]
        public async Task<ActionResult<ClientAccountPosition[]>> Positions(int id)
        {
            var role = UserManager.GetUserRole(User);

            if (role == UserRole.Administrator || role == UserRole.Support || role == UserRole.DigitalExpert ||
                role == UserRole.Developer)
                using (var db = new Database())
                {
                    var result =
                        (await db.ClientAccounts.LoadWith(c => c.Positions).FirstOrDefaultAsync(c => c.Id == id))
                        ?.Positions
                        .Select(p => new
                        {
                            Weight = ((p.Weight ?? 0) * 100).RoundToNot0(2),
                            LastPrice = _securityCache.GetSecuritiy(p.SecurityKey)?.LastPrice ?? 0,
                            p.Number,
                            SecurityKey = p.SecurityKey.Replace(" QUIK", ""),
                            p.AvgPrice,
                            p.Currency,
                            Name = _securityCache.GetSecuritiy(p.SecurityKey)?.Name ??
                                   _securityCache.GetSecuritiy(p.SecurityKey)?.ShortName
                        })
                        .ToArray();
                    return Success(result);
                }

            return Error("Недостаточно прав");
        }

        [HttpGet("info/{id}")]
        public async Task<ActionResult<ClientAccountInfo>> Info(int id)
        {
            var role = UserManager.GetUserRole(User);
            if (role == UserRole.Administrator || role == UserRole.Support || role == UserRole.DigitalExpert ||
                role == UserRole.Developer)
                using (var db = new Database())
                {
                    var cl = await db.ClientAccounts.LoadWith(c => c.Client).LoadWith(c => c.Signals)
                        .LoadWith(c => c.Exams).LoadWith(c => c.SavedPortfolios)
                        .LoadWith(c => c.Checks).LoadWith(c => c.Positions).FirstOrDefaultAsync(c => c.Id == id);
                    if (cl == null) return Error("Not found");
                    string cur = null;
                    if (cl.StrategyId != null)
                        cur = (await GetStrategy(cl.StrategyId.Value))?.Currency;
                    cl.Portfolios = cl.SavedPortfolios?.Where(p => p.Currency == cur).Select(p =>
                        new ClientAccount.Portfolio()
                        {
                            Currency = p.Currency,
                            FreeFunds = p.FreeFunds,
                            LiquidPrice = p.LiquidPrice,
                            PositionsCost = p.PositionsCost,
                            PortfolioPrice = p.Price
                        }).ToArray();
                    if (cl.StrategyId == null) cl.Client = new ClientInfo { Agreement = cl.Client.Agreement };

                    return Success(new ClientAccountInfo(cl));
                }

            return Error("Недостаточно прав");
        }

        [HttpGet("signals/{id}")]
        public async Task<ActionResult<ClientSignal[]>> Signals(int id)
        {
            var role = UserManager.GetUserRole(User);

            if (role == UserRole.Administrator || role == UserRole.Support || role == UserRole.DigitalExpert ||
                role == UserRole.Developer)
                using (var db = new Database())
                {
                    return Success(await db
                        .ClientSignals
                        .LoadWith(s => s.StrategySignal)
                        .Where(s => s.ClientId == id)
                        .OrderByDescending(s => s.DateTime)
                        .ToArrayAsync());
                }

            return Error("Недостаточно прав");
        }

        [HttpGet("follow/{id}")]
        public async Task<ActionResult<FollowHistoryObject[]>> Follow(int id)
        {
            var role = UserManager.GetUserRole(User);

            if (!new[] { UserRole.Administrator, UserRole.Support, UserRole.DigitalExpert, UserRole.Developer }
                    .Contains(role))
            {
                return Error("Недостаточно прав");
            }

            using (var db = new Database())
            using (var lcs = new LCS.Models.Database())
            {
                var client = await db.ClientAccounts.LoadWith(c => c.Client).FirstOrDefaultAsync(ca => ca.Id == id);

                if (client == null) return Error("Клиент не найден");

                // var cahs = db.ClientAccountHistory.Where(h => h.ClientId == client.Id).ToArray();
                var css = await db.ClientSignals
                    .LoadWith(cs => cs.StrategySignal)
                    .LoadWith(cs => cs.Messages)
                    .Where(s => s.ClientId == client.Id && s.DateTime >= client.Client.ServiceDate &&
                                s.Type != ClientSignal.TypeEnum.VarMargin &&
                                s.StrategySignal.Dividend != DividentType.VarMargin
                                && s.Execution != null && s.Execution != "{}")
                    .ToArrayAsync();

                //var phs = db.PortfolioHistories.Where(p => p.ClientId == client.Id).OrderBy(p=>p.ToArray();
                var lcsSigs = lcs.Signals
                    .Where(s => s.StrategyId == client.StrategyId && s.SecurityKey != null &&
                                (s.Type == SignalTypeEnum.Standard || s.Type == SignalTypeEnum.Close ||
                                 s.Type == SignalTypeEnum.Coupon ||
                                 s.Type == SignalTypeEnum.Dividend) && s.OpenTime >= client.Client.ServiceDate)
                    .OrderBy(s => s.Id)
                    .ToArray();

                decimal stratPL = 1;
                var clPL = 1 - (client.InitialValue != 0 ? client.InitialUpl / client.InitialValue : 0);

                return Success(lcsSigs.Select(sig =>
                    {
                        var stat = STS.Kernel.StsService.GetByClientExecInfos(new STS.Kernel.Objects.Signal()
                            {
                                Id = sig.Id,
                                Security = new PositionCalculator.Security(sig.SecurityKey),
                                Weight = sig.Weight,
                                OpenPrice = sig.OpenPrice,
                                OpenTime = sig.OpenTime,
                                OpenQuotation = sig.OpenQuotation
                            }, lcsSigs.FirstOrDefault(s => s.Id > sig.Id && s.SecurityKey == sig.SecurityKey)?.Id,
                            css);

                        stratPL *= 1 + sig.RealizedPnl ?? 0;

                        if (stat.Length != 1)
                        {
                            return new FollowHistoryObject
                            {
                                LCSSignal = sig,
                                SummStratPL = stratPL - 1,
                                SummClientPL = clPL - 1
                            };
                        }

                        clPL *= 1 + stat[0].ExecPL;

                        return new FollowHistoryObject
                        {
                            LCSSignal = sig,
                            Signal = new ClientSignal() { RealizedPnL = stat[0].ExecPL },
                            Position = new TradeSignal.TradeSignalPosition()
                            {
                                ExecNumber = stat[0].ExecNumber,
                                ExecValue = stat[0].ExecPrice * stat[0].ExecNumber,
                                ExecEndTime = stat[0].ExecTime
                            },
                            SummStratPL = stratPL - 1,
                            SummClientPL = clPL - 1
                        };
                    }
                ).ToArray());
            }
        }

        [HttpGet("strategyfollow/{strategyId}")]
        public async Task<ActionResult> StrategyFollow(Guid strategyId)
        {
            var role = UserManager.GetUserRole(User);

            if (role == UserRole.Administrator || role == UserRole.RiskManager || role == UserRole.Developer)
                return Success(await FormStrategyFollow(strategyId));
            return Error("Недостаточно прав");
        }

        // GET: api/clients/registry/problems
        [HttpGet("registry/problems")]
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        public async Task<ActionResult<RegistryItem[]>> UniqueClientProblems(CancellationToken cancellationToken)
        {
            try
            {
                return Success(await _cache.GetOrAdd("client_problems", getClientProblems, TimeSpan.FromMinutes(1),
                    cancellationToken));
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private async Task<RegistryItem[]> getClientProblems(CancellationToken cancellationToken)
        {
            var id = 1;
            return (await _cs.ProblemClients()).Select(c => c.Value).Distinct().OrderBy(p => p).Select(p =>
                new RegistryItem()
                {
                    Id = id++,
                    Name = p
                }).ToArray();
        }

        [HttpPost("problem")]
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        public async Task<ActionResult<ProblemClientStatPage>> ProblemClients(
            [FromBody] PaginationAndSortAndFilter paginationAndSortAndFilter)
        {
            paginationAndSortAndFilter.PageSize = Math.Min(50, paginationAndSortAndFilter.PageSize);

            var problemClients = (await _cs.ProblemClients()).Select(c => new ProblemClient()
                { Id = c.Key, Description = c.Value });

            foreach (var filter in paginationAndSortAndFilter.Filters)
            {
                switch (filter.FieldName)
                {
                    case "id":
                        if (filter.Matches.Length > 0)
                            problemClients = problemClients.Where(c =>
                                c.Id.ToString().Contains(filter.Matches[0].ToString()));
                        break;
                    case "description":
                        if (filter.Matches.Length > 0)
                            problemClients = problemClients.Where(c =>
                                filter.Matches.Contains(c.Description));
                        break;
                }
            }

            switch (paginationAndSortAndFilter.SortFieldName)
            {
                case "id":
                    problemClients = paginationAndSortAndFilter.SortDirection < 0
                        ? problemClients.OrderBy(c => c.Id)
                        : problemClients.OrderByDescending(c => c.Id);
                    break;
                case "description":
                    problemClients = paginationAndSortAndFilter.SortDirection < 0
                        ? problemClients.OrderBy(c => c.Description)
                        : problemClients.OrderByDescending(c => c.Description);
                    break;
            }

            return Success(
                new ProblemClientStatPage()
                {
                    Total = problemClients.Count(),
                    PageStats = problemClients
                        .Skip(paginationAndSortAndFilter.PageSize * paginationAndSortAndFilter.PageNumber)
                        .Take(paginationAndSortAndFilter.PageSize)
                        .ToArray()
                });
        }

        public static async Task<StrategyHistoryObject[]> FormStrategyFollow(Guid strategyId)
        {
            using (var db = new Database())
            using (var lcs = new LCS.Models.Database())
            {
                var lcsSigs = await lcs.Signals.Where(s =>
                        s.StrategyId == strategyId && s.SecurityKey != null &&
                        (s.Type == SignalTypeEnum.Standard || s.Type == SignalTypeEnum.Close))
                    .OrderBy(s => s.Id).ToArrayAsync();


                var clsigs = await db.ClientSignals.LoadWith(c => c.StrategySignal).Where(s =>
                    s.StrategySignal != null && s.StrategySignal.StartegyId == strategyId &&
                    s.Type != ClientSignal.TypeEnum.VarMargin && s.Execution != null &&
                    s.Execution != "{}").OrderBy(s => s.Id).ToArrayAsync();
                decimal stratPL = 1;
                decimal clPL = 1;

                return lcsSigs.Select(lcsSig =>
                    {
                        var stat = STS.Kernel.StsService.GetByClientExecInfos(new STS.Kernel.Objects.Signal()
                            {
                                Id = lcsSig.Id,
                                Weight = lcsSig.Weight,
                                OpenPrice = lcsSig.OpenPrice,
                                OpenTime = lcsSig.OpenTime,
                                OpenQuotation = lcsSig.OpenQuotation,
                                Security = new PositionCalculator.Security(lcsSig.SecurityKey)
                            },
                            lcsSigs.FirstOrDefault(s => s.Id > lcsSig.Id && s.SecurityKey == lcsSig.SecurityKey)?.Id,
                            clsigs);


                        stratPL *= 1 + lcsSig.RealizedPnl ?? 0;


                        if (stat.Length > 0)
                        {
                            var execPrice = stat.Average(s => s.ExecPrice);
                            var meanWeight = stat.Average(s => s.ExecWeight);

                            if ((lcsSig.RealizedPnl ?? 0) != 0)
                            {
                                if (lcsSig.Weight != 0)
                                {
                                    var newPL = (1 - execPrice / lcsSig.OpenPrice *
                                        (1 - lcsSig.RealizedPnl!.Value / lcsSig.Weight)) * meanWeight;
                                    clPL *= 1 + newPL;
                                }
                                else
                                {
                                    clPL *= 1 + lcsSig.RealizedPnl!.Value;
                                }
                            }


                            return new StrategyHistoryObject
                            {
                                LCSSignal = lcsSig,
                                Delay = TimeSpan.FromSeconds(stat.Average(s =>
                                    (s.ExecTime - lcsSig.OpenTime).TotalSeconds)),
                                Signal = new ClientSignal { RealizedPnL = stat.Average(s => s.ExecPL) },
                                PriceStd = stat.Length > 1 ? stat.StandardDeviation(s => (double)s.ExecPrice) : 0,
                                PLStd = stat.Length > 1 ? stat.StandardDeviation(s => (double)s.ExecPL) : 0,
                                Position = new TradeSignal.TradeSignalPosition
                                {
                                    ExecPrice = execPrice, ExecValue = execPrice * stat.Length, ExecNumber = stat.Length
                                },
                                SummStratPL = stratPL - 1,
                                SummClientPL = clPL - 1
                            };
                        }
                        else
                        {
                            clPL *= 1 + (lcsSig.RealizedPnl ?? 0);

                            return new StrategyHistoryObject
                            {
                                LCSSignal = lcsSig,
                                Delay = TimeSpan.Zero,
                                Signal = new ClientSignal { RealizedPnL = 0 },
                                SummStratPL = stratPL - 1,
                                SummClientPL = clPL - 1
                            };
                        }
                    }
                ).SkipWhile(s => (s.Number ?? 0) == 0).ToArray();
            }
        }

        [HttpGet("history/{id}/{sortType?}")]
        public async Task<ActionResult> History(int id, string sortType)
        {
            try
            {
                var role = UserManager.GetUserRole(User);

                if (role == UserRole.Administrator || role == UserRole.Support || role == UserRole.DigitalExpert ||
                    role == UserRole.Developer)
                    using (var db = new Database())
                    {
                        var client = await db.ClientAccounts.FirstOrDefaultAsync(ca => ca.Id == id);

                        if (client == null) return Error("No such client!");

                        var cahs = await db.ClientAccountHistory.Where(h => h.ClientId == client.Id).ToArrayAsync();
                        var css = await db.ClientSignals.LoadWith(cs => cs.StrategySignal).LoadWith(cs => cs.Messages)
                            .Where(s => s.ClientId == client.Id)
                            .ToArrayAsync();
                        var phs = await db.PortfolioHistories.Where(p => p.ClientId == client.Id).ToArrayAsync();

                        var eq = new HistoryObject();

                        var history = cahs.Select(c => new HistoryObject(c))
                            .Union(css.SelectMany(c =>
                                (c.StrategySignal != null
                                    ? new[]
                                    {
                                        new HistoryObject(c), new HistoryObject(c.StrategySignal.ToStrategySignal())
                                    }
                                    : new[] { new HistoryObject(c) })
                                .Union(c.Messages.Select(m => new HistoryObject(m)))))
                            .Union(phs.Select(c => new HistoryObject(c)))
                            .Distinct(eq).ToArray();

                        history = history
                            .Union(history.Where(h => h.ClientSignal != null && h.ClientSignal.Execution != null)
                                .Select(h =>
                                    new HistoryObject(
                                        JsonConvert.DeserializeObject<ClientSignalExecution>(h.ClientSignal
                                            .Execution)))).ToArray();
                        //.Union(history.Where(h => h.ClientSignal != null && h.Message != null).SelectMany(h => h.ClientSignal.Messages.Select(m => new HistoryObject(m))))
                        //.Union(history.Where(h=>h.ClientSignal!=null && h.ClientSignal.StrategySignal!=null).Select(h => new HistoryObject(h.ClientSignal.StrategySignal.ToStrategySignal())))

                        return Success((sortType?.ToLower() == "d"
                                ? history.OrderByDescending(h => h.DateTime)
                                : history.OrderBy(h => h.DateTime))
                            .ToArray());
                    }

                return Error("Недостаточно прав");
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [HttpGet("signal_execution/{id}")]
        public async Task<ActionResult> SignalExecution(int id)
        {
            try
            {
                var role = UserManager.GetUserRole(User);

                if (role == UserRole.Administrator || role == UserRole.RiskManager || role == UserRole.Developer)
                    return Success(await FormStrategyExecution(id));
                return Error("Недостаточно прав");
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        public static async Task<StrategyExecutionObject[]> FormStrategyExecution(int id)
        {
            using (var db = new Database())
            {
                var stratSig = await db.StrategySignals.FirstOrDefaultAsync(s => s.InitId == id);
                if (stratSig == null) throw new NLib.AuxTypes.UserVisibleException("Сигнал не найден");
                if (stratSig.SecurityKey == null)
                    throw new NLib.AuxTypes.UserVisibleException("Не задана бумага сигнала");

                var sigId = stratSig.Id;
                var stratId = stratSig.StartegyId;
                var nextStratSigs = await db.StrategySignals.Where(s => s.StartegyId == stratId && s.Id >= stratSig.Id)
                    .OrderBy(s => s.Id)
                    .Select(s => new { s.Id, s.SecurityKey })
                    .ToArrayAsync();

                var maxId = nextStratSigs
                                .FirstOrDefault(s => s.Id > stratSig.Id && s.SecurityKey == stratSig.SecurityKey)?.Id ??
                            int.MaxValue;
                var stratSigs = nextStratSigs.TakeWhile(sig => sig.Id < maxId).Select(o => o.Id).ToArray();

                var sigs = await db.ClientSignals
                    .Where(s => s.SignalId >= sigId && s.Execution != null &&
                                s.Execution.Contains(stratSig.SecurityKey) &&
                                s.DateTime.Date == stratSig.Date.Date && stratSigs.Contains(s.SignalId))
                    .OrderBy(s => s.DateTime).ToArrayAsync();

                return sigs.Select(s => new
                    {
                        s,
                        p = JsonConvert.DeserializeObject<ClientSignalExecution>(s.Execution)?.Positions
                            ?.FirstOrDefault(p => p.Security == stratSig.SecurityKey)
                    })
                    .GroupBy(s => s.s.ClientId)
                    .Select(g =>
                        new StrategyExecutionObject
                        {
                            ClientId = g.Key,
                            StartPrice = g.First().p?.Price,
                            NTrades = g.Count(o => o.p.ExecNumber == 0 && !string.IsNullOrEmpty(o.p.ErrorDescription)) +
                                      1,
                            ExecPrice = g.FirstOrDefault(o => o.p.ExecNumber != 0)?.p?.ExecPrice,
                            Number = g.First().p?.Number ?? 0,
                            OrderTime = g.FirstOrDefault(o => o.p.ExecNumber != 0)?.p?.ExecEndTime?.ToLocalTime() -
                                        stratSig.Date,
                            SendTime = g.First().s.DateTime - stratSig.Date,
                            Trades = g /*(g.FirstOrDefault(o => o.p.ExecNumber != 0) != null
                                    ? g.TakeWhile(o => o.p.ExecNumber == 0).Append(g.FirstOrDefault(o => o.p.ExecNumber != 0))
                                    : g.TakeWhile(o => o.p.ExecNumber == 0))*/
                                .Select(o => new StrategyExecutionObject.Trade
                                {
                                    Id = o.s.Id,
                                    ExecPrice = o.p.ExecPrice,
                                    StartTime = o.s.DateTime,
                                    EndTime = o.p.ExecEndTime?.ToLocalTime() ?? o.s.DateTime,
                                    StartPrice = o.p.Price,
                                    ExecNumber = o.p.ExecNumber
                                })
                                .ToArray()
                        }).ToArray();
            }
        }

        [HttpGet("accepts/{id:int}")]
        public async Task Accepts(int id, CancellationToken token)
        {
            var role = UserManager.GetUserRole(User);

            if (!new[] { UserRole.Administrator, UserRole.Support, UserRole.DigitalExpert, UserRole.Developer }
                    .Contains(role))
            {
                Response.StatusCode = 403;
                await Response.WriteAsync("Недостаточно прав", token);
                return;
            }

            Response.ContentType = "application/zip";
            Response.Headers.Add("Content-Disposition", $"attachment; filename=Accepts-{id}.zip");

            using var archive = new ZipArchive(Response.BodyWriter.AsStream(), ZipArchiveMode.Create);
            await using var db = new Api.Models.Database();
            var accepts = db.AcceptDocuments.Where(c => c.AccountId == id).OrderBy(c => c.Id).AsAsyncEnumerable();
            await foreach (var record in accepts.WithCancellation(token))
            {
                var entry = archive.CreateEntry($"{record.Date:yyyy-MM-dd_HH-mm} {record.Type}{(!record.IsSigned ? " unsigned" : "")}.pdf");
                var document = Convert.FromBase64String(record.BodyBase64);
                await using var entryStream = entry.Open();
                await entryStream.WriteAsync(document, token);
            }
        }

        [SuppressMessage("ReSharper", "InconsistentNaming")]
        public class FollowHistoryObject
        {
            [JsonIgnore] public SignalDTO LCSSignal;

            [JsonIgnore] public TradeSignal.TradeSignalPosition Position;

            // public PortfolioHistory portfolio;
            [JsonIgnore] public ClientSignal Signal;

            public int Id => LCSSignal?.Id ?? 0;
            public DateTime? StrategyDate => LCSSignal?.OpenTime;

            public string Security => LCSSignal.Type == SignalTypeEnum.Coupon ? "Coupon" :
                LCSSignal.Type == SignalTypeEnum.Dividend ? "Dividend" : LCSSignal?.SecurityKey;

            public decimal? Weight =>
                LCSSignal.Type == SignalTypeEnum.Coupon || LCSSignal.Type == SignalTypeEnum.Dividend
                    ? null
                    : LCSSignal?.Weight;

            public decimal? Price =>
                LCSSignal.Type == SignalTypeEnum.Coupon || LCSSignal.Type == SignalTypeEnum.Dividend ? null :
                LCSSignal.OpenQuotation != 0 ? LCSSignal.OpenQuotation : LCSSignal.OpenPrice;

            private DateTime? ExecDate =>
                LCSSignal.Type == SignalTypeEnum.Coupon || LCSSignal.Type == SignalTypeEnum.Dividend
                    ? null
                    : Position?.ExecEndTime?.ToLocalTime();

            public decimal? ExecPrice =>
                LCSSignal.Type == SignalTypeEnum.Coupon || LCSSignal.Type == SignalTypeEnum.Dividend
                    ? null
                    : Position?.ExecValue / Math.Max(1, Math.Abs((decimal)(Position?.ExecNumber ?? 0)));

            public string PriceDiff => ExecPrice != null && ExecPrice != 0
                ? $"{((ExecPrice ?? 0) - (Price ?? 0)) / (ExecPrice ?? 1):P2}"
                : null;

            public TimeSpan? TimeDiff => ExecDate != null && StrategyDate != null ? ExecDate - StrategyDate : null;
            public decimal StratPL => LCSSignal?.RealizedPnl ?? 0;
            public decimal? PL => Signal?.RealizedPnL;

            public decimal SummStratPL { get; set; }
            public decimal SummClientPL { get; set; }

            public long? Number => Position?.ExecNumber;
            // public string Difference => Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(portfolio.Portfolio).DiffFromStrategy.ToString("P2");

            public long t => (LCSSignal?.OpenTime ?? default).ToJsonTime();
            public decimal v => SummStratPL * 100;
            public decimal vr => SummClientPL * 100;
        }

        [SuppressMessage("ReSharper", "UnusedMember.Local")]
        [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Local")]
        [SuppressMessage("ReSharper", "NotAccessedField.Local")]
        private class HistoryObject : IEqualityComparer<HistoryObject>
        {
            [JsonIgnore] [SuppressMessage("ReSharper", "InconsistentNaming")]
            public readonly CAHistory CAHistory;

            [JsonIgnore] public readonly ClientSignal ClientSignal;

            [JsonIgnore] public readonly MessageDBO Message;

            [JsonIgnore] public readonly ClientAccount PortfolioHistory;

            [JsonIgnore] public readonly ClientSignalExecution SignalExecution;

            public long? SignalId;

            [JsonIgnore] public readonly StrategySignal StrategySignal;

            public HistoryObject(PortfolioHistory h)
            {
                PortfolioHistory = JsonConvert.DeserializeObject<ClientAccount>(h.Portfolio);
                DateTime = h.DateTime;
            }

            public HistoryObject(CAHistory h)
            {
                CAHistory = h;
                DateTime = h.Date;
            }

            public HistoryObject(ClientSignal h)
            {
                ClientSignal = h;
                SignalId = h.Id;
                DateTime = h.DateTime;
            }

            public HistoryObject(StrategySignal h)
            {
                StrategySignal = h;
                DateTime = h.Date;
            }

            public HistoryObject(ClientSignalExecution h)
            {
                SignalExecution = h;
                SignalId = h.SignalId;
                DateTime = h.Positions?.Where(p => p.ExecEndTime.HasValue)
                    .MaxOrDefault(p => p.ExecEndTime!.Value.ToLocalTime()) ?? default(DateTime);
            }

            public HistoryObject(MessageDBO h)
            {
                Message = h;
                DateTime = h.Date;
                SignalId = h.SignalId;
            }

            public HistoryObject()
            {
            }

            public DateTime DateTime { get; }

            public string Client => CAHistory != null || PortfolioHistory != null ? Format() :
                ClientSignal != null ? FormatPortfolio(ClientSignal.Portfolio) : "";

            public string Signals => ClientSignal != null || StrategySignal != null ? Format() : "";
            public string Messages => Message != null ? Format() : "";
            public string Executions => SignalExecution != null ? Format() : "";


            public string Tooltip
            {
                get
                {
                    if (ClientSignal != null)
                        return JsonConvert.SerializeObject(new
                            {
                                ClientSignal.Id, Execution = ClientSignal.Execution != null,
                                Type = ClientSignal.Type.ToString(),
                                Processed = ClientSignal.Processed.ToString(), ClientSignal.MessageSent,
                                StrategySignalId = ClientSignal.StrategySignal?.Id
                            })
                            .Replace("\n", "<br/>");
                    if (StrategySignal != null)
                        return JsonConvert.SerializeObject(new
                        {
                            StrategySignal.InitId,
                            StrategySignal.StrategyId,
                            Portfolio = StrategySignal.Portfolio.ToDictionary(p => p.Key, p => p.Value.Weight),
                            StrategySignal.InitiatingSignal
                        });
                    if (Message != null)
                    {
                        var messageDotsFixed = Message.Message.Replace(".0,", ",");
                        var texts = JsonConvert.DeserializeObject<IrrData>(messageDotsFixed)
                                        ?.Securities
                                        .Select(s =>
                                            $"{s.Symbol} {s.ClassCode}: {s.Volume * s.Direction} x {s.LimitPrice}")
                                    ?? Array.Empty<string>();

                        return string.Join("<br/>", texts);
                    }

                    if (CAHistory != null)
                        return "";

                    return "";
                }
            }

            public bool Equals(HistoryObject x, HistoryObject y)
            {
                if (x?.StrategySignal != null && y?.StrategySignal != null)
                    return x.StrategySignal.Id.Equals(y.StrategySignal.Id);

                if (ReferenceEquals(x, y)) return true;
                return x?.Equals(y) ?? false;
            }

            public int GetHashCode(HistoryObject obj)
            {
                return (obj.DateTime + (obj.CAHistory?.ToString() ?? obj.ClientSignal?.Id.ToString() ??
                    obj.Message?.SignalId.ToString() ??
                    obj.PortfolioHistory?.ToString() ?? obj.SignalExecution?.SignalId.ToString() ??
                    obj.StrategySignal?.Id.ToString() ?? "")).GetHashCode();
            }

            public string Format()
            {
                if (ClientSignal != null)
                    return
                        $"{ClientSignal.Id}<br/>{Enum.GetName(typeof(ClientSignal.ProcessedEnum), ClientSignal.Processed)}";
                if (StrategySignal != null)
                    return $"SS {StrategySignal.Id}";
                if (Message != null)
                    return $"{Message.SignalId}";
                if (CAHistory != null)
                    return $"{CAHistory.StrategyId}<br/>{CAHistory.Status}";
                if (PortfolioHistory != null)
                    return $"Portfolio (diff {PortfolioHistory.DiffFromStrategy:P2})<br/>" +
                           (PortfolioHistory.Positions != null
                               ? string.Join("<br/>",
                                   PortfolioHistory.Positions.Select(p =>
                                       p.SecurityKey == ""
                                           ? $"{p.Number:#.##} {p.Currency} ({p.Weight:P2})"
                                           : $"{p.SecurityKey} = {p.Number:#.#}x{p.AvgPrice:#.####} ({p.Weight:P2})"))
                               : "");
                if (SignalExecution != null)
                    return $"{SignalExecution.SignalId}<br/>" + (SignalExecution.Positions != null
                        ? string.Join("<br/>",
                            SignalExecution.Positions?.Select(p =>
                                p.ExecNumber != 0
                                    ? $"{p.Security}: {p.ExecNumber:#}x{p.ExecPrice:#.####} "
                                    : $"{p.Security}: 0 - {p.ErrorDescription} "))
                        : "");

                return "";
            }

            public string FormatPortfolio(string portf)
            {
                if (string.IsNullOrEmpty(portf)) return "";

                var portfolioHistory = JsonConvert.DeserializeObject<ClientAccount>(portf);

                return $"Portfolio (val {(portfolioHistory?.Value ?? 0):#})<br/>" + (portfolioHistory?.Positions != null
                    ? string.Join("<br/>",
                        portfolioHistory.Positions.Select(p =>
                            p.SecurityKey == ""
                                ? $"{p.Number:#.##} {p.Currency}"
                                : $"{p.SecurityKey} = {p.Number:#.#}x{p.AvgPrice:#.####}"))
                    : "");
            }

            [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Local")]
            private class IrrData
            {
                public long SignalId { get; set; }
                public DateTime AddTime { get; set; }

                public int Type { get; set; }
                public SecurityDto[] Securities { get; set; }
            }

            private class SecurityDto
            {
                public string Name { get; set; }
                public string Symbol { get; set; }
                public string ISIN { get; set; }
                public string ClassCode { get; set; }
                public int LotSize { get; set; }
                public string Board { get; set; }
                public int Direction { get; set; }
                public long Volume { get; set; }
                public decimal LimitPrice { get; set; }
                public decimal Deviation { get; set; }
                public string Currency { get; set; }
                public string CurrencyDisplay => Currency == "SUR" ? "RUB" : Currency;
                public string FaceUnit { get; set; }
                public string ClassName { get; set; }
            }
        }

        [SuppressMessage("ReSharper", "UnusedMember.Global")]
        [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Global")]
        public class StrategyHistoryObject
        {
            public SignalDTO LCSSignal;

            public TradeSignal.TradeSignalPosition Position;

            public ClientSignal Signal;
            public int Id => LCSSignal?.Id ?? 0;
            public DateTime? StrategyDate => LCSSignal?.OpenTime;

            public string Security => LCSSignal.Type == SignalTypeEnum.Coupon ? "Coupon" :
                LCSSignal.Type == SignalTypeEnum.Dividend ? "Dividend" : LCSSignal?.SecurityKey;

            public decimal? Weight =>
                LCSSignal.Type == SignalTypeEnum.Coupon || LCSSignal.Type == SignalTypeEnum.Dividend
                    ? null
                    : LCSSignal?.Weight;

            public decimal? Price =>
                LCSSignal.Type == SignalTypeEnum.Coupon || LCSSignal.Type == SignalTypeEnum.Dividend
                    ? null
                    : LCSSignal.OpenPrice;

            public decimal? ExecPrice =>
                LCSSignal.Type == SignalTypeEnum.Coupon || LCSSignal.Type == SignalTypeEnum.Dividend
                    ? null
                    : Position?.ExecValue / Math.Max(1, Math.Abs((decimal)(Position?.ExecNumber ?? 0)));

            public double? PriceStd { get; set; }

            public string PriceDiff => ExecPrice != null && ExecPrice != 0
                ? $"{((ExecPrice ?? 0) - (Price ?? 0)) / (ExecPrice ?? 1):P2}"
                : null;

            public string PriceStdRel =>
                (ExecPrice ?? 0) != 0 && PriceStd != null ? $"{(PriceStd / (double)ExecPrice!):P2}" : "";

            public TimeSpan Delay { get; set; }
            public decimal StratPL => LCSSignal?.RealizedPnl ?? 0;
            public decimal? PL => Signal?.RealizedPnL;
            public double? PLStd { get; set; }

            public decimal SummStratPL { get; set; }
            public decimal SummClientPL { get; set; }

            public long? Number => Position?.ExecNumber;
        }

        public class ProblemClient
        {
            public int Id { get; set; }
            public string Description { get; set; }
        }

        public class ProblemClientStatPage
        {
            public int Total { get; set; }
            public ProblemClient[] PageStats { get; set; }
        }

        [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Global")]
        public class StrategyExecutionObject
        {
            public Trade[] Trades;
            public int ClientId { get; set; }
            public TimeSpan SendTime { get; set; }
            public decimal? StartPrice { get; set; }
            public decimal? ExecPrice { get; set; }

            public long Number { get; set; }
            public string DiffPrt => $"{(StartPrice - ExecPrice) / StartPrice:P2}";
            public int NTrades { get; set; }
            public TimeSpan? OrderTime { get; set; }

            public string TradeHistory => string.Join(", ",
                Trades.Select(t =>
                    $"{t.StartPrice:.#} > <small>{(t.EndTime - t.StartTime).Minutes + (int)(t.EndTime - t.StartTime).TotalHours * 60}:{(t.EndTime - t.StartTime).Seconds:00}</small> > {(t.ExecPrice == 0 ? " X " : $"{t.ExecPrice:.#} <small>({t.ExecNumber})</small>")}"));

            public class Trade
            {
                public long Id { get; set; }
                public DateTime StartTime { get; set; }
                public DateTime EndTime { get; set; }
                public long ExecNumber { get; set; }
                public decimal StartPrice { get; set; }

                public decimal ExecPrice { get; set; }
            }
        }
    }
}