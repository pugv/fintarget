﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Api.Models;
using Expert.Models;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LifeCycleService.ApiClient;
using LinqToDB;
using LinqToDB.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLib.AuxTypes;
using NLib.Helpers;
using NLib.Linq2dbExtensions;
using ServiceBase;
using Database = Api.Models.Database;
using Index = Api.Models.Index;
using Security = PositionCalculator.Security;
using SignalDTO = LCS.Models.SignalDTO;
using TradeType = Expert.Models.TradeType;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize]
    public class StrategiesController
        : WebCabinetController<StrategiesController>
    {
        private readonly ApiHelpers.IStrategyCatalogApi _evaApi;
        private readonly ILCS _lcs;
        private readonly ISecurityCache _securityCache;

        public StrategiesController(IServiceProvider serviceProvider, ILogger<StrategiesController> logger,
            ILCS lcs, ISecurityCache sec, ApiHelpers.IStrategyCatalogApi evaApi)
            : base(serviceProvider, logger)
        {
            _lcs = lcs;
            _securityCache = sec;
            _evaApi = evaApi;
        }

        // GET: /api/admin/strategies
        [HttpPost]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult<RequestResult<ListPage<AggregateStrategy>>>> GetStrategies(PaginationAndSort paginationAndSort)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var total = await db
                        .Strategies
                        .CountAsync(s => s.Active > 0);

                    var query = db
                        .Strategies
                        .LoadWith(s => s.Tests)
                        .LoadWith(s => s.StrategyEvaParams)
                        .Where(s => !s.IsInvestbox && s.Active > 0);

                    query = SortStrategies(query, paginationAndSort);

                    query = query
                        .Skip(paginationAndSort.PageSize * paginationAndSort.PageNumber)
                        .Take(paginationAndSort.PageSize);

                    var strategies = await query
                        .Select(s => new AggregateStrategy(s))
                        .ToArrayAsync();

                    using (var ftDb = new Database())
                    {
                        var dicMarkets = ftDb.StrategyMarkets
                            .AsEnumerable()
                            .GroupBy(q => q.StrategyId)
                            .ToDictionary(q => q.Key, q => q.Select(m => m.MarketId).ToArray());
                        var dicTools = ftDb.StrategyTools
                            .AsEnumerable()
                            .GroupBy(q => q.StrategyId)
                            .ToDictionary(q => q.Key, q => q.Select(m => m.ToolId).ToArray());
                        var dicBoards = ftDb.StrategyBoards
                            .AsEnumerable()
                            .GroupBy(q => q.StrategyId)
                            .ToDictionary(q => q.Key, q => q.Select(m => m.BoardId).ToArray());
                        var tariffs = ftDb.StrategyTariffs
                            .Where(t => t.Id == 0)
                            .ToArray();

                        foreach (var strategy in strategies)
                        {
                            strategy.SetStrategy(await ftDb.Strategies.FirstOrDefaultAsync(s => s.Id == strategy.Id));

                            if (strategy.Id.HasValue)
                            {
                                strategy.MarketIds = dicMarkets.ContainsKey(strategy.Id.Value)
                                    ? dicMarkets[strategy.Id.Value]
                                    : new int[0];
                                strategy.MarketToolIds = dicTools.ContainsKey(strategy.Id.Value)
                                    ? dicTools[strategy.Id.Value]
                                    : new int[0];
                                strategy.BoardIds = dicBoards.ContainsKey(strategy.Id.Value)
                                    ? dicBoards[strategy.Id.Value]
                                    : new int[0];

                                strategy.AcTariffId = tariffs
                                    .FirstOrDefault(t => t.StrategyId == strategy.Id && t.StrategyType == 2)?.TariffId;
                                strategy.AfTariffId = tariffs
                                    .FirstOrDefault(t => t.StrategyId == strategy.Id && t.StrategyType == 1)?.TariffId;
                            }
                        }
                    }

                    return SuccessValue(new ListPage<AggregateStrategy>
                    {
                        Total = total,
                        PageItems = strategies
                    });
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: /api/admin/strategies/:id
        [HttpGet("{id}")]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult<RequestResult<AggregateStrategy>>> GetStrategyById(Guid id)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var strategy = await db.Strategies
                        .LoadWith(s => s.Comiss)
                        .LoadWith(s => s.Tests)
                        .LoadWith(s => s.StrategyEvaParams)
                        .FirstOrDefaultAsync(s => s.Id == id);

                    if (strategy == null)
                        return Success<AggregateStrategy>(null);

                    using (var ftDb = new Database())
                    {
                        var tariffs = ftDb.StrategyTariffs
                            .Where(t => t.Id == 0)
                            .ToArray();

                        var result = new AggregateStrategy(strategy);

                        result.SetStrategy(
                            await ftDb.Strategies
                                .Where(s => s.Id == strategy.Id)
                                .LoadWith(s => s.SalesPoints.OrderBy(sp => sp.Order))
                                .FirstOrDefaultAsync());

                        if (result.Id.HasValue)
                        {
                            result.MarketIds = ftDb.StrategyMarkets
                                .Where(q => q.StrategyId == strategy.Id)
                                .Select(s => s.MarketId)
                                .ToArray();
                            result.MarketToolIds = ftDb.StrategyTools
                                .Where(q => q.StrategyId == strategy.Id)
                                .Select(s => s.ToolId)
                                .ToArray();
                            result.BoardIds = ftDb.StrategyBoards
                                .Where(q => q.StrategyId == strategy.Id)
                                .Select(s => s.BoardId)
                                .ToArray();

                            result.AcTariffId = tariffs
                                .FirstOrDefault(t => t.StrategyId == strategy.Id && t.StrategyType == 2)?.TariffId;
                            result.AfTariffId = tariffs
                                .FirstOrDefault(t => t.StrategyId == strategy.Id && t.StrategyType == 1)?.TariffId;

                            if (result.IsRestricted)
                            {
                                var clientIds = await ftDb.StrategyClients
                                    .Where(c => c.StrategyId == strategy.Id)
                                    .Select(c => c.ClientId)
                                    .ToArrayAsync();

                                var clients = await ftDb.Clients
                                    .Where(c => clientIds.Contains(c.Id))
                                    .LoadWith(c => c.Accounts)
                                    .ToArrayAsync();

                                result.Clients = clients
                                    .SelectMany(c => c.Accounts
                                        .Select(a => new BriefAgreementInfo(c.Id, a.AgreementName, c.FirstName,
                                            c.LastName, c.MiddleName)))
                                    .OrderBy(c => c.Fio)
                                    .ToArray();
                            }
                        }

                        return Success(result);
                    }
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        private IQueryable<Expert.Models.Strategy> SortStrategies(IQueryable<Expert.Models.Strategy> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName?.ToLower())
            {
                case "name":
                    return paginationAndSort.SortDirection > 0 ? query.OrderBy(s => s.Name) : query.OrderByDescending(s => s.Name);
                case "creationdate":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(s => s.CreateTime)
                        : query.OrderByDescending(s => s.CreateTime);
                // case "leverage": from ft.strategies
                case "currency":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(s => s.Currency)
                        : query.OrderByDescending(s => s.Currency);
                case "active":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(s => s.Active)
                        : query.OrderByDescending(s => s.Active);
                default:
                    return query;
            }
        }

        // GET: /api/admin/strategies/summary
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpGet("summary")]
        public async Task<ActionResult<RequestResult<StrategySummary[]>>> GetStratSummary()
        {
            try
            {
                using (var ftDb = new Database())
                {
                    var clientTariffs = ftDb
                        .ClientTariffs
                        .Select(t => t.ClientTariffId)
                        .Distinct()
                        .ToArray();

                    clientTariffs = clientTariffs.Union(new[]
                        {
                            Guid.Empty
                        })
                        .ToArray();

                    var strategies = ftDb
                        .Strategies
                        .LoadWith(s => s.Duration)
                        .LoadWith(s => s.MinInvestProfile)
                        .LoadWith(s => s.Index)
                        .LoadWith(s => s.PriceCategory)
                        .ToArray();


                    var strategyTasks = strategies.Select(async s =>
                    {
                        var availableTarifs = new List<AvailableTariff>();
                        using (var ftDb1 = new Database())
                        {
                            foreach (var ct in clientTariffs)
                            {
                                var af = await TariffHelper.GetStrategyTariff(ftDb1, ct, s.Id, true);
                                var ac = await TariffHelper.GetStrategyTariff(ftDb1, ct, s.Id, false);

                                //if (ac != null || af != null)
                                {
                                    availableTarifs.Add(new AvailableTariff
                                    {
                                        ClientTariff = ct == Guid.Empty ? null : (Guid?)ct,
                                        AcTariff = ac ?? -1,
                                        AfTariff = af ?? -1
                                    });
                                }
                            }
                        }

                        MakePriceAF(s);
                        return new StrategySummary
                        {
                            Id = s.Id,
                            Name = s.Name,
                            SubscriptionThreshold = s.SubscriptionThreshold,
                            Currency = s.CurrencyId,
                            Autoconsult = s.Autoconsult,
                            Autofollow = s.Autofollow,
                            IsInvestbox = s.IsInvestbox,
                            Category = s.Category,
                            Duration = s.Duration.Name,
                            MinInvestProfile = s.MinInvestProfile?.Name,
                            EstimatedProfit = s.EstimatedProfit,
                            EstimatedDrawdown = s.EstimatedDrawdown,
                            ForQualifiedInvestorsOnly = s.ForQualifiedInvestorsOnly,
                            HidePortfolio = s.HidePortfolio,
                            HideRecentSignals = s.HideRecentSignals,
                            IIS = s.IIS,
                            Index = s.Index?.Name ?? "-",
                            PriceAF = s.Autofollow ? s.PriceAF : "-",
                            PriceAC = s.Autoconsult ? s.PriceAC : "-",
                            ShowFullPortfolio = s.ShowFullPortfolio,
                            TestMode = s.TestMode,
                            IsRestricted = s.IsRestricted,
                            AvailableTariffs = availableTarifs.ToArray()
                        };
                    }).ToArray();

                    await Task.WhenAll(strategyTasks);

                    return Success(strategyTasks.Select(c => c.Result));
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private static void MakePriceAF(Api.Models.Strategy strat)
        {
            if (strat.Price != null)
                strat.PriceAC = strat.Price;
            strat.Price = null;
            strat.ActivationComis = "0.5%";
            if (strat.PriceCategory != null)
            {
                if (strat.PriceCategory.MF == 0 && strat.PriceCategory.SF == 0)
                    strat.PriceAF = "Бесплатно";
                else if (strat.PriceCategory.MF == 0)
                    strat.PriceAF = $"{string.Format("{0:0.##}", strat.PriceCategory.SF)}% от прибыли";
                else if (strat.PriceCategory.SF == 0)
                    strat.PriceAF = $"{string.Format("{0:0.##}", strat.PriceCategory.MF)}% от активов";
                else
                    strat.PriceAF =
                        $"{string.Format("{0:0.##}", strat.PriceCategory.MF)}% от активов + {string.Format("{0:0.##}", strat.PriceCategory.SF)}% от прибыли";
            }
        }

        // GET: /api/admin/strategies/durations
        [Authorize(Roles = "Administrator,Support,DigitalExpert")]
        [HttpGet("durations/{batchSize}")]
        public async Task<ActionResult<RequestResult<Duration[]>>> GetDuration(int batchSize)
        {
            try
            {
                using (var ftdb = new Database())
                {
                    var result = ftdb.Durations.Take(batchSize).ToArrayAsync();

                    return Success(await result);
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // GET: /api/admin/strategies/tariffs
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpGet("tariffs/{batchSize}")]
        public async Task<ActionResult<RequestResult<Models.Tariff[]>>> GetTariffs(int batchSize)
        {
            try
            {
                using var ftdb = new Database();
                var result = await (from t in ftdb.Tariffs
                                    orderby t.Order
                                    select new Models.Tariff
                                    {
                                        Id = t.Id,
                                        Guid = t.TariffId,
                                        EvaId = t.EvaId,
                                        Category = t.CategoryId,
                                        Description = $"{t.Description}{(t.CategoryId != null ? $" (кат. {t.CategoryId})" : "")}",
                                        Kind = t.Kind
                                    }).Take(batchSize).ToArrayAsync();
                return Success(result);
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // GET: /api/admin/strategies/currencies
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpGet("currencies")]
        public async Task<ActionResult<RequestResult<CurrencyInfo[]>>> GetCurrencyInfo()
        {
            try
            {
                using (var ftdb = new Database())
                {
                    var result = ftdb
                        .GetTable<Currency>()
                        .Where(c => c.DbId != "RUB") // в предыдущей версии этот код не использовался
                        .Select(c => new CurrencyInfo { Code = c.Id, Name = c.Name })
                        .ToArrayAsync();

                    return Success(await result);
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }


        private async Task<T[]> GetInfoAsync<T>(Func<DataConnection> dbFactory, int batchSize, [CallerMemberName] string constructedFrom = null)
            where T : class
        {
            using (var db = dbFactory())
            {
                return await db.GetTable<T>()
                    .Take(batchSize)
                    .ToArrayAsync();
            }
        }

        // GET: /api/admin/strategies/refs
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpGet("refs/{batchSize}")]
        public ActionResult<RequestResult<AggregateStrategyInfoRefs>> GetStrategyInfoRefs(int batchSize)
        {
            try
            {
                var durations = GetInfoAsync<Duration>(() => new Database(), batchSize);
                var indexes = GetInfoAsync<Index>(() => new Database(), batchSize);
                var markets = GetInfoAsync<Market>(() => new Database(), batchSize);
                var tools = GetInfoAsync<Tool>(() => new Database(), batchSize);
                var boards = GetInfoAsync<Board>(() => new Database(), batchSize);
                var profiles = GetInfoAsync<InvestProfile>(() => new Database(), batchSize);
                var tests = GetInfoAsync<Test>(() => new Database(), batchSize);
                var tradeTypes = GetInfoAsync<TradeType>(() => new Expert.Models.Database(), batchSize);

                Task.WaitAll(durations, indexes, markets, tools, boards, profiles, tests, tradeTypes);

                return Success(new AggregateStrategyInfoRefs
                {
                    Durations = durations.Result,
                    Indexes = indexes.Result,
                    Markets = markets.Result,
                    MarketTools = tools.Result,
                    Profiles = profiles.Result,
                    Boards = boards.Result,
                    Tests = tests.Result,
                    TradeTypes = tradeTypes.Result
                });
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // GET: /api/admin/strategies/rawhistory/{strategyId}
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpGet("rawhistory/{strategyId}")]
        public async Task<ActionResult<RequestResult<FileDownload>>> DownloadHistory(Guid strategyId)
        {
            try
            {
                using (var db = new Database())
                {
                    var strategy = await db.Strategies.FirstOrDefaultAsync(s => s.Id == strategyId);
                    if (strategy == null)
                        return Error($"Стратегия с идентификатором {strategyId.ToString()} не найдена.");

                    var content = "TODO: заполнить сигналами";

                    return Success(new FileDownload
                    {
                        FileName = $"{strategy.Name}-history.txt",
                        ContentBase64 = ToBase64(content)
                    });
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // GET: /api/admin/strategies/follow/{strategyId}
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpGet("follow/{strategyId}")]
        public async Task<ActionResult<RequestResult<string>>> GetFollowHistory(Guid strategyId)
        {
            try
            {
                using (var db = new Database())
                {
                    var strategy = await db.Strategies.FirstOrDefaultAsync(s => s.Id == strategyId);
                    if (strategy == null)
                        return Error($"Стратегия с идентификатором {strategyId.ToString()} не найдена.");

                    return Success("TODO");
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }


        // GET: /api/admin/strategies/users
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpGet("users/{batchSize}")]
        public async Task<ActionResult<RequestResult<UserInfo[]>>> GetUserInfo(int batchSize)
        {
            try
            {
                int[] userIds = null;
                
                using (var db = new Expert.Models.Database())
                {
                    userIds = await db.Users
                        .Where(u => u.IsActive > 0)
                        .Select(u => u.Id)
                        .ToArrayAsync();
                }
                
                using (var db = new Database())
                {
                    var users = db.Authors
                        .Where(s => userIds.Contains(s.Id))
                        .Select(s => new UserInfo
                        {
                            Id = s.Id,
                            UserType = s.Type,
                            FirstName = s.FirstName,
                            LastName = s.LastName,
                            OrgName = s.Company,
                            DisplayName = s.DisplayName,
                            AgreementNum = s.AgreementNum,
                            Login = null
                        })
                        .ToArrayAsync();

                    return Success(await users);
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // POST: /api/admin/strategies/agreements
        [Authorize(Roles = "Administrator,Support,DigitalExpert")]
        [HttpPost("agreements")]
        public async Task<ActionResult<RequestResult<BriefAgreementInfo[]>>> GetAgreementInfo(string[] agreements)
        {
            try
            {
                using (var ftdb = new Database())
                {
                    var result = await ftdb.ClientAccounts
                        .InnerJoin(
                            ftdb.Clients,
                            (ca, c) => ca.ClientId == c.Id,
                            (ca, c) => new BriefAgreementInfo(c.Id, ca.AgreementName, c.FirstName, c.LastName, c.MiddleName))
                        .Where(c => agreements.Contains(c.Agreement))
                        .ToArrayAsync();

                    return Success(result);
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // POST: /api/admin/strategies/add
        [Authorize(Roles = "Administrator,Support,DigitalExpert")]
        [HttpPost("add")]
        public async Task<ActionResult<RequestResult<AggregateStrategy>>> AddStrategy(AggregateStrategy strategy)
        {
            try
            {
                if (strategy.Id != null) Logger.LogWarning($"AddStrategy id=|{strategy.Id.Value}| ignored");

                var time = DateTime.UtcNow;
                var strategyId = CreateStrategyId();
                strategy.Id = strategyId;
                if (string.IsNullOrEmpty(strategy.Securities))
                    strategy.Securities = "[]"; 

                var cabStrategy = new Expert.Models.Strategy
                {
                    Id = strategyId,
                    ParentStrategy = strategy.ParentId,
                    ManagerId = strategy.ManagerId,
                    CreatorId = strategy.CreatorId,
                    Name = strategy.Name,
                    Active = strategy.Active ? 1 : 0,
                    Currency = strategy.Currency,
                    Securities = strategy.Securities,
                    MaxInstrumentWeight = strategy.MaxInstrumentWeight,
                    MaxSignalWeight = strategy.MaxSignalWeight,
                    SubscriptionThreshold = strategy.SubscriptionThreshold,
                    // AfValueSUR, AfValueUSD, AcValueSUR, AcValueUSD, AfClientCount, AcClientCount = не заполняются
                    RecalcMode = strategy.RecalcMode,
                    IsAlgo = strategy.IsAlgostrategy,
                    Status = StrategyStatus.Standard,
                    ForReport = false, // #fixme спросить у Арсения
                    IsPortfolio = false,
                    Leverage = strategy.Leverage,
                    ProfileId = strategy.MinInvestProfileId,
                    CreateTime = strategy.CreationDate
                };

                using (var cabdb = new Expert.Models.Database())
                {
                    using (var trn = await cabdb.BeginTransactionAsync())
                    {
                        var user = await cabdb.Users.FirstAsync(u => u.Id == strategy.ManagerId);
                        if (user.IsActive == 0)
                            throw new UserVisibleException(
                                $"Пользователь '{user.GetUserName()}' id={user.Id.ToString()} был удален");

                        if (await cabdb.InsertAsync(cabStrategy) == 0)
                            throw new ApplicationException(
                                $"{nameof(AddStrategy)} Insert cabinet strategy id=|{strategyId}| returned zero");

                        await AddFintargetStrategy(strategy, time);
                        await trn.CommitAsync();
                    }
                }

                return Success();
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        [Authorize(Roles = "Administrator")]
        [HttpPost("split")]
        public async Task<ActionResult<RequestResult>> Split(ChangeSignal signal)
        {
            try
            {
                var strats = (await (await GetStrategies())
                        .Where(s => s.ParentStrategy == null).SelectAsync(async s => new { s, p = await GetStrategyOpenPositions(s.Id) }))
                    .Where(o => o.p?.ActivePositions?.ContainsKey(new Security(signal.SecurityKey2)) ?? false).Select(o => o.s).ToArray();

                var key = $"{signal.Symbol} {signal.ClassCode} {signal.Board}";
                try
                {
                    foreach (var strat in strats)
                    {
                        signal.ManagerId = strat.ManagerId;
                        signal.StrategyId = strat.Id;
                        Logger?.LogInformation($"Sending split by {signal.SecurityKey2} to {strat.Id}");
                        await _lcs.NewChangeSignal(signal);
                    }
                }
                catch (Exception e)
                {
                    throw new UserVisibleException(e.Message);
                }

                var security = _securityCache.GetSecuritiy(key);
                await _securityCache.AddSecurities(new[] { key });

                return Success();
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // POST: /api/admin/strategies/edit
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpPost("edit")]
        public async Task<ActionResult<RequestResult<AggregateStrategy>>> UpdateStrategy(AggregateStrategy strategy)
        {
            var time = DateTime.UtcNow;
            var role = UserManager.GetUserRole(User);

            if (role == UserRole.Developer && !strategy.TestMode)
                // developer имеет право редактировать только тестовую стратегию
                return Error("Недостаточно прав для редактирования не-тестовой стратегии");
            
            try
            {
                if (!strategy.Id.HasValue)
                {
                    Logger.LogWarning("UpdateStrategy guid missing");

                    return Error("Strategy id missing", 0);
                }

                if (strategy.ParentId.HasValue && strategy.Id == strategy.ParentId)
                    throw new ArgumentException($"Self-parent strategy is not allowed id=|{strategy.Id.Value}|");

                var friendlyName = TranslitHelper.Instance().ConvertToEng(strategy.Name) ?? string.Empty;

                Expert.Models.Strategy cabStrategy = null;

                using (var cabdb = new Expert.Models.Database())
                {
                    using (var ftdb = new Database())
                    {
                        cabStrategy = await cabdb
                            .Strategies
                            .LoadWith(s => s.Comiss)
                            .LoadWith(s => s.Tests)
                            .FirstAsync(s => s.Id == strategy.Id);

                        using (var trn = await cabdb.BeginTransactionAsync())
                        {
                            var user = await cabdb.Users.FirstAsync(u => u.Id == strategy.ManagerId);
                            if (user.IsActive == 0)
                                throw new UserVisibleException(
                                    $"Пользователь '{user.GetUserName()}' id={user.Id.ToString()} был удален");
                            
                            if (cabStrategy.Securities != strategy.Securities)
                                await cabdb
                                    .InsertAsync(new StrategySecuritiesHistory
                                    {
                                        StrategyId = cabStrategy.Id,
                                        OldValue = cabStrategy.Securities,
                                        NewValue = strategy.Securities,
                                        UpdateTime = DateTime.Now
                                    });

                            var update = cabdb.Strategies
                                .Where(s => s.Id == strategy.Id)
                                //.AsUpdatable()
                                .Set(s => s.ParentStrategy, strategy.ParentId)
                                .Set(s => s.ManagerId, strategy.ManagerId)
                                // creator_id не обновляется
                                .Set(s => s.Name, strategy.Name)
                                .Set(s => s.Active, strategy.Active ? 1 : 0)
                                .Set(s => s.Currency, strategy.Currency)
                                .Set(s => s.Securities, s => strategy.Securities ?? s.Securities)
                                .Set(s => s.SubscriptionThreshold, strategy.SubscriptionThreshold)
                                .Set(s => s.MaxInstrumentWeight, strategy.MaxInstrumentWeight)
                                .Set(s => s.MaxSignalWeight, strategy.MaxSignalWeight)
                                .Set(s => s.IsAlgo, strategy.IsAlgostrategy)
                                .Set(s => s.RecalcMode, strategy.RecalcMode)
                                .Set(s => s.TradeType, strategy.TradeType)
                                //.Set(s => s.Status, strategyStatus)
                                .Set(s => s.Iis, strategy.IIS)
                                .Set(s => s.TradesFrequency, strategy.TradesFrequency)
                                //.Set(s => s.MaxInstrumentFraq, strategy.MaxInstrumentFraq) // на данный момент не используется
                                .Set(s => s.Autoconsult, strategy.Autoconsult)
                                .Set(s => s.Autofollow, strategy.Autofollow)
                                .Set(s => s.Leverage, strategy.Leverage)
                                .Set(s => s.ProfileId, strategy.MinInvestProfileId)
                                .UpdateAsync();

                            if (await update == 0)
                                throw new ApplicationException(
                                    $"{nameof(AddStrategy)} Update cabinet strategy id=|{strategy.Id}| returned zero");

                            await UpdateEvaParamsAsync(cabdb, strategy.Id.Value, strategy.EvaParams);

                            if (cabStrategy.Comiss == null)
                            {
                                if (strategy.RateLong.HasValue || strategy.RateShort.HasValue)
                                    await cabdb.InsertAsync(
                                        new ComissionDBO
                                        {
                                            StratId = strategy.Id.Value,
                                            Long = strategy.RateLong,
                                            Short = strategy.RateShort
                                        });
                            }
                            else if (!strategy.RateLong.HasValue && !strategy.RateShort.HasValue)
                            {
                                await cabdb.GetTable<ComissionDBO>()
                                    .DeleteAsync(s => s.StratId == strategy.Id.Value);
                            }
                            else if (cabStrategy.Comiss.Long != strategy.RateLong ||
                                     cabStrategy.Comiss.Short != strategy.RateShort)
                            {
                                await cabdb.GetTable<ComissionDBO>()
                                    .Where(s => s.StratId == strategy.Id.Value)
                                    .AsUpdatable()
                                    .Set(s => s.Long, strategy.RateLong)
                                    .Set(s => s.Short, strategy.RateShort)
                                    .UpdateAsync();
                            }

                            if (cabStrategy.RecalcMode != strategy.RecalcMode && cabStrategy.Status == StrategyStatus.Standard &&
                                await dataAccessLayer.GetStrategyLastSignal(strategy.Id.Value) != null)
                            {
                                var was = await cabdb.CalcTypeHistories.Where(s => s.StrategyId == strategy.Id).OrderBy(s => s.Date).ToArrayAsync();
                                if (was.Length == 0)
                                    await cabdb.InsertAsync(new CalcTypeHistory
                                    {
                                        StrategyId = strategy.Id.Value,
                                        Type = cabStrategy.RecalcMode
                                    });

                                if ((int?)was.LastOrDefault()?.Type != strategy.RecalcMode)
                                {
                                    var lastDate = was.LastOrDefault()?.Date;

                                    if (lastDate != null && lastDate?.Date == DateTime.Now.Date)
                                        await cabdb.CalcTypeHistories
                                            .Where(s => s.StrategyId == strategy.Id && s.Date == lastDate)
                                            .Set(s => s.Type, strategy.RecalcMode)
                                            .Set(s => s.Date, DateTime.Now)
                                            .UpdateAsync();
                                    else
                                        await cabdb.InsertAsync(new CalcTypeHistory
                                        {
                                            StrategyId = strategy.Id.Value,
                                            Date = DateTime.Now,
                                            Type = strategy.RecalcMode
                                        });
                                }
                            }

                            using (var trnft = await ftdb.BeginTransactionAsync())
                            {
                                if (cabStrategy.ManagerId != strategy.ManagerId)
                                {
                                    var updated = await ftdb.Authors
                                        .Where(a => a.Id == cabStrategy.ManagerId)
                                        .AsUpdatable()
                                        .Set(a => a.Updated, a => a.Updated + 1)
                                        .Set(a => a.UpdateTime, time)
                                        .UpdateAsync();
                                    if (updated == 0)
                                        Logger.LogWarning("Update old strategy author count=0");
                                }

                                var result = await ftdb.Strategies
                                    .Where(s => s.Id == strategy.Id)
                                    .Set(s => s.AuthorId, strategy.ManagerId)
                                    .Set(s => s.ParentStrategy, strategy.ParentId)
                                    .Set(s => s.Name, strategy.Name)
                                    .Set(s => s.FriendlyUrl,
                                        friendlyName.Length > 128
                                            ? friendlyName.Substring(0, 128)
                                            : friendlyName)
                                    .Set(s => s.Tag, strategy.Tag)
                                    .Set(s => s.DescriptionHtml, strategy.DescriptionHtml)
                                    .Set(s => s.InfoHtml, strategy.InfoHtml)
                                    .Set(s => s.ChartComment, strategy.ChartComment)
                                    .Set(s => s.Goal, strategy.Goal)
                                    .Set(s => s.CurrencyId, strategy.Currency)
                                    .Set(s => s.MinInvestProfileId, strategy.MinInvestProfileId)
                                    .Set(s => s.SubscriptionThreshold, strategy.SubscriptionThreshold)
                                    .Set(s => s.DurationId, strategy.DurationId)
                                    .Set(s => s.Open, strategy.Open)
                                    .Set(s => s.Leverage, strategy.Leverage)
                                    .Set(s => s.PlStartDate, strategy.PlStartDate)
                                    .Set(s => s.MaxPositionWeight, strategy.MaxPositionWeight)
                                    //.Set(s => s.MaxIndustryWeight,strategy.MaxIndustryWeight)
                                    .Set(s => s.MaxInstrumentFraq, strategy.MaxPositionWeight)
                                    .Set(s => s.IsAlgostrategy, strategy.IsAlgostrategy)
                                    .Set(s => s.Capacity, strategy.Capacity)
                                    .Set(s => s.Recommended, strategy.Recommended)
                                    .Set(s => s.HidePortfolio, strategy.HidePortfolio)
                                    .Set(s => s.HideRecentSignals, strategy.HideRecentSignals)
                                    .Set(s => s.TestMode, strategy.TestMode)
                                    .Set(s => s.IIS, strategy.IIS)
                                    .Set(s => s.IndexId, strategy.IndexId)
                                    .Set(s => s.HideIndexOnChart, strategy.HideIndexOnChart)
                                    .Set(s => s.HideIndexInWL, strategy.HideIndexInWL)
                                    .Set(s => s.Autofollow, strategy.Autofollow)
                                    .Set(s => s.Autoconsult, strategy.Autoconsult)
                                    .Set(s => s.Category, strategy.Category)
                                    .Set(s => s.Price, strategy.Autoconsult ? strategy.Price : null)
                                    .Set(s => s.ForQualifiedInvestorsOnly, strategy.ForQualifiedInvestorsOnly)
                                    .Set(s => s.ClosedForBinding, !strategy.Open)
                                    .Set(s => s.IsRestricted, strategy.IsRestricted)
                                    .Set(s => s.Updated, s => s.Updated + 1)
                                    .Set(s => s.UpdateLcs, s => s.UpdateLcs + 1)
                                    .Set(s => s.UpdateTime, time)
                                    .Set(s => s.Securities, s => strategy.Securities ?? s.Securities)
                                    .UpdateWithOutputAsync();

                                if (result == null || result.Length == 0)
                                    throw new ApplicationException(
                                        $"{nameof(AddStrategy)} Update fintarget strategy id=|{strategy.Id}| returned zero");

                                await ftdb.GetTable<StrategySalesPoints>()
                                    .DeleteAsync(p => p.StrategyId == strategy.Id);

                                var order = 1;
                                
                                foreach (var part in strategy.InfoParts ?? Array.Empty<StrategyInfoPart>())
                                {
                                    if (string.IsNullOrEmpty(part.Value) && string.IsNullOrEmpty(part.Title))
                                        continue;

                                    await ftdb.InsertAsync(
                                        new StrategySalesPoints
                                        {
                                            StrategyId = strategy.Id.Value,
                                            Title = part.Title,
                                            Text = part.Value,
                                            Order = order++
                                        });
                                }

                                await UpdateTariffAsync(ftdb, strategy);

                                await UpdateTestsAsync(ftdb, cabdb, cabStrategy, strategy.Tests);

                                var markets = await GetMarketsToUpdateAsync(ftdb, strategy.MarketIds, strategy.Id.Value);

                                if (markets.ToRemove.Length > 0)
                                    await ftdb.StrategyMarkets
                                        .DeleteAsync(q => q.StrategyId == strategy.Id && markets.ToRemove.Contains(q.MarketId));

                                foreach (var id in markets.ToAdd)
                                    await ftdb.InsertAsync(new StrategyMarket
                                    { MarketId = id, StrategyId = strategy.Id.Value });

                                var tools = await GetToolsToUpdateAsync(ftdb, strategy.MarketToolIds,
                                    strategy.Id.Value);

                                if (tools.ToRemove.Length > 0)
                                    await ftdb.StrategyTools.DeleteAsync(q =>
                                        q.StrategyId == strategy.Id && tools.ToRemove.Contains(q.ToolId));

                                foreach (var id in tools.ToAdd)
                                    await ftdb.InsertAsync(new StrategyTool
                                    { StrategyId = strategy.Id.Value, ToolId = id });

                                var boards = await GetBoardsToUpdateAsync(ftdb, strategy.BoardIds,
                                    strategy.Id.Value);

                                if (boards.ToRemove.Length > 0)
                                    await ftdb.StrategyBoards.DeleteAsync(q =>
                                        q.StrategyId == strategy.Id && boards.ToRemove.Contains(q.BoardId));

                                foreach (var id in boards.ToAdd)
                                    await ftdb.InsertAsync(new StrategyBoard
                                    { StrategyId = strategy.Id.Value, BoardId = id });

                                if (strategy.IsRestricted && strategy.Clients != null) await UpdateClientsAsync(ftdb, strategy.Id.Value, strategy.Clients);

                                if (strategy.Open)
                                    await ftdb.InsertAsync(
                                        new ShopfrontObject
                                        {
                                            ObjectType = "strategy",
                                            ObjectId = strategy.Id.Value
                                        });

                                await trnft.CommitAsync();
                            }

                            await trn.CommitAsync();
                        }
                    }
                }
                await StoreAuditActionAsync(AuditRecord.Actions.EditStrategy, new { Info = "Updated strategy", Strategy = strategy });

                return Success();
            }
            catch (Exception e)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.EditStrategy, new { Info = "Failed to update strategy", Strategy = strategy, Error = e.Message });
                return Error(e);
            }
        }

        private async Task UpdateEvaParamsAsync(Expert.Models.Database cabdb, Guid strategyId, EvaParamsDto evaParams)
        {
            await cabdb.InsertOrReplaceAsync(new StrategyEvaParams
            {
                StrategyId = strategyId,
                CreditGO = evaParams?.CreditGO ?? false,
                CurrencyMarket = evaParams?.CurrencyMarket ?? false,
                CurrencyMarketEBS = evaParams?.CurrencyMarketEBS ?? false,
                FortsRTS = evaParams?.FortsRTS ?? false,
                FortsRTSEBS = evaParams?.FortsRTSEBS ?? false,
                Lse = evaParams?.Lse ?? false,
                MmvbUSD = evaParams?.MmvbUSD ?? false,
                SpbRTS = evaParams?.SpbRTS ?? false,
                StockMarketMMVB = evaParams?.StockMarketMMVB ?? false,
                StockMarketOffexchange = evaParams?.StockMarketOffexchange ?? false,
                UsMarkets = evaParams?.UsMarkets ?? false,
            }, columnFilter: (entity, column, isInsert) => column.ColumnName != nameof(StrategyEvaParams.EvaUpdatedAt));
        }

        [Authorize(Roles = "Administrator,Developer")]
        [HttpPost("send")]
        public async Task<ActionResult> SendStrategies()
        {
            var strats = await GetStrategies(new PaginationAndSort() {PageSize = 32000});
            foreach (var strat in strats.Value.Result.PageItems)
            {
                await PostLcsStrategy(strat, false);
            }

            return Success("Sent OK");
        }

        // POST: /api/admin/strategies/state
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpPost("state")]
        public async Task<ActionResult<RequestResult<AggregateStrategyState>>> UpdateStrategyState(
            AggregateStrategyState state)
        {
            var time = DateTime.UtcNow;

            try
            {
                var result = new AggregateStrategyState { Id = state.Id };
                AggregateStrategy aggregateStrategy = null;

                using (var db = new Expert.Models.Database())
                {
                    var cabStrategy = await db.Strategies.FirstOrDefaultAsync(s => s.Id == state.Id);
                    if (cabStrategy == null)
                    {
                        Logger?.LogError($"Cabinet strategy not found id=|{state.Id}|");

                        throw new UserVisibleException("Strategy not found in CabinetDb");
                    }

                    aggregateStrategy = new AggregateStrategy(cabStrategy);
                }

                if (state.Open.HasValue && state.Open.Value)
                    using (var db = new Database())
                    {
                        var tests = await db.StrategyTests
                            .Where(t => t.StrategyId == state.Id)
                            .Select(t => t.TestId)
                            .ToArrayAsync();

                        if (tests.Length > 0)
                            using (var lcs = new LCS.Models.Database())
                            {
                                var lastSignal = await lcs.Signals.Where(s => s.StrategyId == state.Id)
                                    .OrderByDescending(s => s.Id)
                                    .FirstOrDefaultAsync();

                                if (lastSignal != null)
                                {
                                    var lastState = SignalDTO.StateFromJson(lastSignal.State, lastSignal.Id);

                                    foreach (var pos in lastState.ActivePositions)
                                    {
                                        var sec = _securityCache.GetSecuritiy(pos.Key.GetKey());
                                        if (sec.RequiredTest != null &&
                                            !tests.Contains(sec.RequiredTest))
                                            throw new UserVisibleException(
                                                $"Инструмент {sec.Symbol}, присутствующий в текущем портфеле требует теста {sec.RequiredTest}, не заявленного в стратегии");
                                    }
                                }
                            }
                    }

                if (state.Active.HasValue)
                    using (var db = new Expert.Models.Database())
                    {
                        using (var trn = await db.BeginTransactionAsync())
                        {
                            var current = await db.Strategies
                                .FirstOrDefaultAsync(s => s.Id == state.Id);

                            if (aggregateStrategy.Active != state.Active.Value)
                            {
                                // MB-23990
                                if (!state.Active.Value)
                                    state.Open = false;

                                result.Active = state.Active.Value;

                                var update = await db.Strategies
                                    .Where(s => s.Id == state.Id)
                                    .Set(s => s.Active, state.Active.Value ? 1 : 0)
                                    .UpdateAsync();

                                await trn.CommitAsync();
                            }
                        }
                    }

                if (state.Open.HasValue)
                    using (var db = new Database())
                    {
                        using (var trn = await db.BeginTransactionAsync())
                        {
                            result.Open = state.Open;

                            var update = await db.Strategies
                                .Where(s => s.Id == state.Id)
                                .Set(s => s.Open, state.Open)
                                .Set(s => s.Updated, s => s.Updated + 1)
                                .Set(s => s.UpdateTime, time)
                                .UpdateWithOutputAsync();

                            if (update != null && update.Length > 0)
                            {
                                var existingStrategy = update.FirstOrDefault().Deleted;
                                aggregateStrategy.SetStrategy(existingStrategy);
                                aggregateStrategy.Open = state.Open.Value;

                                await db.InsertAsync(new ShopfrontObject
                                {
                                    ObjectType = "strategy",
                                    ObjectId = state.Id
                                });

                                if (_lcs != null && state.Open.Value)
                                    if (!await _lcs.PushToCS(state.Id))
                                        throw new ApplicationException($"Push to CS api call failed, id=|{state.Id}|");

                            }

                            await trn.CommitAsync();
                        }
                    }

                await StoreAuditActionAsync(AuditRecord.Actions.PublishStrategy, new { Info = "Changed publishing status", State = state });
                return Success(result);
            }
            catch (Exception e)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.PublishStrategy, new { Info = "Failed to change publishing status", State = state, Error = e.Message });
                return Error(e);
            }
        }


        private async Task UpdateTariffAsync(Database ftdb, AggregateStrategy strategy)
        {
            Debug.Assert(strategy.Id.HasValue);

            var tariffs = await ftdb.StrategyTariffs
                .Where(q => q.StrategyId == strategy.Id.Value)
                .ToArrayAsync();

            var updateTime = DateTime.Now;

            if (strategy.AfTariffId.HasValue)
            {
                if (!tariffs.Any(q => q.Id == 0 && q.StrategyType == 1 && q.TariffId == strategy.AfTariffId))
                {
                    await ftdb.StrategyTariffs
                        .DeleteAsync(q => q.StrategyId == strategy.Id.Value && q.Id == 0 && q.StrategyType == 1);
                    await ftdb.InsertAsync(new TariffStrategy
                    {
                        Id = 0,
                        StrategyId = strategy.Id.Value,
                        StrategyType = 1,
                        TariffId = strategy.AfTariffId.Value,
                        UpdateTime = updateTime
                    });
                }
            }
            else
            {
                await ftdb.StrategyTariffs
                    .DeleteAsync(q => q.StrategyId == strategy.Id.Value && q.Id == 0 && q.StrategyType == 1);
            }

            if (strategy.AcTariffId.HasValue)
            {
                if (!tariffs.Any(q => q.Id == 0 && q.StrategyType == 2 && q.TariffId == strategy.AcTariffId))
                {
                    await ftdb.StrategyTariffs
                        .DeleteAsync(q => q.StrategyId == strategy.Id.Value && q.Id == 0 && q.StrategyType == 2);
                    await ftdb.InsertAsync(new TariffStrategy
                    {
                        Id = 0,
                        StrategyId = strategy.Id.Value,
                        StrategyType = 2,
                        TariffId = strategy.AcTariffId.Value,
                        UpdateTime = updateTime
                    });
                }
            }
            else
            {
                await ftdb.StrategyTariffs
                    .DeleteAsync(q => q.StrategyId == strategy.Id.Value && q.Id == 0 && q.StrategyType == 2);
            }
        }

        private async Task UpdateTestsAsync(Database ftdb, Expert.Models.Database cabdb, Expert.Models.Strategy strategy, string[] tests)
        {
            var listTests = tests != null ? new List<string>(tests) : new List<string>();
            var listToRemove = new List<string>();

            foreach (var t in strategy.Tests)
            {
                var index = listTests.IndexOf(t.TestId);
                if (index < 0)
                    listToRemove.Add(t.TestId);
                else
                    listTests.RemoveAt(index);
            }

            if (listToRemove.Count > 0)
            {
                var testsToRemove = listToRemove.ToArray();
                await cabdb.StrategyTests
                    .DeleteAsync(t => t.StrategyId == strategy.Id && testsToRemove.Contains(t.TestId));
                //await ftdb.StrategyTests
                //    .DeleteAsync(t => t.StrategyId == strategy.Id && testsToRemove.Contains(t.TestId));
            }

            foreach (var t in listTests)
                await cabdb.InsertAsync(new Expert.Models.StrategyTest { StrategyId = strategy.Id, TestId = t });
            //await ftdb.InsertAsync(new Api.Models.StrategyTest { StrategyId = strategy.Id, TestId = t });

            if (listToRemove.Any() || listTests.Any())
            {
                await ftdb.StrategyTests.DeleteAsync(t => t.StrategyId == strategy.Id); // удалить лишние ручные записи

                foreach (var t in tests)
                    await ftdb.InsertAsync(new Api.Models.StrategyTest { StrategyId = strategy.Id, TestId = t });
            }
        }

        private async Task UpdateClientsAsync(Database db, Guid strategyId, BriefAgreementInfo[] clients)
        {
            var clientIds = clients
                .Select(c => c.Id)
                .Distinct()
                .ToArray();

            var existingClientIds = await db.StrategyClients
                .Where(c => c.StrategyId == strategyId)
                .Select(c => c.ClientId)
                .ToArrayAsync();

            var toRemove = existingClientIds
                .Where(c => !clientIds.Contains(c))
                .ToArray();
            if (toRemove.Length > 0)
                await db.StrategyClients
                    .DeleteAsync(c => c.StrategyId == strategyId && toRemove.Contains(c.ClientId));

            var toAdd = clientIds
                .Where(c => !existingClientIds.Contains(c))
                .ToArray();
            if (toAdd.Length > 0)
                foreach (var id in toAdd)
                    await db.InsertAsync(new StrategyClient { ClientId = id, StrategyId = strategyId });
        }

        private async Task AddFintargetStrategy(AggregateStrategy aggregateStrategy, DateTime time)
        {
            Debug.Assert(aggregateStrategy.Id.HasValue);

            var friendlyName = TranslitHelper.Instance().ConvertToEng(aggregateStrategy.Name) ?? string.Empty;

            var strategy = new Api.Models.Strategy
            {
                Id = aggregateStrategy.Id.Value,
                ParentStrategy = aggregateStrategy.ParentId,
                AuthorId = aggregateStrategy.ManagerId,
                Name = aggregateStrategy.Name,
                FriendlyUrl = friendlyName.Length > 128 ? friendlyName.Substring(0, 128) : friendlyName,
                Tag = aggregateStrategy.Tag,
                InfoHtml = aggregateStrategy.InfoHtml,
                DescriptionHtml = aggregateStrategy.DescriptionHtml,
                ChartComment = aggregateStrategy.ChartComment,
                PictureFormat = string.Empty, // obsolete
                ToolDrawndown = 0, // не используется
                CurrencyId = aggregateStrategy.Currency,
                MinInvestProfileId = aggregateStrategy.MinInvestProfileId,
                SubscriptionThreshold = aggregateStrategy.SubscriptionThreshold,
                EstimatedDrawdown = 0,
                EstimatedProfit = 0,
                // ActualProfit, ActualDrawdown - не заполняются
                IsPortfolio = false,
                DurationId = aggregateStrategy.DurationId,
                Open = aggregateStrategy.Open,
                Leverage = aggregateStrategy.Leverage,
                PlStartDate = aggregateStrategy.PlStartDate,
                MaxPositionWeight = aggregateStrategy.MaxPositionWeight,
                MaxIndustryWeight = aggregateStrategy.MaxIndustryWeight,
                MaxInstrumentFraq = aggregateStrategy.MaxPositionWeight,
                IsAlgostrategy = aggregateStrategy.IsAlgostrategy,
                Capacity = aggregateStrategy.Capacity,
                Recommended = aggregateStrategy.Recommended,
                Order = aggregateStrategy.Order,
                StartDate = aggregateStrategy.StartDate ?? new DateTime(1994, 1, 1),
                HidePortfolio = aggregateStrategy.HidePortfolio,
                HideRecentSignals = aggregateStrategy.HideRecentSignals,
                TestMode = aggregateStrategy.TestMode,
                Price = aggregateStrategy.Price,
                IIS = aggregateStrategy.IIS,
                IndexId = aggregateStrategy.IndexId,
                HideIndexOnChart = aggregateStrategy.HideIndexOnChart,
                HideIndexInWL = aggregateStrategy.HideIndexInWL,
                Autofollow = aggregateStrategy.Autofollow,
                Autoconsult = aggregateStrategy.Autoconsult,
                IsInvestbox = false,
                ForQualifiedInvestorsOnly = aggregateStrategy.ForQualifiedInvestorsOnly,
                //BackColor = #fixme соответствует "Цвет фона для МБ"
                ClosedForBinding = !aggregateStrategy.Open,
                Goal = aggregateStrategy.Goal,
                IsRestricted = aggregateStrategy.IsRestricted,
                Updated = aggregateStrategy.Open ? 1 : 0,
                UpdateLcs = 1,
                UpdateCs = true,
                UpdateTime = time,
                Securities = aggregateStrategy.Securities
            };

            using (var db = new Database())
            {
                using (var trn = await db.BeginTransactionAsync())
                {
                    if (await db.InsertAsync(strategy) == 0)
                        throw new ApplicationException(
                            $"{nameof(AddStrategy)} Insert cabinet strategy id=|{aggregateStrategy.Id}| returned zero");

                    if (aggregateStrategy.Open)
                        await db.InsertAsync(
                            new ShopfrontObject
                            {
                                ObjectType = "strategy",
                                ObjectId = aggregateStrategy.Id.Value
                            });

                    if (aggregateStrategy.Autofollow && aggregateStrategy.AfTariffId.HasValue)
                        await db.InsertAsync(
                            new TariffStrategy
                            {
                                Id = 0,
                                StrategyId = aggregateStrategy.Id.Value,
                                StrategyType = 1,
                                TariffId = aggregateStrategy.AfTariffId.Value,
                                UpdateTime = time
                            });
                    if (aggregateStrategy.Autoconsult && aggregateStrategy.AcTariffId.HasValue)
                        await db.InsertAsync(
                            new TariffStrategy
                            {
                                Id = 0,
                                StrategyId = aggregateStrategy.Id.Value,
                                StrategyType = 2,
                                TariffId = aggregateStrategy.AcTariffId.Value,
                                UpdateTime = time
                            });

                    await trn.CommitAsync();
                }
            }
        }

        private async Task<(int[] ToRemove, int[] ToAdd)> GetMarketsToUpdateAsync(
            Database ftdb,
            int[] marketIds,
            Guid strategyId)
        {
            var markets = await ftdb.StrategyMarkets
                .Where(s => s.StrategyId == strategyId)
                .ToArrayAsync();
            var toRemove = markets
                .Where(q => !marketIds.Contains(q.MarketId))
                .Select(q => q.MarketId)
                .ToArray();
            var toAdd = marketIds
                .Where(id => markets.All(q => q.MarketId != id))
                .ToArray();

            return (toRemove, toAdd);
        }

        private async Task<(int[] ToRemove, int[] ToAdd)> GetToolsToUpdateAsync(
            Database ftdb,
            int[] toolIds,
            Guid strategyId)
        {
            var tools = await ftdb.StrategyTools
                .Where(s => s.StrategyId == strategyId)
                .ToArrayAsync();
            var toRemove = tools
                .Where(q => !toolIds.Contains(q.ToolId))
                .Select(q => q.ToolId)
                .ToArray();
            var toAdd = toolIds
                .Where(id => tools.All(q => q.ToolId != id))
                .ToArray();

            return (toRemove, toAdd);
        }

        private async Task<(int[] ToRemove, int[] ToAdd)> GetBoardsToUpdateAsync(
            Database ftdb,
            int[] boardIds,
            Guid strategyId)
        {
            var boards = await ftdb.StrategyBoards
                .Where(s => s.StrategyId == strategyId)
                .ToArrayAsync();
            var toRemove = boards
                .Where(q => !boardIds.Contains(q.BoardId))
                .Select(q => q.BoardId)
                .ToArray();
            var toAdd = boardIds
                .Where(id => boards.All(q => q.BoardId != id))
                .ToArray();

            return (toRemove, toAdd);
        }

        private Guid CreateStrategyId()
        {
            return Guid.NewGuid();
        }

        private async Task PostLcsStrategy(AggregateStrategy strategy, bool pushToCs)
        {
            Debug.Assert(strategy.Id.HasValue);

            string[] securities = null;
            var sec = strategy.Securities;

            if (sec != null)
                try
                {
                    securities = JsonConvert.DeserializeObject<string[]>(sec);
                }
                catch (Exception e)
                {
                    Logger?.LogWarning($"UpdateStrategy id=|{strategy.Id}| deserialize securities {e.Message}");
                }

            var lcsStrategy = new LCS.Models.Strategy
            {
                Active = strategy.Active,
                AllowedSecurities = securities ?? new string[0],
                Created = strategy.CreationDate,
                CreatorId = strategy.CreatorId,
                Currency = strategy.Currency,
                Description = null,
                Id = strategy.Id.Value,
                ManagerId = strategy.ManagerId,
                Leverage = strategy.Leverage,
                IsAutoconsult = strategy.Autoconsult,
                IsAutofollow = strategy.Autofollow,
                IsInvestbox = false,
                IsPortfolio = strategy.IsPortfolio,
                ParentStrategy = strategy.ParentId,
                RecalcMode = strategy.RecalcMode,
                Title = strategy.Name,
                MinSumm = strategy.SubscriptionThreshold,
                // leverage comission rates
                ShortComiss = (decimal?)strategy.RateShort,
                LongComiss = (decimal?)strategy.RateLong,
                ProfileId = strategy.MinInvestProfileId,
                TradeType = strategy.TradeType,
                RequiredTests = strategy.Tests ?? Array.Empty<string>()
            };

            if (_lcs != null)
            {
                if (!await _lcs.SetStrategy(lcsStrategy))
                    throw new ApplicationException("UpdateStrategy to LCS service failed");

                if (pushToCs)
                    if (!await _lcs.PushToCS(strategy.Id.Value))
                        throw new ApplicationException($"Push to CS api call failed, id=|{strategy.Id.Value}|");
            }
        }

        // POST: /api/admin/strategies/publishToEva
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpPost("publishToEva")]
        public async Task<ActionResult<RequestResult>> PublishToEva([FromBody] Guid Id)
        {
            try
            {
                using var db = new Expert.Models.Database();
                using var ftDb = new Database();

                var strategy = (await ftDb.Strategies
                    .Where(c => c.Id == Id).FirstOrDefaultAsync())
                    ?? throw new Exception($"Стратегия {Id} не найдена");
                if (!strategy.MinInvestProfileId.HasValue || !ApiHelpers.StrategyCatalogHelper.EvaRiskProfileCodes.TryGetValue(strategy.MinInvestProfileId.Value, out var riskProfileCode))
                {
                    throw new UserVisibleException("Не задан минимальный инвест-профиль стратегии");
                }

                var evaParams = await db.StrategyEvaParams.Where(c => c.StrategyId == Id).FirstOrDefaultAsync() ?? new StrategyEvaParams();

                var request = new ApiHelpers.PostStrategyCatalogRq
                {
                    nameStrategy = strategy.Name,
                    riskProfileCode = riskProfileCode,
                    currencyCode = strategy.CurrencyId switch
                    {
                        "USD" => 840,
                        "SUR" => 643,
                        "HKD" => 344,
                        _ => throw new ArgumentException("Unknown Currency code=" + strategy.Currency)
                    },
                    isActual = strategy.Open,
                    stockMarketMMVB = evaParams.StockMarketMMVB,
                    fortsRTS = evaParams.FortsRTS,
                    creditGO = evaParams.CreditGO,
                    currencyMarket = evaParams.CurrencyMarket,
                    spbRTS = evaParams.SpbRTS,
                    currencyMarketEBS = evaParams.CurrencyMarketEBS,
                    stockMarketOffexchange = evaParams.StockMarketOffexchange,
                    mmvbUSD = evaParams.MmvbUSD,
                    fortsRTSEBS = evaParams.FortsRTSEBS,
                    lse = evaParams.Lse,
                    usMarkets = evaParams.UsMarkets,
                    isQualification = strategy.ForQualifiedInvestorsOnly,
                    brokerStrategyTypes = GetBrokerStrategyTypes(strategy),
                    minSum = strategy.SubscriptionThreshold,
                    brokerRateStrategies = Config.EvaBrokerRateStrategies
                    .Select(s => new ApiHelpers.BrokerRateStrategy { brokerRateStrategyID = s })
                    .ToArray()
                };

                await _evaApi.CreateStrategyAsync(Id, request);
                await db.StrategyEvaParams.InsertOrUpdateAsync(
                    () => new StrategyEvaParams { StrategyId = Id, EvaUpdatedAt = DateTime.Now },
                    c => new StrategyEvaParams { StrategyId = Id, EvaUpdatedAt = DateTime.Now });
                return Success();
            }
            catch (ApiHelpers.ApiException ex)
            {
                return Error(ex.Message);
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        private static ApiHelpers.BrokerStrategyType[] GetBrokerStrategyTypes(Api.Models.Strategy strategy)
        {
            var brokerStrategyTypes = new List<ApiHelpers.BrokerStrategyType>();
            if (strategy.Autofollow)
            {
                brokerStrategyTypes.Add(new ApiHelpers.BrokerStrategyType { brokerStrategyTypeID = 1 });
            }
            if (strategy.Autoconsult)
            {
                brokerStrategyTypes.Add(new ApiHelpers.BrokerStrategyType { brokerStrategyTypeID = 2 });
            }

            return brokerStrategyTypes.ToArray();
        }

        // POST: /api/admin/strategies/updateInEva
        [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
        [HttpPost("updateInEva")]
        public async Task<ActionResult<RequestResult>> UpdateInEva([FromBody] Guid strategyId)
        {
            try
            {
                using var ftDb = new Database();

                var strategy = (await ftDb.Strategies
                    .Where(c => c.Id == strategyId).FirstOrDefaultAsync())
                    ?? throw new Exception($"Стратегия {strategyId} не найдена");

                var request = new ApiHelpers.StrategyCatalogRq
                {
                    isActual = strategy.Open,
                    isQualification = strategy.ForQualifiedInvestorsOnly,
                    minSum = strategy.SubscriptionThreshold,
                    brokerStrategyTypes = GetBrokerStrategyTypes(strategy),
                    brokerRateStrategies = Config.EvaBrokerRateStrategies
                    .Select(s => new ApiHelpers.BrokerRateStrategy { brokerRateStrategyID = s })
                    .ToArray()
                };

                await _evaApi.ModifyStrategyAsync(strategyId, request);

                using var db = new Expert.Models.Database();
                await db.StrategyEvaParams.InsertOrUpdateAsync(
                    () => new StrategyEvaParams { StrategyId = strategyId, EvaUpdatedAt = DateTime.Now },
                    c => new StrategyEvaParams { StrategyId = strategyId, EvaUpdatedAt = DateTime.Now });
                return Success();
            }
            catch (ApiHelpers.ApiException ex)
            {
                return Error(ex.Message);
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

    }
}