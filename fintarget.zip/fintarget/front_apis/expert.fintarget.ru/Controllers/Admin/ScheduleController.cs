﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Expert.Models;
using fin_expert.Models;
using fin_expert.Utilities;
using HS.Models;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NLib.AuxTypes;
using ServiceBase;
using Database = HS.Models.Database;
using TradeTime = fin_expert.Models.TradeTime;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
    [ApiController]
    public class ScheduleController : WebCabinetController<ScheduleController>
    {
        public ScheduleController(IServiceProvider provider, ILogger<ScheduleController> logger) : base(provider, logger)
        {
        }

        // GET api/admin/schedule
        [HttpGet]
        public async Task<ActionResult<RequestResult<MarketSchedule[]>>> GetSchedule()
        {
            Logger.LogInformation("GetSchedule all");

            try
            {
                var currentDate = DateTime.Now.Date;

                using (var db = new Database())
                {
                    var markets = await db.ScheduleMarkets.ToArrayAsync();
                    var allTimes = await db.Schedules.ToArrayAsync();
                    var weekends = await db.ScheduleWeekends
                        .Where(s => s.Date >= currentDate)
                        .OrderBy(s => s.Date)
                        .ToArrayAsync();

                    var mapTimes = allTimes
                        .GroupBy(s => new KeyValuePair<int, SchedType>(s.Id, s.Type))
                        .ToDictionary(s => s.Key, s => s.Max(t => t.SaveTime));

                    var result = markets
                        .Select(m =>
                            new MarketSchedule
                            {
                                Id = m.Id,
                                ClassCodes = m.ClassCodes.Split(',').Select(c => c.Trim()).ToArray(),
                                Name = m.Name
                            })
                        .ToArray();

                    //#fixme переделать на правильный запрос из hs db
                    foreach (var market in result)
                    {
                        if (mapTimes.TryGetValue(new KeyValuePair<int, SchedType>(market.Id, SchedType.trade),
                                out var saveTime))
                            market.TradeTimes = allTimes
                                .Where(t => t.Id == market.Id && t.Type == SchedType.trade && t.SaveTime == saveTime)
                                .Select(t => new TradeTime
                                {
                                    Start = t.Start.ToString(),
                                    End = t.End.ToString(),
                                    Description = t.Description
                                })
                                .ToArray();
                        else
                            market.TradeTimes = new TradeTime[0];


                        if (mapTimes.TryGetValue(new KeyValuePair<int, SchedType>(market.Id, SchedType.signal),
                                out saveTime))
                            market.SignalTimes = allTimes
                                .Where(t => t.Id == market.Id && t.Type == SchedType.signal && t.SaveTime == saveTime)
                                .Select(t => new TradeTime { Start = t.Start.ToString(), End = t.End.ToString(), Description = t.Description })
                                .ToArray();
                        else
                            market.SignalTimes = new TradeTime[0];

                        if (mapTimes.TryGetValue(new KeyValuePair<int, SchedType>(market.Id, SchedType.rebalance),
                                out saveTime))
                            market.RebalanceTimes = allTimes
                                .Where(t => t.Id == market.Id && t.Type == SchedType.rebalance && t.SaveTime == saveTime)
                                .Select(t => new TradeTime
                                {
                                    Start = t.Start.ToString(),
                                    End = t.End.ToString(),
                                    Description = t.Description
                                })
                                .ToArray();
                        else
                            market.RebalanceTimes = new TradeTime[0];

                        market.Weekends = weekends
                            .Where(s => s.Id == market.Id)
                            .Select(s => new Weekend { Id = s.Id, Day = s.Date.ToString("dd.MM.yyyy") })
                            .Distinct(new WeekendComparer())
                            .ToArray();
                    }

                    return Success(result);
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }
        
        // GET api/admin/schedule/forbidden
        [HttpGet("forbidden")]
        public async Task<ActionResult<RequestResult<Security[]>>> GetForbidden()
        {
            try
            {
                using (var db = new Database())
                {
                    var result = await db.Forbidden.InnerJoin(db.Securities,
                            (f, s) => f.SecurityId == s.Id,
                            (f, s) => new Security
                            {
                                Key = s.Key,
                                ClassCode = s.ClassCode,
                                Name = s.Name
                            })
                        .ToArrayAsync();

                    return Success(result);
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // GET api/admin/schedule/codes
        [HttpGet("codes")]
        public async Task<ActionResult<RequestResult<string[]>>> GetClassCodes()
        {
            try
            {
                using (var db = new Database())
                {
                    var result = await db.ClassCodes
                        .Where(c => !string.IsNullOrEmpty(c.Code))
                        .Select(c => c.Code)
                        .Distinct()
                        .ToArrayAsync();

                    return Success(result
                        .Select(c => c.Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault())
                        .Where(c => !string.IsNullOrEmpty(c))
                    );
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // POST api/admin/schedule/add
        [HttpPost("add")]
        public async Task<ActionResult<RequestResult<MarketSchedule>>> AddTimes(MarketSchedule schedule)
        {
            if (schedule == null)
                return Error("Ошибка - переданы нулевые данные");

            Logger?.LogInformation($"AddTimes id={schedule.Id} name=|{schedule.Name}|");

            try
            {
                var updateTime = DateTime.Now;

                using (var db = new Database())
                {
                    using (var trn = db.BeginTransaction())
                    {
                        if (schedule.Id <= 0)
                        {
                            schedule.Id = await db.InsertWithInt32IdentityAsync(
                                new ScheduleMarket
                                {
                                    Name = schedule.Name ?? string.Empty,
                                    ClassCodes = string.Join(',', schedule.ClassCodes ?? new string[0]),
                                    UpdateTime = updateTime
                                });
                        }
                        else
                        {
                            var updated = await db.ScheduleMarkets
                                .Where(s => s.Id == schedule.Id && s.UpdateTime <= updateTime)
                                .AsUpdatable()
                                .Set(s => s.Name, s => string.IsNullOrEmpty(schedule.Name) ? s.Name : schedule.Name)
                                .Set(s => s.ClassCodes,
                                    s => schedule.ClassCodes != null ? string.Join(',', schedule.ClassCodes) : s.ClassCodes)
                                .Set(s => s.UpdateTime, updateTime)
                                .UpdateAsync();
                            if (updated == 0)
                                return Error("Расписание устарело или было изменено другими пользователями");
                        }

                        if (schedule.TradeTimes != null)
                            foreach (var t in schedule.TradeTimes)
                                await db.InsertAsync(
                                    new ScheduleTime
                                    {
                                        Id = schedule.Id,
                                        Type = SchedType.trade,
                                        Start = TimeSpan.Parse(t.Start),
                                        End = TimeSpan.Parse(t.End),
                                        Description = t.Description,
                                        SaveTime = updateTime
                                    });
                        if (schedule.SignalTimes != null)
                            foreach (var t in schedule.SignalTimes)
                                await db.InsertAsync(
                                    new ScheduleTime
                                    {
                                        Id = schedule.Id,
                                        Type = SchedType.signal,
                                        Start = TimeSpan.Parse(t.Start),
                                        End = TimeSpan.Parse(t.End),
                                        Description = t.Description,
                                        SaveTime = updateTime
                                    });
                        if (schedule.RebalanceTimes != null)
                            foreach (var t in schedule.RebalanceTimes)
                                await db.InsertAsync(
                                    new ScheduleTime
                                    {
                                        Id = schedule.Id,
                                        Type = SchedType.rebalance,
                                        Start = TimeSpan.Parse(t.Start),
                                        End = TimeSpan.Parse(t.End),
                                        Description = t.Description,
                                        SaveTime = updateTime
                                    });

                        if (schedule.RemoveForbiddenSecurities != null)
                        {
                            var toRemove = await db.Securities
                                .Where(s => schedule.RemoveForbiddenSecurities.Contains(s.Key))
                                .Select(s => s.Id)
                                .ToArrayAsync();

                            if (toRemove.Any())
                            {
                                var removed = await db.Forbidden.DeleteAsync(s => toRemove.Contains(s.SecurityId));

                                Logger?.LogTrace($"Forbidden " +
                                                 $"removed=[{string.Concat(";", schedule.RemoveForbiddenSecurities)}] " +
                                                 $"count={removed.ToString()}");
                            }
                        }

                        if (schedule.AddForbiddenSecurities != null)
                        {
                            var toAdd = await db.Securities
                                .Where(s => schedule.AddForbiddenSecurities.Contains(s.Key))
                                .ToArrayAsync();

                            foreach (var sec in toAdd)
                                await db.InsertAsync(new ForbiddenSecurity {SecurityId = sec.Id});
                            
                            Logger?.LogTrace($"Forbidden added=[{string.Join(";", schedule.AddForbiddenSecurities)}");
                        }

                        trn.Commit();
                    }
                }

                await StoreAuditActionAsync(AuditRecord.Actions.UpdateSchedule, new { Info = "Schedule updated", Schedule = schedule });
                return Success(schedule);
            }
            catch (Exception e)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.UpdateSchedule, new { Info = "Failed to update schedule", Schedule = schedule, Error = e.Message });
                return Error(e);
            }
        }

        // POST api/admin/schedule/remove/:id
        [HttpPost("remove/{id}")]
        public async Task<ActionResult<RequestResult<MarketSchedule>>> RemoveTimes(int id)
        {
            try
            {
                ScheduleTime[] removedTimes = null;
                ScheduleMarket[] removedMarkets = null;

                using (var db = new Database())
                {
                    using (var trn = db.BeginTransaction())
                    {
                        removedTimes = await db.Schedules.Where(s => s.Id == id).DeleteWithOutputAsync();
                        removedMarkets = await db.ScheduleMarkets.Where(s => s.Id == id).DeleteWithOutputAsync();
                        trn.Commit();
                    }
                }

                Logger?.LogInformation($"Removed schedules id={id} count={removedTimes.Count()}");
                Logger?.LogInformation($"Removed schedule markets=|{string.Join(",", removedMarkets.Select(s => s.Name))}|");

                return Success(removedMarkets.FirstOrDefault());
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // POST api/admin/schedule/weekend
        [HttpPost("weekend")]
        public async Task<ActionResult<RequestResult>> AddWeekend(Weekend weekend)
        {
            if (weekend == null)
                return Error("Ошибка - переданы нулевые данные");
            if (weekend.Id <= 0)
                return Error("Ошибка - не указана торговая площадка");

            Logger?.LogInformation($"Add weekend id={weekend.Id} name=|{weekend.Day}|");

            var updateTime = DateTime.Now;

            try
            {
                using (var db = new Database())
                {
                    using (var trn = db.BeginTransaction())
                    {
                        var market = await db.ScheduleMarkets.FirstOrDefaultAsync(s => s.Id == weekend.Id);
                        if (market == null)
                            return Error("Ошибка - неизвестная торговая площадка");

                        await db.InsertAsync(new ScheduleWeekend
                        {
                            Id = weekend.Id,
                            Date = DateTime.ParseExact(weekend.Day, "dd.MM.yyyy", null).Date,
                            Type = SchedType.trade,
                            SaveTime = updateTime,
                        });

                        await db.InsertAsync(new ScheduleWeekend
                        {
                            Id = weekend.Id,
                            Date = DateTime.ParseExact(weekend.Day, "dd.MM.yyyy", null).Date,
                            Type = SchedType.signal,
                            SaveTime = updateTime,
                        });

                        await db.InsertAsync(new ScheduleWeekend
                        {
                            Id = weekend.Id,
                            Date = DateTime.ParseExact(weekend.Day, "dd.MM.yyyy", null).Date,
                            Type = SchedType.rebalance,
                            SaveTime = updateTime,
                        });

                        trn.Commit();
                    }
                }

                await StoreAuditActionAsync(AuditRecord.Actions.UpdateSchedule, new { Info = "Holiday added", Weekend = weekend });
                return Success();
            }
            catch(Exception e)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.UpdateSchedule, new { Info = "Failed to add holiday", Weekend = weekend, Error = e.Message });
                return Error(e);
            }
        }

        // DELETE api/admin/schedule/weekend
        [HttpDelete("weekend")]
        public async Task<ActionResult<RequestResult>> RemoveWeekend(Weekend weekend)
        {
            if (weekend == null)
                return Error("Ошибка - переданы нулевые данные");

            Logger?.LogInformation($"Remove weekend id={weekend.Id} name=|{weekend.Day}|");

            try
            {
                var date = DateTime.Parse(weekend.Day).Date;

                using (var db = new Database())
                {
                    var result = await db.ScheduleWeekends
                        .Where(s => s.Id == weekend.Id && s.Date == date)
                        .DeleteAsync();

                    if (result == 0)
                    {
                        throw new UserVisibleException($"Ошибка - запись {weekend.Day} не найдена");
                    }
                    await StoreAuditActionAsync(AuditRecord.Actions.UpdateSchedule, new { Info = "Holiday removed", Weekend = weekend });

                    return Success();
                }
            }
            catch (Exception e)
            {
                Logger?.LogError(e, nameof(RemoveWeekend));
                await StoreAuditActionAsync(AuditRecord.Actions.UpdateSchedule, new { Info = "Failed to remove holiday", Weekend = weekend, Error = e.Message });
                return Error(e);
            }
        }
    }
}