﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Api.Models;
using CS.Balance;
using CS.Balance.Interfaces;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NLib.ParsersFormatters;
using PS.Models;
using ServiceBase;
using Database = Api.Models.Database;
using Portfolio = PS.Models.Portfolio;

namespace fin_expert.Controllers
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator,DigitalExpert,Developer")]
    public class PortfolioController : WebCabinetController<PortfolioController>
    {
        private readonly AppConfig _connfig;
        private readonly PortfolioBalancer _portfolioBalancer;
        private readonly ISecurityCache _securityCache;

        public PortfolioController(IServiceProvider serviceProvider, ILogger<PortfolioController> logger,
            ISecurityCache securityCache,
            PortfolioBalancer portfolioBalancer,
            AppConfig config)
            : base(serviceProvider, logger)
        {
            _securityCache = securityCache;
            _portfolioBalancer = portfolioBalancer;
            _connfig = config;
        }

        // POST: /api/admin/portfolio/statistics
        [HttpPost("statistics")]
        [Authorize(Roles = "Administrator,DigitalExpert")]
        public async Task<ActionResult<RequestResult<PortfolioStatistics>>> GetStatistics(PortfolioStatisticsRequest request)
        {
            var fromDate = request.FromDate.Date;
            var toDate = request.ToDate.Date.AddDays(1);
            var result = new PortfolioStatistics();
            try
            {
                using (var db = new PortfolioDatabase())
                {
                    result.UniqueListViews = await db.HistoryListViews.Where(c => c.RequestDate >= fromDate && c.RequestDate < toDate).Select(c => c.ClientId)
                        .Distinct().CountAsync();
#pragma warning disable 0472
                    result.Entries = await (from p in db.Portfolios
                        from e in db.ExecutionRequests.Where(c => c.Created >= fromDate && c.Created < toDate).LeftJoin(c => c.PortfolioId == p.Id)
                        group new { p, e } by new { p.Id, p.Name, p.OrderNum, p.Currency }
                        into grp
                        orderby grp.Key.OrderNum
                        select new PortfolioStatisticsEntry
                        {
                            Id = grp.Key.Id,
                            Name = grp.Key.Name,
                            PurchaseAttempts = grp.Count(c => c.e.PacketOrderId != null),
                            Purchases = grp.Sum(c => c.e.Purchased ? 1 : 0),
                            Currency = grp.Key.Currency,
                            PurchaseSumInRubles = Math.Round(grp.Sum(c => c.e.Purchased ? c.e.SumInRubles ?? 0 : 0), 2)
                        }).ToArrayAsync();
#pragma warning restore 0472
                    var purchaseSums = await (from p in db.Portfolios
                        from e in db.ExecutionRequests.LeftJoin(c => c.PortfolioId == p.Id)
                        from ep in db.ExecutionRequestPositions.LeftJoin(c => c.PacketOrderId == e.PacketOrderId)
                        where e.Created >= fromDate && e.Created < toDate && e.Purchased
                        group new { p, e, ep } by p.Id
                        into grp
                        select new
                        {
                            Id = grp.Key,
                            PurchaseSum = grp.Sum(c => c.ep.Price * c.ep.Quantity)
                        }).ToDictionaryAsync(c => c.Id, c => c.PurchaseSum);
                    var views = await (from p in db.Portfolios
                            join r in db.HistoryRecords.Where(c => c.FirstRequest >= fromDate && c.FirstRequest < toDate) on p.Id equals r.PortfolioId
                            group new { p, r } by p.Id
                            into grouping
                            select new { grouping.Key, Views = grouping.CountExt(c => c.r.ClientId, Sql.AggregateModifier.Distinct) })
                        .ToDictionaryAsync(c => c.Key, c => c.Views);
                    foreach (var entry in result.Entries)
                    {
                        if (purchaseSums.TryGetValue(entry.Id, out var sum)) entry.PurchaseSum = Math.Round(sum, 2);
                        if (views.TryGetValue(entry.Id, out var cnt)) entry.UniqueViewers = cnt;
                    }
                }

                return Success(result);
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: Portfolio
        [HttpGet("csv")]
        [Authorize(Roles = "Administrator")]
        public FileResult Csv(DateTime fromDate, DateTime toDate)
        {
            using (var stream = new MemoryStream())
            {
                using (var writer = new StreamWriter(stream, Encoding.Unicode))
                {
                    //                    writer.WriteLine("sep=,");
                    writer.WriteLine(
                        "Id\tFirst request\tLast request\tClient id\tClient\tPortfolio\tCurrency\tFree funds\tLiquid price\tWas purchased\tAgreement\tPortfolio price");
                    using (var db = new PortfolioDatabase())
                    using (var apiDb = new Database())
                    {
                        var rows = (from h in db.HistoryRecords
                            join p in db.Portfolios on h.PortfolioId equals p.Id
                            from e in db.ExecutionRequests.LeftJoin(c => c.HistoryRecordId == h.Id && c.Purchased)
                            from ep in db.ExecutionRequestPositions.LeftJoin(c => c.PacketOrderId == e.PacketOrderId)
                            where h.FirstRequest >= fromDate && h.LastRequest <= toDate
                            group ep by new { h, p, e, ep.PacketOrderId }
                            into g
                            select new
                            {
                                g.Key.h.Id,
                                g.Key.h.FirstRequest,
                                g.Key.h.LastRequest,
                                g.Key.h.ClientId,
                                Portfolio = g.Key.p.Name,
                                g.Key.h.FreeFunds,
                                g.Key.h.LiquidPrice,
                                g.Key.p.Currency,
                                WasPurchased = g.Key.e.Purchased,
                                g.Key.e.AgreementId,
                                PortfolioPrice = g.Sum(c => c.Price * c.Quantity)
                            }).ToArray();

                        var clients = new Dictionary<Guid, Client>();
                        foreach (var client in apiDb.Clients.Where(c => rows.Select(r => r.ClientId).Contains(c.Id))) clients[client.Id] = client;
                        var accounts = new Dictionary<Guid, ClientAccount>();
                        foreach (var account in apiDb.ClientAccounts.Where(c => rows.Select(r => r.AgreementId).Contains(c.AgreementId)))
                            accounts[account.AgreementId] = account;
                        foreach (var row in rows)
                        {
                            clients.TryGetValue(row.ClientId, out var client);
                            accounts.TryGetValue(row.AgreementId, out var agreement);
                            writer.WriteLine(
                                $"{row.Id}\t{row.FirstRequest}\t{row.LastRequest}\t{row.ClientId}\t{Escape(client?.FirstName)} {Escape(client?.MiddleName)} {Escape(client?.LastName)}\t{Escape(row.Portfolio)}\t{row.Currency}\t{row.FreeFunds}\t{row.LiquidPrice}\t{row.WasPurchased}\t{Escape(agreement?.AgreementName)}\t{row.PortfolioPrice}");
                        }
                    }
                }

                return new FileContentResult(stream.GetBuffer(), "text/csv")
                {
                    FileDownloadName = $"PortfolioReport {fromDate:yyyyMMdd} - {toDate:yyyyMMdd}.csv"
                };
            }
        }

        private string Escape(string lastName)
        {
            return lastName?.Replace('\t', ' ').Replace("\r\n", " ").Replace('\r', ' ').Replace('\n', ' ').Trim();
        }

        // POST: /api/admin/portfolio
        [HttpPost]
        [Authorize(Roles = "Administrator,DigitalExpert,Developer")]
        public async Task<ActionResult<RequestResult<PortfolioPage>>> Get(PaginationAndSort paginationAndSort)
        {
            try
            {
                using (var db = new PortfolioDatabase())
                {
                    var total = await db
                        .Portfolios
                        .CountAsync();

                    var portfolios = db
                        .Portfolios
                        .LoadWith(p => p.Positions);

                    var result = await
                        SortPortfolios(portfolios, paginationAndSort).ThenOrBy(c => c.Id)
                            .Skip(paginationAndSort.PageNumber * paginationAndSort.PageSize)
                            .Take(paginationAndSort.PageSize)
                            .Select(c => new PortfolioDto
                            {
                                Active = c.Active,
                                Annotation = c.Annotation,
                                Currency = c.Currency,
                                Description = c.Description,
                                ForecastSourceId = c.ForecastSourceId,
                                Id = c.Id,
                                ImageUrl = c.ImageUrl,
                                Name = c.Name,
                                OrderNum = c.OrderNum,
                                Positions = c.Positions.Select(p => new PortfolioDto.PortfolioPosition
                                {
                                    OrderNum = p.OrderNum,
                                    SecurityKey = p.SecurityKey,
                                    Weight = p.Weight
                                }).ToArray()
                            })
                            .ToArrayAsync();

                    var forecasts = await db.SecurityForecasts.ToDictionaryAsync(c => (c.SecurityKey, c.SourceId), c => c.Forecast);

                    foreach (var p in result)
                    {
                        var errors = new List<string>();
                        try
                        {
                            var strategy = CreateStrategy(p);

                            var minBalance = _portfolioBalancer.CalcMinSum(strategy);
                            p.MinBalance = Math.Round(
                                _portfolioBalancer.BalanceClientToMatchStrategy(new PortfolioClient(minBalance), strategy).Sum(c => c.AvgPrice * c.Number),
                                2);
                        }
                        catch (Exception ex)
                        {
                            Logger.LogWarning(ex, $"Can't calculate min balance for portfolio '{p.Name}'");
                            errors.Add(ex.Message);
                        }

                        var psum = p.Positions.Sum(p => p.Weight);
                        if (psum != 1) errors.Add($"Сумма весов позиций равна {Math.Round(psum, 2)}");

                        p.Forecast = (p.Positions.Sum(c =>
                            forecasts.TryGetValue((c.SecurityKey, p.ForecastSourceId), out var forecast) ? c.Weight * forecast : 0) * 100m).RoundTo(2);
                        foreach (var pos in p.Positions)
                            pos.Weight = pos.Weight * 100m;
                        p.ErrorMessage = errors.Count > 0 ? string.Join('\n', errors) : null;
                    }

                    return Success(new PortfolioPage
                    {
                        Total = total,
                        PageItems = result
                    });
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private IStrategyInfo CreateStrategy(PortfolioDto portfolio)
        {
            var strat = new PortfolioStrategy(portfolio.Currency);

            foreach (var pos in portfolio.Positions)
            {
                var security = _securityCache.GetSecuritiy(pos.SecurityKey);
                if (security == null) throw new Exception($"SecurityKey '{pos.SecurityKey}' not found");
                strat.Positions.Add(
                    pos.SecurityKey,
                    new PortfolioStrategy.PortfolioStrategyPosition(
                        new PortfolioSecurityProxy(security, _connfig.PortfolioPriceMultiplier),
                        pos.Weight
                    )
                );
            }

            return strat;
        }

        // POST: /api/admin/portfolio/edit
        [HttpPost("edit")]
        [Authorize(Roles = "Administrator,DigitalExpert")]
        public async Task<ActionResult<RequestResult>> Edit(PortfolioDto portfolioDto)
        {
            try
            {
                using (var db = new PortfolioDatabase())
                {
                    var portfolio = new Portfolio
                    {
                        Id = portfolioDto.Id,
                        Active = portfolioDto.Active,
                        Annotation = portfolioDto.Annotation,
                        Currency = portfolioDto.Currency,
                        Description = portfolioDto.Description,
                        ForecastSourceId = portfolioDto.ForecastSourceId,
                        ImageUrl = portfolioDto.ImageUrl,
                        Name = portfolioDto.Name,
                        OrderNum = portfolioDto.OrderNum
                    };
                    var isNew = portfolio.Id == default;
                    if (isNew) portfolio.Id = Guid.NewGuid();
                    var positions = portfolioDto.Positions.Select(c => new PortfolioPosition
                    {
                        OrderNum = c.OrderNum,
                        PortfolioId = portfolio.Id,
                        SecurityKey = c.SecurityKey,
                        Weight = c.Weight / 100m
                    });
                    var targets = portfolioDto.Positions.Select(c => new { c.SecurityKey, c.TargetPrice }).Where(c => c.TargetPrice != null);

                    using (var trans = await db.BeginTransactionAsync())
                    {
                        if (isNew)
                        {
                            portfolio.Active = false; // first save in inactive state
                            await db.InsertAsync(portfolio);
                        }
                        else
                        {
                            await db.PortfolioPositions.DeleteAsync(p => p.PortfolioId == portfolio.Id);
                            await db.UpdateAsync(portfolio);
                        }

                        foreach (var p in positions) await db.InsertAsync(p);
                        foreach (var t in targets)
                        {
                            var currentPrice = _securityCache.GetSecuritiy(t.SecurityKey)?.LastPrice;
                            if (currentPrice == 0) currentPrice = null;
                            var forecast = t.TargetPrice / currentPrice - 1 ?? 0;
                            if (t.TargetPrice == 0) forecast = 0;
                            await db.SecurityForecasts.InsertOrUpdateAsync(
                                () => new SecurityForecast
                                {
                                    SecurityKey = t.SecurityKey,
                                    SourceId = portfolio.ForecastSourceId,
                                    ForecastDate = DateTime.Now,
                                    TargetPrice = t.TargetPrice,
                                    CurrentPrice = currentPrice,
                                    Forecast = forecast
                                }, c => new SecurityForecast
                                {
                                    ForecastDate = c.IsFixedForecast ? c.ForecastDate : DateTime.Now,
                                    TargetPrice = c.IsFixedForecast ? c.TargetPrice : t.TargetPrice,
                                    CurrentPrice = c.IsFixedForecast ? c.CurrentPrice : currentPrice,
                                    Forecast = c.IsFixedForecast ? c.Forecast : forecast
                                });
                        }

                        await trans.CommitAsync();
                    }

                    return Success();
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: /api/admin/portfolio/forecasts
        [HttpGet("forecasts")]
        [Authorize(Roles = "Administrator,DigitalExpert,Developer")]
        public async Task<ActionResult<RequestResult<SecurityForecastsSource[]>>> GetForecastSources()
        {
            try
            {
                using (var db = new PortfolioDatabase())
                {
                    return Success(await db.SecurityForecastSources.ToArrayAsync());
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private static IQueryable<Portfolio> SortPortfolios(IQueryable<Portfolio> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName?.ToLower())
            {
                case "name":
                    return OrderQueryBy(query, p => p.Name, paginationAndSort.SortDirection);
                case "annotation":
                    return OrderQueryBy(query, p => p.Annotation, paginationAndSort.SortDirection);
                case "description":
                    return OrderQueryBy(query, p => p.Description, paginationAndSort.SortDirection);
                case "active":
                    return OrderQueryBy(query, p => p.Active, paginationAndSort.SortDirection);
                case "currency":
                    return OrderQueryBy(query, p => p.Currency, paginationAndSort.SortDirection);
                case "ordernum":
                    return OrderQueryBy(query, p => p.OrderNum, paginationAndSort.SortDirection);
                default:
                    return query;
            }
        }
    }
}