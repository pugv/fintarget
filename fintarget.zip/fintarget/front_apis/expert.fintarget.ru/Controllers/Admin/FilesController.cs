﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using fin_expert.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceBase;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator,DigitalExpert,ContentManager")]
    public class FilesController
        : WebCabinetController<FilesController>
    {
        public static long MaxFileSize = 800000;
        public static string[] AllowedExtentions = { ".jpg", ".pdf" };

        public static Dictionary<string, byte[]> Signatures = new Dictionary<string, byte[]>
        {
            { ".jpg", new byte[] { 0xFF, 0xD8 } },
            { ".png", new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A } },
            { ".pdf", new byte[] { 0x25, 0x50, 0x44, 0x46 } }
        };

        public FilesController(IServiceProvider serviceProvider, ILogger<FilesController> logger)
            : base(serviceProvider, logger)
        {
        }

        [ProducesResponseType(typeof(RequestResult<UploadedFile>), 200)]
        [ProducesResponseType(500)]
        [HttpPost("upload")]
        public Task<IActionResult> UploadFile(IFormFile file)
        {
            return DoUploadFile(file, Config.UploadedFilesLocation);
        }

        [ProducesResponseType(typeof(RequestResult<UploadedFile>), 200)]
        [ProducesResponseType(500)]
        [HttpPost("upload_pf")]
        public Task<IActionResult> UploadFileForPortfolio(IFormFile file)
        {
            return DoUploadFile(file, Config.UploadedPortfolioFilesLocation);
        }

        [ProducesResponseType(typeof(RequestResult<UploadedFile>), 200)]
        [ProducesResponseType(500)]
        [HttpPost("upload_author")]
        public Task<IActionResult> UploadFileForAuthors(IFormFile file)
        {
            return DoUploadFile(file, Config.UploadedAuthorsFilesLocation);
        }

        private bool CheckSignature(string ext, byte[] content)
        {
            if (Signatures.TryGetValue(ext, out var sig))
                return sig.Select((c, i) => content[i] == c).All(v => v);
            return true;
        }

        private async Task<IActionResult> DoUploadFile(IFormFile file, string fileLocation)
        {
            if (file.Length > MaxFileSize) return Error($"File exeeds {MaxFileSize} bytes");
            var ext = Path.GetExtension(file.FileName.ToLower());
            if (!AllowedExtentions.Contains(ext))
                return Error($"Wrong file type {ext}");

            try
            {
                byte[] content;
                using (var stream = file.OpenReadStream())
                {
                    content = new byte[file.Length];
                    await stream.ReadAsync(content, 0, (int)file.Length);
                }

                if (!CheckSignature(Path.GetExtension(file.FileName.ToLower()), content))
                    return Error("Wrong file contents");

                var destination = Path.Combine(fileLocation, file.FileName);
                Directory.CreateDirectory(Path.Combine(Config.FintargetWebRootPath, fileLocation));
                System.IO.File.WriteAllBytes(Path.Combine(Config.FintargetWebRootPath, destination), content);
                if (!string.IsNullOrEmpty(Config.FintargetTestWebRootPath))
                {
                    try
                    {
                        Directory.CreateDirectory(Path.Combine(Config.FintargetTestWebRootPath, fileLocation));
                        System.IO.File.WriteAllBytes(Path.Combine(Config.FintargetTestWebRootPath, destination), content);
                    }
                    catch (Exception e)
                    {
                        Logger.LogWarning($"Can't write file to test: {e}");
                    }
                }

                var parts = destination.Replace('\\', '/').Split('/');
                return Success(new UploadedFile
                {
                    Name = "/" + string.Join('/', parts.Select(Uri.EscapeDataString))
                });
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }
    }
}