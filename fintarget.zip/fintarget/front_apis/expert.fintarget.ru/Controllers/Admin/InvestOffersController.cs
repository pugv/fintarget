﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Api.Models;
using CS.Balance;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceBase;
using Database = Api.Models.Database;

namespace fin_expert.Controllers
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator,DigitalExpert")]
    public class InvestOfferController : WebCabinetController<InvestOfferController>
    {
        private AppConfig _connfig;
        private PortfolioBalancer _portfolioBalancer;
        private ISecurityCache _securityCache;

        public InvestOfferController(IServiceProvider serviceProvider, ILogger<InvestOfferController> logger,
            ISecurityCache securityCache,
            PortfolioBalancer portfolioBalancer,
            AppConfig config)
            : base(serviceProvider, logger)
        {
            _securityCache = securityCache;
            _portfolioBalancer = portfolioBalancer;
            _connfig = config;
        }


        // POST: /api/admin/investOffer
        [HttpPost]
        [Authorize(Roles = "Administrator,DigitalExpert")]
        public async Task<ActionResult<RequestResult<InvestOfferPage>>> Get(PaginationAndSort paginationAndSort)
        {
            try
            {
                if (paginationAndSort.PageSize == 0) return Error("PageSize is 0");
                using (var db = new Database())
                {
                    var total = await db
                        .InvestOffers
                        .CountAsync();

                    var portfolios = db
                        .InvestOffers
                        .LoadWith(p => p.Positions);

                    var result = await
                        SortPortfolios(portfolios, paginationAndSort)
                            .Skip(paginationAndSort.PageNumber * paginationAndSort.PageSize)
                            .Take(paginationAndSort.PageSize)
                            .Select(c => new InvestOfferDto
                            {
                                Active = c.Active,
                                Comment = c.Comment,
                                Description = c.Description,
                                Image = c.Image,
                                Id = c.Id,
                                Subtitle = c.Subtitle,
                                Title = c.Title,
                                Positions = c.Positions.OrderBy(p => p.OrderNum).Select(p => new InvestOfferDto.Position
                                {
                                    SecurityKey = p.SecurityKey,
                                    FullDescription = p.FullDescription,
                                    IssuerDescription = p.IssuerDescription
                                }).ToArray()
                            })
                            .ToArrayAsync();

                    return Success(new InvestOfferPage
                    {
                        Total = total,
                        PageItems = result
                    });
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // POST: /api/admin/investOffer/edit
        [HttpPost("edit")]
        [Authorize(Roles = "Administrator,DigitalExpert")]
        public async Task<ActionResult<RequestResult>> Edit(InvestOfferDto investOfferDto)
        {
            try
            {
                using (var db = new Database())
                {
                    var pos = 0;
                    var positions = investOfferDto.Positions?.Select(c => new InvestOfferPosition
                    {
                        OrderNum = pos++,
                        InvestOfferId = investOfferDto.Id,
                        SecurityKey = c.SecurityKey,
                        FullDescription = c.FullDescription,
                        IssuerDescription = c.IssuerDescription
                    });

                    using (var trans = await db.BeginTransactionAsync())
                    {
                        await db.InvestOfferPositions.DeleteAsync(p => p.InvestOfferId == investOfferDto.Id);
                        await db.InvestOffers.Where(c => c.Id == investOfferDto.Id)
                            .Set(c => c.Active, investOfferDto.Active)
                            .Set(c => c.Comment, investOfferDto.Comment)
                            .Set(c => c.Image, investOfferDto.Image)
                            .Set(c => c.Description, investOfferDto.Description)
                            .Set(c => c.Subtitle, investOfferDto.Subtitle)
                            .Set(c => c.Title, investOfferDto.Title)
                            .UpdateAsync();

                        foreach (var p in positions ?? Enumerable.Empty<InvestOfferPosition>()) await db.InsertAsync(p);

                        await trans.CommitAsync();
                    }

                    return Success();
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private static IQueryable<InvestOffer> SortPortfolios(IQueryable<InvestOffer> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName?.ToLower())
            {
                case "title":
                    return OrderQueryBy(query, p => p.Title, paginationAndSort.SortDirection);
                case "subtitle":
                    return OrderQueryBy(query, p => p.Subtitle, paginationAndSort.SortDirection);
                case "description":
                    return OrderQueryBy(query, p => p.Description, paginationAndSort.SortDirection);
                case "active":
                    return OrderQueryBy(query, p => p.Active, paginationAndSort.SortDirection);
                case "comment":
                    return OrderQueryBy(query, p => p.Comment, paginationAndSort.SortDirection);
                default:
                    return query;
            }
        }
    }
}