﻿using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Api.Models;
using Expert.Models;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NLib.AuxTypes;
using ServiceBase;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator")]
    public class UsersController
        : WebCabinetController<UsersController>
    {
        private readonly ILCS lcs;

        public UsersController(IServiceProvider serviceProvider, ILogger<UsersController> logger, ILCS lCS)
            : base(serviceProvider, logger)
        {
            lcs = lCS;
        }

        // GET: /api/admin/users/roles
        [HttpGet("roles")]
        //[Authorize(Roles = "Administrator,Developer")]
        [Authorize(Roles = "Administrator")]
        public ActionResult<RequestResult<string[]>> GetUserRoles()
        {
            try
            {
                return Success(((UserRole[])Enum.GetValues(typeof(UserRole))).Select(v => v.ToString()).ToArray());
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: /api/admin/users
        [HttpPost]
        public async Task<ActionResult<RequestResult<ListPage<AggregateUser>>>> GetUsers(PaginationAndSort paginationAndSort)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var total = await db
                        .Users
                        .CountAsync(u => u.IsActive > 0);

                    IQueryable<User> query = db
                        .Users
                        .Where(u => u.IsActive > 0);

                    query = SortUsers(query, paginationAndSort);

                    query = query
                        .Skip(paginationAndSort.PageSize * paginationAndSort.PageNumber)
                        .Take(paginationAndSort.PageSize);

                    var users = await query
                        .Select(u => new AggregateUser(u))
                        .ToArrayAsync();

                    using (var ftDb = new Api.Models.Database())
                    {
                        foreach (var user in users)
                            user.SetAuthor(await ftDb.Authors.FirstOrDefaultAsync(a => a.Id == user.Id));
                    }

                    return Success(new ListPage<AggregateUser>
                    {
                        Total = total,
                        PageItems = users
                    });
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private IQueryable<User> SortUsers(IQueryable<User> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName.ToLower())
            {
                case "login":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(u => u.Login)
                        : query.OrderByDescending(u => u.Login);
                case "firstname":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(u => u.FullName)
                        : query.OrderByDescending(u => u.FullName);
                case "role":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(u => u.Role)
                        : query.OrderByDescending(u => u.Role);
                case "company":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(u => u.OrgName)
                        : query.OrderByDescending(u => u.OrgName);
                default:
                    return query;
            }
        }

        // POST: api/admin/users/edit
        [HttpPost("edit")]
        public async Task<ActionResult<RequestResult<User>>> EditUser(AggregateUser userData)
        {
            if ((string.IsNullOrEmpty(userData.FirstName) || string.IsNullOrEmpty(userData.LastName)) &&
                string.IsNullOrEmpty(userData.Company))
                return Error("Не указаны имя, фамилия пользователя или название организации",
                    (int)Errors.UserOrCompanyName);

            var time = DateTime.UtcNow;

            var changePassword = !string.IsNullOrEmpty(userData.Password);

            try
            {
                var master = await GetMasterUser(userData);

                var isOrg = userData.UserType == AuthorType.Org && userData.Role == UserRole.Manager.ToString();

                var orgName = master != null
                    ? string.IsNullOrEmpty(master.Company) ? null : master.Company
                    : string.IsNullOrEmpty(userData.Company)
                        ? null
                        : userData.Company;

                var user = new User
                {
                    Id = userData.Id,
                    MasterId = userData.MasterId,
                    CreateDate = DateTime.Now,
                    DraftPassword = 1,
                    IsActive = 1,
                    IsDeleted = 0,
                    Login = string.IsNullOrEmpty(userData.Login) ? master?.Login : userData.Login,
                    //Name = $"{userData.FirstName} {userData.LastName ?? string.Empty}",
                    FirstName = isOrg || string.IsNullOrEmpty(userData.FirstName)
                        ? orgName // #fixme исправил для #27142 
                        : userData.FirstName,
                    LastName = isOrg || string.IsNullOrEmpty(userData.LastName) ? null : userData.LastName,
                    MidName = isOrg || string.IsNullOrEmpty(userData.MidName) ? null : userData.MidName,
                    OrgName = orgName,
                    Phone = userData.Phone ?? master?.Phone,
                    //Salt = salt,
                    //PasswordHash = UserManager.GetHash(userData.Password, salt),
                    Role = userData.Role,
                    UserType = userData.UserType
                };

                user.FullName = user.GetUserName();

                if (changePassword)
                {
                    if (userData.Password.Length > 255)
                    {
                        throw new UserVisibleException("Превышена максимальная длина пароля в 255 символов");
                    }
                    var salt = UserManager.CreateUserSalt();
                    user.Salt = salt;
                    user.PasswordHash = UserManager.GetHash(userData.Password, salt);
                }

                Author author = null;
                if (user.Role == UserRole.Manager.ToString())
                {
                    author = new Author
                    {
                        Id = userData.Id,
                        MasterId = userData.MasterId,
                        Type = userData.UserType,
                        Company = orgName,
                        OrgInn = userData.OrgInn,
                        OrgOgrn = userData.OrgOgrn,
                        OrgKpp = userData.OrgKpp,
                        Email = string.IsNullOrEmpty(userData.Email) ? master?.Email : userData.Email,
                        FirstName = isOrg || string.IsNullOrEmpty(userData.FirstName)
                            ? orgName // #fixme исправил для #27142
                            : userData.FirstName,
                        LastName = isOrg || string.IsNullOrEmpty(userData.LastName) ? string.Empty : userData.LastName,
                        MiddleName = isOrg || string.IsNullOrEmpty(userData.MidName) ? null : userData.MidName,
                        DisplayName = user.FullName,
                        PassportId = userData.PassportId,
                        PassportIssued = userData.PassportIssued,
                        EmployeeId = userData.EmployeeId,
                        AgreementNum = userData.AgreementNum,
                        Commission = userData.Comission ? 1 : 0,
                        InfoHtml = userData.InfoHtml ?? string.Empty,
                        ShortInfoHtml = string.IsNullOrEmpty(userData.ShortinfoHtml) ? null : userData.ShortinfoHtml,
                        InfoText = string.IsNullOrEmpty(userData.InfoText) ? null : userData.InfoText,
                        ShortInfoText = string.IsNullOrEmpty(userData.ShortinfoText) ? null : userData.ShortinfoText,
                        //PhotoBase64 = userData.PhotoBase64,
                        PhotoFormat = userData.PhotoFormat ?? string.Empty,
                        ImageUrl = userData.Photo,
                        FriendlyUrl = TranslitHelper.Instance().ConvertToEng(user.FullName),
                        Position = string.IsNullOrEmpty(userData.Position) ? null : userData.Position,
                        //Rating = userData.Rating,
                        Updated = 1,
                        UpdateTime = time
                    };

                    user.Agreement = userData.AgreementNum;
                    //user.UserType = userData.UserType;
                }

                using (var db = new Expert.Models.Database())
                {
                    using (var ftDb = new Api.Models.Database())
                    {
                        using (var tr = await db.BeginTransactionAsync())
                        {
                            using (var ftTr = await ftDb.BeginTransactionAsync())
                            {
                                if (userData.Id == 0) // new user
                                {
                                    if (!changePassword)
                                        throw new UserVisibleException("Не задан пароль пользователя");

                                    user.Id = await db.InsertWithInt32IdentityAsync(user);

                                    if (author != null) // add author if role == Manager
                                    {
                                        author.Id = user.Id;
                                        author.ImageUrl = SaveImage(author.ImageUrl, user.Id);
                                        author.PhotoFormat = GetImageFormat(author.ImageUrl) ?? string.Empty;

                                        await ftDb.InsertAsync(author);
                                    }
                                }
                                else // edit user
                                {
                                    await db.UpdateAsync(user);

                                    if (changePassword)
                                        await db
                                            .Users
                                            .Where(u => u.Id == user.Id)
                                            .Set(u => u.Salt, user.Salt)
                                            .Set(u => u.PasswordHash, user.PasswordHash)
                                            .Set(u => u.DraftPassword, 1)
                                            .UpdateAsync();

                                    if (author != null) // add (if was not Manager) or edit author if role == Manager
                                    {
                                        if (await ftDb.Authors.AnyAsync(a => a.Id == userData.Id))
                                        {
                                            if (userData.PhotoChanged)
                                            {
                                                author.ImageUrl = SaveImage(author.ImageUrl, user.Id);
                                                author.PhotoFormat = GetImageFormat(author.ImageUrl) ?? string.Empty;
                                            }

                                            await ftDb.UpdateAsync(author);

                                            await ftDb.Authors
                                                .Where(u => u.Id == userData.Id)
                                                .Set(u => u.Updated, u => u.Updated + 1)
                                                .UpdateAsync();
                                        }
                                        else
                                        {
                                            await ftDb.InsertAsync(author);
                                        }
                                    }
                                }

                                await ftTr.CommitAsync();
                            }

                            await tr.CommitAsync();
                        }
                    }

                    try
                    {
                        if (!await lcs.SetUsers((await db.Users.Select(u => new
                                {
                                    u.Id,
                                    u.Login,
                                    Name = u.FullName,
                                    u.Role
                                }).ToArrayAsync())
                                .Select(o => new LCS.Kernel.BusinessModel.User
                                {
                                    Id = o.Id,
                                    Login = o.Login,
                                    Name = o.Name,
                                    Role = Enum.TryParse(typeof(LCS.Kernel.BusinessModel.UserRole), o.Role, out var role)
                                        ? (LCS.Kernel.BusinessModel.UserRole)role
                                        : LCS.Kernel.BusinessModel.UserRole.None
                                }).ToArray()))
                            throw new Exception();
                    }
                    catch (Exception e)
                    {
                        Logger?.LogError(e, "LCS.SetUsers");
                        throw new UserVisibleException("Пользователь добавлен, но не передан в LCS. У него не будет прав на подачу сигналов. Попробуйте обновить его позже");
                    }
                }

                await StoreAuditActionAsync(AuditRecord.Actions.ModifyUser, new { Info = "User changed", UserData = userData.HideSensitiveClone() });
                return Success(user);
            }
            catch (Exception ex)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.ModifyUser, new { Info = "Failed to change user", UserData = userData.HideSensitiveClone(), Error = ex.Message });
                return Error(ex);
            }
        }

        // DELETE: api/admin/users/{id}
        [HttpDelete("{id}")]
        public async Task<ActionResult<RequestResult<AggregateUser>>> RemoveUser(int id)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    using (var trn = await db.BeginTransactionAsync())
                    {
                        var strategy = await db.Strategies
                            .FirstOrDefaultAsync(s => s.Active > 0 && s.ManagerId == id);
                        if (strategy != null)
                            throw new UserVisibleException(
                                $"Пользователь является автором стратегии \"{strategy.Name}\"");
                        
                        var removeResult = await db.Users
                            .Where(s => s.Id == id)
                            .AsUpdatable()
                            .Set(s => s.IsActive, 0)
                            .UpdateWithOutputAsync();

                       if (removeResult.Length == 0)
                            throw new ApplicationException(
                                $"{nameof(RemoveUser)} Update active cabinet user id=|{id}| returned zero");

                        var user = removeResult.First().Inserted;

                        await trn.CommitAsync();
                        await StoreAuditActionAsync(AuditRecord.Actions.RemoveUser, user);
                        return Success(new AggregateUser(user));
                    }
                }
            }
            catch (Exception e)
            {
                await StoreAuditActionAsync(AuditRecord.Actions.RemoveUser, new {Info = "Failed remove user", id, e.Message});
                return Error(e);
            }
        }

        public async Task<AggregateUser> GetMasterUser(AggregateUser userData)
        {
            //if (userData.UserType != AuthorType.Representative ||
            //    !string.IsNullOrEmpty(userData.Login) &&
            //    !string.IsNullOrEmpty(userData.Phone) &&
            //    !string.IsNullOrEmpty(userData.Email))
            //{
            //    return null;
            //}

            if (userData.UserType != AuthorType.Representative)
                return null;

            if (!userData.MasterId.HasValue)
                throw new UserVisibleException("Не задана организация для представителя");

            using (var db = new Expert.Models.Database())
            {
                var user = await db.Users.FirstOrDefaultAsync(u => u.Id == userData.MasterId.Value);
                if (user == null)
                    throw new UserVisibleException("Данная организация отсутствует");

                var result = new AggregateUser(user);

                using (var ftdb = new Api.Models.Database())
                {
                    result.SetAuthor(await ftdb.Authors.FirstOrDefaultAsync(a => a.Id == userData.MasterId.Value));
                }

                return result;
            }
        }
        
        private string GetImageFormat(string imageUrl)
        {
            if (string.IsNullOrEmpty(imageUrl))
                return null;

            var offset = imageUrl.LastIndexOf('.');
            if (offset < 0)
                return string.Empty;

            var ext = imageUrl.Substring(offset + 1).ToLower(CultureInfo.InvariantCulture);
            switch (ext)
            {
                case "jpeg":
                case "jpg": return "jpeg";
                default: return ext;
            }
        }

        private string SaveImage(string photoUrl, int id)
        {
            if (string.IsNullOrEmpty(photoUrl))
                return null;

            var file = HttpUtility.UrlDecode(photoUrl);

            var parts = file.Split('/', StringSplitOptions.RemoveEmptyEntries);
            var url2Path = string.Join('\\', parts);
            parts[^1] = id + Path.GetExtension(parts[^1]);

            if (!string.IsNullOrEmpty(Config.FintargetWebRootPath))
            {
                var src = Path.Combine(Config.FintargetWebRootPath, url2Path);
                Directory.CreateDirectory(Path.GetDirectoryName(src) ?? string.Empty);
                var dst = Path.Combine(Path.GetDirectoryName(src) ?? string.Empty, parts[^1]);
                System.IO.File.Move(src, dst, true);
            }
            else if (!string.IsNullOrEmpty(Config.FintargetTestWebRootPath))
            {
                var src = Path.Combine(Config.FintargetTestWebRootPath, url2Path);
                var dst = Path.Combine(Path.GetDirectoryName(src) ?? string.Empty, parts[^1]);
                Directory.CreateDirectory(Path.GetDirectoryName(src) ?? string.Empty);
                System.IO.File.Move(src, dst, true);
            }

            return string.Concat("/", string.Join('/', parts));
        }
    }
}