using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Api.Models;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLib.AuxTypes;
using ServiceBase;
using ExpertStrategy = Expert.Models.Strategy;
using StrategySecuritiesHistory = Expert.Models.StrategySecuritiesHistory;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize]
    public class InvestboxesController : WebCabinetController<InvestboxesController>
    {
        private readonly ILCS _lcs;

        public InvestboxesController(IServiceProvider serviceProvider, ILCS lcs, ILogger<InvestboxesController> logger) : base(
            serviceProvider, logger)
        {
            _lcs = lcs;
        }

        // GET: /api/admin/investboxes
        [HttpPost]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult<RequestResult<ListPage<AggregateInvestbox>>>> GetInvestboxes(
            PaginationAndSort paginationAndSort)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var total = await db
                        .Strategies
                        .CountAsync(s => s.IsInvestbox && s.Active > 0);

                    var query = db.Strategies
                        .LoadWith(s => s.Tests)
                        .Where(s => s.IsInvestbox && s.Active > 0);

                    query = Sort(query, paginationAndSort)
                        .Skip(paginationAndSort.PageSize * paginationAndSort.PageNumber)
                        .Take(paginationAndSort.PageSize);

                    var investboxes = await query
                        .Select(s => new AggregateInvestbox(s))
                        .ToArrayAsync();

                    var investboxIds = investboxes.Select(s => s.Id.Value).ToArray();

                    using (var ftdb = new Database())
                    {
                        var ftInvestboxes = await ftdb.Strategies
                            .Where(s => s.IsInvestbox && investboxIds.Contains(s.Id))
                            .LeftJoin(ftdb.Investboxes,
                                (s, ib) => s.Id == ib.Id,
                                (s, ib) => new
                                {
                                    s.Id,
                                    s.Tag,
                                    s.Open,
                                    TariffId = ib != null ? ib.TariffId : default(Guid?),
                                    TariffName = ib != null ? ib.TariffName : null
                                })
                            .ToArrayAsync();

                        foreach (var investbox in investboxes)
                        {
                            var ftInvestbox = ftInvestboxes.FirstOrDefault(s => s.Id == investbox.Id);
                            if (ftInvestbox != null)
                            {
                                investbox.IsOpen = ftInvestbox.Open;
                                investbox.Tag = ftInvestbox.Tag;
                                investbox.TariffId = ftInvestbox.TariffId;
                                investbox.TariffName = ftInvestbox.TariffName;
                            }
                        }
                    }

                    return SuccessValue(new ListPage<AggregateInvestbox>
                    {
                        Total = total,
                        PageItems = investboxes
                    });
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // GET: /api/admin/investboxes/:id
        [HttpGet("{id}")]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult<RequestResult<AggregateInvestbox>>> GetInvestboxById(Guid id)
        {
            try
            {
                using (var db = new Expert.Models.Database())
                {
                    var investbox = await db.Strategies
                        .LoadWith(s => s.Tests)
                        .FirstOrDefaultAsync(s => s.IsInvestbox && s.Id == id);

                    if (investbox == null)
                        return Error($"Инвест-копилка с идентификатором {id.ToString()} не существует");

                    using (var ftdb = new Database())
                    {
                        var result = new AggregateInvestbox(investbox);

                        var ftInvestbox = await ftdb.Strategies
                            .InnerJoin(ftdb.Investboxes,
                                (s, ib) => s.Id == ib.Id,
                                (s, ib) => new
                                {
                                    s.IsInvestbox,
                                    s.Id,
                                    s.Tag,
                                    TariffId = ib != null ? ib.TariffId : default(Guid?),
                                    TariffName = ib != null ? ib.TariffName : null
                                })
                            .FirstOrDefaultAsync(s => s.IsInvestbox && s.Id == id);

                        if (ftInvestbox != null)
                        {
                            result.Tag = ftInvestbox.Tag;
                            result.TariffId = ftInvestbox.TariffId;
                            result.TariffName = ftInvestbox.TariffName;
                        }

                        return Success(result);
                    }
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // POST: /api/admin/investboxes/add
        [HttpPost("add")]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult<AggregateInvestbox>> AddInvestbox(AggregateInvestbox investbox)
        {
            try
            {
                if (investbox.Id != null) Logger.LogWarning($"AddStrategy id=|{investbox.Id.Value}| ignored");

                var time = DateTime.Now;
                var investboxId = Guid.NewGuid();
                investbox.Id = investboxId;

                var cabInvestbox = new Expert.Models.Strategy
                {
                    Id = investboxId,
                    Name = investbox.Title,
                    ParentStrategy = investbox.ParentId,
                    CreatorId = investbox.CreatorId,
                    ManagerId = investbox.ManagerId,
                    Currency = investbox.Currency,
                    Active = investbox.Active ? 1 : 0,
                    SubscriptionThreshold = investbox.SubscriptionThreshold,
                    MaxInstrumentWeight = 100,
                    RecalcMode = 1, // EntryPriceNoRecalc = 1
                    Status = Expert.Models.StrategyStatus.Standard,
                    ForReport = false,
                    IsPortfolio = false,
                    Autofollow = false,
                    Autoconsult = false,
                    IsInvestbox = true,
                    Securities = "[]",
                    Leverage = investbox.Leverage,
                    CreateTime = investbox.CreationDate
                };

                using (var db = new Expert.Models.Database())
                {
                    using (var trn = await db.BeginTransactionAsync())
                    {
                        if (await db.InsertAsync(cabInvestbox) == 0)
                            throw new ApplicationException(
                                $"{nameof(AddInvestbox)} Insert cabinet investbox id=|{investboxId}| returned zero");

                        await AddFintargetInvestboxAsync(investbox, time);
                        await trn.CommitAsync();
                    }
                }

                return Success(investbox);
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // POST: /api/admin/investboxes/edit
        [HttpPost("edit")]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult<AggregateInvestbox>> UpdateInvestbox(AggregateInvestbox investbox)
        {
            var time = DateTime.Now;

            try
            {
                if (!investbox.Id.HasValue)
                {
                    Logger.LogWarning("UpdateInvestbox guid missing");
                    return Error("Investbox id missing", 0);
                }

                using (var cabdb = new Expert.Models.Database())
                {
                    using (var trn = await cabdb.BeginTransactionAsync())
                    {
                        var cabInvestbox = await cabdb.Strategies
                            .LoadWith(s => s.Tests)
                            .FirstAsync(s => s.IsInvestbox && s.Id == investbox.Id);

                        if (cabInvestbox.Securities != investbox.Securities)
                            await cabdb
                                .InsertAsync(new StrategySecuritiesHistory
                                {
                                    StrategyId = cabInvestbox.Id,
                                    OldValue = cabInvestbox.Securities,
                                    NewValue = investbox.Securities,
                                    UpdateTime = DateTime.Now
                                });

                        var update = cabdb.Strategies
                            .Where(s => s.Id == investbox.Id)
                            .Set(s => s.ParentStrategy, investbox.ParentId)
                            .Set(s => s.ManagerId, investbox.ManagerId)
                            .Set(s => s.Name, investbox.Title)
                            // .Set(s => s.Active, investbox.Active ? 1 : 0)
                            .Set(s => s.Currency, investbox.Currency)
                            .Set(s => s.Securities, s => investbox.Securities ?? s.Securities)
                            .Set(s => s.SubscriptionThreshold, investbox.SubscriptionThreshold)
                            .Set(s => s.Leverage, investbox.Leverage)
                            .UpdateAsync();

                        if (await update == 0)
                            throw new ApplicationException(
                                $"{nameof(AddInvestbox)} Update cabinet strategy id=|{investbox.Id}| returned zero");

                        var tests = investbox.Tests ?? Array.Empty<string>();

                        if (tests.Length != cabInvestbox.Tests.Length ||
                            tests.Any(t => cabInvestbox.Tests.All(tt => t != tt.TestId)))
                        {
                            await cabdb.StrategyTests.DeleteAsync(t => t.StrategyId == investbox.Id.Value);

                            foreach (var testId in tests)
                            {
                                await cabdb.InsertAsync(new StrategyTest
                                {
                                    StrategyId = investbox.Id.Value,
                                    TestId = testId
                                });
                            }
                        }

                        await UpdateFintargetInvestboxAsync(investbox, cabInvestbox.ManagerId, time);
                        await trn.CommitAsync();

                        return Success(investbox);
                    }
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        private async Task AddFintargetInvestboxAsync(AggregateInvestbox args, DateTime time)
        {
            Debug.Assert(args.Id.HasValue);

            var friendlyName = TranslitHelper.Instance().ConvertToEng(args.Title) ?? string.Empty;
            var investboxStrategy = new Strategy
            {
                Id = args.Id.Value,
                Name = args.Title,
                ParentStrategy = null,
                AuthorId = args.ManagerId,
                FriendlyUrl = friendlyName.Length > 128 ? friendlyName.Substring(0, 128) : friendlyName,
                Tag = args.Tag,
                InfoHtml = string.Empty,
                PictureFormat = string.Empty, // obsolete?
                ToolDrawndown = 0, // obsolete?
                CurrencyId = args.Currency,
                SubscriptionThreshold = args.SubscriptionThreshold,
                EstimatedDrawdown = 0, // obsolete?
                EstimatedProfit = 0, // obsolete?
                IsPortfolio = false,
                DurationId = 0,
                Open = args.IsOpen,
                Leverage = args.Leverage,
                IsAlgostrategy = false,
                Recommended = false,
                MaxPositionWeight = 100,
                MaxIndustryWeight = 100,
                MaxInstrumentFraq = 100,
                Autofollow = false,
                Autoconsult = false,
                IsInvestbox = true,
                Updated = args.IsOpen ? 1 : 0,
                UpdateLcs = 1,
                UpdateCs = true,
                StartDate = new DateTime(1994, 1, 1),
                UpdateTime = time
            };

            using (var db = new Database())
            {
                using (var trn = await db.BeginTransactionAsync())
                {
                    if (await db.InsertAsync(investboxStrategy) == 0)
                        throw new ApplicationException(
                            $"{nameof(AddFintargetInvestboxAsync)} Insert fintarget investbox id=|{args.Id}| returned zero");
                            
                    if (args.IsOpen)
                        await db.InsertAsync(
                            new ShopfrontObject
                            {
                                ObjectType = "strategy",
                                ObjectId = args.Id.Value
                            });

                    if (args.TariffId.HasValue)
                        await db.InsertAsync(new Investbox
                        {
                            Id = args.Id.Value,
                            TariffId = args.TariffId.Value,
                            TariffName = args.TariffName
                        });

                    await trn.CommitAsync();
                }
            }
        }

        private async Task UpdateFintargetInvestboxAsync(AggregateInvestbox investbox, int oldManagerId, DateTime time)
        {
            Debug.Assert(investbox.Id.HasValue);
            
            var friendlyName = TranslitHelper.Instance().ConvertToEng(investbox.Title) ?? string.Empty;
            
            using (var db = new Database())
            {
                using (var trn = await db.BeginTransactionAsync())
                {
                    if (oldManagerId != investbox.ManagerId)
                    {
                        var updated = await db.Authors
                            .Where(a => a.Id == oldManagerId)
                            .AsUpdatable()
                            .Set(a => a.Updated, a => a.Updated + 1)
                            .Set(a => a.UpdateTime, time)
                            .UpdateAsync();
                        if (updated == 0)
                            Logger.LogWarning("Update old investbox author count=0");
                    }

                    var result = await db.Strategies
                        .Where(s => s.Id == investbox.Id.Value && s.UpdateTime <= time)
                        .Set(s => s.Name, investbox.Title)
                        .Set(s => s.Tag, investbox.Tag ?? string.Empty)
                        .Set(s => s.AuthorId, investbox.ManagerId)
                        .Set(s => s.FriendlyUrl, friendlyName)
                        .Set(s => s.CurrencyId, investbox.Currency)
                        .Set(s => s.Leverage, investbox.Leverage)
                        .Set(s => s.SubscriptionThreshold, investbox.SubscriptionThreshold)
                        .Set(s => s.UpdateTime, time)
                        .Set(s => s.Updated, s => s.Updated + 1)
                        .Set(s => s.UpdateLcs, s => s.UpdateLcs + 1)
                        .UpdateAsync();
                    
                    if (result == 0)
                        throw new UserVisibleException("Данные инвесткопилки устарели, обновите страницу.");

                    if (investbox.TariffId.HasValue)
                    {
                        await db.InsertOrReplaceAsync(new Investbox
                        {
                            Id = investbox.Id.Value,
                            TariffId = investbox.TariffId.Value,
                            TariffName = investbox.TariffName?.Length > 20
                                ? investbox.TariffName.Substring(0, 20)
                                : investbox.TariffName
                        });
                    }
                    
                    if (investbox.IsOpen)
                        await db.InsertAsync(
                            new ShopfrontObject
                            {
                                ObjectType = "strategy",
                                ObjectId = investbox.Id.Value
                            });

                    await trn.CommitAsync();
                }
            }
        }
        
        private static IQueryable<ExpertStrategy> Sort(IQueryable<ExpertStrategy> query,
            PaginationAndSort paginationAndSort)
        {
            return paginationAndSort.SortFieldName?.ToLower() switch
            {
                "name" => paginationAndSort.SortDirection > 0
                    ? query.OrderBy(s => s.Name)
                    : query.OrderByDescending(s => s.Name),
                "creationdate" => paginationAndSort.SortDirection > 0
                    ? query.OrderBy(s => s.CreateTime)
                    : query.OrderByDescending(s => s.CreateTime),
                "currency" => paginationAndSort.SortDirection > 0
                    ? query.OrderBy(s => s.Currency)
                    : query.OrderByDescending(s => s.Currency),
                "active" => paginationAndSort.SortDirection > 0
                    ? query.OrderBy(s => s.Active)
                    : query.OrderByDescending(s => s.Active),
                _ => query
            };
        }
    }
}