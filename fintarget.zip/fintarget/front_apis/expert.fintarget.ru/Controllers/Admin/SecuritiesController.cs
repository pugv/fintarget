﻿using System;
using System.Linq;
using System.Threading.Tasks;
using ExchangeHelpers;
using ExchangeHelpers.HS;
using fin_expert.Interfaces;
using fin_expert.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NLib.ParsersFormatters.DateTime;
using RMDS.Common;
using ServiceBase;
using Security = CS.Kernel.Model.Security;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize(Roles = "Developer,Administrator")]
    public class SecuritiesController : WebCabinetController<SecuritiesController>
    {
        private readonly ICS cs;
        private readonly ISecurityCache secCache;

        public SecuritiesController(IServiceProvider serviceProvider, ILogger<SecuritiesController> logger, ISecurityCache sec, ICS cs) : base(serviceProvider,
            logger)
        {
            secCache = sec;
            this.cs = cs;
        }

        private RMDS.ApiClient.Api rmds => secCache.Rmds;

        [HttpGet("get/{key}")]
        public ActionResult<RequestResult<SecurityRecord>> Get(string key)
        {
            return Success(secCache.GetSecuritiy(key));
        }

        [HttpGet("fromcs/{key}")]
        public async Task<ActionResult<RequestResult<string>>> FromCS(string key)
        {
            return Success(new RawHtmlData(FormatToHtmlJson(await cs.Security(key))));
        }

        private string FormatToHtmlJson(object value)
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(value, Newtonsoft.Json.Formatting.Indented);
        }

        [HttpPost("fromrmds")]
        public async Task<ActionResult<RequestResult<BidAsk>>> FromRMDS([FromBody] string key)
        {
            return Success((await rmds.RequestMarketDataAsync(new[] { key })).FirstOrDefault());
        }

        [HttpPost("endofday")]
        public async Task<ActionResult<RequestResult<string>>> EndOfDay([FromBody] string key)
        {
            var data = await secCache.EndOfDay(key);

            var html = "<table>" + string.Concat(data.OrderByDescending(p => p.Date).Select(p =>
                $"<tr><td>{p.Date.ToStandardDateString()}</td><td>{p.Price}</td></tr>"
            )) + "</table>";

            return Success(new RawHtmlData(html));
        }

        [HttpPost("info")]
        public ActionResult<RequestResult<SecurityInfoFull>> GetInfo([FromBody] string key)
        {
            if (key.EndsWith(" QUIK"))
                key = key.Substring(0, key.IndexOf(" QUIK"));
            // accepts null as allowedPatterns

            var security = secCache.SearchSecurities(null, null, key.ToLower(), Config.MaxSecuritySearchResuls).FirstOrDefault();

            if (security == null)
                return Error("ЦБ по запрошенным данным не найдены");

            return Success(new SecurityInfoFull
            {
                Ticker = security.Symbol,
                ClassCode = security.ClassCode,
                ClassName = security.ClassName,
                Name = security.Name,
                ShortName = security.ShortName,
                Isin = security.IsinCode,
                Currency = security.Currency,
                Type = secCache.GetSecurityTypeInfo(security.Type),
                ShortsAllowed = security.ShortAllowed,
                LotSize = security.SharesInLot ?? 1,
                PriceStep = security.PriceStep,
                IsCurrent = security.Current,
                LastPrice = security.LastPrice,
                LastTime = security.LastTime
            });
        }
    }
}