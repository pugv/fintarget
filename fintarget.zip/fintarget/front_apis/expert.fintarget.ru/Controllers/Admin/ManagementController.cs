﻿using System;
using System.Threading.Tasks;
using fin_expert.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ServiceBase;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator,Developer")]
    public class ManagementController : WebCabinetController<ManagementController>
    {
        private readonly ICS cs;
        private readonly ISTS sts;

        public ManagementController(IServiceProvider serviceProvider, ILogger<ManagementController> logger, ICS cs, ISTS sts) : base(serviceProvider, logger)
        {
            this.cs = cs;
            this.sts = sts;
        }

        [HttpPost("stopcs")]
        public async Task<ActionResult> StopCS()
        {
            if (await cs.Exit())
                return Success("Stopped");
            return Error("Returned false", 500);
        }

        [HttpGet("recalc_history/{stratId}")]
        public async Task<ActionResult> RecalcHistory(Guid stratId)
        {
            if (await sts.UpdateHistory(stratId))
                return Success("Ok");
            return Error("Returned false", 500);
        }

        [HttpGet("csdiag")]
        public async Task<ActionResult<RequestResult>> CsDiag()
        {
            return Success(
                JsonConvert.DeserializeObject(await cs.Info()));
        }
    }
}