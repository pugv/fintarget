﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Api.Models;
using fin_expert.Models;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceBase;
using Database = Api.Models.Database;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator,ContentManager,DigitalExpert")]
    public class AnalyticsController
        : WebCabinetController<AnalyticsController>
    {
        public AnalyticsController(IServiceProvider serviceProvider, ILogger<AnalyticsController> logger)
            : base(serviceProvider, logger)
        {
        }

        // POST: /api/admin/analytics
        [HttpPost]
        public async Task<ActionResult<RequestResult<AnalyticsPage>>> Get(PaginationAndSort paginationAndSort)
        {
            try
            {
                using (var db = new Database())
                {
                    var total = await db
                        .Analytics
                        .CountAsync();

                    var analytics = db
                        .Analytics
                        .LoadWith(a => a.Strategies)
                        .LoadWith(a => a.AnalyticsCategories);

                    var result = await
                        SortAnalytics(analytics, paginationAndSort)
                            .Skip(paginationAndSort.PageNumber * paginationAndSort.PageSize)
                            .Take(paginationAndSort.PageSize)
                            .ToArrayAsync();

                    foreach (var a in result)
                    {
                        a.Author = await db
                            .Authors
                            .Where(au => au.Id == a.AuthorId)
                            .Select(au => new Author
                            {
                                Id = au.Id,
                                FirstName = au.FirstName,
                                MiddleName = au.MiddleName,
                                LastName = au.LastName,
                                DisplayName = au.DisplayName,
                                FriendlyUrl = au.FriendlyUrl
                            })
                            .FirstOrDefaultAsync();

                        var cats = a.AnalyticsCategories.Select(c => c.CategoryId).ToArray();

                        a.Categories = await db
                            .ArticleCategories
                            .Where(c => cats.Contains(c.Id))
                            .ToArrayAsync();
                    }

                    return Success(new AnalyticsPage
                    {
                        Total = total,
                        PageItems = result
                    });
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // POST: /api/admin/analytics/edit
        [HttpPost("edit")]
        public async Task<ActionResult<RequestResult>> Edit(Analytics analytics)
        {
            try
            {
                analytics.AuthorId = analytics.Author.Id;

                using (var db = new Database())
                {
                    if (analytics.Id == 0) // new
                    {
                        analytics.Active = false; // first save in inactive state

                        using (var trans = await db.BeginTransactionAsync())
                        {
                            if (analytics.Date == null)
                                analytics.Date = DateTime.Now;
                            //analytics.Date = analytics.Date.TruncateToMinutes();

                            var id = await db
                                .InsertWithInt64IdentityAsync(analytics);

                            foreach (var s in analytics.Strategies)
                            {
                                s.AnalyticsId = id;
                                await db.InsertAsync(s);
                            }

                            foreach (var c in analytics.Categories)
                                await db.InsertAsync(new AnalyticsCategory
                                {
                                    AnalyticsId = id,
                                    CategoryId = c.Id
                                });

                            await trans.CommitAsync();
                        }
                    }
                    else // existing
                    {
                        using (var trans = await db.BeginTransactionAsync())
                        {
                            await db
                                .AnalyticsStrategies
                                .DeleteAsync(s => s.AnalyticsId == analytics.Id);

                            await db
                                .AnalyticsCategories
                                .DeleteAsync(c => c.AnalyticsId == analytics.Id);

                            var id = analytics.Id;

                            await db
                                .UpdateAsync(analytics);

                            foreach (var s in analytics.Strategies)
                            {
                                s.AnalyticsId = id;
                                await db.InsertAsync(s);
                            }

                            foreach (var c in analytics.Categories)
                                await db.InsertAsync(new AnalyticsCategory
                                {
                                    AnalyticsId = id,
                                    CategoryId = c.Id
                                });

                            await trans.CommitAsync();
                        }
                    }

                    return Success();
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: /api/admin/analytics/categories
        [HttpGet("categories")]
        public async Task<ActionResult<RequestResult<ArticleCategory[]>>> GetCategories()
        {
            try
            {
                using (var db = new Database())
                {
                    return Success(await db.ArticleCategories.ToArrayAsync());
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private static IQueryable<Analytics> SortAnalytics(IQueryable<Analytics> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName.ToLower())
            {
                case "title":
                    return OrderQueryBy(query, a => a.Title, paginationAndSort.SortDirection);
                case "date":
                    return OrderQueryBy(query, a => a.Date, paginationAndSort.SortDirection);
                default:
                    return query;
            }
        }
    }
}