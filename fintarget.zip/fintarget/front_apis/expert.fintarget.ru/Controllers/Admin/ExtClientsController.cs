﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ES.Models;
using fin_expert.Models;
using LinqToDB;
using LinqToDB.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceBase;
using Database = ES.Models.Database;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize]
    public class ExtClientsController : WebCabinetController<ExtClientsController>
    {
        private readonly Dictionary<StatusEnum, string> mapFollowTypeNames = new Dictionary<StatusEnum, string>
        {
            { StatusEnum.AutoFollow, "Автоследование" },
            { StatusEnum.Recommendations, "Автоконсультирование" },
            { StatusEnum.Investbox, "ИнвестКопилка" },
            { StatusEnum.Unattached, "отсутствует" }
        };

        public ExtClientsController(IServiceProvider provider, ILogger<ExtClientsController> logger)
            : base(provider, logger)
        {
        }

        // GET: /api/admin/extclients/info
        [HttpGet("{id}")]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult<RequestResult<ExternalClient>>> GetInfo(Guid id)
        {
            try
            {
                using (var db = new Database())
                {
                    var clients = await db.Clients
                        .LoadWith(r => r.Accounts)
                        .Where(c => c.AgreementId == id)
                        .ToArrayAsync();

                    if (clients.Length > 1)
                        Logger?.LogWarning($"Multiple clients for agreement id=|{id}|");

                    var client = clients.FirstOrDefault();
                    if (client == null)
                        return Success<ExternalClient>(null);

                    var result = new ExternalClient
                    {
                        ClientId = client.ClientId,
                        AgreementId = client.AgreementId,
                        Contract = client.Number,
                        FirstName = client.FirstName,
                        LastName = client.LastName,
                        MidName = client.MiddleName,
                        TariffId = client.Accounts.FirstOrDefault()?.TariffId
                    };

                    return Success(result);
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        // POST: /api/admin/extclients/query
        [HttpPost("query")]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult<RequestResult<ListPage<ExternalClient[]>>>> QueryClients(
            PaginationAndSortClients query)
        {
            var sql = "select top " + query.PageSize +
                      " c.ClientId, c.AgreementId, c.ContractNum as [Contract], c.FirstName, c.LastName, c.MiddleName as [MidName]," +
                      "a.ClientCode as [TradeCode], a.FutCode, a.Qual as [IsQual]," +
                      "c.RiskProfileName as [RiskName], c.RiskTime as [RiskTime], a.EventTime," +
                      "a.StrategyId, a.StrategyName, a.StrategyType, a.ChangeTime, a.Active as [IsActive]," +
                      "a.ClientTariffId as [TariffId]" +
                      " from Clients c inner join Accounts a on c.id=a.id";

            if (query.Strategies != null && query.Strategies.Any()) sql = sql + " and StrategyId in ('" + string.Join("','", query.Strategies) + "')";
            if (query.Types != null && query.Types.Any())
            {
                var types = query.Types
                    .Select(s => mapFollowTypeNames.ContainsKey(s) ? mapFollowTypeNames[s] : "не известно");

                sql = sql + " and StrategyType in ('" + string.Join("','", types) + "')";
            }

            // #fixme add sort field
            sql = sql +
                  " where c.ContractNum like '" + (query.ContractMask ?? string.Empty) +
                  "%' order by c.ContractNum" + (query.SortDirection > 0 ? " asc" : " desc");

            try
            {
                using (var db = new Database())
                {
                    var result = await db.QueryToArrayAsync<ExternalClient>(sql);

                    foreach (var s in result)
                    {
                        if (s.IsActive == StrategyState.On)
                            s.StrategyStatus = "Подключен";
                        else
                            s.StrategyStatus = string.Empty;

                        switch (s.StrategyType)
                        {
                            case "Автоконсультирование":
                            case "автоконсультирование":
                                s.StrategyType = "AK";
                                break;
                            case "Автоследование":
                            case "автоследование":
                                s.StrategyType = "AC";
                                break;
                            case "Инвесткопилка":
                            case "инвесткопилка":
                                s.StrategyType = "Копилка";
                                break;
                            default:
                                s.StrategyType = " - ";
                                break;
                        }
                    }

                    return Success(result);
                }
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        private IQueryable<Client> SortClients(IQueryable<Client> query, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName.ToLower())
            {
                case "contract":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(c => c.Number)
                        : query.OrderByDescending(c => c.Number);
                case "lastName":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(c => c.LastName)
                        : query.OrderByDescending(c => c.LastName);
                case "firstName":
                    return paginationAndSort.SortDirection > 0
                        ? query.OrderBy(c => c.FirstName)
                        : query.OrderByDescending(c => c.FirstName);
                //case "tradeCode":
                //    return paginationAndSort.SortDirection > 0
                //        ? query.OrderBy(c => c.TradeCode)
                //        : query.OrderByDescending(c => c.TradeCode);
                default:
                    return query;
            }
        }

        public class PaginationAndSortClients : PaginationAndSort
        {
            public string ContractMask { get; set; }

            public Guid[] Strategies { get; set; }

            public StatusEnum[] Types { get; set; }
        }
    }
}