﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ExchangeHelpers;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using QRCApi;
using RMDS.Common;
using ServiceBase;
using Database = CS.Kernel.Functionality.Database;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [Authorize(Roles = "Administrator,Support,DigitalExpert,Developer")]
    [ApiController]
    public class ClientsController : WebCabinetController<ClientsController>
    {
        private static ConcurrentQueue<PositionsResponse> RMDSPositionsResponses;
        private static readonly SemaphoreSlim rmdsrequest = new SemaphoreSlim(1);
        private readonly ICS cs;
        private readonly IQRCApi qrc;
        private readonly RMDS.ApiClient.Api rmds;

        public ClientsController(IServiceProvider serviceProvider, ILogger<ClientsController> logger, ICS cs, ISecurityCache sec, IQRCApi qrc) : base(
            serviceProvider, logger)
        {
            this.cs = cs;
            rmds = sec.Rmds;
            this.qrc = qrc;
        }

        // GET: api/Clients
        [HttpPost("block")]
        public async Task<ActionResult<RequestResult>> Block(BlockRequest block, CancellationToken cancellationToken)
        {
            string clientcode;
            using (var db = new Database())
            {
                clientcode = (await db.ClientAccounts.FirstOrDefaultAsync(c => c.Id == block.Id)).ClientCode;
            }

            if (await cs.BlockClient(clientcode, block.Time, cancellationToken))
                return Success();
            return Error("CS returned false");
        }

        [HttpPost("rebalance")]
        public async Task<ActionResult<RequestResult>> Rebalace(BlockRequest block)
        {
            string clientcode;
            using (var db = new Database())
            {
                clientcode = (await db.ClientAccounts.FirstOrDefaultAsync(c => c.Id == block.Id)).ClientCode;
            }

            if (await cs.Rebalance(clientcode))
                return Success();
            return Error("CS returned false");
        }

        [HttpPost("attach")]
        public async Task<ActionResult<RequestResult>> Attach(AttachRequest attach)
        {
            string clientcode;
            using (var db = new Database())
            {
                clientcode = (await db.ClientAccounts.FirstOrDefaultAsync(c => c.Id == attach.Id)).ClientCode;
            }

            var cl = (await cs.GetClientAccountByCodeAsync(clientcode)).FirstOrDefault();
            if (cl == null) return Error("CS can't find client");

            cl.Positions = null;
            cl.Examinations = null;
            cl.StrategyId = attach.Strategy;
            cl.Status = attach.Status;

            await cs.UpdateClientAccountAsync(cl);

            return Success();
        }

        [HttpPost("detach/{Id}")]
        public Task<ActionResult<RequestResult>> Detach(int Id)
        {
            return Attach(new AttachRequest { Strategy = null, Status = SubscriptionStatusEnum.Unattached, Id = Id });
        }


        [HttpGet("calc_rebalance/{id}")]
        public async Task<ActionResult<object>> CalcRebalace(int Id)
        {
            string clientcode;
            using (var db = new Database())
            {
                clientcode = (await db.ClientAccounts.FirstOrDefaultAsync(c => c.Id == Id)).ClientCode;

                try
                {
                    return Success(await cs.CalcRebalance(clientcode));
                }
                catch (Exception e)
                {
                    return Error(e);
                }
            }
        }

        [HttpGet("info/{id}")]
        public async Task<ActionResult<ClientAccountTO>> Info(int id)
        {
            var role = UserManager.GetUserRole(User);

            if (role != UserRole.Administrator && role != UserRole.Developer && role != UserRole.Developer &&
                role != UserRole.DigitalExpert && role != UserRole.Support) return Error("Недостаточно прав");
            try
            {
                Api.Models.ClientAccount clientAccount;
                Api.Models.Strategy strategy = null;
                Api.Models.Tariff tariff = null;
                Api.Models.InvestProfile profile = null;
                await using (var db = new Api.Models.Database())
                {
                    clientAccount = await db.ClientAccounts.FirstOrDefaultAsync(c => c.Id == id);
                    if (clientAccount == null)
                    {
                        return Error("Клиент не найден");
                    }
                    if (clientAccount.StrategyId != null)
                    {
                        strategy = await db.Strategies.FirstOrDefaultAsync(s => s.Id == clientAccount.StrategyId);
                        var tariffId = (await db.StrategyTariffs.FirstOrDefaultAsync(st => st.StrategyId == strategy.Id && st.StrategyType == (int) clientAccount.Status)).TariffId;
                        tariff = await db.Tariffs.FirstOrDefaultAsync(t => t.Id == tariffId);
                    }

                    if (clientAccount.ProfileId != null)
                        profile = await db.InvestProfiles.FirstOrDefaultAsync(p => p.Id == clientAccount.ProfileId);
                }

                var cl = (await cs.GetClientAccountByCodeAsync(clientAccount.ClientCode)).FirstOrDefault();
                if (cl != null && cl.StrategyId == null) cl.Client = null; // не выводим персданные по неподключенному клиенту
                else
                    cl.Client.FirstName = cl.Client.LastName = cl.Client.MiddleName = cl.Client.Address = cl.Client.Email = null;

                if (tariff != null)
                {
                    cl.StrategyTariffId = tariff.TariffId;
                    cl.StrategyTariff = $"{tariff.CategoryId} - {tariff.Description}";
                }

                if (profile != null)
                {
                    cl.Client.RiskProfileId = profile.ProfileId;
                    cl.Client.RiskProfileName = profile.Name;
                    cl.Client.RiskProfileDate = clientAccount.ProfileDate;
                }
                
                return Success(cl);
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        [HttpGet("rmdslimits/{clientcode}")]
        public async Task<ActionResult<LimitPosition[]>> RmdsLimits(string clientCode)
        {
            var role = UserManager.GetUserRole(User);

            if (role == UserRole.Administrator || role == UserRole.Developer || role == UserRole.DigitalExpert || role == UserRole.Support)
            {
                if (RMDSPositionsResponses == null)
                {
                    RMDSPositionsResponses = new ConcurrentQueue<PositionsResponse>();
                    rmds.StartListeningForPositions(p =>
                    {
                        RMDSPositionsResponses.Enqueue(p);
                        return Task.CompletedTask;
                    });
                }

                string futurescode;
                using (var db = new Database())
                {
                    var cl = await db.ClientAccounts.FirstOrDefaultAsync(c => c.ClientCode == clientCode);
                    if (cl == null) throw new Exception("No such client");
                    futurescode = cl?.FuturesCode;
                }

                await rmdsrequest.WaitAsync();
                try
                {
                    var start = DateTime.Now;
                    var totalDelayS = 20;
                    RMDSPositionsResponses.Clear();


                    await rmds.SubscribeForPositionsAsync(new[] { clientCode }, string.IsNullOrEmpty(futurescode) ? new string[0] : new[] { futurescode });

                    await Task.Run(async () =>
                    {
                        while ((DateTime.Now - start).TotalSeconds < totalDelayS
                               && (RMDSPositionsResponses.Count == 0
                                   || RMDSPositionsResponses.FirstOrDefault(r => r.ClientCode == clientCode && r.IsSnapshot) == null
                                   || !string.IsNullOrEmpty(futurescode) &&
                                   RMDSPositionsResponses.FirstOrDefault(r => r.ClientCode == futurescode && r.IsSnapshot) == null))
                            await Task.Delay(1000);
                    });

                    await rmds.UnsubscribeForPositionsAsync(new[] { clientCode }, string.IsNullOrEmpty(futurescode) ? new string[0] : new[] { futurescode });

                    return Success(
                        RMDSPositionsResponses.Where(r => r.IsSnapshot).GroupBy(r => r.ClientCode)
                            .SelectMany(g => g.Last().Positions
                                .Select(p => new LimitPosition
                                {
                                    ClientCode = g.Key,
                                    Security = p.Security,
                                    Number = p.Number,
                                    Price = p.Price,
                                    Currency = p.Currency,
                                    Depo = p.Depo,
                                    Kind = p.Kind,
                                    Tag = p.Tag
                                })).ToArray()
                    );
                }
                finally
                {
                    rmdsrequest.Release();
                }
            }

            return Error("Недостаточно прав");
        }

        [HttpGet("qrclimits/{clientcode}")]
        public async Task<ActionResult<ClientPortfolio[]>> QrcLimits(string clientCode)
        {
            var role = UserManager.GetUserRole(User);

            if (role == UserRole.Administrator || role == UserRole.Developer || role == UserRole.DigitalExpert || role == UserRole.Support)
            {
                string futurescode = null;
                using (var db = new Database())
                {
                    var cl = await db.ClientAccounts.FirstOrDefaultAsync(c => c.ClientCode == clientCode);
                    if (cl == null) throw new Exception("No such client");
                    futurescode = cl?.FuturesCode;
                }

                var result = await qrc.GetLimits(futurescode != null ? new[] { clientCode, futurescode } : new[] { clientCode });

                return Success(result?.Values
                    ?.Where(pp => pp != null)
                    ?.SelectMany(pp =>
                        pp?.Select(p => new LimitPosition
                        {
                            ClientCode = p.ClientCode,
                            Depo = p.Depo,
                            Currency = p.Currency,
                            Security = p.SecurityKey,
                            Tag = p.Tag,
                            Kind = p.Kind,
                            Number = p.Qty,
                            Price = p.AvgPrice,
                            VarMargin = p.Varmargin,
                            TotalVarmargin = p.TotalVarmargin,
                            PositionValue = p.PositionValue
                        })) ?? throw new Exception("QRC not ready"));
            }

            return Error("Недостаточно прав");
        }

        public class BlockRequest
        {
            public int Id { get; set; }
            public TimeSpan Time { get; set; }
        }

        public class AttachRequest
        {
            public int Id { get; set; }
            public Guid? Strategy { get; set; }
            public SubscriptionStatusEnum Status { get; set; }
        }

        public class RmdsPosition : ClientAccountPosition
        {
            public string ClientCode { get; set; }
        }
    }
}