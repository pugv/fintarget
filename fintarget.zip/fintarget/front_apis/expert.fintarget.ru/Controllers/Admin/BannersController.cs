﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Api.Models;
using fin_expert.Models;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ServiceBase;
using Database = Api.Models.Database;

namespace fin_expert.Controllers.Admin
{
    [Route("api/admin/[controller]")]
    [ApiController]
    [Authorize(Roles = "Administrator")]
    public class BannersController
        : WebCabinetController<BannersController>
    {
        public BannersController(IServiceProvider serviceProvider, ILogger<BannersController> logger)
            : base(serviceProvider, logger)
        {
        }

        // GET: /api/admin/banners/utms
        [HttpGet("utms")]
        public async Task<ActionResult<RequestResult<Utm[]>>> GetUtms()
        {
            try
            {
                using (var db = new Database())
                {
                    return Success(await db.Utms.ToArrayAsync());
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // POST: /api/admin/banners
        [HttpPost]
        public async Task<ActionResult<RequestResult<ListPage<Banner>>>> Get(PaginationAndSort paginationAndSort)
        {
            try
            {
                using (var db = new Database())
                {
                    var total = await db
                        .Banners
                        .CountAsync();

                    IQueryable<Banner> banners = db
                        .Banners;

                    var result = await
                        SortBanners(banners, paginationAndSort)
                            .Skip(paginationAndSort.PageNumber * paginationAndSort.PageSize)
                            .Take(paginationAndSort.PageSize)
                            .ToArrayAsync();

                    return Success(new ListPage<Banner>
                    {
                        Total = total,
                        PageItems = result
                    });
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // POST: /api/admin/banners/edit
        [HttpPost("edit")]
        public async Task<ActionResult<RequestResult<Banner>>> Edit(Banner banner)
        {
            try
            {
                using (var db = new Database())
                {
                    if (banner.Id == 0) // new
                    {
                        banner.Active = false; // first save in inactive state

                        banner.Id = await db
                            .InsertWithInt32IdentityAsync(banner);
                    }
                    else // existing
                    {
                        await db
                            .UpdateAsync(banner);
                    }

                    return Success(banner);
                }
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private IQueryable<Banner> SortBanners(IQueryable<Banner> banners, PaginationAndSort paginationAndSort)
        {
            switch (paginationAndSort.SortFieldName.ToLower())
            {
                case "title":
                    return paginationAndSort.SortDirection > 0 ? banners.OrderBy(b => b.Title) : banners.OrderByDescending(b => b.Title);
                case "subtitle":
                    return paginationAndSort.SortDirection > 0 ? banners.OrderBy(b => b.Subtitle) : banners.OrderByDescending(b => b.Subtitle);
                case "type":
                    return paginationAndSort.SortDirection > 0 ? banners.OrderBy(b => b.Type) : banners.OrderByDescending(b => b.Type);
                case "url":
                    return paginationAndSort.SortDirection > 0 ? banners.OrderBy(b => b.Url) : banners.OrderByDescending(b => b.Url);
                case "utm":
                    return paginationAndSort.SortDirection > 0 ? banners.OrderBy(b => b.Utm) : banners.OrderByDescending(b => b.Utm);
                case "buttontext":
                    return paginationAndSort.SortDirection > 0 ? banners.OrderBy(b => b.ButtonText) : banners.OrderByDescending(b => b.ButtonText);
                case "active":
                    return paginationAndSort.SortDirection > 0 ? banners.OrderBy(b => b.Active) : banners.OrderByDescending(b => b.Active);
                default:
                    return paginationAndSort.SortDirection > 0 ? banners.OrderBy(b => b.Id) : banners.OrderByDescending(b => b.Id);
            }
        }
    }
}