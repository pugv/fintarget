﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using CS.Kernel.Model;
using ExchangeHelpers.HS;
using fin_expert.Interfaces;
using fin_expert.Models;
using Expert.Models;
using fin_expert.Utilities;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLib.ParsersFormatters;
using PS.Models;
using ServiceBase;
using Database = CS.Kernel.Functionality.Database;
using Security = fin_expert.Models.Security;

namespace fin_expert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SecuritiesController
        : WebCabinetController<SecuritiesController>
    {
        private readonly ISecurityCache securityCache;

        public SecuritiesController(IServiceProvider serviceProvider, ILogger<SecuritiesController> logger, ISecurityCache security)
            : base(serviceProvider, logger)
        {
            securityCache = security;
        }

        // POST: api/securities/search
        [Authorize]
        [HttpPost("search")]
        public async Task<ActionResult<RequestResult<Security[]>>> Search(SecuritySearch criteria)
        {
            try
            {
                Strategy strategy = null;
                if (criteria.StrategyId != null)
                    strategy = await CheckStrategyAccessRights(criteria.StrategyId.Value);

                string[] allowedPatterns = null;

                if (strategy != null)
                    allowedPatterns = JsonConvert.DeserializeObject<string[]>(strategy.Securities);

                // accepts null as allowedPatterns
                var securities = securityCache.SearchSecurities(allowedPatterns, criteria.ClassCodes,
                    criteria.Pattern.ToLower(), Config.MaxSecuritySearchResuls);

                return Success(securities.OrderBy(s => s.IsinCode).Select(s => new Security
                {
                    Key = $"{GetSecuritySymbolName(s)} {s.ClassCode} {s.Board}",
                    Symbol = s.Symbol,
                    ClassCode = s.ClassCode,
                    Name = s.Name,
                    Isin = s.IsinCode
                }).ToArray());
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [Authorize]
        [HttpGet("all")]
        public ActionResult<RequestResult<SecurityRecord[]>> All()
        {
            try
            {
                return Success(securityCache.GetSecurities());
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [HttpPost("optimalweight")]
        public async Task<ActionResult<RequestResult<OptimalWeightResult>>> OptimalWeight(SecurityRequest request)
        {
            try
            {
                Strategy strategy = null;

                if (string.IsNullOrEmpty(request.ApiKey))
                    strategy = await CheckStrategyAccessRights(request.StrategyId);
                else
                    return StatusError(HttpStatusCode.Unauthorized, "Ошибка авторизации");

                var security = await securityCache.GetSecuritiyWithLatestPrice(request.SecurityKey);

                if (security != null)
                {
                    var role = UserManager.GetUserRole(User);
                    if (role == UserRole.Administrator || role == UserRole.Manager)
                        return Success(
                            await OptimalWeight(security, strategy));

                    return StatusError(HttpStatusCode.Forbidden, "Error");
                }

                return StatusError(HttpStatusCode.BadRequest, "Инструмент не найден", (int)Errors.SecurityNotFound);
            }
            catch (Exception ex)
            {
                return StatusError(HttpStatusCode.InternalServerError, ex);
            }
        }

        public static async Task<OptimalWeightResult> OptimalWeight(SecurityRecord security, Strategy strategy)
        {
            var threshold = strategy.SubscriptionThreshold;

            if (security.Type == "FuturesContract")
                security.SharesInLot = 1;

            var minWeight = threshold != 0 ? (100m * security.LastPrice * security.SharesInLot / threshold).RoundTo(2) : 0;
            decimal? maxWeight = strategy.MaxInstrumentWeight?.RoundTo(2) ?? 100;

            // var weight = strategy.RecalcMode == 2 ? ((p.Value.Weight * security?.LastPrice / p.Value.OpenPrice / (1 + unrealizedPL)) ?? 0)

            var nDigits = security.PriceStep?.GetDigitsAfterPoint() ?? 0;
            var symbol = GetSecuritySymbolName(security);

            using (var db = new Database())
            {
                var values = await db.ClientAccounts.Where(c => c.StrategyId == strategy.Id && c.Status == ClientAccount.StatusEnum.AutoFollow)
                    .Select(c => c.Value).Where(c => c > strategy.SubscriptionThreshold / 2).OrderBy(c => c).ToArrayAsync();
                values = values.Take((int)Math.Ceiling(values.Length / 2.0)).ToArray();
                var lotPrice = (security.SharesInLot ?? 1) * (double)(security.LastPrice ?? 0.0000001m);


                var weights = Enumerable.Range((int)Math.Max(minWeight ?? 1, 1), 100).Select(i => i / 100.0)
                    .Select(w => new OptimalWeightResult.OptimalWeightPoint
                    {
                        w = w,
                        d = values.Average(v => Math.Abs(w - Math.Floor((double)v * w / lotPrice) * lotPrice / (double)v) / w)
                    }).ToArray();


                return new OptimalWeightResult
                {
                    Points = weights
                };
            }
        }

        // POST: api/securities/info
        [HttpPost("info")]
        public async Task<ActionResult<RequestResult<SecurityAdvanced>>> Info(SecurityRequest request)
        {
            try
            {
                Strategy strategy = null;

                if (string.IsNullOrEmpty(request.ApiKey))
                {
                    strategy = await CheckStrategyAccessRights(request.StrategyId);
                }
                else
                {
                    var (apiKey, _) = await dataAccessLayer.GetStrategyApiKey(request.StrategyId);

                    if (apiKey == null)
                        return StatusError(HttpStatusCode.BadRequest, $"На стратегии {request.StrategyId} запрещён приём внешних сигналов");

                    if (request.ApiKey != apiKey) return StatusError(HttpStatusCode.Unauthorized, "Ошибка авторизации");

                    strategy = await dataAccessLayer.GetStrategy(request.StrategyId);
                }

                // if (!securityCache.InCache(request.SecurityKey))
                //     await securityCache.AddSecurities(new[] { request.SecurityKey });

                var security = await securityCache.GetSecuritiyWithLatestPrice(request.SecurityKey);

                if (security != null)
                {
                    var threshold = strategy.SubscriptionThreshold;
                    var maxSignalWeight = strategy.MaxSignalWeight;

                    if (request.CheckChildren)
                        using (var db = new Expert.Models.Database())
                        {
                            var childParams = await db
                                .Strategies
                                .Where(s => s.ParentStrategy == strategy.Id)
                                .Select(s => new { SubscriptionThreshold = s.SubscriptionThreshold, MaxSignalWeight = s.MaxSignalWeight })
                                .ToArrayAsync();

                            if (childParams.Length > 0)
                            {
                                threshold = Math.Min(threshold, childParams.Min(p => p.SubscriptionThreshold));
                                maxSignalWeight = childParams.Select(p => p.MaxSignalWeight).Concat(new [] { maxSignalWeight }).Min();
                            }
                        }

                    if (security.Type == "FuturesContract")
                        security.SharesInLot = 1;

                    var minWeight = threshold != 0 ? (100m * security.LastPrice * security.SharesInLot / threshold).RoundTo(2) : 0;
                    var maxWeight = strategy.MaxInstrumentWeight?.RoundTo(2) ?? 100;
                    var state = await GetStrategyOpenPositions(strategy.Id);

                    var unrealizedPL = state?.ActivePositions?.Sum(p =>
                    {
                        var security = securityCache.GetSecuritiy(p.Key.GetKey());
                        return (GetUnrealizedPositionPL(p.Value, security) ?? 0m) * Math.Abs(p.Value.Weight);
                    }) ?? 0;

                    var pos = state?.ActivePositions?.FirstOrDefault(p => p.Key.GetKey() == request.SecurityKey).Value;

                    var curWeight = pos == null ? 0 :
                        strategy.RecalcMode == 2 ? (pos.Weight * security?.LastPrice / pos.OpenPrice / (1 + unrealizedPL) * 100m).RoundTo(2) :
                        (pos.Weight * 100m).RoundTo(2);

                    var minTPBuy = (security.LastQuotation ?? 0) * 1.005m;
                    var maxSLBuy = (security.LastQuotation ?? 0) * 0.998m;
                    var maxTPSell = (security.LastQuotation ?? 0) * 0.995m;
                    var minSLSell = (security.LastQuotation ?? 0) * 1.002m;

                    var nDigits = security.PriceStep?.GetDigitsAfterPoint() ?? 0;
                    var symbol = GetSecuritySymbolName(security);

                    var (g, t) = securityCache.GetGammaTheta(security.ClassCode);

                    decimal? coef = 0;
                    var role = UserManager.GetUserRole(User);
                    if (role == UserRole.Administrator || role == UserRole.Manager)
                        coef = (security.Turnover ?? 0) != 0
                            ? g * t * security.Volatility * (strategy.Currency == "SUR" ? strategy.AfValueSUR : strategy.AfValueUSD) / security.Turnover
                            : 0;

                    return Success(new SecurityAdvanced
                    {
                        Key = $"{symbol} {security.ClassCode} {security.Board}",
                        Symbol = security.Symbol,
                        ClassCode = security.ClassCode,
                        Board = security.Board,
                        Name = security.Name,
                        Price = security.LastPrice,
                        Quotation = security.LastQuotation,
                        Currency = SecurityCache.GetCurrency(security.Currency),
                        LotSize = security.SharesInLot ?? 1,
                        ShortAllowed = await securityCache.IsShortAllowed(security.Key),
                        Type = securityCache.GetSecurityTypeInfo(security.Type),
                        MinWeight = minWeight,
                        MaxWeight = maxWeight,
                        MaxSignalWeight = maxSignalWeight,
                        CurrentWeight = curWeight ?? 0,
                        MaxSLBuy = maxSLBuy.RoundTo(nDigits),
                        MinTPBuy = minTPBuy.RoundTo(nDigits),
                        MinSLSell = minSLSell.RoundTo(nDigits),
                        MaxTPSell = maxTPSell.RoundTo(nDigits),
                        PriceDigits = nDigits,
                        ExecCoef = coef ?? 0
                    });
                }

                return StatusError(HttpStatusCode.BadRequest, "Инструмент не найден", (int)Errors.SecurityNotFound);
            }
            catch (Exception ex)
            {
                return StatusError(HttpStatusCode.InternalServerError, ex);
            }
        }

        // POST: api/securities/forecast
        [HttpPost("forecast")]
        public async Task<ActionResult<RequestResult<SecurityForecastDto[]>>> Forecast(SecurityForecastRequest request)
        {
            try
            {
                using (var db = new PortfolioDatabase())
                {
                    var records = db.SecurityForecasts.Where(c => c.SourceId == request.SourceId && request.SecurityKeys.Contains(c.SecurityKey))
                        .Select(c => new SecurityForecastDto
                            { SecurityKey = c.SecurityKey, CurrentPrice = c.CurrentPrice, Forecast = c.Forecast, TargetPrice = c.TargetPrice });
                    return Success(await records.ToArrayAsync());
                }
            }
            catch (Exception ex)
            {
                return StatusError(HttpStatusCode.InternalServerError, ex);
            }
        }


        public class OptimalWeightResult
        {
            public OptimalWeightPoint[] Points { get; set; }
            public Tuple<double, double>[] Intervals { get; set; }

            public struct OptimalWeightPoint
            {
                public double w;
                public double d;
            }
        }
    }
}