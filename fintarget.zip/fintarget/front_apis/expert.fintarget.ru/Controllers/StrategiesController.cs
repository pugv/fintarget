﻿using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Expert.Models;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LCS.Models;
using LinqToDB;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NLib.AuxTypes;
using NLib.Helpers;
using NLib.MathUtils;
using NLib.ParsersFormatters;
using NLib.ParsersFormatters.DateTime;
using PositionCalculator;
using ServiceBase;
using Database = Expert.Models.Database;
using Security = PositionCalculator.Security;

namespace fin_expert.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StrategiesController
        : WebCabinetController<StrategiesController>
    {
        private static readonly ConcurrentDictionary<Guid, Task> ModerateTasks = new ConcurrentDictionary<Guid, Task>();
        private readonly ILCS _lcs;
        private readonly ISecurityCache _securityCache;
        private readonly ISTS _sts;

        public StrategiesController(IServiceProvider serviceProvider, ILogger<StrategiesController> logger, ISecurityCache cache, ILCS lcs, ISTS sts)
            : base(serviceProvider, logger)
        {
            _securityCache = cache;
            _lcs = lcs;
            _sts = sts;
        }

        // GET: api/strategies
        [HttpGet]
        [Authorize]
        public async Task<ActionResult<RequestResult<StrategyDirectoryItem[]>>> Get()
        {
            try
            {
                var id = UserManager.GetUserId(User);
                var role = UserManager.GetUserRole(User);

                return Success(await GetUserStrategies(id, role));
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [HttpPost("requestmoderate/{strategyId}/{yesno}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<StrategyDirectoryItem>>> RequestModerate([FromRoute] Guid strategyId, [FromRoute] string yesno)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(strategyId);
                if (strategy != null)
                {
                    if (yesno.Equals("yes", StringComparison.OrdinalIgnoreCase) && strategy.Status == StrategyStatus.SandBox)
                    {
                        Logger.LogInformation($"Strategy {strategyId} send to moderaton by {UserManager.GetUserName(User)}");

                        if (await dataAccessLayer.SetStrategyStatus(strategyId, StrategyStatus.Moderate))
                            return Success(new StrategyDirectoryItem
                            {
                                Id = strategyId,
                                Name = strategy.Name,
                                ParentStrategy = null,
                                IsChild = strategy.ParentStrategy != null,
                                Status = StrategyStatus.Moderate
                            });
                    }
                    else if (yesno.Equals("no", StringComparison.OrdinalIgnoreCase) && strategy.Status == StrategyStatus.Moderate)
                    {
                        Logger.LogInformation($"Strategy {strategyId} removed from moderation {UserManager.GetUserName(User)}");

                        if (await dataAccessLayer.SetStrategyStatus(strategyId, StrategyStatus.SandBox))
                            return Success(new StrategyDirectoryItem
                            {
                                Id = strategyId,
                                Name = strategy.Name,
                                ParentStrategy = null,
                                IsChild = strategy.ParentStrategy != null,
                                Status = StrategyStatus.SandBox
                            });
                    }
                }
            }
            catch (Exception e)
            {
                Logger.LogError(e, "Moderate");
            }

            return Error("Error");
        }

        [HttpPost("tosandbox/{strategyId}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<StrategyDirectoryItem>>> ToSandbox([FromRoute] Guid strategyId)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(strategyId);
                if (UserManager.GetUserRole(User) == UserRole.Administrator && strategy != null)
                {
                    if (ModerateTasks.TryGetValue(strategyId, out var t) && t != null)
                        return Error("Стратегия переводится к запуску");

                    Logger.LogInformation($"Strategy {strategyId} send to sandbox {UserManager.GetUserName(User)}");

                    if (await dataAccessLayer.SetStrategyStatus(strategyId, StrategyStatus.SandBox))
                        return Success(new StrategyDirectoryItem
                        {
                            Id = strategyId,
                            Name = strategy.Name,
                            ParentStrategy = null,
                            IsChild = strategy.ParentStrategy != null,
                            Status = StrategyStatus.SandBox
                        });
                }
                else
                {
                    return Error("Access denied");
                }
            }
            catch (Exception e)
            {
                Logger.LogError(e, "ToSandbox");
            }

            return Error("Error");
        }


        [HttpPost("moderate/{strategyId}/{yesno}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<StrategyDirectoryItem>>> Moderate([FromRoute] Guid strategyId, [FromRoute] string yesno)
        {
            try
            {
                var strategy = await CheckStrategyWriteRights(strategyId);
                var strat = (await dataAccessLayer.GetApiStrategies()).FirstOrDefault(s => s.Id == strategy.Id);

                if (UserManager.GetUserRole(User) == UserRole.Administrator &&
                    strategy != null && strat!=null)
                {
                    if (ModerateTasks.TryGetValue(strategyId, out var t) && t != null)
                        return Error("Стратегия переводится к запуску");

                    if (yesno.Equals("yes", StringComparison.OrdinalIgnoreCase) && strategy.Status == StrategyStatus.Moderate)
                    {
                        var cbstrat = await dataAccessLayer.GetStrategy(strat.Id);

                        var patterns = cbstrat.AllowedSecuritiesArray;

                        Logger.LogInformation($"Strategy {strategyId} accepted by {UserManager.GetUserName(User)}");


                        if (await dataAccessLayer.SetStrategyStatus(strategyId, StrategyStatus.Standard))
                        {
                            var task = Task.Run(async () =>
                            {
                                try
                                {
                                    foreach (var s in (await dataAccessLayer.GetSnaboxSignals(strat.Id)).Where(s => s.SecurityKey != null).Distinct())
                                        if (!patterns.Any(pattern =>
                                            Regex.IsMatch(s.SecurityKey, pattern) ||
                                            Regex.IsMatch(
                                                _securityCache.GetSecuritiy(s.SecurityKey)?.CategoryPattern ??
                                                throw new UserVisibleException($"Инструмент {s.SecurityKey} не найден"), pattern)))
                                            throw new UserVisibleException($"Инструмент {s.SecurityKey} не разрешён для стратегии");

                                    await dataAccessLayer.CopyStrategySignalsFromSandbox(strategyId);

                                    if (!await _lcs.ReloadStrategy(strategyId))
                                        throw new Exception("Can't reload strategy");

                                    if (!await _sts.UpdateHistory(strategyId)) Logger?.LogError($"Update strategy history from sandbox {strategyId}");
                                    ModerateTasks[strategyId] = null;

                                    //Logger.LogInformation($"Strategy {StrategyId} successfully copied from sandbox");
                                    NLib.Logger.MonitoringService.Log($"Strategy {strategyId} successfully copied from sandbox");
                                }
                                catch (Exception e)
                                {
                                    Logger?.LogError(e, $"Copy strategy from sandbox {strategyId}");
                                    NLib.Logger.MonitoringService.Log($"Error copy strategy from sandbox {strategyId}: {e.Message}", NLib.Logger.LogLevel.Error);

                                    await dataAccessLayer.SetStrategyStatus(strategyId, StrategyStatus.Moderate);
                                    ModerateTasks[strategyId] = null;
                                    throw;
                                }
                            });

                            ModerateTasks[strategyId] = task;

                            await Task.Delay(2000);
                            if (task.Status == TaskStatus.Faulted)
                                return Error(task.Exception);


                            return Success(new StrategyDirectoryItem
                            {
                                Id = strategyId,
                                Name = strategy.Name,
                                ParentStrategy = null,
                                IsChild = strategy.ParentStrategy != null,
                                Status = strat.Open ? StrategyStatus.Standard : StrategyStatus.Closed
                            });
                        }
                    }
                    else if (yesno.Equals("no", StringComparison.OrdinalIgnoreCase) && strategy.Status == StrategyStatus.Moderate)
                    {
                        Logger.LogInformation($"Strategy {strategyId} declined by {UserManager.GetUserName(User)}");

                        if (await dataAccessLayer.SetStrategyStatus(strategyId, StrategyStatus.SandBox))
                            return Success(new StrategyDirectoryItem
                            {
                                Id = strategyId,
                                Name = strategy.Name,
                                ParentStrategy = null,
                                IsChild = strategy.ParentStrategy != null,
                                Status = StrategyStatus.SandBox
                            });
                    }
                }
                else
                {
                    return Error("Access denied");
                }
            }
            catch (Exception e)
            {
                Logger.LogError(e, "Moderate");
            }

            return Error("Error");
        }

        // GET: api/strategies/openpositions/{strategyId}
        [HttpGet("openpositions/{strategyId}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<OpenPosition[]>>> OpenPositions(Guid strategyId)
        {
            try
            {
                var strategy = await CheckStrategyAccessRights(strategyId);

                if (strategy.ParentStrategy != null)
                    strategyId = strategy.ParentStrategy.Value;

                var state = await GetStrategyOpenPositions(strategyId);

                if (state != null)
                {
                    await _securityCache.AddSecurities(state.ActivePositions.Select(p => p.Key.GetKey()));

                    var unrealized = state.ActivePositions.Sum(p =>
                        p.Value.Weight * (_securityCache.GetSecuritiy(p.Key.GetKey())?.LastPrice - p.Value.OpenPrice) / p.Value.OpenPrice ?? 0);
                    return SuccessValue(state.ActivePositions.Select(p =>
                    {
                        var security = _securityCache.GetSecuritiy(p.Key.GetKey());

                        var upl = GetUnrealizedPositionPL(p.Value, security);

                        return new OpenPosition
                        {
                            SecurityKey = p.Key.GetKey(),
                            Symbol = GetSecuritySymbolName(security),
                            ClassCode = p.Value.Security.ClassCode,
                            Name = security?.Name,
                            Comment = p.Value.Comment,
                            CurrentPrice = ConvertPriceToString((security?.LastQuotation ?? 0) != 0 ? security.LastQuotation : security?.LastPrice,
                                security),
                            OpenPrice =  ConvertPriceToString(p.Value.OpenQuotation != 0 ? p.Value.OpenQuotation : p.Value.OpenPrice, security),
                            OpenTime = p.Value.OpenTime,
                            RealizedPL = (p.Value.RealizedPnl * 100m).ToStdString(2),
                            StopLoss = ConvertPriceToString(p.Value.StopLoss, security),
                            TakeProfit = ConvertPriceToString(p.Value.TakeProfit, security),
                            UnrealizedPL = (upl * 100m)?.ToStdString(2),
                            UnrealizedPLPortfolio = upl == null ? null : (upl * 100m * Math.Abs(p.Value.Weight)).Value.ToStdString(2),
                            Weight = (p.Value.Weight * 100m).ToStdString(2),
                            CurrentWeight = (p.Value.Weight * security.LastPrice / p.Value.OpenPrice / (1 + unrealized) * 100m ?? 0).ToStdString(2)
                        };
                    }).OrderByDescending(t => t.OpenTime).ToArray());
                }

                return SuccessValue(new OpenPosition[0]);
            }
            catch (Exception ex)
            {
                return Error(new UserVisibleException(ex.Message + ex.StackTrace));
            }
        }

        // GET: api/strategies/history/{strategyId}/{period}
        [HttpGet("history/{strategyId}/{period}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<StrategyHistory>>> StrategyHistory(Guid strategyId, string period)
        {
            try
            {
                var role = UserManager.GetUserRole(User);

                DateTime? startDate = null;
                var vcIndex = 0;

                switch (period)
                {
                    case "ytd":
                        startDate = new DateTime(DateTime.Now.Year, 1, 1);
                        vcIndex = 5;
                        break;
                    case "1m":
                        startDate = DateTime.Now.Date.AddMonths(-1);
                        vcIndex = 4;
                        break;
                    case "3m":
                        startDate = DateTime.Now.Date.AddMonths(-3);
                        vcIndex = 3;
                        break;
                    case "6m":
                        startDate = DateTime.Now.Date.AddMonths(-6);
                        vcIndex = 2;
                        break;
                    case "1y":
                        startDate = DateTime.Now.Date.AddYears(-1);
                        vcIndex = 1;
                        break;
                }

                var strategy = await CheckStrategyAccessRights(strategyId);

                var history = await GetStrategyHistory(strategyId, startDate);

                if (!(history?.Any() ?? false))
                {
                    Logger?.LogInformation($"No history by strategy {strategy.Id}");

                    return SuccessValue(new StrategyHistory
                    {
                        History = null,
                        IndexName = null
                    });
                }

                if (startDate == null)
                    startDate = history.First().t.FromJsonTime();

                var (indexHistory, indexName) = await GetIndexHistory(strategyId, history?.FirstOrDefault()?.t.FromJsonTime());

                // to portfolio price (in %) & normalize
                Array.ForEach(history, p =>
                {
                    p.v = p.v / 100m + 1m;
                    p.vr = p.vr / 100m + 1m;
                    if (p.vc != null && p.vc.Length > vcIndex)
                        p.vc[vcIndex] = p.vc[vcIndex] / 100m + 1m;
                });

                var indexIdx = 0;
                if (indexHistory != null)
                    while (indexIdx < indexHistory.Length - 1 && indexHistory[indexIdx + 1].t <= history[0].t)
                        indexIdx++;
                var firstIndexIdx = indexIdx;

                var result = new StrategyHistory.AggregateHistoryPoint[history.Length];

                // fill in charts
                for (var idx = 0; idx < history.Length; idx++)
                {
                    result[idx] = new StrategyHistory.AggregateHistoryPoint();
                    result[idx].t = history[idx].t;

                    if (role == UserRole.Administrator || role == UserRole.RiskManager || role == UserRole.Manager || role == UserRole.DigitalExpert ||
                        role == UserRole.Support || role == UserRole.ContentManager || role == UserRole.Developer)
                        result[idx].v = 100m * (history[idx].v / history[0].v - 1m);
                    else
                        result[idx].v = null;

                    if (role == UserRole.Administrator || role == UserRole.RiskManager || role == UserRole.Expert || role == UserRole.Manager ||
                        role == UserRole.DigitalExpert || role == UserRole.Support || role == UserRole.ContentManager || role == UserRole.Developer)
                    {
                        result[idx].vr = 100m * (history[idx].vr / history[0].vr - 1m);

                        //if (role == UserRole.Administrator || role == UserRole.RiskManager || role == UserRole.Expert) // DIS-994
                        //{
                        if (history[idx].vc != null)
                        {
                            if (history[idx].vc.Length > vcIndex)
                                result[idx].vc = 100m * (history[idx].vc[vcIndex] /
                                    (history[0].vc != null && history[0].vc.Length > vcIndex ? history[0].vc[vcIndex] : 1) - 1m);
                            else
                                result[idx].vc = 0;
                        }
                        //}
                    }

                    if (indexHistory != null)
                    {
                        while (indexIdx < indexHistory.Length - 1 && indexHistory[indexIdx + 1].t <= history[idx].t)
                            indexIdx++;
                        result[idx].vi = 100m * (indexHistory[indexIdx].v / indexHistory[firstIndexIdx].v - 1m);
                    }
                }

                return SuccessValue(new StrategyHistory
                {
                    IndexName = indexName,
                    History = result,
                    MeanYearProfit = history.Length > 1
                        ? Math.Round(
                            Math.Pow((double)((history.LastOrDefault()?.v ?? 0) / (history.FirstOrDefault()?.v ?? 1)),
                                365 / ((history.LastOrDefault()?.t.FromJsonTime() ?? default) - (history.FirstOrDefault()?.t.FromJsonTime() ?? default))
                                .TotalDays) * 100 - 100, 2)
                        : 0,
                    Profit = (double)Math.Round(((history.LastOrDefault()?.v ?? 0) / (history.FirstOrDefault()?.v ?? 1) - 1) * 100, 2),
                    Drawdown = (double)(history.MaxOrDefault(h => history.Where(hh => hh.t > h.t).MaxOrDefault(hh => h.v - hh.v)) * 100m).RoundTo(2)
                });

            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // POST: api/strategies/alltrades/{strategyId}
        [HttpGet("snapshot/{strategyId}/{date}")]
        [Authorize]
        public async Task<ActionResult> GetSnapshot(Guid strategyId, DateTime date)
        {
            var strategy = await CheckStrategyAccessRights(strategyId);

            if (strategy.Status != StrategyStatus.Standard && GetType() == typeof(StrategiesController))
                return new RedirectResult($"/api/sandbox/snapshot/{strategyId}/{date:yyyy-MM-dd}");

            var sig = await GetStrategyLastSignal(strategy.ParentStrategy ?? strategyId, date);
            var state = new SignalProcessor.State();
            if (sig?.State != null)
                state = SignalDTO.StateFromJson(sig.State, sig.Id);

            var hist = (await GetStrategyHistory(strategyId, null, false)).FirstOrDefault(h => h.t >= date.ToJsonTime());

            if (state.ActivePositions.Count > 0)
            {
                var prices = (await _securityCache.EndOfDay(state.ActivePositions.Select(p => p.Key.GetKey()).ToArray(), date))
                    .ToDictionary(p => new Security(p.Key), p => (p.Value.Price,p.Value.Price)); //TODO: Get real quotation
                SignalProcessor.UpdateState(state, prices);
            }

            return Success(new Snapshot
            {
                Date = date,
                RealizedPnl = hist?.r ?? 0,
                UnrealizedPnl = hist?.u ?? 0,
                PosUnrealizedPnl = state.ActivePositions.Sum(p => p.Value.UnrealizedPnl),
                Positions = state.ActivePositions.Select(p => p.Value).ToArray()
            });
        }

        // POST: api/strategies/alltrades/{strategyId}
        [HttpPost("alltrades/{strategyId}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<TradePage>>> AllTrades(Guid strategyId, [FromBody] PaginationAndSort paginationAndSort)
        {
            try
            {
                var strategy = await CheckStrategyAccessRights(strategyId);

                if (strategy.ParentStrategy != null)
                    strategyId = strategy.ParentStrategy.Value;

                var (total, trades) = await GetStrategyTrades(strategyId, paginationAndSort);

                if (trades != null)
                {
                    var nStratUsers = strategy.AfClientCount ?? 0;

                    var pageTrades = trades.Select(t =>
                    {
                        var security = string.IsNullOrEmpty(t.SecurityKey) ? null : _securityCache.GetSecuritiy(t.SecurityKey);

                        return new Trade
                        {
                            Symbol = security == null && t.Type == SignalTypeEnum.Dividend ? "комиссия" :
                                security != null ? GetSecuritySymbolName(security) : "",
                            Name = security?.Name,
                            Type = t.Type.ToString().ToLower(),
                            Comment = security == null && t.Type == SignalTypeEnum.Dividend ? "Комиссия за использование заёмных средств" : t.Comment,
                            Price = t.OpenQuotation != 0
                                ? t.OpenQuotation.RoundTo(((security?.PriceStep ?? 0.001m) * (t.OpenPrice != 0 ? t.OpenQuotation / t.OpenPrice : 1))
                                    .GetDigitsAfterPoint())
                                : t.OpenPrice.RoundTo(security?.PriceStep?.GetDigitsAfterPoint() ?? 3),
                            Time = t.OpenTime,
                            Weight = ((t.Type == SignalTypeEnum.VarMargin ? t.RealizedPnl.Sign() : 1) * t.Weight * 100m).RoundToNot0(2),
                            RealizedPL = (t.RealizedPnl * 100m)?.RoundToNot0(2) ?? 0,

                            IsInProcess = (t.nExecDone < nStratUsers || (t.nExecuting ?? 0) != 0) && DateTime.Now < t.OpenTime + TimeSpan.FromMinutes(30),
                            nExecPrice = t.nExecPrice ?? 0,
                            nDone = t.nExecDone ?? 0,
                            ExecPL = ((t.ExecPL ?? 0) * 100).RoundToNot0(2),
                            ExecPrice = t.ExecPrice?.RoundTo(t.ExecPrice.Value.GetDigitsAfterPoint()),
                            ExecutingPrt = nStratUsers != 0 ? Math.Round(100.0 * (t.nExecuting ?? 0) / nStratUsers) : 0,
                            ExecWeight = ((t.ExecWeight ?? 0) * 100m).RoundToNot0(2),
                            DonePrt = nStratUsers != 0 ? Math.Round(100.0 * (t.nExecDone ?? 0) / nStratUsers) : 0
                        };
                    }).ToArray();

                    return SuccessValue(new TradePage
                    {
                        PageTrades = pageTrades,
                        TotalTrades = total
                    });
                }

                return SuccessValue(new TradePage
                {
                    PageTrades = new Trade[0],
                    TotalTrades = 0
                });
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        // GET: api/strategies/download/trades/{strategyId}
        [HttpGet("download/trades/{strategyId}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<FileDownload>>> DownloadTrades(Guid strategyId)
        {
            try
            {
                var strategy = await CheckStrategyAccessRights(strategyId);

                if (strategy.ParentStrategy != null) strategyId = strategy.ParentStrategy.Value;

                var (_, trades) = await GetStrategyTrades(strategyId, new PaginationAndSort
                {
                    PageSize = 0,
                    SortDirection = -1,
                    SortFieldName = "time"
                });

                if (trades != null)
                {
                    var content = "Время\tИнструмент\tЦена\tКотировка\tВес\tСделка" + Environment.NewLine +
                                  string.Join(Environment.NewLine, trades.Select(t => GetTradeLine(t)));

                    return Success(new FileDownload
                    {
                        // Берём имя из дочерней стратегии
                        FileName = $"{strategy.Name}-trades-{DateTime.Now:dd.MM.yyyy}.txt",
                        ContentBase64 = ToBase64(content)
                    });
                }

                return Error("История сделок не найдена");
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }


        // GET: api/strategies/download/history/{strategyId}
        [HttpGet("download/history/{strategyId}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<FileDownload>>> DownloadHistory(Guid strategyId)
        {
            try
            {
                var strategy = await CheckStrategyAccessRights(strategyId);

                var history = await GetStrategyHistory(strategyId, null, false);

                if (history != null)
                {
                    var content = string.Join(Environment.NewLine,
                        new[] { "Date\tTotal\tRealized\tUnrealized" }.Union(history.Select(hp => GetHistoryLine(hp))));

                    return Success(new FileDownload
                    {
                        // Берём имя из дочерней стратегии
                        FileName = $"{strategy.Name}-history-{DateTime.Now:dd.MM.yyyy}.txt",
                        ContentBase64 = ToBase64(content)
                    });
                }

                return Error("История по стратегии не найдена");
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private string GetHistoryLine(StrategyHistory.HistoryPoint hp)
        {
            return $"{hp.t.FromJsonTime():yyyy-MM-dd}\t{hp.v}\t{hp.r}\t{hp.u}";
        }

        private string GetTradeLine(SignalDTO trade)
        {
            return
                $"{trade.OpenTime.ToStandardString()}\t{(trade.SecurityKey != null ? trade.SecurityKey.Split(' ').FirstOrDefault() : trade.Comment)}\t{trade.OpenPrice}\t{trade.OpenQuotation}\t{Math.Abs(trade.Weight)}\t{(trade.Weight.Sign() > 0 ? "Покупка" : "Продажа")}";
        }

        // POST: api/strategies/delayedsignals/{strategyId}
        [HttpPost("delayedsignals/{strategyId}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<DelayedSignalsPage>>> DelayedSignals(Guid strategyId, [FromBody] PaginationAndSort paginationAndSort)
        {
            try
            {
                var strategy = await CheckStrategyAccessRights(strategyId);

                if (strategy.ParentStrategy != null) strategyId = strategy.ParentStrategy.Value;

                var (total, signals) = await GetStrategyDelayedSignals(strategyId, paginationAndSort);

                if (signals != null)
                {
                    var pageSignals = signals.Select(s =>
                    {
                        var security = _securityCache.GetSecuritiy(s.SecurityKey);

                        return new DelayedSignal
                        {
                            Symbol = GetSecuritySymbolName(security),
                            Name = security?.Name,
                            Comment = s.Comment,
                            OpenPrice = ConvertPriceToString(s.OpenQuotation, security),
                            ExecPrice = ConvertPriceToString(s.ExecQuotation, security),
                            Direction = s.ExecQuotation > s.OpenQuotation ? 1 : -1,
                            FillingTime = s.OpenTime,
                            Weight = (s.Weight * 100m).ToStdString(2),
                            Id = s.Id,
                            CurrentPrice = ConvertPriceToString(security?.LastQuotation, security),
                            StopLoss = ConvertPriceToString(s.StopLoss, security),
                            TakeProfit = ConvertPriceToString(s.TakeProfit, security),
                            Type = s.Type
                        };
                    }).ToArray();

                    return Success(new DelayedSignalsPage
                    {
                        PageSignals = pageSignals,
                        TotalSignals = total
                    });
                }

                return Success(new DelayedSignalsPage
                {
                    PageSignals = new DelayedSignal[0],
                    TotalSignals = 0
                });
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }


        // GET: api/strategies/portfolio/{strategyId}
        [HttpGet("portfolio/{strategyId}")]
        [Authorize]
        public async Task<ActionResult<RequestResult<Portfolio>>> Portfolio(Guid strategyId)
        {
            try
            {
                var strategy = await CheckStrategyAccessRights(strategyId);

                var lastSignal = await GetStrategyOpenPositions(strategy.ParentStrategy ?? strategyId);
                var hist = await GetStrategyHistory(strategyId, null);


                if (lastSignal != null)
                {
                    await _securityCache.AddSecurities(lastSignal.ActivePositions.Select(p => p.Key.GetKey()));

                    var unrealizedPL = lastSignal.ActivePositions.Sum(p =>
                    {
                        var security = _securityCache.GetSecuritiy(p.Key.GetKey());
                        return (GetUnrealizedPositionPL(p.Value, security) ?? 0m) * Math.Abs(p.Value.Weight);
                    });
                    if (unrealizedPL == -1)
                    {
                        throw new Exception($"UnrealizedPL == -1 for strategy {strategyId}");
                    }
                    decimal inPositions = 0;
                    decimal npr1 = 0;
                    
                    var positions = lastSignal.ActivePositions.Select(p =>
                    {
                        var security = _securityCache.GetSecuritiy(p.Key.GetKey());
                        var weight = strategy.RecalcMode == 2
                            ? p.Value.Weight * security?.LastPrice / p.Value.OpenPrice / (1 + unrealizedPL) ?? 0
                            : p.Value.Weight;
                        npr1 += p.Value.Weight >= 0
                            ? weight * (security?.RiskLong / 100m ?? 1)
                            : -p.Value.Weight * (security?.RiskShort / 100m ?? 1);
                        inPositions += Math.Abs(weight);
                        return new Portfolio.Position
                        {
                            Symbol = GetSecuritySymbolName(security),
                            Name = security?.Name,
                            Weight = (weight * 100m).ToStdString(2)
                        };
                    }).ToArray();

                    var free = Math.Max(0, 1 - inPositions);

                    decimal? maxdev = null;
                    decimal? dev1 = null;
                    if (strategy.SubscriptionThreshold > 0)
                        for (var threshold = strategy.SubscriptionThreshold; threshold < 2 * strategy.SubscriptionThreshold; threshold *= 1.05m)
                        {
                            var dev = lastSignal.ActivePositions.Sum(p =>
                            {
                                var security = _securityCache.GetSecuritiy(p.Key.GetKey());
                                var lot = (security?.SharesInLot ?? 1) * (security?.LastPrice ?? 1);
                                if (lot == 0)
                                {
                                    throw new Exception($"Lot price == 0 for strategy {strategyId} security '{p.Key}'");
                                }
                                var weight = strategy.RecalcMode == 2
                                    ? p.Value.Weight * security?.LastPrice / p.Value.OpenPrice / (1 + unrealizedPL) ?? 0
                                    : p.Value.Weight;
                                return Math.Abs(weight - Math.Floor(threshold * weight / lot) * lot / threshold);
                            });

                            if (dev1 == null)
                                dev1 = dev;

                            if (dev > (maxdev ?? 0))
                                maxdev = dev;
                        }

                    if (free > 0)
                        positions = positions.Append(new Portfolio.Position
                        {
                            Symbol = strategy.Currency,
                            Name = "Свободные средства",
                            Weight = (free * 100m).ToStdString(2)
                        }).ToArray();

                    unrealizedPL = hist?.LastOrDefault()?.u ?? 0;
                    var realizedPnL = hist?.LastOrDefault()?.r ?? 0;


                    return Success(new Portfolio
                    {
                        Currency = strategy.Currency,
                        PortfolioWeight = (inPositions * 100m).ToStdString(2),
                        CurrentFree = (free * 100m).ToStdString(2),
                        RelizedPL = realizedPnL.ToStdString(2),
                        UnrealizedPL = unrealizedPL.ToStdString(2),
                        CurrentBalance = ((1m + unrealizedPL / 100) * (1m + realizedPnL / 100) * 100m).ToStdString(2),
                        Positions = positions,
                        Npr1 = ((1 - npr1) * 100m).ToStdString(2),
                        Deviation = dev1 != null ? (dev1.Value * 100m).ToStdString(2) : null,
                        MaxDeviation = maxdev != null ? (maxdev.Value * 100m).ToStdString(2) : null
                    });
                }

                return Success(new Portfolio
                {
                    CurrentBalance = "100",
                    CurrentFree = "100",
                    PortfolioWeight = "0",
                    Npr1 = "0",
                    Positions = new[]
                    {
                        new Portfolio.Position
                        {
                            Symbol = strategy.Currency,
                            Name = "Свободные средства",
                            Weight = "100"
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [HttpPost("portfolio/{strategyId}")]
        public async Task<ActionResult<RequestResult<Portfolio>>> Portfolio(Guid strategyId, [FromBody] PortfolioRequest request)
        {
            try
            {
                var (apiKey, _) = await dataAccessLayer.GetStrategyApiKey(strategyId);

                if (apiKey == null)
                    return StatusError(HttpStatusCode.BadRequest, $"На стратегии {strategyId} запрещён приём внешних сигналов");

                if (request.ApiKey != apiKey) return StatusError(HttpStatusCode.Unauthorized, "Ошибка авторизации");

                var strategy = await dataAccessLayer.GetStrategy(strategyId);

                var lastSignal = await GetStrategyOpenPositions(strategy.ParentStrategy ?? strategyId);
                var hist = await GetStrategyHistory(strategyId, null);

                if (lastSignal != null)
                {
                    var unrealizedPL = lastSignal.ActivePositions.Sum(p =>
                    {
                        var security = _securityCache.GetSecuritiy(p.Key.GetKey());
                        return (GetUnrealizedPositionPL(p.Value, security) ?? 0m) * Math.Abs(p.Value.Weight);
                    });

                    decimal inPositions = 0;
                    var positions = lastSignal.ActivePositions.Select(p =>
                    {
                        var security = _securityCache.GetSecuritiy(p.Key.GetKey());
                        var weight = strategy.RecalcMode == 2
                            ? p.Value.Weight * security?.LastPrice / p.Value.OpenPrice / (1 + unrealizedPL) ?? 0
                            : p.Value.Weight;
                        inPositions += Math.Abs(weight);
                        return new
                        {
                            Security = p.Key.GetKey(),
                            AvgPrice = p.Value.OpenPrice,
                            p.Value.RealizedPnl,
                            Weight = weight
                        };
                    }).ToArray();


                    var free = Math.Max(0, 1 - inPositions);

                    if (free > 0)
                        positions = positions.Append(new
                        {
                            Security = "",
                            AvgPrice = 0m,
                            RealizedPnl = 0m,
                            Weight = free
                        }).ToArray();

                    unrealizedPL = hist?.LastOrDefault()?.u / 100 ?? 0;
                    var realizedPnL = hist?.LastOrDefault()?.r / 100 ?? 0;
                    return Success(new
                    {
                        strategy.Currency,
                        PortfolioWeight = inPositions,
                        CurrentFree = free,
                        RelizedPL = lastSignal.RealizedPnL,
                        UnrealizedPL = unrealizedPL,
                        CurrentBalance = (1m + unrealizedPL) * (1m + lastSignal.RealizedPnL),
                        Positions = positions
                    });
                }

                return Success(new
                {
                    strategy.Currency,
                    PortfolioWeight = 0,
                    CurrentFree = 1,
                    RelizedPL = 0,
                    UnrealizedPL = 0,

                    Positions = new[]
                    {
                        new
                        {
                            Security = "",
                            AvgPrice = 0m,
                            RealizedPnl = 0m,
                            Weight = 1m
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private async Task<StrategyDirectoryItem[]> GetUserStrategies(long authorId, UserRole role)
        {
            var strats = (await dataAccessLayer.GetApiStrategies()).ToDictionary(s => s.Id);
            using (var db = new Database())
            {
                switch (role)
                {
                    case UserRole.Administrator:
                    case UserRole.RiskManager:
                    case UserRole.Expert:
                    case UserRole.Support:
                    case UserRole.ContentManager:
                    case UserRole.DigitalExpert:
                    case UserRole.Developer:
                        return await db
                            .Strategies
                            .Where(s => s.Active > 0)
                            .OrderBy(s => s.Name)
                            .Select(s => new StrategyDirectoryItem
                            {
                                Id = s.Id,
                                Name = s.Name,
                                ManagerId = s.ManagerId,
                                Status = s.Status == StrategyStatus.Standard
                                    ? !strats.ContainsKey(s.Id) || !strats[s.Id].Open ? StrategyStatus.Closed : s.Status
                                    : s.Status,
                                IsChild = s.ParentStrategy != null,
                                RecalcMode = s.RecalcMode,
                                ParentStrategy = s.ParentStrategy != null
                                    ? db.Strategies
                                        .Where(ps => ps.Id == s.ParentStrategy)
                                        .Select(ps => ps.Name)
                                        .FirstOrDefault()
                                    : null,
                                IsAutofollow = s.Autofollow,
                                IsAutoconsult = s.Autoconsult,
                                IsInvestbox = s.IsInvestbox
                            })
                            .ToArrayAsync();
                    case UserRole.Manager:
                        return await db
                            .Strategies
                            .Where(s => s.Active > 0 &&
                                        (s.ManagerId == authorId || db.StrategyManagers.Any(sm => sm.StrategyId == s.Id && sm.ManagerId == authorId))
                            )
                            .OrderBy(s => s.Name)
                            .Select(s => new StrategyDirectoryItem
                            {
                                Id = s.Id,
                                Name = s.Name,
                                ManagerId = s.ManagerId,
                                Status = s.Status == StrategyStatus.Standard
                                    ? !strats.ContainsKey(s.Id) || !strats[s.Id].Open ? StrategyStatus.Closed : s.Status
                                    : s.Status,
                                IsChild = s.ParentStrategy != null,
                                RecalcMode = s.RecalcMode,
                                ParentStrategy = s.ParentStrategy != null
                                    ? db.Strategies
                                        .Where(ps => ps.Id == s.ParentStrategy)
                                        .Select(ps => ps.Name)
                                        .FirstOrDefault()
                                    : null,
                                IsAutofollow = s.Autofollow,
                                IsAutoconsult = s.Autoconsult,
                                IsInvestbox = s.IsInvestbox
                            })
                            .ToArrayAsync();
                    default:
                        return Array.Empty<StrategyDirectoryItem>();
                }
            }
        }

        // GET: api/strategies/updatehistory
        [HttpGet("updatehistory")]
        [Authorize]
        public async Task<ActionResult<RequestResult>> UpdateHistory()
        {
            try
            {
                using (var db = new Api.Models.Database())
                {
                    var anyStrategy = await db.Strategies.Where(s => s.Open).FirstOrDefaultAsync();
                    if (anyStrategy != null)
                        if (!await _sts.UpdateHistory(anyStrategy.Id))
                            Logger?.LogError($"Update any strategy history from sandbox, id={anyStrategy.Id}");
                }

                return Success();
            }
            catch (Exception e)
            {
                return Error(e);
            }
        }

        public class Snapshot
        {
            public decimal RealizedPnl { get; set; }
            public decimal UnrealizedPnl { get; set; }
            public DateTime Date { get; set; }
            public Position[] Positions { get; set; }
            public decimal PosUnrealizedPnl { get; set; }
        }

        public class PortfolioRequest
        {
            public string ApiKey { get; set; }
        }
    }
}