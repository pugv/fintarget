﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Api.Models;
using CS.Kernel.DBO;
using CS.Kernel.Model;
using ExchangeHelpers;
using fin_expert.Interfaces;
using fin_expert.Models;
using fin_expert.Utilities;
using LinqToDB;
using MathNet.Numerics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLib.Helpers;
using NLib.ParsersFormatters.DateTime;
using ClientAccount = CS.Kernel.Model.ClientAccount;
using Database = CS.Kernel.Functionality.Database;
using StrategySignal = CS.Kernel.Model.StrategySignal;

namespace fin_expert.Controllers
{
    [Route("api/system")]
    [ApiController]
    [Authorize]
    [SuppressMessage("ReSharper", "UnusedMember.Local")]
    [SuppressMessage("ReSharper", "NotAccessedField.Local")]
    [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Local")]
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public class SysDiagController : WebCabinetController
    {
        private readonly IDataAccessLayer _dal;
        protected readonly ISecurityCache SecurityCache;
        private ILogger<SysDiagController> _logger;

        public SysDiagController(IServiceProvider serviceProvider, ISecurityCache securityCache, IDataAccessLayer dal,
            ILogger<SysDiagController> logger) :
            base(serviceProvider, logger)
        {
            SecurityCache = securityCache;
            _dal = dal;
            _logger = logger;
        }


        public ActionResult System(string clientCode)
        {
            var sb = new StringBuilder("<h1>System</h1>");
            sb.AppendLine("<h2>Strategies</h2>");
            sb.AppendLine("<select id='selstrat'>");
            foreach (var s in _dal.GetApiStrategies().Result.OrderBy(s=>s.Name))
                sb.AppendLine($"<option value='{s.Id}'>{s.Name}</option>");
            sb.AppendLine("</select>");
            sb.AppendLine(
                "<br><button onclick='document.location.href=\"/api/system/strategyfollow/\"+document.getElementById(\"selstrat\").value'>Follow</button>");
            sb.AppendLine(
                "<br><button onclick='document.location.href=\"/api/system/calcstratfollow/\"+document.getElementById(\"selstrat\").value+\"/\"+document.getElementById(\"period\").value'>CalcFollowCoef</button> <input type='number' min='1' max='100' id='period' value='12'/> months");
            sb.AppendLine("<br>Security: <input id='security'/>");
            sb.AppendLine(
                " <button onclick='document.location.href=\"/api/system/checkweight/\"+document.getElementById(\"selstrat\").value+\"/\"+document.getElementById(\"security\").value'>Check Weight</button></a>");
            sb.AppendLine("<br>Date: <input id='date' type='date'/>");
            sb.AppendLine(
                "<br><button onclick='document.location.href=\"/api/strategies/snapshot/\"+document.getElementById(\"selstrat\").value+\"/\"+document.getElementById(\"date\").value'>Snapshot</button>");

            return Content(sb.ToString(), "text/html", Encoding.UTF8);
        }

        [HttpGet("strategyfollow/{guid}")]
        public async Task<ActionResult> StrategyFollow(Guid guid)
        {
            try
            {
                var role = UserManager.GetUserRole(User);

                if (role == UserRole.Administrator || role == UserRole.RiskManager || role == UserRole.Developer || role == UserRole.DigitalExpert || role == UserRole.Support)
                    return FormTable(await ClientsController.FormStrategyFollow(guid),
                        new Dictionary<string, Func<object, string>> { { "Id", id => $"./../strategyexecution/{id}" } });
            }
            catch (Exception e)
            {
                return Error(e);
            }

            return Error("No access");
        }

        [HttpGet("strategyexecution/{id}")]
        public async Task<ActionResult> StrategyExecution(int id)
        {
            try
            {
                var role = UserManager.GetUserRole(User);

                if (role == UserRole.Administrator || role == UserRole.RiskManager || role == UserRole.Developer || role == UserRole.DigitalExpert || role == UserRole.Support)
                    return FormTable(await ClientsController.FormStrategyExecution(id),
                        new Dictionary<string, Func<object, string>> { { "ClientId", i => $"/statistic/client_details/info/{i}" } });
            }
            catch (Exception e)
            {
                return Error(e);
            }

            return Error("No access");
        }

        [HttpGet("calcstratfollow/{guid}/{period?}")]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult> CalcStratFollow(Guid guid, string period)
        {
            var minSum = (await dataAccessLayer.GetStrategy(guid))?.SubscriptionThreshold ?? throw new Exception($"Strategy {guid} is not found");
            var periodAgo = DateTime.Now.AddMonths(string.IsNullOrEmpty(period)?-12:-int.Parse(period));

            using (var csdb = new Database())
            {
                var maxDate = DateTime.Now - TimeSpan.FromDays(30);
                
                var clients = (await csdb.ClientAccounts
                    .LoadWith(c => c.Client)    
                    .LoadWith(c => c.PortfolioHistories)
                    .LoadWith(c => c.Signals)
                    .Where(c => c.Status== ClientAccount.StatusEnum.AutoFollow && c.StrategyId == guid && c.Client.ServiceDate < maxDate )
                    .Take(5000)     
                    .ToArrayAsync());

                var badClients = new Dictionary<int, string>();
                
                var good = clients.Where(c => c.PortfolioHistories.Where(h=>h.DateTime>=periodAgo).All(el =>
                                              {
                                                  var portf = JsonConvert.DeserializeObject<ClientAccount>(el.Portfolio);
                                                  var pos = portf!.Positions?.FirstOrDefault(p => p.AvgPrice == 0 && p.Number != 0 && p.RealizedPnL!=0);
                                                  
                                                  if (pos != null)
                                                      badClients[c.Id] = $"{el.DateTime} Position: {pos.SecurityKey}={pos.Number} x {pos.AvgPrice}";
                                                  
                                                  return pos == null;
                                              })
                                              && (c.Signals?.Where(s=>s.DateTime>=periodAgo).All(s =>
                                              {
                                                  if (s.Portfolio == null) return true;

                                                  if ((JsonConvert.DeserializeObject<ClientAccount>(s.Portfolio) is var portf &&
                                                       (portf?.Positions?.All(p => p.AvgPrice != 0 || p.Number == 0) ?? true) && portf?.Value > minSum / 2))
                                                      return true;
                                                  
                                                  badClients[c.Id] =
                                                      $"{s.DateTime} Portfolio: {s.Id} {(portf?.Positions?.FirstOrDefault(p => p.AvgPrice == 0 && p.Number != 0)?.SecurityKey ?? portf?.Value.ToString(CultureInfo.InvariantCulture))}";
                                                  
                                                  return false;

                                              }) ?? true))
                    .ToDictionary(c=>c.Id);

                var histJson = (await dataAccessLayer.GetStrategyHistory(guid))?.HistoryJson ?? throw new Exception($"No strategy {guid} history");
                var hist = JsonConvert.DeserializeObject<HistoryPoint[]>(histJson);

                using (var apiDB = new global::Api.Models.Database())
                {
                    var pls = (await apiDB.AccountHistory
                        .Where(a => good.ContainsKey((int)a.AccountId))
                        .OrderBy(a => a.Date)
                        .ToArrayAsync())
                        .GroupBy(pl => pl.AccountId)
                        .ToDictionary(g => g.Key, g => g.ToArray());

                    double aveR;

                    Dictionary<int, double> result = new Dictionary<int, double>();
                    foreach (var client in good.Values)
                        if (pls.TryGetValue(client.Id, out var pl))
                        {
                            try
                            {
                                var plPeriod = pl.SkipWhile(p => p.Date.FromJsonTime() < periodAgo).ToArray();
                                var y = plPeriod.Select(p => (double)p.PnL).ToArray();
                                var x = hist!.SkipWhile(h => h.t.FromJsonTime().Date < plPeriod[0].Date.FromJsonTime().Date).Select(h => (double)h.vc[0])
                                    .ToArray();
                                if (x.Length != y.Length)
                                    throw new Exception($"PL points don't match strategy history");
                                var (a, b) = Fit.Line(x, y);
                                if (double.IsNaN(a)) throw new Exception("Can't calc correlation");
                                var r = GoodnessOfFit.RSquared(x.Select(xx => a + b * xx), y);
                                result[client.Id] = r;
                            }
                            catch (Exception e)
                            {
                                _logger.LogError($"Error calc follow for {client.ClientCode}: {e.Message}");
                                badClients[client.Id] = e.Message;
                            }
                        }

                    if (result.Count>0)
                    {
                        result = result.OrderByDescending(r => good[r.Key].Value).Take(result.Count > 2 ? (int) Math.Ceiling(result.Count / 2.0) : result.Count)
                            .ToDictionary(r => r.Key, r => r.Value);
                        aveR = result.Average(r => r.Value);
                    }
                    else aveR = Double.NaN;
                    
                    return Ok(new
                    {
                        AveFit = aveR,
                        FitRating = aveR switch
                        {
                            Double.NaN => 0,
                            < 0.5 => 1,
                            >= 0.5 and < 0.65 => 2,
                            >= 0.65 and < 0.75 => 3,
                            >= 0.75 and < 0.9 => 4,
                            >= 0.9 => 5
                        },
                        Result = result,
                        BadClients = badClients,
                    });
                }
            }
        }

        [HttpGet("checkweight/{guid}/{security}")]
        [Authorize(Roles = "Administrator,Developer")]
        public async Task<ActionResult> CheckWeight(Guid guid, string security)
        {
            try
            {
                var strategy = await CheckStrategyAccessRights(guid);
                var sec = await SecurityCache.GetSecuritiyWithLatestPrice(security);

                if (sec != null)
                {
                    var role = UserManager.GetUserRole(User);
                    if (role == UserRole.Administrator || role == UserRole.Manager)
                    {
                        var ow =
                            await SecuritiesController.OptimalWeight(sec, strategy);

                        var sb = new StringBuilder();
                        sb.AppendLine("<script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>");
                        sb.AppendLine($"<h3>{strategy.Name} weight difference for {sec.Key} (lot size: {sec.SharesInLot * sec.LastPrice})</h3>");
                        sb.AppendLine(
                            "<div style='position: relative; height: 40vh; width: 60vw'><canvas id='myChart' width='600' height='400'></canvas><script>");
                        sb.AppendLine("const data = { labels: [" +
                                      string.Join(",", ow.Points.Select(p => p.w.ToString("0.000", CultureInfo.InvariantCulture))) +
                                      "],  datasets: [{ label: 'diff', data: [" +
                                      string.Join(",", ow.Points.Select(p => (p.d * 100).ToString("0.000", CultureInfo.InvariantCulture))) +
                                      "], fill: true,  borderColor: 'rgb(75, 192, 192)', tension: 0.1 }]}; ");
                        sb.AppendLine(
                            "const config = { type: 'line',  data: data, options: {respositive: false, scales: { y: { min :0, suggestedMax: 10 }}}}; ");
                        sb.AppendLine(
                            "var ctx = document.getElementById('myChart').getContext('2d'); var myChart = new Chart(ctx, config);</script>");

                        using (var db = new Database())
                        {
                            var cls = await db.ClientAccounts
                                .Where(c => c.StrategyId == strategy.Id && c.Status == ClientAccount.StatusEnum.AutoFollow &&
                                            c.Value > strategy.SubscriptionThreshold / 2).Select(c => c.Value).ToArrayAsync();
                            cls = cls.OrderBy(c => c).Take((int)Math.Ceiling(cls.Length / 2.0)).ToArray();
                            var N = Math.Min(cls.Length, 10);
                            var R = cls[cls.Length - 1] - cls[0] + 1;
                            var data = Enumerable.Range(0, N + 1).Select(q => cls.Count(c => c >= cls[0] + (q - 1) * R / N && c < cls[0] + q * R / N))
                                .ToArray();
                            var labels = Enumerable.Range(0, N + 1).Select(q => cls[0] + q * R / N).ToArray();

                            sb.AppendLine("<h3>Strategy 50% poorest clients</h3>");
                            sb.AppendLine("<canvas id='myChart2' width='600' height='400'></canvas></div><script>");
                            sb.AppendLine("const data2 = { labels: [" + string.Join(",", labels.Select(p => (int)p)) +
                                          "],  datasets: [{ label: 'number', data: [" + string.Join(",", data) +
                                          "], fill: true,  borderColor: 'rgb(75, 192, 192)', tension: 0.1 }]}; ");
                            sb.AppendLine("const config2 = { type: 'bar',  data: data2}; ");
                            sb.AppendLine(
                                "var ctx2 = document.getElementById('myChart2').getContext('2d'); var myChart2 = new Chart(ctx2, config2);</script></div>");
                        }

                        return Content(sb.ToString(), "text/html", Encoding.UTF8);
                    }

                    return StatusError(HttpStatusCode.Forbidden, "Error");
                }

                return StatusError(HttpStatusCode.BadRequest, "Инструмент не найден", (int)Errors.SecurityNotFound);
            }
            catch (Exception ex)
            {
                return StatusError(HttpStatusCode.InternalServerError, ex);
            }
        }


        // GET: api/History
        [HttpGet("history/{clientCode}")]
        public ActionResult History(string clientCode)
        {
            try
            {
                var role = UserManager.GetUserRole(User);

                if (role == UserRole.Administrator || role == UserRole.Support || role == UserRole.DigitalExpert)
                {
                    var db = new Database();

                    var client = db.ClientAccounts.FirstOrDefault(ca => ca.ClientCode == clientCode);

                    if (client == null) return Error("No such client!");

                    var cahs = db.ClientAccountHistory.Where(h => h.ClientId == client.Id).ToArray();
                    var css = db.ClientSignals.LoadWith(cs => cs.StrategySignal).LoadWith(cs => cs.Messages).Where(s => s.ClientId == client.Id)
                        .ToArray();
                    var phs = db.PortfolioHistories.Where(p => p.ClientId == client.Id).ToArray();

                    var eq = new HistoryObject();

                    var history = cahs.Select(c => new HistoryObject(SecurityCache, c))
                        .Union(css.SelectMany(
                            c => c.StrategySignal == null
                                ? new[] { new HistoryObject(SecurityCache, c) }
                                : new[] { new HistoryObject(SecurityCache, c), new HistoryObject(SecurityCache, c.StrategySignal.ToStrategySignal()) }
                                    .Union(c.Messages.Select(m => new HistoryObject(SecurityCache, m)))))
                        .Union(phs.Select(c => new HistoryObject(SecurityCache, c)))
                        .Distinct(eq)
                        .ToArray();


                    var clientHistory = history
                        .Union(history.Where(h => h.ClientSignal != null && h.ClientSignal.Execution != null).Select(h =>
                            new HistoryObject(SecurityCache, JsonConvert.DeserializeObject<ClientSignalExecution>(h.ClientSignal.Execution))))
                        //.Union(history.Where(h => h.ClientSignal != null && h.Message != null).SelectMany(h => h.ClientSignal.Messages.Select(m => new HistoryObject(m))))
                        //.Union(history.Where(h=>h.ClientSignal!=null && h.ClientSignal.StrategySignal!=null).Select(h => new HistoryObject(h.ClientSignal.StrategySignal.ToStrategySignal())))
                        .OrderBy(h => h.DateTime)
                        .ToArray();


                    return FormTable(clientHistory);
                }

                return Error("Недостаточно прав");
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private ContentResult FormTable<T>(T[] array, Dictionary<string, Func<object, string>> refs = null)
        {
            var cols = typeof(T).GetProperties().Select(p => new { p, p.Name }).ToArray();


            var sb = new StringBuilder();

            sb.Append(
                "<html><style type='text/css'> table {border-spacing: 0px; width:100%; } td { border: 1px solid grey; padding:10px;} .tooltip { border - bottom: 1px dotted #0077AA;	cursor: help; } .tooltip::after { background: rgba(0, 0, 0, 0.8); border-radius: 8px 8px 8px 0px; box-shadow: 1px 1px 10px rgba(0, 0, 0, 0.5); color: #FFF; content: attr(data-tooltip); margin-top: -24px; opacity: 0; padding: 3px 7px; position: absolute; visibility: hidden; transition: all 0.4s ease-in-out; } .tooltip:hover::after { opacity: 1; visibility: visible;}</style>");

            sb.Append("<body><table><tr><th>");
            sb.Append(string.Join("</th><th>", cols.Select(c => c.Name)));
            sb.Append("</th></tr>");

            foreach (var row in array)
            {
                sb.Append("<tr>");
                foreach (var col in cols)
                    if (refs?.ContainsKey(col.Name) ?? false)
                        sb.Append($"<td><a href='{refs[col.Name](col.p.GetValue(row))}'>{col.p.GetValue(row)}</a></td>");
                    else
                        sb.Append($"<td>{col.p.GetValue(row)}</td>");
                sb.Append("</tr>");
            }

            sb.Append("</table></body></html>");

            return Content(sb.ToString(), "text/html");
        }


        private ContentResult FormTable(HistoryObject[] array)
        {
            var cols = typeof(HistoryObject).GetProperties().Select(p => new { p, p.Name }).ToArray();


            var sb = new StringBuilder();

            sb.Append(
                "<html><style type='text/css'> table {border-spacing: 0px; width:100%; } td { border: 1px solid grey; padding:10px;} .tooltip { border - bottom: 1px dotted #0077AA;	cursor: help; } .tooltip::after { background: rgba(0, 0, 0, 0.8); border-radius: 8px 8px 8px 0px; box-shadow: 1px 1px 10px rgba(0, 0, 0, 0.5); color: #FFF; content: attr(data-tooltip); margin-top: -24px; opacity: 0; padding: 3px 7px; position: absolute; visibility: hidden; transition: all 0.4s ease-in-out; } .tooltip:hover::after { opacity: 1; visibility: visible;}</style>");

            sb.Append("<body><table><tr><th>");
            sb.Append(string.Join("</th><th>", cols.Select(c => c.Name)));
            sb.Append("</th></tr>");

            foreach (var row in array)
            {
                sb.Append("<tr>");
                foreach (var col in cols)
                {
                    string obj;
                    if (col.Name == "DateTime")
                    {
                        obj = row.DateTime.ToString(CultureInfo.InvariantCulture);
                        sb.Append($"<td>{obj}</td>");
                    }
                    else
                    {
                        obj = col.p.GetValue(row) as string;

                        if (!string.IsNullOrEmpty(obj))
                            sb.Append(
                                $"<td><span class='tooltip' data-tooltip='{HttpUtility.HtmlEncode(row.Tooltip())}'>{HttpUtility.HtmlEncode(obj).Replace("\n", "<br>")}</span></td>");
                        else
                            sb.Append("<td></td>");
                    }
                }
            }

            sb.Append("</table></body></html>");

            return Content(sb.ToString(), "text/html");
        }

        private class HistoryObject : IEqualityComparer<HistoryObject>
        {
            // ReSharper disable once InconsistentNaming
            public readonly CAHistory CAHistory;
            public readonly ClientSignal ClientSignal;
            public readonly MessageDBO Message;
            public readonly ClientAccount PortfolioHistory;
            private readonly ISecurityCache _sec;
            public readonly ClientSignalExecution SignalExecution;

            public long? SignalId;
            
            public readonly StrategySignal StrategySignal;


            public HistoryObject(ISecurityCache sec, PortfolioHistory h)
            {
                this._sec = sec;
                PortfolioHistory = JsonConvert.DeserializeObject<ClientAccount>(h.Portfolio);
                DateTime = h.DateTime;
            }

            public HistoryObject(ISecurityCache sec, CAHistory h)
            {
                this._sec = sec;
                CAHistory = h;
                DateTime = h.Date;
            }

            public HistoryObject(ISecurityCache sec, ClientSignal h)
            {
                this._sec = sec;
                ClientSignal = h;
                SignalId = h.Id;
                DateTime = h.DateTime;
            }

            [SuppressMessage("ReSharper", "UnusedParameter.Local")]
            public HistoryObject(ISecurityCache sec, StrategySignal h)
            {
                StrategySignal = h;
                DateTime = h.Date;
            }

            public HistoryObject(ISecurityCache sec, ClientSignalExecution h)
            {
                _sec = sec;
                SignalExecution = h;
                SignalId = h.SignalId;
                DateTime = h.Positions?.Where(p => p.ExecEndTime.HasValue).MaxOrDefault(p => p.ExecEndTime!.Value.ToLocalTime()) ?? default(DateTime);
            }

            public HistoryObject(ISecurityCache sec, MessageDBO h)
            {
                _sec = sec;
                Message = h;
                DateTime = h.Date;
                SignalId = h.SignalId;
            }

            public HistoryObject()
            {
            }

            public DateTime DateTime { get; }

            public string Client => CAHistory != null || PortfolioHistory != null ? Format() : "";
            public string Signals => ClientSignal != null || StrategySignal != null ? Format() : "";
            public string Messages => Message != null ? Format() : "";
            public string Executions => SignalExecution != null ? Format() : "";


            public bool Equals(HistoryObject x, HistoryObject y)
            {
                if (x?.StrategySignal != null && y?.StrategySignal != null) return x.StrategySignal.Id.Equals(y.StrategySignal.Id);

                return x?.Equals(y)??false;
            }

            public int GetHashCode(HistoryObject obj)
            {
                return (obj.DateTime + ( obj.CAHistory?.ToString() ?? obj.ClientSignal?.Id.ToString() ?? obj.Message?.SignalId.ToString() ??
                        obj.PortfolioHistory?.ToString() ?? obj.SignalExecution?.SignalId.ToString() ?? obj.StrategySignal?.Id.ToString() ?? ""))
                    .GetHashCode();
            }

            public string Format()
            {
                if (ClientSignal != null)
                    return $"{ClientSignal.Id}\n{Enum.GetName(typeof(ClientSignal.ProcessedEnum), ClientSignal.Processed)}";
                if (StrategySignal != null)
                    return $"SS {StrategySignal.Id}";
                if (Message != null)
                    return $"{Message.SignalId}";
                if (CAHistory != null)
                    return $"{CAHistory.StrategyId}\n{CAHistory.Status}";
                if (PortfolioHistory != null)
                    return $"Portfolio (diff {PortfolioHistory.DiffFromStrategy:P2})\n" + (PortfolioHistory.Positions != null
                        ? string.Join("\n",
                            PortfolioHistory.Positions.Select(p =>
                                p.SecurityKey == ""
                                    ? $"{p.Number:#.##} {p.Currency} ({p.Weight:P2})"
                                    : $"{FormatSecurity(p.SecurityKey)} = {p.Number:#.#}x{p.AvgPrice:#.####} ({p.Weight:P2})"))
                        : "");
                if (SignalExecution != null)
                    return $"{SignalExecution.SignalId}\n" + (SignalExecution.Positions != null
                        ? string.Join("\n",
                            SignalExecution.Positions?.Select(p => $"{FormatSecurity(p.Security)}: {p.ExecNumber:#}x{p.ExecPrice:#.####} "))
                        : "");

                return "";
            }


            public string Tooltip()
            {
                if (ClientSignal != null)
                    return JsonConvert.SerializeObject(new
                    {
                        ClientSignal.Id, Execution = ClientSignal.Execution != null, Type = ClientSignal.Type.ToString(),
                        Processed = ClientSignal.Processed.ToString(), ClientSignal.MessageSent, StrategySignalId = ClientSignal.StrategySignal?.Id
                    });
                if (StrategySignal != null)
                    return JsonConvert.SerializeObject(new
                    {
                        StrategySignal.InitId,
                        StrategySignal.StrategyId,
                        Portfolio = StrategySignal.Portfolio.ToDictionary(p => p.Key, p => p.Value.Weight),
                        StrategySignal.InitiatingSignal
                    });
                if (Message != null)
                    return JsonConvert.SerializeObject(
                        JsonConvert.DeserializeObject<IrrData>(Message.Message)!.Securities.Select(s => new
                            { Key = FormatSecurity($"{s.Symbol} {s.ClassCode} {s.Board}"), s.Volume, s.LimitPrice, s.Direction }));
                if (CAHistory != null)
                    return "";

                return "";
            }

            public string FormatSecurity(string key)
            {
                var secur = _sec?.GetSecuritiy(key);
                if (secur != null)
                    return $"{GetSecuritySymbolName(secur)} {secur.ClassCode}";
                return key;
            }

            private class IrrData
            {
                public long SignalId { get; set; }
                public DateTime AddTime { get; set; }

                public int Type { get; set; }

//                public ClientDto Client { get; set; }
//                public AccountDto Account { get; set; }
                public SecurityDto[] Securities { get; set; }
            }

            [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Local")]
            private class SecurityDto
            {
                public string Name { get; set; }
                public string Symbol { get; set; }
                public string ISIN { get; set; }
                public string ClassCode { get; set; }
                public int LotSize { get; set; }
                public string Board { get; set; }
                public int Direction { get; set; }
                public long Volume { get; set; }
                public decimal LimitPrice { get; set; }
                public decimal Deviation { get; set; }
                public string Currency { get; set; }
                public string CurrencyDisplay => Currency == "SUR" ? "RUB" : Currency;
                public string FaceUnit { get; set; }
                public string ClassName { get; set; }
            }
        }
    }
}