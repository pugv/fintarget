﻿using System;
using Microsoft.Extensions.Logging;
using ILogger = NLib.Logger.ILogger;

namespace fin_expert.Utilities
{
    public class NLogWrapper : ILogger
    {
        private readonly Microsoft.Extensions.Logging.ILogger logger;

        public NLogWrapper(Microsoft.Extensions.Logging.ILogger logger)
        {
            this.logger = logger;
        }

        public IDisposable BeginScope<TState>(TState state)
            => logger.BeginScope(state);

        public void Error(string message)
        {
            logger.LogError(message);
        }

        public void Error(string format, params object[] args)
        {
            logger.LogError(format, args);
        }

        public void Error(Exception exception, string message)
        {
            logger?.LogError(exception, message);
        }

        public void Error(Exception exception, string format, params object[] args)
        {
            logger?.LogError(exception, format, args);
        }

        public void Info(string message)
        {
            logger?.LogInformation(message);
        }

        public void Info(string format, params object[] args)
        {
            logger?.LogInformation(format, args);
        }

        public void Trace(string message)
        {
            logger?.LogTrace(message);
        }

        public void Trace(string format, params object[] args)
        {
            logger?.LogTrace(format, args);
        }

        public void Warn(string message)
        {
            logger?.LogWarning(message);
        }

        public void Warn(string format, params object[] args)
        {
            logger?.LogWarning(string.Format(format, args));
        }
    }
}