﻿using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace fin_expert.Utilities
{
    public class TranslitHelper
    {
        private static TranslitHelper _instance;
        private static readonly object _sync = new object();
        private readonly Dictionary<char, string> compositeChars;

        private readonly Dictionary<char, char> simpleChars;

        private TranslitHelper()
        {
            simpleChars = new Dictionary<char, char>();
            compositeChars = new Dictionary<char, string>
            {
                { 'ж', "zh" },
                { 'х', "kh" },
                { 'ц', "ts" },
                { 'ч', "ch" },
                { 'ш', "sh" },
                { 'щ', "shch" },
                { 'ь', "" },
                { 'я', "ya" },
                { 'Ж', "zh" },
                { 'Х', "kh" },
                { 'Ц', "ts" },
                { 'Ч', "ch" },
                { 'Ш', "sh" },
                { 'Щ', "shch" },
                { 'Ь', "" },
                { 'Я', "ya" },
                { '№', "no" }
            };

            var charsFrom = "АБВГДЕЁЗИЙКЛМНОПРСТУФЪЫЭЮабвгдеёзийклмнопрстуфъыэю- &$";
            var charsTo = "abvgdeeziyklmnoprstuf-ieuabvgdeeziyklmnoprstuf-ieu--ns";
            var length = charsTo.Length > charsFrom.Length ? charsFrom.Length : charsTo.Length;

            for (var i = 0; i < length; ++i)
                simpleChars[charsFrom[i]] = charsTo[i];
        }

        public static TranslitHelper Instance()
        {
            if (_instance == null)
                lock (_sync)
                {
                    _instance ??= new TranslitHelper();
                }

            return _instance;
        }

        public string ConvertToEng(string value)
        {
            return value?
                .Aggregate(new StringBuilder(),
                    (sb, c) =>
                        simpleChars.TryGetValue(c, out var ch)
                            ? sb.Append(ch)
                            : compositeChars.TryGetValue(c, out var str)
                                ? sb.Append(str)
                                : IsEnglishLetterOrDigit(c)
                                    ? sb.Append(char.ToLower(c, CultureInfo.InvariantCulture))
                                    : sb
                )
                .ToString();
        }

        public bool IsEnglishLetterOrDigit(char c)
        {
            return c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' || c >= '0' && c <= '9';
        }
    }
}