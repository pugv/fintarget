﻿using fin_expert.Interfaces;

namespace fin_expert.Utilities
{
    public class LCSApi : LifeCycleService.ApiClient.Api, ILCS
    {
        public LCSApi(string serverUrl, int serverPort) : base(serverUrl, serverPort)
        {
        }
    }
}