﻿using System;
using System.Threading.Tasks;
using ExchangeHelpers;
using fin_expert.Interfaces;
using Newtonsoft.Json;
using NLib.Http;

namespace fin_expert.Utilities
{
    public class STSApi : HttpRequester, ISTS
    {
        public STSApi(string serverHost, int serverPort, int timeout = 10) : base(serverHost, serverPort, timeout)
        {
        }

        public async Task<bool> UpdateHistory(Guid stratId)
        {
            try
            {
                var res =
                    JsonConvert.DeserializeObject<StandardResponse>(await RequestAsync("/strategy/updatehistory", $"'{stratId}'"));
                return res.Success;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}