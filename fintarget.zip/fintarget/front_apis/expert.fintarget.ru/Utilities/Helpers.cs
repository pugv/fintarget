﻿using System;
using System.Linq;
using System.Net;
using Expert.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace fin_expert.Utilities
{
    public static class Helpers
    {
        public static T GetContent<T>(this ActionResult<T> res)
        {
            return JsonConvert.DeserializeObject<T>((res.Result as ContentResult).Content);
        }
    }
}