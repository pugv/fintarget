﻿using fin_expert.Models;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace fin_expert.Utilities
{
    public class WeekendComparer : IEqualityComparer<Weekend>
    {
        public bool Equals([AllowNull] Weekend x, [AllowNull] Weekend y)
        {
            return x.Id == y.Id && x.Day == y.Day;
        }

        public int GetHashCode([DisallowNull] Weekend obj)
        {
            return obj.Id.GetHashCode() ^ obj.Day.GetHashCode();
        }
    }
}
