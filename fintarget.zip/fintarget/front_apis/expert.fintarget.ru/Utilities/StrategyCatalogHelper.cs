﻿using System;
using System.Threading.Tasks;
using ApiHelpers;

namespace fin_expert.Utilities
{
    public class StrategyCatalogHelperStub : IStrategyCatalogApi
    {

        public Task CreateStrategyAsync(Guid codeStrategy, PostStrategyCatalogRq request)
        {
            return Task.CompletedTask;
        }

        public Task ModifyStrategyAsync(Guid codeStrategy, StrategyCatalogRq request)
        {
            return Task.CompletedTask;
        }

    }
}