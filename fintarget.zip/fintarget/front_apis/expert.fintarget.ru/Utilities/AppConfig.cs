﻿using System;

namespace fin_expert.Utilities
{
    public class AppConfig
    {
        public bool AuthTwoFactor { get; set; }
        public TimeSpan AuthSmsExpiration { get; set; }
        public TimeSpan AuthSessionExpiration { get; set; }
        public bool MockUnrealizedPL { get; set; }
        public bool MockSecurityCache { get; set; }
        public int MaxHistoryPoints { get; set; }
        public int MaxSecuritySearchResuls { get; set; }
        public string RecaptchaClientKey { get; set; }
        public string BuildVersion { get; set; }
        public DateTime BuildDate { get; set; }
        public int UserSaltMinLength { get; set; }
        public int UserSaltMaxLength { get; set; }
        public string FintargetWebRootPath { get; set; }
        public string FintargetTestWebRootPath { get; set; }
        public string FintargetHostAddress { get; set; }
        public string UploadedFilesLocation { get; set; }
        public string UploadedPortfolioFilesLocation { get; set; }
        public string UploadedAuthorsFilesLocation { get; set; }
        public decimal PortfolioPriceMultiplier { get; set; }
        public string[] AuthNoSmsWhiteList { get; internal set; }
        public int AuthMaxOtpsPerInterval { get; internal set; }
        public TimeSpan AuthMaxOtpsInterval { get; internal set; }

        public string EvaApiUrl { get; set; }
        public TimeSpan EvaTimeout { get; set; }
        public int[] EvaBrokerRateStrategies { get; set; }
        public bool EvaTraceRawResponses { get; internal set; }
    }
}