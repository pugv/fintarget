﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Expert.Models;
using fin_expert.Models;
using LinqToDB;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using NLib.AuxTypes;

namespace fin_expert.Utilities
{
    public class UserManager
    {
        private static readonly string staticSalt = "g%^523vf132[)8M@64MJKD21fdsa;k-";
        private static readonly Range<int> userSaltLengthRange = new Range<int>(20, 40);

        private readonly Database db;

        public UserManager() // Конструктор для SignOut
        {
        }

        public UserManager(Database db)
        {
            this.db = db;
        }

        public static string GetUserLogin(ClaimsPrincipal user)
        {
            var claim = (user.Identity as ClaimsIdentity).Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier);
            return claim?.Value;
        }

        public static string GetUserName(ClaimsPrincipal user)
        {
            var claim = (user.Identity as ClaimsIdentity).Claims.FirstOrDefault(x => x.Type == ClaimTypes.Name);
            return claim?.Value;
        }

        internal static string CreateUserSalt()
        {
            var rnd = new Random(Environment.TickCount);

            var userSaltLength = rnd.Next(userSaltLengthRange.Start, userSaltLengthRange.End);

            var userSaltBuilder = new StringBuilder(userSaltLength);

            for (var idx = 0; idx < userSaltLength; idx++)
                userSaltBuilder.Append((char)rnd.Next(31, 125)); // ASCII от '!' до '}'

            return userSaltBuilder.ToString();
        }

        public static long GetUserId(ClaimsPrincipal user)
        {
            var claim = (user.Identity as ClaimsIdentity).Claims.FirstOrDefault(x => x.Type == ClaimTypes.SerialNumber);
            if (claim == null)
                return 0;
            long id = 0;
            long.TryParse(claim?.Value, out id);
            return id;
        }

        public static UserRole GetUserRole(ClaimsPrincipal user)
        {
            var claim = (user.Identity as ClaimsIdentity).Claims.FirstOrDefault(x => x.Type == ClaimTypes.Role);
            if (claim == null)
                return UserRole.None;
            var val = UserRole.None;
            if (Enum.TryParse(claim?.Value, out val))
                return val;
            return UserRole.None;
        }

        public static (string, string) GetHash(string password)
        {
            byte[] hash;

            var userSalt = CreateUserSalt();

            using (var sha = SHA512.Create())
            {
                hash = sha.ComputeHash(Encoding.UTF8.GetBytes(staticSalt + password + userSalt));
            }

            return (BitConverter.ToString(hash), userSalt);
        }

        public static string GetHash(string password, string userSalt)
        {
            byte[] hash;

            using (var sha = SHA512.Create())
            {
                hash = sha.ComputeHash(Encoding.UTF8.GetBytes(staticSalt + password + userSalt));
            }

            return BitConverter.ToString(hash);
        }

        public async Task<User> ValidateCredentials(string login, string password)
        {
            return await ValidateCredentials(
                await db.Users
                    .Where(u => u.MasterId == null && u.IsActive == 1 && u.IsDeleted != 1 && u.Login == login)
                    .FirstOrDefaultAsync(),
                password);
        }

        public async Task<User> ValidateCredentials(int Id, string password)
        {
            return await ValidateCredentials(await db.Users
                .Where(u => u.IsActive == 1 && u.IsDeleted != 1 && u.Id == Id).FirstOrDefaultAsync(), password);
        }

        public async Task<bool> ValidateCredentials(User user, Func<bool> check)
        {
            if (user == null) return false;
            if (user.UnsuccessfullLogins >= 5 && user.LastLogin > DateTime.Now.AddMinutes(-30))
                throw new UserVisibleException("Превышено количество неудачных попыток входа в систему");
            if (user.LastLogin <= DateTime.Now.AddMinutes(-30))
                await db
                    .Users
                    .Where(u => u.Id == user.Id)
                    .Set(u => u.UnsuccessfullLogins, 0)
                    .Set(u => u.LastLogin, DateTime.Now)
                    .UpdateAsync();

            if (!check())
            {
                await db
                    .Users
                    .Where(u => u.Id == user.Id)
                    .Set(u => u.UnsuccessfullLogins, user.UnsuccessfullLogins + 1)
                    .Set(u => u.LastLogin, DateTime.Now)
                    .UpdateAsync();

                return false;
            }

            return true;
        }

        private async Task<User> ValidateCredentials(User user, string password)
        {
            if (await ValidateCredentials(user, () => user.PasswordHash == GetHash(password, user.Salt)))
                return user;
            throw new UserVisibleException("Имя пользователя или пароль указаны неверно");
        }

        public async Task<User> GetUser(ClaimsPrincipal user)
        {
            return await GetUser((int)GetUserId(user));
        }

        public async Task<User> GetUser(int id)
        {
            return await db.Users
                .Where(u => u.Id == id).FirstOrDefaultAsync();
        }
       
        public async Task SignIn(HttpContext httpContext, User user, TimeSpan cookieExpirationPeriod)
        {
            var identity = new ClaimsIdentity(CookieAuthenticationDefaults.AuthenticationScheme, ClaimTypes.Name, ClaimTypes.Role);

            identity.AddClaims(GetUserClaims(user));

            //CustomIdentity identity = new CustomIdentity(this.GetUserClaims(user), CookieAuthenticationDefaults.AuthenticationScheme, user);
            var principal = new ClaimsPrincipal(identity);

            var authProperties = new AuthenticationProperties
            {
                AllowRefresh = true,
                ExpiresUtc = DateTimeOffset.Now + cookieExpirationPeriod
            };

            await httpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, authProperties);
        }

        internal async Task<User> ChangePassword(HttpContext httpContext, string Login, string oldPassword, string newPassword, string newPasswordConfirmation,
            TimeSpan cookieExpirationPeriod)
        {
            var user = await ValidateCredentials(Login, oldPassword);

            if (newPassword != newPasswordConfirmation)
                throw new UserVisibleException("Новый пароль и подтверждение не совпадают");

            CheckValidPassword(newPassword);

            (user.PasswordHash, user.Salt) = GetHash(newPassword);

            //user.DraftPassword = 0;
            //await db.UpdateAsync(user);

            await db.Users
                .Where(a => a.Id == user.Id)
                .AsUpdatable()
                .Set(a => a.DraftPassword, 0)
                .Set(a => a.Salt, user.Salt)
                .Set(a => a.PasswordHash, user.PasswordHash)
                .UpdateAsync();

            return user;
        }

        private void CheckValidPassword(string password)
        {
            /*
			длина не менее 8 символов
				обязательное наличие хотя бы одной цифры
				обязательное наличие хотя бы одной буквы в нижнем регистре
			обязательное наличие хотя бы одной буквы в верхнем регистре.»
			*/

            if (password.Length < 8
                || password.IndexOfAny("0123456789".ToCharArray()) == -1
                || password.IndexOfAny("ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray()) == -1
                || password.IndexOfAny("abcdefghijklmnopqrstuvwxyz".ToCharArray()) == -1
               )
                throw new UserVisibleException(
                    "Длина пароля должна быть не менее 8 символов, пароль должен содержать цифры и буквы латиницы в верхнем и нижнем регистрах");
        }

        public async Task SignOut(HttpContext httpContext)
        {
            await httpContext.SignOutAsync();
        }

        private IEnumerable<Claim> GetUserClaims(User user)
        {
            var claims = new List<Claim>();

            claims.Add(new Claim(ClaimTypes.NameIdentifier, user.Login));
            claims.Add(new Claim(ClaimTypes.Name, user.GetUserName() ?? string.Empty));
            claims.Add(new Claim(ClaimTypes.Role, user.Role));
            claims.Add(new Claim(ClaimTypes.SerialNumber, user.Id.ToString()));
            return claims;
        }
    }
}