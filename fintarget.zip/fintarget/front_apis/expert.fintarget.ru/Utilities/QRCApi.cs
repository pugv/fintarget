﻿using fin_expert.Interfaces;
using QRC = QRCApi;

namespace fin_expert.Utilities
{
    public class QRCApi : QRC.QRCApi, IQRCApi
    {
        public QRCApi(string host, int port) : base(host, port)
        {
        }
    }
}