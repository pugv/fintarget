﻿using fin_expert.Interfaces;

namespace fin_expert.Utilities
{
    public class CSApi : CS.ApiClient.Api, ICS
    {
        public CSApi(string serverUrl, int serverPort) : base(serverUrl, serverPort)
        {
        }
    }
}