﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using ExchangeHelpers.HS;
using fin_expert.Interfaces;
using HS.Models;
using Microsoft.Extensions.Logging;
using NLib.AuxTypes;
using NLib.Timers;
using RMDS.ApiClient;
using RMDS.Common;

namespace fin_expert.Utilities
{
    public class SecurityCache : ISecurityCache
    {
        private readonly IDataAccessLayer dataAccessLayer;

        private volatile Dictionary<string, (decimal, decimal)> gammaTheta = new Dictionary<string, (decimal, decimal)>();
        private readonly HS.ApiClient.Api hsApi;
        private readonly ILogger logger;
        private readonly bool mock;
        private readonly Dictionary<string, SecurityRecord> securities = new Dictionary<string, SecurityRecord>();

        private HashSet<string> securityKeys = new HashSet<string>();
        private readonly object syncRoot = new object();

        public SecurityCache(string hsUrl, int hsPort, IApiConfig RMDSConfig, IDataAccessLayer dataAccessLayer, ILogger logger, TimeSpan refreshPeriod,
            TimeSpan refreshAllPeriod, CancellationToken cancellation, bool mock = false)
        {
            this.logger = logger;
            this.mock = mock;
            this.dataAccessLayer = dataAccessLayer;

            if (mock)
            {
                securities.Add("AAPL SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "AAPL", ClassCode = "SPBXM", Name = "Apple Inc.", Type = "Security", IsinCode = "US0378331005", Currency = "USD",
                        LastPrice = 324, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("ABBV SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "ABBV", ClassCode = "SPBXM", Name = "AbbVie Inc.", Type = "Security", IsinCode = "US00287Y1091", Currency = "USD",
                        LastPrice = 87.91m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("ADBE SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "ADBE", ClassCode = "SPBXM", Name = "Adobe Inc.", Type = "Security", IsinCode = "US00724F1012", Currency = "USD",
                        LastPrice = 367.23m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("AFLT TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "AFLT", ClassCode = "TQBR", Name = "Аэрофлот-росс.авиалин(ПАО)ао", Type = "Security", IsinCode = "RU0009062285",
                        Currency = "SUR", LastPrice = 118.58m, LastTime = DateTime.Now, Current = true, SharesInLot = 10
                    });
                securities.Add("AKRN TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "AKRN", ClassCode = "TQBR", Name = "Акрон ПАО ао", Type = "Security", IsinCode = "RU0009028674", Currency = "SUR",
                        LastPrice = 4838, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("COST SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "COST", ClassCode = "SPBXM", Name = "Costco Wholesale Corporation", Type = "Security", IsinCode = "US22160K1051",
                        Currency = "USD", LastPrice = 310.63m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("ETLN TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "ETLN", ClassCode = "TQBR", Name = "ГДР ETALON GROUP PLC ORD SHS", Type = "Security", IsinCode = "US29760G1031",
                        Currency = "SUR", LastPrice = 142.48m, LastTime = DateTime.Now, Current = true, SharesInLot = 10
                    });
                securities.Add("FEES TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "FEES", ClassCode = "TQBR", Name = "ФСК ЕЭС ПАО ао", Type = "Security", IsinCode = "RU000A0JPNN9", Currency = "SUR",
                        LastPrice = 0.2269m, LastTime = DateTime.Now, Current = true, SharesInLot = 10000
                    });
                securities.Add("FIVE SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "FIVE", ClassCode = "SPBXM", Name = "Five Below, Inc.", Type = "Security", IsinCode = "US33829M1018", Currency = "USD",
                        LastPrice = 118.75m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("GAZP TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "GAZP", ClassCode = "TQBR", Name = "Газпром (ПАО) ао", Type = "Security", IsinCode = "RU0007661625", Currency = "SUR",
                        LastPrice = 230.9m, LastTime = DateTime.Now, Current = true, SharesInLot = 10
                    });
                securities.Add("GBT SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "GBT", ClassCode = "SPBXM", Name = "Global Blood Therapeutics Inc.", Type = "Security", IsinCode = "US37890U1088",
                        Currency = "USD", LastPrice = 71.31m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("GIS SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "GIS", ClassCode = "SPBXM", Name = "General Mills, Inc.", Type = "Security", IsinCode = "US3703341046", Currency = "USD",
                        LastPrice = 51.76m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("GOOGL SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "GOOGL", ClassCode = "SPBXM", Name = "Alphabet Inc. Class A", Type = "Security", IsinCode = "US02079K3059", Currency = "USD",
                        LastPrice = 1476.64m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("HALS TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "HALS", ClassCode = "TQBR", Name = "ПАО \"Галс - Девелопмент\"", Type = "Security", IsinCode = "RU000A0JNP96",
                        Currency = "SUR", LastPrice = 1010, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("IBM SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "IBM", ClassCode = "SPBXM", Name = "INTERNATIONAL BUSINESS MACHINES CORPORATION", Type = "Security", IsinCode = "US4592001014",
                        Currency = "USD", LastPrice = 155.03m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("INGN SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "INGN", ClassCode = "SPBXM", Name = "Inogen, Inc.", Type = "Security", IsinCode = "US45780L1044", Currency = "USD",
                        LastPrice = 47.16m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("JELD SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "JELD", ClassCode = "SPBXM", Name = "JELD-WEN Holding Inc.", Type = "Security", IsinCode = "US47580P1030", Currency = "USD",
                        LastPrice = 26.53m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("KAZT TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "KAZT", ClassCode = "TQBR", Name = "Куйбышевазот ПАО ао", Type = "Security", IsinCode = "RU000A0B9BV2", Currency = "SUR",
                        LastPrice = 176.6m, LastTime = DateTime.Now, Current = true, SharesInLot = 10
                    });
                securities.Add("LEVI SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "LEVI", ClassCode = "SPBXM", Name = "Levi Strauss & Co. ClassA", Type = "Security", IsinCode = "US52736R1023",
                        Currency = "USD", LastPrice = 19.3m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("LKOH TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "LKOH", ClassCode = "TQBR", Name = "НК ЛУКОЙЛ (ПАО) - ао", Type = "Security", IsinCode = "RU0009024277", Currency = "SUR",
                        LastPrice = 6477.5m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("LTHM SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "LTHM", ClassCode = "SPBXM", Name = "Livent Corporation", Type = "Security", IsinCode = "US53814L1089", Currency = "USD",
                        LastPrice = 10.64m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("MAGN TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "MAGN", ClassCode = "TQBR", Name = "Магнитогорск.мет.комб ПАО ао", Type = "Security", IsinCode = "RU0009084396",
                        Currency = "SUR", LastPrice = 45.34m, LastTime = DateTime.Now, Current = true, SharesInLot = 100
                    });
                securities.Add("MGNT TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "MGNT", ClassCode = "TQBR", Name = "Магнит ПАО ао", Type = "Security", IsinCode = "RU000A0JKQU8", Currency = "SUR",
                        LastPrice = 3717, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("MSFT SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "MSFT", ClassCode = "SPBXM", Name = "Microsoft Corporation", Type = "Security", IsinCode = "US5949181045", Currency = "USD",
                        LastPrice = 183.83m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("NFLX SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "NFLX", ClassCode = "SPBXM", Name = "Netflix, Inc.", Type = "Security", IsinCode = "US64110L1061", Currency = "USD",
                        LastPrice = 366.13m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("OLED SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "OLED", ClassCode = "SPBXM", Name = "Universal Display Corporation", Type = "Security", IsinCode = "US91347P1057",
                        Currency = "USD", LastPrice = 179.63m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("PBCT SPBXM QUIK",
                    new SecurityRecord
                    {
                        Symbol = "PBCT", ClassCode = "SPBXM", Name = "People''s United Financial, Inc.", Type = "Security", IsinCode = "US7127041058",
                        Currency = "USD", LastPrice = 16.02m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("SBER TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "SBER", ClassCode = "TQBR", Name = "Сбербанк России ПАО ао", Type = "Security", IsinCode = "RU0009029540", Currency = "SUR",
                        LastPrice = 251.5m, LastTime = DateTime.Now, Current = true, SharesInLot = 10
                    });
                securities.Add("AFM0 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "AFM0", ClassCode = "SPBFUT", Name = "AFLT-6.20", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 12154, LastTime = DateTime.Now, Current = true, SharesInLot = 100
                    });
                securities.Add("BRX0 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "BRX0", ClassCode = "SPBFUT", Name = "BR-11.20", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR", LastPrice = 56,
                        LastTime = DateTime.Now, Current = true, SharesInLot = 10
                    });
                securities.Add("CLQ9 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "CLQ9", ClassCode = "SPBFUT", Name = "CL-8.19", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 56.2m, LastTime = DateTime.Now, Current = true, SharesInLot = 10
                    });
                securities.Add("EuH0 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "EuH0", ClassCode = "SPBFUT", Name = "Eu-3.20", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 70285, LastTime = DateTime.Now, Current = true, SharesInLot = 1000
                    });
                securities.Add("GZM9 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "GZM9", ClassCode = "SPBFUT", Name = "GAZR-6.19", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 23193, LastTime = DateTime.Now, Current = true, SharesInLot = 100
                    });
                securities.Add("JPM9 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "JPM9", ClassCode = "SPBFUT", Name = "UJPY-6.19", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 107.82m, LastTime = DateTime.Now, Current = true, SharesInLot = 1000
                    });
                securities.Add("LKZ0 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "LKZ0", ClassCode = "SPBFUT", Name = "LKOH-12.20", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 68000, LastTime = DateTime.Now, Current = true, SharesInLot = 10
                    });
                securities.Add("MXU0 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "MXU0", ClassCode = "SPBFUT", Name = "MIX-9.20", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 314050, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("RIU0 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "RIU0", ClassCode = "SPBFUT", Name = "RTS-9.20", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 154930, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("SiH0 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "SiH0", ClassCode = "SPBFUT", Name = "Si-3.20", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 63939, LastTime = DateTime.Now, Current = true, SharesInLot = 1000
                    });
                securities.Add("USH0 SPBFUT QUIK",
                    new SecurityRecord
                    {
                        Symbol = "USH0", ClassCode = "SPBFUT", Name = "U500-3.20", Type = "FuturesContract", IsinCode = "NULL", Currency = "SUR",
                        LastPrice = 2495.5m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                //
                securities.Add("CHMF TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "CHMF", ClassCode = "TQBR", Name = "Северсталь (ПАО)ао", Type = "Security", IsinCode = "RU0009046510", Currency = "SUR",
                        LastPrice = 1743.2m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                //securities.Add("FEES TQBR QUIK", new SecurityRecord() { Symbol = "FEES", ClassCode = "TQBR", Name = "\"ФСК ЕЭС\" ПАО ао", Type = "Security", IsinCode = "RU000A0JPNN9", Currency = "SUR", LastPrice = 0.21818m, LastTime = DateTime.Now, IsCurrent = true, SharesInLot = 1 });
                //securities.Add("MAGN TQBR QUIK", new SecurityRecord() { Symbol = "MAGN", ClassCode = "TQBR", Name = "\"Магнитогорск.мет.комб\" ПАО ао", Type = "Security", IsinCode = "RU0009084396", Currency = "SUR", LastPrice = 65.045m, LastTime = DateTime.Now, IsCurrent = true, SharesInLot = 1 });
                securities.Add("ALRS TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "ALRS", ClassCode = "TQBR", Name = "АЛРОСА ПАО ао", Type = "Security", IsinCode = "RU0007252813", Currency = "SUR",
                        LastPrice = 110.53m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("POLY TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "POLY", ClassCode = "TQBR", Name = "Polymetal International plc", Type = "Security", IsinCode = "JE00B6T5S470",
                        Currency = "SUR", LastPrice = 1626, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("HYDR TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "HYDR", ClassCode = "TQBR", Name = "ПАО \"РусГидро\"", Type = "Security", IsinCode = "RU000A0JPKH7", Currency = "SUR",
                        LastPrice = 0.8386m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                //securities.Add("GAZP TQBR QUIK", new SecurityRecord() { Symbol = "GAZP", ClassCode = "TQBR", Name = "\"Газпром\" (ПАО) ао", Type = "Security", IsinCode = "RU0007661625", Currency = "SUR", LastPrice = 236.96m, LastTime = DateTime.Now, IsCurrent = true, SharesInLot = 1 });
                securities.Add("MTSS TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "MTSS", ClassCode = "TQBR", Name = "Мобильные ТелеСистемы ПАО ао", Type = "Security", IsinCode = "RU0007775219",
                        Currency = "SUR", LastPrice = 322.1m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("ROSN TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "ROSN", ClassCode = "TQBR", Name = "ПАО НК Роснефть", Type = "Security", IsinCode = "RU000A0J2Q06", Currency = "SUR",
                        LastPrice = 542.7m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });
                securities.Add("PLZL TQBR QUIK",
                    new SecurityRecord
                    {
                        Symbol = "PLZL", ClassCode = "TQBR", Name = "Полюс ПАО ао", Type = "Security", IsinCode = "RU000A0JNAA8", Currency = "SUR",
                        LastPrice = 14097.5m, LastTime = DateTime.Now, Current = true, SharesInLot = 1
                    });


                foreach (var sec in securities) sec.Value.Board = "QUIK";
            }
            else
            {
                hsApi = new HS.ApiClient.Api(hsUrl, hsPort);
                if (!string.IsNullOrEmpty(RMDSConfig.GrpcHost))
                    Rmds = new RMDS.ApiClient.Api(RMDSConfig, "expert");
                new PeriodicTask().RunAsync(UpdateSecurities, refreshPeriod, cancellation);
                new PeriodicTask().RunAsync(UpdateAllSecurities, refreshAllPeriod, cancellation);
            }
        }

        public RMDS.ApiClient.Api Rmds { get; }

        public string GetSecurityTypeInfo(string typeCode)
        {
            switch (typeCode)
            {
                case "Indices":
                    return "Индекс";
                case "Option":
                    return "Опцион";
                case "Spread":
                    return "Спред";
                case "FuturesContract":
                    return "Фьючерсный контракт";
                case "Currency":
                    return "Валюта";
                case "Bond":
                    return "Облигация";
                default:
                    return "Акция";
            }
        }

        public bool InCache(string key)
        {
            lock (syncRoot)
            {
                return securityKeys.Contains(key);
            }
        }

        public async Task AddSecurities(IEnumerable<string> keys, bool immediateRefresh = true)
        {
            var added = false;
            lock (syncRoot)
            {
                foreach (var key in keys)
                    if (!securityKeys.Contains(key))
                    {
                        securityKeys.Add(key);
                        added = true;
                    }
            }

            if (added && immediateRefresh && !mock)
                await UpdateSecurities();
        }

        public void ActualizeSecurities(IEnumerable<string> keys)
        {
            lock (syncRoot)
            {
                securityKeys = new HashSet<string>(keys);
            }
        }

        /// <summary>
        /// Получение списка securities с фильтрацией по allowedPatterns ИЛИ classCodes
        /// </summary>
        /// <param name="allowedPatterns">список рег. выражений для security key</param>
        /// <param name="classCodes">список названий класс-кодов</param>
        /// <param name="pattern"></param>
        /// <param name="maxResuls"></param>
        /// <returns></returns>
        public SecurityRecord[] SearchSecurities(string[] allowedPatterns, string[] classCodes, string pattern, int maxResuls)
        {
            var found = new List<SecurityRecord>();

            lock (syncRoot)
            {
                if (allowedPatterns != null)
                    foreach (var allowed in allowedPatterns)
                    {
                        var re = new Regex(allowed);
                        found.AddRange(securities
                            .Where(s => s.Value.Current && (re.IsMatch(s.Key) || re.IsMatch(s.Value.CategoryPattern)))
                            .Select(s => s.Value));
                    }
                else if (classCodes != null)
                    found.AddRange(securities
                        .Where(s => classCodes.Contains(s.Value.ClassCode))
                        .Select(s => s.Value));
                else
                    found.AddRange(securities.Select(s => s.Value));
            }

            var records = found.Distinct();

            records = records.Where(s =>
            {
                if (s.Symbol == null || s.ClassCode == null)
                    return false;

                if ((s.Symbol + " " + s.ClassCode).ToLower().Contains(pattern))
                    return true;

                if (s.Name != null && s.Name.ToLower().Contains(pattern))
                    return true;

                if (s.ShortName != null && s.ShortName.ToLower().Contains(pattern))
                    return true;

                if (s.IsinCode != null && s.IsinCode.ToLower().Contains(pattern))
                    return true;

                return false;
            });


            records = records.OrderByDescending(s => s.Symbol.ToLower() == pattern || s.ShortName != null && s.ShortName.ToLower() == pattern);

            records = records.Take(maxResuls);

            return records.ToArray();
        }

        public Dictionary<string, Split[]> GetSplits(string[] keys)
        {
            try
            {
                using (var db = new Database())
                {
                    return db.Splits.Where(s => keys.Contains(s.Security)).OrderBy(s => s.Date).ToArray().GroupBy(s => s.Security)
                        .ToDictionary(s => s.Key, s => s.ToArray());
                }
            }
            catch (Exception e)
            {
                logger?.LogError(e, "Can't get splits from HS");
                return new Dictionary<string, Split[]>();
            }
        }

        public (decimal, decimal) GetGammaTheta(string classCode)
        {
            gammaTheta.TryGetValue(classCode, out var res);
            return res;
        }

        public SecurityRecord GetSecuritiy(string key)
        {
            lock (syncRoot)
            {
                return securities.ContainsKey(key) ? securities[key].Clone() : null;
            }
        }

        public async Task<bool> IsShortAllowed(string key)
        {
            try
            {
                return (await hsApi.ShortsAllowed(new[] { key })).First().Allowed;
            }
            catch (Exception e)
            {
                logger?.LogError(e, "IsShortAllowed");
            }

            return false;
        }

        public async Task<SecurityRecord> GetSecuritiyWithLatestPrice(string key)
        {
            var sec = GetSecuritiy(key);

            if (Rmds != null)
                try
                {
                    var res = (await Rmds.RequestMarketDataAsync(new[] { key })).FirstOrDefault();
                    if (res != null)
                    {
                        sec.LastPrice = res.FuturesPrice ??
                                        (sec.Type == "Bond" ? res.LastPrice * sec.FaceValue / 100 + sec.SecAccruedint : res.LastPrice) ?? sec.LastPrice;
                        sec.LastQuotation = (sec.Type == "Bond" ? res.LastPrice * sec.FaceValue / 100 + sec.SecAccruedint : res.LastPrice) ?? sec.LastQuotation;
                        sec.LastTime = res.TimeStamp?.ToLocalTime();
                    }
                    else
                        throw new ArgumentException($"Security key {key} not found");
                }
                catch (Exception e)
                {
                    logger?.LogError(e, "GetSecuritiyWithLatestPrice");
                }

            return sec;
        }

        public Dictionary<string, string> GetUSACodes()
        {
            lock (syncRoot)
            {
                return securities
                    .Where(s => s.Value.ClassCode.StartsWith('N') && !string.IsNullOrEmpty(s.Value.ShortName) && !string.IsNullOrEmpty(s.Value.Symbol))
                    .GroupBy(s => s.Value.ShortName)
                    .ToDictionary(g => g.Key, g => g.First().Value.Symbol);
            }
        }

        public Dictionary<string, string> GetLSECodes()
        {
            lock (syncRoot)
            {
                return securities
                    .Where(s => s.Value.ClassCode == "LSE_IOB" && !string.IsNullOrEmpty(s.Value.ShortName) && !string.IsNullOrEmpty(s.Value.Symbol))
                    .GroupBy(s => s.Value.ShortName)
                    .ToDictionary(g => g.Key, g => g.First().Value.Symbol);
            }
        }

        public SecurityRecord[] GetSecurities()
        {
            lock (securities)
            {
                return securities.Values.ToArray();
            }
        }

        public async Task<PriceItem[]> EndOfDay(string key)
        {
            var data = await hsApi.EndOfDay(new[] { key }, new Range<DateTime>(DateTime.Parse("2015-01-01"), DateTime.Now.Date), false);
            return data.GetValueOrDefault(key, Array.Empty<PriceItem>()); 
        }

        public async Task<Dictionary<string, PriceItem>> EndOfDay(string[] keys, DateTime date)
        {
            return (await hsApi.EndOfDay(keys, new Range<DateTime>(date.AddDays(-5), date), true))
                .ToDictionary(e => e.Key, e => e.Value.Last());
        }


        public static string GetCurrency(string currency)
        {
            return currency == "SUR" || currency == "RUR" ? "RUB" : currency;
        }

        private async Task UpdateSecurities()
        {
            try
            {
                string[] keys;
                lock (syncRoot)
                {
                    keys = securityKeys.ToArray();
                }

                if (keys.Length == 0)
                    return;

                var records = Rmds != null
                    ? await Rmds.PollMarketDataAsync(keys)
                    : new BidAsk[0];
                
                lock (syncRoot)
                {
                    foreach (var security in records)
                    {
                        var sec = securities.ContainsKey(security.Security) ? securities[security.Security] : null;

                        if (sec != null)
                            if (security.LastPrice != null)
                            {
                                if (sec.Type == "Bond")
                                    security.LastPrice = security.LastPrice * sec.FaceValue / 100 + sec.SecAccruedint;

                                if (sec.Type == "FuturesContract")
                                {
                                    if (security.FuturesPrice != null)
                                    {
                                        sec.LastQuotation = security.LastPrice ?? sec.LastPrice;
                                        sec.LastPrice = security.FuturesPrice ?? sec.LastQuotation;
                                    }
                                }
                                else
                                {
                                    sec.LastPrice = sec.LastQuotation = security.LastPrice ?? sec.LastPrice;
                                }
                            }
                    }
                }
            }
            catch (Exception ex)
            {
                logger?.LogError(ex, "updateSecurities");
            }
        }

        private async Task UpdateAllSecurities()
        {
            try
            {
                var records = await hsApi.UpdateFullList();
                logger?.LogTrace($"UPDFULL: {records.Length}");
                foreach (var security in records)
                {

                    var key = security.Key;

                    lock (syncRoot)
                    {
                        if (securities.ContainsKey(key))
                            securities[key] = security;
                        else
                            securities.Add(key, security);
                    }
                }

                if (dataAccessLayer != null) gammaTheta = await dataAccessLayer.GetGammaTheta();
            }
            catch (Exception ex)
            {
                logger?.LogError(ex, "updateAllSecurities");
            }

            await UpdateSecurities();
        }
    }
}