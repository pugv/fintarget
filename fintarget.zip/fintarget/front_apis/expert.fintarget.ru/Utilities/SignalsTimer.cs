﻿using System;
using System.Collections.Generic;

namespace fin_expert.Utilities
{
    public class SignalsTimer
    {
        private readonly TimeSpan _delay;

        private readonly Dictionary<Guid, DateTime> dict = new Dictionary<Guid, DateTime>();

        public SignalsTimer(TimeSpan delay)
        {
            _delay = delay;
        }

        public void SetTimer(Guid strat)
        {
            dict[strat] = DateTime.Now;
        }

        public TimeSpan? IsReady(Guid strat)
        {
            if (!dict.ContainsKey(strat) || DateTime.Now - dict[strat] > _delay)
            {
                dict.Remove(strat);
                return null;
            }

            return _delay - (DateTime.Now - dict[strat]);
        }
    }
}