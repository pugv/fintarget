﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Api.Models;
using ExchangeHelpers;
using ExchangeHelpers.LCS;
using fin_expert.Interfaces;
using Expert.Models;
using HS.Models;
using LCS.Kernel.BusinessModel;
using LCS.Kernel.Functionality;
using LCS.Kernel.Interfaces;
using LCS.Kernel.Objects;
using LCS.Models;
using LinqToDB;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLib.AuxTypes;
using NLib.Helpers;
using NLib.Http;
using NLib.ParsersFormatters.DateTime;
using PositionCalculator;
using STS.Kernel;
using STS.Kernel.Objects;
using static PositionCalculator.SignalProcessor;
using Dividend = LCS.Kernel.BusinessModel.Dividend;
using HistoryService = LCS.Kernel.Functionality.HistoryService;
using IDataAccessLayer = fin_expert.Interfaces.IDataAccessLayer;
using PriceItem = STS.Kernel.Objects.PriceItem;
using Security = LCS.Kernel.BusinessModel.Security;
using Signal = LCS.Kernel.BusinessModel.Signal;
using SignalDTO = LCS.Models.SignalDTO;
using Strategy = Expert.Models.Strategy;
using TimedPortfolio = LCS.Kernel.BusinessModel.TimedPortfolio;
using Trade = LCS.Kernel.Objects.Trade;
using User = LCS.Kernel.BusinessModel.User;

namespace fin_expert.Utilities
{
    public class StrategySandbox : IDisposable, IStrategySandbox
    {
        private readonly IDataAccessLayer _dataAccessLayer;
        private readonly HistoryService _historyService;

        private readonly HttpRequester _httpRequester;
        private readonly ILogger<StrategySandbox> _logger;
        private readonly decimal _longCommission;
        private readonly Dictionary<(string, string), (string, string)> _secExchanges;
        private readonly ISecurityCache _securityCache;
        private readonly decimal _shortCommission;
        private readonly decimal _usaCommission;

        private readonly ConcurrentDictionary<Guid, UploadCancellationTokenSource> _uploadStatus =
            new ConcurrentDictionary<Guid, UploadCancellationTokenSource>();

        public StrategySandbox(ISecurityCache securityCache, ILogger<StrategySandbox> logger, IDataAccessLayer dataAccessLayer, string hsHost, int hsPort,
            decimal shortCommission, decimal longCommission, decimal usaCommission, bool mock)
        {
            Precision = 0.0001m;

            _securityCache = securityCache;
            if (!mock)
            {
                _httpRequester = new HttpRequester(hsHost, hsPort, 30);
                _historyService = new HistoryService(_httpRequester, null, false);
            }

            _longCommission = longCommission;
            _shortCommission = shortCommission;
            _usaCommission = usaCommission;
            _logger = logger;
            _dataAccessLayer = dataAccessLayer;

            _secExchanges = new Dictionary<(string, string), (string, string)>();
            
            if (!mock)
                _secExchanges =
                    JsonConvert.DeserializeObject<StandardResponse<Dictionary<string, (string, string)>>>(_httpRequester.Request("currencies", ""))?.Result
                        .ToDictionary(k => (k.Key.Split(',')[0], k.Key.Split(',')[1]), k => k.Value) ?? _secExchanges;
        }


        public void Dispose()
        {
            if (_historyService != null) _historyService.Dispose();
            if (_httpRequester != null) _httpRequester.Dispose();
        }

        public async Task Clear(Guid stratId)
        {
            if (_uploadStatus.ContainsKey(stratId) && _uploadStatus[stratId] != null) _uploadStatus[stratId].Cancel();
            _uploadStatus[stratId] = null;

            using (var db = new SandboxDatabase())
            {
                await db.StrategyHistory.DeleteAsync(s => s.StrategyId == stratId);
                await db.Signals.DeleteAsync(s => s.StrategyId == stratId);
            }
        }

        public Task UploadData(Guid stratId, IStrategySandbox.UploadDataRequest req)
        {
            if (_uploadStatus.TryGetValue(stratId, out var ups)) ups?.Cancel();

            _logger.LogInformation($"Start upload track of {req.StratId}");


            var converter = new SignalConverter(GetConverterSupplier(false));

            if (req.Type == IStrategySandbox.TrackType.Numbers && req.StartingFunds <= 0) throw new Exception("Укажите стартовую сумму");

            converter.CheckSyntax(req.Lines);

            _logger.LogInformation($"Syntax of {req.Lines.Length} lines is Ok");

            var source = new UploadCancellationTokenSource();
            _uploadStatus.AddOrUpdate(stratId, a => source, (a, u) => source);

            _ = Task.Run(async () =>
            {
                try
                {
                    SignalProcessor proc;

                    var classCodes = new List<string>();

                    var isUsa = false;
                    var isLse = false;
                    var currency = "";
                    var strategy = await _dataAccessLayer.GetStrategy(stratId);

                    if (req.Markets == null)
                    {
                        classCodes.Add("TQBR");
                    }
                    else if (req.Markets.Contains(IStrategySandbox.SignalsMarket.Euro))
                    {
                        classCodes.Add("SPBDE");
                        currency = "EUR";
                    }
                    else if (req.Markets.Contains(IStrategySandbox.SignalsMarket.HKD))
                    {
                        classCodes.Add("SPBHKEX");
                        currency = "HKD";
                    }
                    else
                    {
                        if (req.Markets.Count == 0 || req.Markets.Contains(IStrategySandbox.SignalsMarket.Moex))
                        {
                            classCodes.AddRange(new[] { "TQBR", "TQTF", "TQIF" });
                            currency = "SUR";
                        }
                        else if (req.Markets.Contains(IStrategySandbox.SignalsMarket.MoexUSD))
                        {
                            classCodes.AddRange(new[] { "TQTD" });
                            currency = "USD";
                        }

                        if (!req.Markets.Contains(IStrategySandbox.SignalsMarket.Moex))
                        {
                            if (req.Markets.Contains(IStrategySandbox.SignalsMarket.Spbxm))
                            {
                                classCodes.AddRange(new[] { "SPBXM" });
                                currency = "USD";
                            }
                            else
                            {
                                if (req.Markets.Contains(IStrategySandbox.SignalsMarket.Usa))
                                {
                                    classCodes.AddRange(new[] { "NYSE_ARCA", "NYSE_MKT", "NASDAQ_BEST", "NASDAQ", "NYSE_BEST", "NYSE" });
                                    isUsa = true;
                                }

                                if (req.Markets.Contains(IStrategySandbox.SignalsMarket.LSE))
                                {
                                    isLse = true;
                                    currency = "USD";
                                    classCodes.AddRange(new[] { "LSE", "LSE_IOB" });
                                }
                            }

                            if (isUsa)
                                currency = "USD";
                        }

                        if (currency != "USD" && currency != "EUR")
                        {
                            if (req.Markets.Contains(IStrategySandbox.SignalsMarket.Bonds))
                                classCodes.AddRange(new[] { "TQOB", "TQCB", "EQOB", "EQCB" });
                            if (req.Markets.Contains(IStrategySandbox.SignalsMarket.Futures))
                                classCodes.AddRange(new[] { "SPBFUT" });
                            currency = "SUR";
                        }
                    }

                    if (currency != strategy.Currency)
                        throw new Exception("Валюта стратегии не соответсвует выбранному рынку");


                    source.PercentsDone = 1;
                    converter = new SignalConverter(GetConverterSupplier(isLse));

                    if (req.Type == IStrategySandbox.TrackType.Numbers)
                        proc = converter.ConvertNumbers(req.Lines,
                            new SignalConverter.ImportSettings
                                { CalcNkd = req.CalcNkd, Funds = req.StartingFunds, IsAlgo = req.IsAlgo, IsUSA = isUsa | isLse });
                    else
                        proc = converter.ConvertAlgo(req.Lines,
                            new SignalConverter.ImportSettings { CalcNkd = req.CalcNkd, IsAlgo = req.IsAlgo, IsUSA = isUsa | isLse });

                    _logger.LogInformation($"Conversion of track {req.StratId} done");

                    var secs = proc.Signals.SelectMany(s => new[] { s.Security?.GetKey()?.Trim(' '), s.Security2?.GetKey()?.Trim(' ') }).Distinct()
                        .Where(s => s != null).ToDictionary(s => s, s =>
                        {
                            var parts = s.Split(' ');
                            string res;
                            if (parts.Length == 1)
                                res = classCodes.Select(c => _securityCache.GetSecuritiy($"{s} {c} QUIK")).Where(securityRecord => securityRecord != null)
                                    .OrderByDescending(securityRecord => securityRecord.LastTime).FirstOrDefault()?.Key;
                            else
                                res = _securityCache.GetSecuritiy($"{s} QUIK")?.Key;

                            if (res != null) return res;
                            throw new Exception($"Тикер {s} не найден на выбранных рынках");
                        });
                    // calc dividends and comissions

                    if (!source.Token.IsCancellationRequested)
                    {
                        source.PercentsDone = 20;

                        var keys = proc.Signals.Where(s => s.Security != null).Select(s => s.Security.GetKey().Trim(' ')).Distinct().Select(s => secs[s])
                            .ToArray();
                        var splits = _securityCache.GetSplits(keys);
                        keys = keys.Concat(splits
                                .SelectMany(s => s.Value.SelectMany(ss => new[] { ss.Security, ss.SecurityTo }).Where(s1 => s1 != null).Distinct()).Distinct())
                            .Distinct().ToArray();

                        var reg = new SignalRegistrar(this, !req.IsAlgo, strategy, splits);

                        reg.PreloadBonds(keys);
                        reg.PreloadDivs(keys);

                        var pc = new PaymentsCalculator(reg, reg, reg, null, reg, null, _shortCommission, _longCommission, _usaCommission,
                            Array.Empty<TimeSpan>()) {DivAccuracy = 0.005m};

                        decimal multiplier = 1;
                        var count = proc.Signals.Count();
                        var i = 0;

                        using (var db = new SandboxDatabase())
                        {
                            await db.Signals.DeleteAsync(s => s.StrategyId == stratId);
                        }

                        foreach (var s in proc.Signals)
                            if (!source.IsCancellationRequested)
                            {
                                var result = pc.RegisterNewSignal(new Signal
                                {
                                    Id = s.Id,
                                    Security = s.Security != null ? new Security(secs[s.Security.GetKey().Trim(' ')]) : null,
                                    //Security2 = s.Security2 == null ? null : new LCS.Kernel.BusinessModel.Security(secs[s.Security2.Symbol]),
                                    OpenPrice = s.OpenPrice,
                                    OpenQuotation = s.OpenQuotation,
                                    OpenTime = s.OpenTime,
                                    Weight = s.Weight * multiplier,
                                    Type = s.Type,
                                    IsHistorical = true
                                }) as PaymentsCalculator.PaymentsJsonResult;

                                if (result?.Success!=true)
                                    throw new Exception(result?.Message??"Result is null");

                                multiplier *= result.Multiplier;
                                multiplier *= (1 + result.RealizedPnl / multiplier) / (1 + result.RealizedPnl);

                                if (multiplier > 20) throw new Exception("Арифметическое переполнение/ошибки в треке");

                                source.PercentsDone = 20 + 60 * ++i / count;
                            }

                        pc.RegisterNewSignal(new Signal
                        {
                            OpenTime = DateTime.Now,
                            IsHistorical = true
                        });

                        _logger.LogInformation($"Calculating of track {req.StratId} done");

                        source.PercentsDone = 80;

                        if (!source.IsCancellationRequested)
                        {
                            // calc history

                            var days = await GetEndOfDay(
                                reg.Manager.Signals.Where(s => s.Security != null).Select(s => s.Security.GetKey()).Distinct().ToArray(),
                                new Range<DateTime>(reg.Manager.Signals.First().OpenTime.Date, DateTime.Now.Date));
                            var signals = reg.Manager.Signals.Select(s => new STS.Kernel.Objects.Signal
                            {
                                Id = s.Id,
                                Security = s.Security,
                                OpenPrice = s.OpenPrice,
                                OpenQuotation = s.OpenQuotation,
                                OpenTime = s.OpenTime,
                                RealizedPnL = s.RealizedPnL,
                                Security2 = s.Security2,
                                /*State = s.State, */
                                Weight = s.Weight,
                                Type = s.Type
                            }).ToArray();

                            decimal mFee = 0;
                            decimal sFee = 0;

                            var apiStrat = await _dataAccessLayer.GetApiStrategy(strategy.Id);
                            if (apiStrat.Category != null)
                            {
                                mFee = apiStrat.PriceCategory.MF / 100;
                                sFee = apiStrat.PriceCategory.SF / 100;
                            }

                            var points = StsService.CalculateStrategyHistory(signals, days, req.IsAlgo ? CalcMode.OpenFixWeights : CalcMode.OpenFloatWeights,
                                mFee, sFee, p => { source.PercentsDone = 80 + (int)(p / 5.6); });

                            source.PercentsDone = 99;

                            if (!source.IsCancellationRequested)
                                using (var db = new SandboxDatabase())
                                {
                                    await db.StrategyHistory.Where(s => s.StrategyId == stratId).DeleteAsync();

                                    await db.InsertOrReplaceAsync(new StrategyPL
                                    {
                                        StrategyId = stratId,
                                        HistoryJson =
                                            JsonConvert.SerializeObject(points.Select(p => new
                                            {
                                                t = p.Time.ToJsonTime(), v = p.Value, r = Math.Round(p.R * 100, 6), u = Math.Round(p.U * 100, 6), vc = p.Vc
                                            }))
                                    });
                                }


                            if (!source.IsCancellationRequested)
                            {
                                _uploadStatus.AddOrUpdate(stratId, (UploadCancellationTokenSource)null, (a, b) => b == source ? null : b);

                                _logger.LogInformation($"Uploading of track {req.StratId} done");
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    _logger.LogWarning(e, $"Uploading of track {req.StratId}");

                    source.Error = e.Message;
                }
            }, source.Token);

            return Task.CompletedTask;
        }


        public IStrategySandbox.Status GetStatus(Guid stratId)
        {
            if (_uploadStatus.ContainsKey(stratId) && _uploadStatus[stratId] != null)
                return new IStrategySandbox.Status { Loading = true, Error = _uploadStatus[stratId].Error, PercentsDone = _uploadStatus[stratId].PercentsDone };

            return new IStrategySandbox.Status { Loading = false };
        }

        public void Cancel(Guid stratId)
        {
            if (_uploadStatus.ContainsKey(stratId) && _uploadStatus[stratId] != null)
            {
                _uploadStatus[stratId].Cancel();
                _uploadStatus[stratId] = null;
            }
        }

        public async Task<Dictionary<string, PriceItem[]>> GetEndOfDay(string[] securities, Range<DateTime> range)
        {
            try
            {
                var request = new EndOfDayRequest
                {
                    DateRange = range,
                    Securities = securities,
                    FillEmptyDays = false
                };
                var response = await _httpRequester.RequestAsync("prices/endofday", JsonConvert.SerializeObject(request));
                var val = JsonConvert.DeserializeObject<dynamic>(response) ?? throw new Exception("Can't parse prices/endofday");

                return ((IEnumerable<dynamic>)val).ToDictionary(
                    v => (string)v.Name,
                    v => ((IEnumerable<dynamic>)v.Value).Select(
                        i => new PriceItem
                        {
                            Date = i.Date,
                            Price = i.Price
                        }).ToArray());
            }
            catch (Exception e)
            {
                _logger?.LogError(e, nameof(GetEndOfDay));
                return null;
            }
        }

        public IConverterSupplier GetConverterSupplier(bool convertLse)
        {
            return new Converter(this, convertLse);
        }

        public Task TestUploadData(Guid stratId, IStrategySandbox.UploadDataRequest req)
        {
            if (_uploadStatus.ContainsKey(stratId) && _uploadStatus[stratId] != null) _uploadStatus[stratId].Cancel();

            var source = new UploadCancellationTokenSource();

            while (!_uploadStatus.TryAdd(stratId, source))
            {
                
            }

            var converter = new SignalConverter(GetConverterSupplier(false));

            if (req.Type == IStrategySandbox.TrackType.Numbers && req.StartingFunds <= 0) throw new Exception("Укажите стартовую сумму");

            converter.CheckSyntax(req.Lines);

            _ = Task.Run(async () =>
            {
                try
                {
                    for (source.PercentsDone = 1; source.PercentsDone < 90; source.PercentsDone++)
                        await Task.Delay(100);


                    if (!source.IsCancellationRequested)
                        using (var db = new SandboxDatabase())
                        {
                            await db.StrategyHistory.Where(s => s.StrategyId == stratId).DeleteAsync();

                            await db.Signals.DeleteAsync(s => s.StrategyId == stratId);

                            await db.InsertAsync(new SignalDTO
                            {
                                Id = 1,
                                SecurityKey = "LKOH TQBR QUIK",
                                StrategyId = stratId,
                                OpenPrice = 100,
                                OpenTime = DateTime.Now.Subtract(TimeSpan.FromDays(2)),
                                Weight = 0.2m
                            });


                            await db.InsertOrReplaceAsync(new StrategyPL
                            {
                                StrategyId = stratId,
                                HistoryJson =
                                    JsonConvert.SerializeObject(new[]
                                    {
                                        new HistoryPoint { t = DateTime.Now.Date.AddDays(-1).ToJsonTime(), v = 0.0m },
                                        new HistoryPoint { t = DateTime.Now.Date.ToJsonTime(), v = 0.1m }
                                    })
                            });
                        }

                    source.Error = DateTime.Now.Second % 2 == 0 ? "Ошибка: вам не повезло" : null;

                    if (_uploadStatus[stratId] == source)
                        _uploadStatus[stratId] = null;
                }
                catch (Exception e)
                {
                    source.Error = e.Message;
                }
            }, source.Token);

            return Task.CompletedTask;
        }

        private class Converter : IConverterSupplier
        {
            public readonly bool ConvertLse;
            private readonly StrategySandbox _parent;

            public Converter(StrategySandbox parent, bool useLSE)
            {
                _parent = parent;
                ConvertLse = useLSE;
            }

            private ISecurityCache SecurityCache => _parent._securityCache;
            private HttpRequester HttpRequester => _parent._httpRequester;
            private HistoryService HistoryService => _parent._historyService;
            private IDictionary<(string, string), (string, string)> SecExchanges => _parent._secExchanges;

            public decimal CalcBondPrice(string key, DateTime date, decimal price)
            {
                var bondCodes = new[] { "EQOB", "TQOB", "EQCB", "TQCB" };
                var sec = bondCodes.Select(c => SecurityCache.GetSecuritiy($"{key} {c} QUIK")).Where(c => c != null).OrderByDescending(c => c.LastTime)
                    .FirstOrDefault();
                if (sec != null)
                {
                    var securityRecord = HistoryService.GetSecurity(new Security(sec.Key));
                    if (securityRecord != null)
                    {
                        var nkd = PaymentsCalculator.CalcNcd(securityRecord,
                            HistoryService.GetBondsHistory(new[] { securityRecord.Security }).OrderBy(h => h.Date).ToArray(), date);

                        return securityRecord.FaceValue!.Value * price / 100 + nkd;
                    }

                    throw new Exception($"Can't calc nkd for {key}");
                }

                return price;
            }

            public Dictionary<string, (string, decimal)> GetFutures()
            {
                return JsonConvert.DeserializeObject<StandardResponse<Dictionary<string, (string, decimal)>>>(HttpRequester.Request("futures", ""))?.Result;
            }

            public Dictionary<string, string> GetUSACodes()
            {
                var secs = SecurityCache.GetSecurities();

                var res = secs.Where(s =>
                        !string.IsNullOrEmpty(s.ShortName) && !string.IsNullOrEmpty(s.Symbol) && (s.ClassCode.StartsWith('N') || s.ClassCode == "LSE_IOB"))
                    .GroupBy(s => $"{s.ShortName} {s.ClassCode}").Select(g => g.OrderByDescending(e => e.Current).ThenByDescending(e => e.LastTime).First())
                    .Select(s => new KeyValuePair<string, string>($"{s.ShortName} {s.ClassCode}", $"{s.Symbol} {s.ClassCode}"));

                if (ConvertLse)
                    return SecurityCache.GetLSECodes().ToArray().Concat(res).ToDictionary(k => k.Key, k => k.Value);

                return SecurityCache.GetUSACodes().ToArray().Concat(res).ToDictionary(k => k.Key, k => k.Value);
            }

            public Dictionary<DateTime, decimal> GetUsdHistory(DateTime start)
            {
                return HistoryService.GetEndOfDayData(new[] { new Security(SecExchanges[("USD", "SUR")].Item1) },
                    new Range<DateTime>(start, DateTime.Now), true).First().Value.ToDictionary(pi => pi.Date, pi => pi.Price);
            }
        }

        private class UploadCancellationTokenSource : CancellationTokenSource
        {
            public int PercentsDone { get; set; }
            public string Error { get; set; }
        }

        public class SignalRegistrar : ILcsService, IManagerAccountPool, LCS.Kernel.Interfaces.IDataAccessLayer, IHistoryService
        {
            private Dictionary<string, BondCoupon[]> _coupons;

            private Dictionary<string, Dividend[]> _divs;
            private int _id = 1;

            private Signal _lastSignal;
            private DateTime? _lastTime;

            public readonly ManagerAccount Manager;
            private readonly StrategySandbox _sandbox;
            private readonly Dictionary<string, Split[]> _splits;

            public SignalRegistrar(StrategySandbox sandbox, bool recalcWeights, Strategy strat, Dictionary<string, Split[]> splits)
            {
                _sandbox = sandbox;
                Manager = new ManagerAccount(new LCS.Models.Strategy
                {
                    RecalcMode = recalcWeights ? 0 : 1,
                    Id = strat.Id,
                    LongComiss = (decimal?)strat.Comiss?.Long,
                    ShortComiss = (decimal?)strat.Comiss?.Short
                }, null, null, null);
                this._splits = splits;
            }

            private State State => Manager.GetCurrentBundle();

            public Signal[] GetSignals(Guid strategy)
            {
                return Manager.Signals.OrderBy(s => s.Id).Select(s => new Signal
                {
                    Id = s.Id,
                    State = s.State,
                    OpenPrice = s.OpenPrice,
                    OpenTime = s.OpenTime,
                    OpenQuotation = s.OpenQuotation,
                    Security = s.Security == null ? null : new Security(s.Security.GetKey()),
                    Security2 = s.Security2 == null ? null : new Security(s.Security2.GetKey()),
                    Type = s.Type,
                    Weight = s.Weight
                }).ToArray();
            }

            public Task<SignalDTO> GetLastSignal(Guid strategyId)
            {
                throw new NotImplementedException();
            }

            public Result SaveSignal(Signal signal, Func<Signal, string> callback = null)
            {
                throw new NotImplementedException();
            }

            public Result SaveSignals(Signal[] signals, Func<Signal[], string> callback = null)
            {
                throw new NotImplementedException();
            }

            public Task<Result> SavePortfolioAndSignal(TimedPortfolio ports, Signal genSignal, Func<TimedPortfolio, Signal, Task<bool>> callback)
            {
                throw new NotImplementedException();
            }

            public bool HasSignal(int id)
            {
                throw new NotImplementedException();
            }

            public bool HasSignal(Guid strategyId, DateTime openTime)
            {
                throw new NotImplementedException();
            }

            public Task ClosePortfolios(Guid agrId)
            {
                throw new NotImplementedException();
            }

            Task LCS.Kernel.Interfaces.IDataAccessLayer.ClosePortfolio(int id, PortfolioClosingReason closingReason)
            {
                throw new NotImplementedException();
            }

            public TimedPortfolio[] GetPortfolios()
            {
                throw new NotImplementedException();
            }

            public void SavePortfolioPositions(TimedPortfolio p)
            {
                throw new NotImplementedException();
            }

            string LCS.Kernel.Interfaces.IDataAccessLayer.GetSnapshotOnDate(Guid strategyId, DateTime date)
            {
                throw new NotImplementedException();
            }

            public Signal[] GetStrategyStates(int[] ids)
            {
                throw new NotImplementedException();
            }

            public int[] GetNoStateSignalIds()
            {
                throw new NotImplementedException();
            }

            public bool SaveStrategy(Guid id, string content)
            {
                throw new NotImplementedException();
            }

            public LCS.Models.Strategy[] GetStrategies()
            {
                throw new NotImplementedException();
            }

            public Signal[] GetSignals()
            {
                throw new NotImplementedException();
            }

            public bool SaveUsers(User[] users)
            {
                throw new NotImplementedException();
            }

            public string[] GetRestrictedSecurities()
            {
                throw new NotImplementedException();
            }

            public Signal GetSignal(int id)
            {
                throw new NotImplementedException();
            }

            public User[] GetUsers()
            {
                throw new NotImplementedException();
            }

            public Dictionary<Guid, int[]> GetStrategyManagers()
            {
                throw new NotImplementedException();
            }

            public bool SetSignalExecutionStatus(int signalId, int status)
            {
                throw new NotImplementedException();
            }

            public void SaveSignalsPL(IEnumerable<Signal> signals)
            {
                throw new NotImplementedException();
            }

            public void SaveSignalsStates(IEnumerable<Signal> signals)
            {
                throw new NotImplementedException();
            }

            public bool SaveDelayedSignal(DelayedSignalDTO signal)
            {
                throw new NotImplementedException();
            }

            void LCS.Kernel.Interfaces.IDataAccessLayer.DeleteDelayedSignals(int[] id)
            {
                throw new NotImplementedException();
            }

            public void ExecuteDelayedSignals(Dictionary<int, int> ids)
            {
                throw new NotImplementedException();
            }

            public DelayedSignalDTO[] GetDelayedSignals()
            {
                throw new NotImplementedException();
            }


            public SecurityRecord GetSecurity(Security key)
            {
                var s = _sandbox._securityCache.GetSecuritiy(key.GetKey());
                return new SecurityRecord
                {
                    Security = new Security(s.Key),
                    SecAccruedint = s.SecAccruedint ?? 0,
                    LastPrice = s.LastPrice,
                    LastQuotation = s.LastQuotation ?? 0,
                    SharesInLot = (int?)s.SharesInLot,
                    Currency = s.Currency,
                    CouponPeriod = s.CouponPeriod,
                    CouponValue = s.CouponValue,
                    Type = (SecurityRecord.SecurityType)Enum.Parse(typeof(SecurityRecord.SecurityType), s.Type)
                };
            }

            public BondCoupon[] GetBondsHistory(Security[] keys)
            {
                if (_coupons == null) throw new Exception("Call PreloadBonds first");
                return keys.SelectMany(k => _coupons.TryGetValue(k.GetKey(), out var v) ? v : new BondCoupon[0]).ToArray();
            }

            public Dividend[] GetDividendsHistory(Security[] keys)
            {
                if (_coupons == null) throw new Exception("Call PreloadDivs first");
                return keys.SelectMany(k => _divs.TryGetValue(k.GetKey(), out var v) ? v : new Dividend[0]).ToArray();
            }

            public SecurityRecord[] GetSecurities(Security[] key)
            {
                throw new NotImplementedException();
            }

            public bool AddToShortList(Security key)
            {
                throw new NotImplementedException();
            }

            public IDictionary<Security, LCS.Kernel.Objects.PriceItem[]> GetEndOfDayData(Security[] keys, Range<DateTime> dateRange, bool fillEmptyDates)
            {
                throw new NotImplementedException();
            }

            public Range<TimeSpan>[] GetTradeTimes(Security security)
            {
                throw new NotImplementedException();
            }

            public void RefreshShortSecurityList()
            {
                throw new NotImplementedException();
            }

            public bool IsShortAllowed(string securityKey)
            {
                throw new NotImplementedException();
            }

            public Dictionary<string, bool> IsTradeDay(string[] classCodes, DateTime day)
            {
                throw new NotImplementedException();
            }

            public string[] GetSecuritiesClassCodes()
            {
                throw new NotImplementedException();
            }

            public void Dispose()
            {
                throw new NotImplementedException();
            }

            public Result<Signal[]> RegisterNewSignals(Signal[] signal)
            {
                throw new NotImplementedException();
            }

            public Result<DelayedSignalDTO> NewDelayedSignal(DelayedSignal signal)
            {
                throw new NotImplementedException();
            }

            public Result DeleteDelayedSignals(int[] ids)
            {
                throw new NotImplementedException();
            }

            public Task<Result> ClosePortfolio(int id, PortfolioClosingReason closingReason)
            {
                throw new NotImplementedException();
            }

            public Task<Result> CloseAllPortfolios(Guid agreem)
            {
                throw new NotImplementedException();
            }

            public Task<Result<TimedPortfolio>> RegisterPortfolio(TimedPortfolio timedPortfolio)
            {
                throw new NotImplementedException();
            }

            public Result Executed(ExecutionReport report)
            {
                throw new NotImplementedException();
            }

            public Result<LotCalcResult> LotCalc(LotCalcRequest lotCalcRequest)
            {
                throw new NotImplementedException();
            }

            public Result ConstructStrategyPortfolio(Guid stratId, int managerId, ConstructStrategyPosition[] positions)
            {
                throw new NotImplementedException();
            }

            public Result<Signal> CloseSignal(CloseSignalParams closingSignal)
            {
                throw new NotImplementedException();
            }

            public Result PushStrategiesToCS(Guid id)
            {
                throw new NotImplementedException();
            }

            public Task<Result<SecurityRecordDTO[]>> QueryLastSignalInfo(Guid strategyId)
            {
                throw new NotImplementedException();
            }

            public Result ReloadStrategy(Guid guid)
            {
                throw new NotImplementedException();
            }

            public Result RegisterSignal(Signal signal, Dictionary<Security, (decimal, decimal)> lastPrices = null)
            {
                throw new NotImplementedException();
            }

            public Result RegisterSignals(Signal[] signal, Dictionary<Security, (decimal, decimal)> lastPrices = null)
            {
                throw new NotImplementedException();
            }

            public void ReloadStrategy(LCS.Models.Strategy strategy, Signal[] signals)
            {
                throw new NotImplementedException();
            }

            public string CanRegisterSignal(Signal signal)
            {
                throw new NotImplementedException();
            }

            public string CanRegisterSignal(DelayedSignalDTO signal)
            {
                throw new NotImplementedException();
            }

            public Result CloseSignal(Signal signal)
            {
                throw new NotImplementedException();
            }

            public bool RegisterSignalExecutionStatus(int signalId, int status)
            {
                throw new NotImplementedException();
            }

            public ManagerAccountSnapshot GetStatistics(Guid strategyId)
            {
                throw new NotImplementedException();
            }

            public ManagerAccountSnapshot[] GetStatistics()
            {
                throw new NotImplementedException();
            }

            public AccountStatistics GetStatistics2()
            {
                throw new NotImplementedException();
            }

            public Position GetPosition(Guid strategyId, Security security)
            {
                throw new NotImplementedException();
            }

            public Dictionary<Guid, Dictionary<Security, Trade[]>> GetClosedTrades()
            {
                throw new NotImplementedException();
            }

            public State GetSnapshot(Guid strategyId)
            {
                return State;
            }

            public State GetSnapshotOnDate(Guid strategyId, DateTime date)
            {
                return null;
            }

            public State CalculateSnapshot(Signal signal, Dictionary<Security, (decimal,decimal)> lastPrices = null)
            {
                throw new NotImplementedException();
            }

            public State[] CalculateSnapshot(Signal[] signals, Dictionary<Security, (decimal,decimal)> lastPrices = null)
            {
                throw new NotImplementedException();
            }

            public LCS.Models.Strategy GetStrategy(Guid strategyId)
            {
                return Manager.Strategy;
            }

            public LCS.Models.Strategy[] GetChildStrategies(Guid strategyId)
            {
                throw new NotImplementedException();
            }

            public DelayedSignalDTO[] CheckDelayedSignals(IEnumerable<DelayedSignalDTO> sigs)
            {
                throw new NotImplementedException();
            }

            public Security[] GetSecurities()
            {
                throw new NotImplementedException();
            }

            public Security[] GetActiveSecurities()
            {
                throw new NotImplementedException();
            }

            public Signal[] CheckSLTP()
            {
                throw new NotImplementedException();
            }

            public void ProcessTick()
            {
                throw new NotImplementedException();
            }

            public Dictionary<Security, (decimal price, decimal quot)> GetPrices(Guid stratId)
            {
                throw new NotImplementedException();
            }

            public IEnumerable<(LCS.Models.Strategy, decimal)> CheckNpr()
            {
                throw new NotImplementedException();
            }

            private Signal[] WasSplit(DateTime now, DateTime? lastTime)
            {
                return State.ActivePositions.SelectMany(p => _splits.TryGetValue(p.Key.GetKey(), out var sps)
                    ? sps.Where(s => s.Date > lastTime && s.Date <= now)
                        .Select(s => new Signal
                        {
                            OpenTime = s.Date,
                            Weight = s.Coef,
                            Security = s.SecurityTo != null ? new Security(s.SecurityTo) : new Security(s.Security),
                            Security2 = new Security(s.Security),
                            Type = SignalTypeEnum.Split
                        })
                    : new Signal[0]).ToArray();
            }

            private decimal CalcSplitPrice(decimal price, DateTime date, string key)
            {
                if (_splits.TryGetValue(key, out var sps))
                {
                    var coef = sps.Where(s => s.Date > date).Multiply(s => s.Coef);
                    if (coef != 0)
                        return price / coef;
                }

                return price;
            }

            public virtual void WriteSignal(Signal ss)
            {
                using (var db = new SandboxDatabase())
                {
                    db.Insert(new SignalDTO
                    {
                        Id = ss.Id,
                        SecurityKey = ss.Security?.GetKey(),
                        SecurityKey2 = ss.Security2?.GetKey(),
                        StrategyId = Manager.Strategy.Id,
                        OpenQuotation = ss.OpenQuotation,
                        OpenPrice = ss.OpenPrice,
                        OpenTime = ss.OpenTime,
                        RealizedPnl = ss.PercentPnl,
                        State = ss.State,
                        Type = ss.Type,
                        Weight = ss.Weight
                    });
                }
            }

            public Result<Signal> RegisterNewSignal(Signal signal)
            {
                // splits
                if (_lastTime != null)
                {
                    var wassplits = WasSplit(signal.OpenTime, _lastTime);
                    if (wassplits?.Length > 0)
                        foreach (var s in wassplits)
                        {
                            s.StrategyId = signal.StrategyId;
                            s.ManagerId = signal.ManagerId;
                            s.Id = _id++;
                            Manager.RegisterSignal(s);
                            WriteSignal(s);
                            if (_lastSignal != null) _lastSignal.State = null;
                            _lastSignal = s;
                            /*if (manager.Signals.Skip(1).FirstOrDefault() != null)
                            {
                                var sigs = manager.Signals.TakeLast(2);
                                sigs.First().State = null; // free mem
                            }*/
                        }
                }

                if (!(signal.Security == null && signal.Type == SignalTypeEnum.Standard))
                {
                    signal.Id = _id++;
                    if (signal.Security != null)
                    {
                        var pr = CalcSplitPrice(signal.OpenPrice, signal.OpenTime, signal.Security.GetKey());
                        if (pr != signal.OpenPrice)
                            signal.OpenPrice = signal.OpenQuotation = pr;
                    }

                    Manager.RegisterSignal(signal);
                    WriteSignal(signal);
                    if (_lastSignal != null) _lastSignal.State = null;
                    _lastSignal = signal;
                }

                _lastTime = signal.OpenTime < _lastTime ? _lastTime : signal.OpenTime;
                return Result.Ok(signal);
            }

            public void PreloadBonds(string[] keys)
            {
                try
                {
                    var arr = JsonConvert.DeserializeObject<StandardResponse<BondCoupon[]>>(_sandbox._httpRequester.Request("coupons/bykey",
                        JsonConvert.SerializeObject(keys))) ?? throw new Exception("Can't get coupons/bykey");
                    _coupons = arr.Result.Select(a =>
                    {
                        a.Security = new Security(a.SecurityKey);
                        return a;
                    }).GroupBy(a => a.SecurityKey).ToDictionary(a => a.Key, a => a.ToArray());
                }
                catch (Exception e)
                {
                    _sandbox._logger?.LogError(e, "GetBondsHistory");
                }
            }

            public void PreloadDivs(string[] keys)
            {
                try
                {
                    var arr = JsonConvert.DeserializeObject<StandardResponse<Dividend[]>>(_sandbox._httpRequester.Request("dividends/bykey",
                        JsonConvert.SerializeObject(keys))) ?? throw new Exception("Can't get dividends/bykey");
                    _divs = arr.Result.Select(a =>
                    {
                        a.Security = new Security(a.SecurityKey);
                        return a;
                    }).GroupBy(a => a.SecurityKey).ToDictionary(a => a.Key, a => a.ToArray());
                }
                catch (Exception e)
                {
                    _sandbox._logger?.LogError(e, "GetDividendsHistory");
                }
            }
        }
    }
}