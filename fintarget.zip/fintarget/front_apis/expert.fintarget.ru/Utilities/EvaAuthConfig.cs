﻿using System;
using Microsoft.Extensions.Configuration;
using NLib.Config;

namespace fin_expert.Utilities
{
    public class EvaAuthConfig
        : TypedConfig
    {
        public EvaAuthConfig(IConfigurationSection section)
        {
            TokenSourceUrl = section.GetValue<string>("TokenSourceUrl");
            BasicLogin = section.GetValue<string>("BasicLogin");
            BasicPassword = section.GetValue<string>("BasicPassword");
            ClientId = section.GetValue<string>("ClientId");
            AuthType = section.GetValue<string>("AuthType");
            BasicCredentialStoreTarget = section.GetValue<string>("BasicCredentialStoreTarget");
            BasicUseCredentialStore = section.GetValue<bool>("BasicUseCredentialStore");
            HttpTimeout = section.GetValue<TimeSpan>("HttpTimeout");
            ClientSecret = string.Empty;
        }

        public string TokenSourceUrl { get; }

        public string BasicLogin { get; }

        public string BasicPassword { get; }

        public bool BasicUseCredentialStore { get; }

        public string BasicCredentialStoreTarget { get; }

        public string ClientId { get; }

        public string AuthType { get; }

        public TimeSpan HttpTimeout { get; }

        public string ClientSecret { get; }
    }
}