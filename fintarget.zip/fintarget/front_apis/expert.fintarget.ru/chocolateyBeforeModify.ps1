$sname = "expert_preprod"

Stop-IISSite -Name $sname -Confirm:$false