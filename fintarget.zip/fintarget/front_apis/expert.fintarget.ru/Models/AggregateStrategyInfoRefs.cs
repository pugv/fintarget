﻿using Api.Models;
using Expert.Models;

namespace fin_expert.Models
{
    public class AggregateStrategyInfoRefs
    {
        public Board[] Boards;
        public Duration[] Durations;
        public Index[] Indexes;
        public Market[] Markets;
        public Tool[] MarketTools;
        public InvestProfile[] Profiles;
        public Test[] Tests;
        public TradeType[] TradeTypes;
    }
}