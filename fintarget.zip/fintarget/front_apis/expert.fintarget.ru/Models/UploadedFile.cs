﻿namespace fin_expert.Models
{
    public class UploadedFile
    {
        public string Name { get; set; }
    }
}