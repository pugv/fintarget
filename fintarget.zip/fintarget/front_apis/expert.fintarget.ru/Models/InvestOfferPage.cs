﻿namespace fin_expert.Models
{
    public class InvestOfferPage
    {
        public int Total { get; set; }
        public InvestOfferDto[] PageItems { get; set; }
    }
}