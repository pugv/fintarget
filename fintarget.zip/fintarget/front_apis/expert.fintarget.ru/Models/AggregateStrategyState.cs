﻿using System;

namespace fin_expert.Models
{
    public class AggregateStrategyState
    {
        public Guid Id { get; set; }
        public bool? Active { get; set; }
        public bool? IsRestricted { get; set; }
        public bool? Open { get; set; }
    }
}