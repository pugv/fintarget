﻿namespace fin_expert.Models
{
    public class SecurityForecastRequest
    {
        public int SourceId { get; set; }
        public string[] SecurityKeys { get; set; }
    }

    public class SecurityForecastDto
    {
        public string SecurityKey { get; set; }
        public decimal? CurrentPrice { get; set; }
        public decimal? TargetPrice { get; set; }
        public decimal? Forecast { get; set; }
    }
}