﻿using System;
using System.Linq;

namespace fin_expert.Models
{
    public class PortfolioStatisticsRequest
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
    }

    public class PortfolioStatistics
    {
        /// <summary>
        ///     Число уникальных пользователей, просмотревших список портфелей
        /// </summary>
        public int UniqueListViews { get; set; }

        public PortfolioStatisticsEntry[] Entries { get; set; }
        public int TotalUniqueViewers => Entries?.Sum(c => c.UniqueViewers) ?? 0;
        public int TotalPurchaseAttempts => Entries?.Sum(c => c.PurchaseAttempts) ?? 0;
        public int TotalPurchases => Entries?.Sum(c => c.Purchases) ?? 0;
        public decimal TotalPurchaseSumInRubles => Entries?.Sum(c => c.PurchaseSumInRubles) ?? 0m;
    }

    public class PortfolioStatisticsEntry
    {
        /// <summary>
        ///     id портфеля
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        ///     Название портфеля
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        ///     Количество уникальных пользователей, открывших карточку портфеля
        /// </summary>
        public int UniqueViewers { get; set; }

        /// <summary>
        ///     Количество попыток купить портфель
        /// </summary>
        public int PurchaseAttempts { get; set; }

        /// <summary>
        ///     Количество покупок
        /// </summary>
        public int Purchases { get; set; }

        /// <summary>
        ///     Общая сумма покупки
        /// </summary>
        public decimal PurchaseSum { get; set; }

        /// <summary>
        ///     Общая сумма покупки в рублях
        /// </summary>
        public decimal PurchaseSumInRubles { get; set; }

        /// <summary>
        ///     Валюта портфеля
        /// </summary>
        public string Currency { get; set; }
    }
}