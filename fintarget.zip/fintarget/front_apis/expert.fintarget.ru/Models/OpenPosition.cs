using System;

namespace fin_expert.Models
{
    public class OpenPosition
    {
        public string SecurityKey { get; set; }
        public string Symbol { get; set; }
        public string ClassCode { get; set; }
        public string Name { get; set; }
        public string Comment { get; set; }
        public string Weight { get; set; }
        public string OpenPrice { get; set; }
        public string OpenQuotation { get; set; }
        public DateTime OpenTime { get; set; }
        public string CurrentPrice { get; set; }
        public string CurrentQuotation { get; set; }
        public string StopLoss { get; set; }
        public string TakeProfit { get; set; }
        public string RealizedPL { get; set; }
        public string UnrealizedPL { get; set; }
        public string UnrealizedPLPortfolio { get; set; }

        public string CurrentWeight { get; set; }
    }
}