﻿namespace fin_expert.Models
{
    public class Portfolio
    {
        public string Currency { get; set; }
        public string CurrentBalance { get; set; }
        public string CurrentFree { get; set; }
        public string RelizedPL { get; set; }
        public string UnrealizedPL { get; set; }
        public string PortfolioWeight { get; set; }
        public string Npr1 { get; set; }
        public Position[] Positions { get; set; }

        public string Deviation { get; set; }
        public string MaxDeviation { get; set; }

        public class Position
        {
            public string Symbol { get; set; }
            public string Name { get; set; }
            public string Weight { get; set; }
        }
    }
}