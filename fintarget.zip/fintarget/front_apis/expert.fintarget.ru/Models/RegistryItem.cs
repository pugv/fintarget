﻿namespace fin_expert.Models
{
    public class RegistryItem
    {
        public object Id { get; set; }
        public string Name { get; set; }
    }
}