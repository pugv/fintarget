﻿using System;
using LCS.Models;

namespace fin_expert.Models
{
    public class DelayedSignal
    {
        public long Id { get; set; }
        public string Symbol { get; set; }
        public string Name { get; set; }
        public DateTime FillingTime { get; set; }
        public string Weight { get; set; }
        public string OpenPrice { get; set; }
        public string ExecPrice { get; set; }
        public int Direction { get; set; }
        public string CurrentPrice { get; set; }
        public string StopLoss { get; set; }
        public string TakeProfit { get; set; }
        public string Comment { get; set; }
        public DelayedSignalType Type { get; set; }
    }
}