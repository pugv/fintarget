﻿using LifeCycleService.ApiClient;

namespace fin_expert.Models
{
    public class MarketSignalExt : MarketSignal
    {
        public string ApiKey { get; set; }
        public string Manager { get; set; }
        internal MarketSignalExt HideSensitiveClone()
        {
            var result = (MarketSignalExt)MemberwiseClone();
            result.ApiKey = string.IsNullOrEmpty(result.ApiKey) ? null : "***";
            return result;
        }
    }
}