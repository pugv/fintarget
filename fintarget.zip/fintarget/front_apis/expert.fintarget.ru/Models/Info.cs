﻿using System;

namespace fin_expert.Models
{
    public class Info
    {
        public string Version { get; set; }
        public DateTime BuildDate { get; set; }
        public string RcKey { get; set; }
        public string FriendlyUrl { get; set; }
    }
}