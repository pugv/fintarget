﻿using NLib.Enum;

namespace fin_expert.Models
{
    public enum UserRole
    {
        [DisplayName("Управляющий")] Manager,
        [DisplayName("Эксперт")] Expert,
        [DisplayName("Менеджер")] Administrator,
        [DisplayName("Риск-менеджер")] RiskManager,
        [DisplayName("Поддержка")] Support,
        [DisplayName("Контент-менеджер")] ContentManager,
        [DisplayName("Digital-эксперт")] DigitalExpert,
        [DisplayName("Администратор")] Developer,
        [DisplayName("Аудитор")] Auditor,
        None
    }
}