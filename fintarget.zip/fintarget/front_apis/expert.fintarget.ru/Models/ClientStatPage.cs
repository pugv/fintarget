﻿namespace fin_expert.Models
{
    public class ClientStatPage
    {
        public int Total { get; set; }
        public ClientStat[] PageStats { get; set; }
    }
}