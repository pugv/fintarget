﻿using System;

namespace fin_expert.Models
{
    public class SecuritySearch
    {
        public Guid? StrategyId { get; set; }
        public string[] ClassCodes { get; set; }
        public string Pattern { get; set; }
    }
}