﻿using System;

namespace fin_expert.Models
{
    public class SecurityRequest
    {
        public string SecurityKey { get; set; }
        public Guid StrategyId { get; set; }
        public string ApiKey { get; set; }
        public bool CheckChildren { get; set; } = true;
    }
}