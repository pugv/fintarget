﻿namespace fin_expert.Models
{
    public class FileDownload
    {
        public string FileName { get; set; }
        public string ContentBase64 { get; set; }
    }
}