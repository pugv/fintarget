﻿namespace fin_expert.Models
{
    public class Security
    {
        public string Key { get; set; }
        public string Symbol { get; set; }
        public string ClassCode { get; set; }
        public string Name { get; set; }
        public string Isin { get; set; }

        public string Board { get; set; }
    }

    public class SecurityAdvanced
        : Security
    {
        public string Type { get; set; }
        public uint LotSize { get; set; }
        public decimal? Price { get; set; }
        public decimal? Quotation { get; set; }
        public string Currency { get; set; }
        public bool ShortAllowed { get; set; }
        public decimal? MinWeight { get; set; }
        public decimal? MaxWeight { get; set; }
        public decimal? MaxSignalWeight { get; set; }
        public decimal CurrentWeight { get; set; }
        public decimal? MaxSLBuy { get; set; }
        public decimal? MinTPBuy { get; set; }
        public decimal? MinSLSell { get; set; }
        public decimal? MaxTPSell { get; set; }

        public int PriceDigits { get; set; }
        public decimal ExecCoef { get; set; }
    }
}