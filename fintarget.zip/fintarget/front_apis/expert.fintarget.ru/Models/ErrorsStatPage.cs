﻿using System;
using System.Collections.Generic;

namespace fin_expert.Models
{
    public class ErrorsStatPage
    {
        public DateTime[] Dates { get; set; }
        public List<ErrorStatsRow> ErrorStatsRows { get; set; } = new List<ErrorStatsRow>();
    }

    public class ErrorStatsRow
    {
        public string Source { get; set; }
        public string Error { get; set; }
        public int[] Occurrences { get; set; }

        public override string ToString()
        {
            return $"{Source} - {Error}: {string.Join("/", Occurrences)}";
        }
    }

    public class StrategyErrorsStatPage
    {
        public DateTime[] Dates { get; set; }
        public List<StrategyErrorStatsRow> ErrorStatsRows { get; set; } = new List<StrategyErrorStatsRow>();
    }

    public class StrategyErrorStatsRow
    {
        public string Strategy { get; set; }
        public Guid StrategyId { get; set; }
        public string Source { get; set; }
        public string Error { get; set; }
        public int[] Occurrences { get; set; }

        public override string ToString()
        {
            return $"{Strategy}: {string.Join("/", Occurrences)}";
        }
    }
}