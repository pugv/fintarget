﻿namespace fin_expert.Models
{
    public class PaginationAndSortAndFilter
        : PaginationAndSort
    {
        public Filter[] Filters { get; set; }

        public class Filter
        {
            public enum Criteria
            {
                Equals = 1,
                Contains = 2
            }

            public string FieldName { get; set; }
            public Criteria FilterCriteria { get; set; }
            public object[] Matches { get; set; }
        }
    }
}