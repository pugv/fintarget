﻿namespace fin_expert.Models
{
    public class RawHtmlData
    {
        public RawHtmlData(string html)
        {
            Html = html;
        }

        public string Html { get; set; }
    }
}