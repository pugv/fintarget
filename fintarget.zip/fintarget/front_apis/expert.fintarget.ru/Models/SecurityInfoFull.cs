﻿using System;

namespace fin_expert.Models
{
    public class SecurityInfoFull
    {
        public string Ticker { get; set; }
        public string ClassCode { get; set; }
        public string ClassName { get; set; }
        public string Name { get; set; }
        public string ShortName { get; set; }
        public string Isin { get; set; }
        public string Currency { get; set; }
        public string Type { get; set; }
        public bool ShortsAllowed { get; set; }
        public uint LotSize { get; set; }
        public decimal? PriceStep { get; set; }
        public bool IsCurrent { get; set; }
        public decimal? LastPrice { get; set; }
        public DateTime? LastTime { get; set; }
    }
}