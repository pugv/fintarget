﻿using System;
using Newtonsoft.Json;

namespace fin_expert.Models
{
    public class ClientStat
    {
        public int Id { get; set; }
        public string Agreement { get; set; }

        [JsonIgnore] public decimal dDeviation { get; set; }

        public string Deviation { get; set; }

        [JsonIgnore] public decimal dMinDiff { get; set; }

        public string MinDiff { get; set; }

        [JsonIgnore] public decimal dPortfolio { get; set; }

        public string Portfolio { get; set; }

        [JsonIgnore] public decimal dPositions { get; set; }

        public string Positions { get; set; }

        [JsonIgnore] public decimal dFree { get; set; }

        public string Free { get; set; }
        public string Strategy { get; set; }
        public string Service { get; set; }
        public DateTime BindDate { get; set; }
        public string HistoryUrl { get; set; }
        public string Currency { get; set; }
    }
}