using System;
using System.Linq;
using Expert.Models;

namespace fin_expert.Models
{
    public class AggregateInvestbox
    {
        public AggregateInvestbox()
        {
        }

        public AggregateInvestbox(Strategy strategy)
        {
            Id = strategy.Id;
            Title = strategy.Name;
            ParentId = strategy.ParentStrategy;
            ManagerId = strategy.ManagerId;
            CreatorId = strategy.CreatorId;
            Currency = strategy.Currency;
            Active = strategy.Active > 0;
            CreationDate = strategy.CreateTime;
            Leverage = strategy.Leverage ?? 0;
            Securities = strategy.Securities;
            Tests = strategy.Tests?.Select(t => t.TestId).ToArray() ?? Array.Empty<string>();
            SubscriptionThreshold = strategy.SubscriptionThreshold;
        }
        
        public Guid? Id { get; set; }
        public string Title { get; set; }
        public Guid? ParentId { get; set; }
        public int ManagerId { get; set; }
        public int CreatorId { get; set; }
        public DateTime CreationDate { get; set; }
        public bool Active { get; set; }
        public string Currency { get; set; }
        public decimal Leverage { get; set; }
        public string Securities { get; set; }
        public string[] Tests { get; set; }
        public string Tag { get; set; }
        public Guid? TariffId { get; set; }
        public string TariffName { get; set; }
        public bool IsOpen { get; set; }
        public decimal SubscriptionThreshold { get; set; }
    }
}