﻿using System;
using ES.Models;
using Newtonsoft.Json;

namespace fin_expert.Models
{
    public class ExternalClient
    {
        public Guid ClientId { get; set; }
        public Guid AgreementId { get; set; }
        public string Contract { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MidName { get; set; }
        public string TradeCode { get; set; }
        public string FutCode { get; set; }
        public bool? IsQual { get; set; }
        public string RiskName { get; set; }
        public DateTime? EventTime { get; set; }
        [JsonIgnore] public Guid? StrategyId { get; set; }
        public string StrategyName { get; set; }
        public string StrategyStatus { get; set; }
        public string StrategyType { get; set; }
        [JsonIgnore] public StrategyState IsActive { get; set; }
        public Guid? TariffId { get; set; }
        public DateTime? ChangeTime { get; set; }
    }
}