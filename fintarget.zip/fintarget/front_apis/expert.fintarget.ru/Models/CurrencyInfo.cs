﻿namespace fin_expert.Models
{
    public class CurrencyInfo
    {
        public string Code { get; set; }

        public string Name { get; set; }
    }
}