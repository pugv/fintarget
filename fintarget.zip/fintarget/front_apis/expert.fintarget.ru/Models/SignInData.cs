﻿namespace fin_expert.Models
{
    public class SignInData
    {
        public string UserId { get; set; }
        public string Password { get; set; }
    }

    public class LoginSmsCode
    {
        public string SmsCode { get; set; }
    }
}