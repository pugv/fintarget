﻿using System;
using HS.Models;

namespace fin_expert.Models
{
    public class TradeTime
    {
        public string Start { get; set; }
        public string End { get; set; }
        public string Description { get; set; }
    }

    public class Weekend
    {
        public int Id { get; set; }
        public string Day { get; set; }
    }

    public class MarketSchedule
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string[] ClassCodes { get; set; }
        public TradeTime[] TradeTimes { get; set; }
        public TradeTime[] SignalTimes { get; set; }
        public TradeTime[] RebalanceTimes { get; set; }
        public Weekend[] Weekends { get; set; }
        public string[] AddForbiddenSecurities { get; set; }
        public string[] RemoveForbiddenSecurities { get; set; }
    }
}
