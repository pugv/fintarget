﻿using NLib.Excel;
using System;
using NLib.Enum;


namespace fin_expert.Models
{
    public enum OrderStatusEnum
    {
        [DisplayName("Не определён")]
        NA = 0, 
        [DisplayName("Заявка активна")]
        Active = 1,  
        [DisplayName("Заявка частично исполнена")]
        PartialFill = 2,  
        [DisplayName("Заявка исполнена")]
        Fill = 3,  
        [DisplayName("Заявка отменена")]
        Canceled = 4,  
        [DisplayName("Заявка заменена")]
        Replaced = 5,  
        [DisplayName("Заявка в состоянии отмены")]
        Canceling = 6,  
        [DisplayName("Заявка отвергнута")]
        Rejected = 7,  
        [DisplayName("Приостановлено исполнение заявки")]
        Paused = 8,  
        [DisplayName("Заявка в состоянии регистрации")]
        Registering = 9,  
        [DisplayName("Заявка снята по времени действия")]
        CanceledByTime = 10,  
        [DisplayName("Заявка в состоянии замены")]
        Replacing = 11  
    }
    
    public class Order
    {
        // FROM IIR
        
        [NLib.Excel.ExcelColumn(Order = 4, DisplayName = "Имя")]
        public string FirstName { get; set; }
        [NLib.Excel.ExcelColumn(Order = 3, DisplayName = "Фамилия")]
        public string LastName { get; set; }
        [NLib.Excel.ExcelColumn(Order = 5, DisplayName = "Отчество")]
        public string MiddleName { get; set; }
        [NLib.Excel.ExcelColumn(Order = 6, DisplayName = "Генеральное соглашение No")]
        public string Agreement { get; set; }
        [NLib.Excel.ExcelColumn(Order = 7, DisplayName = "Генеральное соглашение от")]
        public DateTime? AgreementStartDate { get; set; }
        [NLib.Excel.ExcelColumn(Order = 8, DisplayName = "Договор об инвестиционном консультировании от")]
        public DateTime? InvestmentAdviceAgreementDate { get; set; }
        [NLib.Excel.ExcelColumn(Order = 14, DisplayName = "Номер ИИР")]
        public long SignalId { get; set; }
        [NLib.Excel.ExcelColumn(Order = 15, DisplayName = "Дата/время формирования")]
        public DateTime SignalDate { get; set; }
        [NLib.Excel.ExcelColumn(Order = 19, DisplayName = "Наименование стратегии")]
        public string StrategyName { get; set; }
        
        // FROM Instrument

        [NLib.Excel.ExcelColumn(Order = 9, DisplayName = "Финансовый инструмент код")]
        public string Symbol { get; set; }
        [NLib.Excel.ExcelColumn(Order = 10, DisplayName = "Финансовый инструмент класс")]
        public string Classcode { get; set; }
        [NLib.Excel.ExcelColumn(Order = 18, DisplayName = "Цена в ИИР")]
        public decimal Price { get; set; }
        public decimal Count { get; set; }

        [NLib.Excel.ExcelColumn(Order = 16, DisplayName = "Вид сделки в ИИР")]
        public string Type => Count < 0 ? "Продажа" : "Покупка";

        [NLib.Excel.ExcelColumn(Order = 17, DisplayName = "Количество в ИИР")]
        public decimal AbsCount => Math.Abs(Count);

        // FROM Order

        [ExcelColumn(DisplayName = "Дата/время выставления поручения брокеру", Order = 2)]
        public DateTime CreationTime { get; set; }
        [ExcelColumn(DisplayName = "Номер поручения брокеру", Order = 1)]
        public long OrderId { get; set; }
        [ExcelColumn(DisplayName = "Номер биржевого ордера", Order = 20)]
        public string BrokerOrderId { get; set; }
        [ExcelColumn(DisplayName = "Вид сделки в поручении брокеру", Order = 8)]
        public string Direction => Size >= 0 ? "Покупка" : "Продажа";

        public decimal Size { get; set; }

        [ExcelColumn(DisplayName = "Количество в поручении брокеру", Order = 12)]
        public decimal AbsSize => Math.Abs(Size);


        [ExcelColumn(DisplayName = "Цена в поручении брокеру", Order = 13)]
        public decimal? OrderPrice { get; set; }
        public OrderStatusEnum Status { get; set; }

        [ExcelColumn(DisplayName = "Признак исполнения поручения", Order = 21)]
        public string StatusName => Status.GetDisplayName();
        
        [ExcelColumn(Order = 22, DisplayName = "Наименование брокера")]
        public string BrokerName => "ООО \"Компания БКС\"";
    }
}
