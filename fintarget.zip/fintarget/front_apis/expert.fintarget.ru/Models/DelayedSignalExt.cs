﻿namespace fin_expert.Models
{
    public class DelayedSignalExt : ExchangeHelpers.LCS.DelayedSignal
    {
        public string ApiKey { get; set; }
        public string Manager { get; set; }
        internal DelayedSignalExt HideSensitiveClone()
        {
            var result = (DelayedSignalExt)MemberwiseClone();
            result.ApiKey = string.IsNullOrEmpty(result.ApiKey) ? null : "***";
            return result;
        }
    }
}