﻿using Api.Models;

namespace fin_expert.Models
{
    public class UserInfo
    {
        public int Id { get; set; }
        public AuthorType UserType { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string OrgName { get; set; }
        public string DisplayName { get; set; }
        public string AgreementNum { get; set; }
        public string Login { get; set; }
    }
}