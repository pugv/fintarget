﻿namespace fin_expert.Models
{
    public class LimitPosition
    {
        public string ClientCode { get; set; }

        public string Depo { get; set; }

        public string Currency { get; set; }

        public string Security { get; set; }

        public string Tag { get; set; }

        public string Kind { get; set; }

        public decimal Number { get; set; }

        public decimal Price { get; set; }

        public decimal? VarMargin { get; set; }

        public decimal? TotalVarmargin { get; set; }

        public decimal? PositionValue { get; set; }
    }
}