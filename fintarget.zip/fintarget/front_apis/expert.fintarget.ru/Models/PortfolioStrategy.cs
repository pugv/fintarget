﻿using System.Collections.Generic;
using System.Linq;
using CS.Balance.Interfaces;

namespace fin_expert.Models
{
    internal class PortfolioStrategy
        : IStrategyInfo
    {
        public PortfolioStrategy(string currency = "SUR")
        {
            Currency = currency;
        }

        public Dictionary<string, IStrategyPosition> Positions { get; } = new Dictionary<string, IStrategyPosition>();

        public string Currency { get; set; }
        public decimal? S => null;

        public bool AllowCell => false;

        public override string ToString()
        {
            return string.Join("; ", Positions.Select(c => $"{c.Key} - {c.Value.Weight}"));
        }

        internal class PortfolioStrategyPosition
            : IStrategyPosition
        {
            public PortfolioStrategyPosition(ISecurity security, decimal weight)
            {
                Security = security;
                Weight = weight;
            }

            public decimal Weight { get; }

            public ISecurity Security { get; }

            public override string ToString()
            {
                return $"{Security} - {Weight}";
            }
        }
    }
}