﻿using System;

namespace fin_expert.Models
{
    public class Tariff
    {
        public int Id { get; set; }
        public Guid Guid { get; set; }
        public int EvaId { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public int? Kind { get; internal set; }
    }
}