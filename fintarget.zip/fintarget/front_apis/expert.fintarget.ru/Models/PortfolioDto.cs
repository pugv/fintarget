﻿using System;

namespace fin_expert.Models
{
    public class PortfolioDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Annotation { get; set; }
        public string Description { get; set; }
        public bool Active { get; set; }
        public string Currency { get; set; }
        public PortfolioPosition[] Positions { get; set; }
        public int OrderNum { get; set; }
        public string ImageUrl { get; set; }
        public int ForecastSourceId { get; set; }
        public string ErrorMessage { get; set; }
        public decimal MinBalance { get; set; }
        public decimal Forecast { get; set; }

        public class PortfolioPosition
        {
            public string SecurityKey { get; set; }
            public decimal Weight { get; set; }
            public int OrderNum { get; set; }
            public decimal? TargetPrice { get; set; }
        }
    }
}