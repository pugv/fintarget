﻿namespace fin_expert.Models
{
    public class UserDirectoryItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}