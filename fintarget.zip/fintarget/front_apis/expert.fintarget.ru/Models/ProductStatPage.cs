﻿namespace fin_expert.Models
{
    public class ProductStatPage
    {
        public int Total { get; set; }
        public ProductStat[] PageStats { get; set; }

        public string TotalClients { get; set; }
        public string TotalSUR { get; set; }
        public string TotalUSD { get; set; }
    }
}