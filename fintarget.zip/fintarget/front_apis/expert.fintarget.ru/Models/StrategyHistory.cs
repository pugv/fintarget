﻿namespace fin_expert.Models
{
    public class StrategyHistory
    {
        public string IndexName { get; set; }

        public AggregateHistoryPoint[] History { get; set; }

        public double MeanYearProfit { get; set; }
        public double Profit { get; set; }
        public double Drawdown { get; set; }

        public class HistoryPoint
        {
            public decimal? r;
            public long t;
            public decimal? u;
            public decimal v;
            public decimal[] vc;
            public decimal vr;
        }

        public struct AggregateHistoryPoint
        {
            public long t;
            public decimal? v;
            public decimal vi;
            public decimal? vc;
            public decimal? vr;
        }
    }
}