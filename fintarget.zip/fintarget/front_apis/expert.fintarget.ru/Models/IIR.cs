﻿using fin_expert.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace fin_expert.Models
{

    public class IIR
    {
        [NLib.Excel.ExcelColumn(Order = 4, DisplayName = "Имя")]
        public string FirstName { get; set; }
        [NLib.Excel.ExcelColumn(Order = 3, DisplayName = "Фамилия")]
        public string LastName { get; set; }
        [NLib.Excel.ExcelColumn(Order = 5, DisplayName = "Отчество")]
        public string MiddleName { get; set; }
        [NLib.Excel.ExcelColumn(Order = 6, DisplayName = "Генеральное соглашение No")]
        public string Agreement { get; set; }
        [NLib.Excel.ExcelColumn(Order = 7, DisplayName = "Генеральное соглашение от")]
        public DateTime? AgreementStartDate { get; set; }
        [NLib.Excel.ExcelColumn(Order = 8, DisplayName = "Договор об инвестиционном консультировании от")]
        public DateTime? InvestmentAdviceAgreementDate { get; set; }
        [NLib.Excel.ExcelColumn(Order = 1, DisplayName = "Номер ИИР")]
        public long SignalId { get; set; }
        [NLib.Excel.ExcelColumn(Order = 2, DisplayName = "Дата/время формирования")]
        public DateTime SignalDate { get; set; }
        [NLib.Excel.ExcelColumn(Order = 9, DisplayName = "Наименование стратегии")]
        public string StrategyName { get; set; }
        [NLib.Excel.ExcelColumn(Order = 10)]
        public List<IIRInstrument> Instruments { get; set; }
    }
}
