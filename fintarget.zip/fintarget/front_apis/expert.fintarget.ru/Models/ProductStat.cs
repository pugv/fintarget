﻿using Newtonsoft.Json;

namespace fin_expert.Models
{
    public class ProductStat
    {
        [JsonIgnore] public ProductType iProductType { get; set; }
        public string ProductType { get; set; }
        public string Name { get; set; }
        public string Author { get; set; }

        [JsonIgnore] public int? iClientCount { get; set; }

        [JsonIgnore] public decimal? dValueSUR { get; set; }

        [JsonIgnore] public decimal? dValueUSD { get; set; }

        public string ClientCount { get; set; }
        public string ValueSUR { get; set; }
        public string ValueUSD { get; set; }
    }
}