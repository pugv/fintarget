﻿using System;

namespace fin_expert.Models
{
    public class ErrorsStatFilter
    {
        public Guid? StrategyId { get; set; }
        public DateTime From { get; set; }
        public DateTime To { get; set; }

        public ErrorsStatMode ErrorsStatMode { get; set; }
    }

    public class StrategyErrorsStatFilter
    {
        public DateTime From { get; set; }
        public DateTime To { get; set; }

        public ErrorsStatMode ErrorsStatMode { get; set; }
    }

    public enum ErrorsStatMode
    {
        ByWeeks,
        ByMonths
    }
}