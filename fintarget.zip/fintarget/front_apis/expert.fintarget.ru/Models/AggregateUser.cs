﻿using Api.Models;
using Expert.Models;

namespace fin_expert.Models
{
    public class AggregateUser
    {
        public AggregateUser()
        {
        }

        public AggregateUser(User user)
        {
            Id = user.Id;
            MasterId = user.MasterId;
            Company = user.OrgName;
            Role = user.Role;
            Login = user.Login;
            Phone = user.Phone;

            if (string.IsNullOrEmpty(user.OrgName) &&
                (string.IsNullOrEmpty(user.FirstName) || string.IsNullOrEmpty(user.LastName)))
            {
                // workaround for old fio
                var names = user.FullName?.Split(' ') ?? new string[0];
                FirstName = names.Length > 0 ? names[0] : string.Empty;
                LastName = names.Length > 1 ? names[1] : string.Empty;
            }
            else
            {
                FirstName = user.FirstName;
                LastName = user.LastName;
            }

            MidName = user.MidName;
        }

        public int Id { get; set; }
        public int? MasterId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MidName { get; set; }
        public string Role { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }

        public string Phone { get; set; }

        // for authors
        public AuthorType UserType { get; set; }
        public string Company { get; set; }
        public string OrgInn { get; set; }
        public string OrgOgrn { get; set; }
        public string OrgKpp { get; set; }
        public string PassportId { get; set; }
        public string PassportIssued { get; set; }
        public string IssueDate { get; set; }
        public string EmployeeId { get; set; }
        public string AgreementNum { get; set; }
        public bool Comission { get; set; }
        public string Position { get; set; }
        public string Photo { get; set; }
        public string PhotoFormat { get; set; }
        public bool PhotoChanged { get; set; }

        //public string PhotoBase64 { get; set; }
        public string Email { get; set; }
        public string InfoHtml { get; set; }
        public string ShortinfoHtml { get; set; }
        public string InfoText { get; set; }

        public string ShortinfoText { get; set; }
        //public int Rating { get; set; }

        // readonly
        public string DisplayName { get; set; }

        internal void SetAuthor(Author author)
        {
            if (author != null)
            {
                UserType = author.Type;
                Company = author.Company;
                OrgInn = author.OrgInn;
                OrgOgrn = author.OrgOgrn;
                PassportId = author.PassportId;
                PassportIssued = author.PassportIssued;
                EmployeeId = author.EmployeeId;
                AgreementNum = author.AgreementNum;
                Comission = author.Commission != 0;
                Position = author.Position;
                Photo = author.ImageUrl;
                PhotoFormat = author.PhotoFormat;
                PhotoChanged = false;
                //PhotoBase64 = author.PhotoBase64;
                Email = author.Email;
                InfoHtml = author.InfoHtml;
                ShortinfoHtml = author.ShortInfoHtml;
                InfoText = author.InfoText;
                ShortinfoText = author.ShortInfoText;
                //Rating = author.Rating;
                DisplayName = author.DisplayName;
            }
        }

        internal AggregateUser HideSensitiveClone()
        {
            var result = (AggregateUser)MemberwiseClone();
            result.Password = string.IsNullOrEmpty(result.Password) ? null : "***";
            return result;
        }
    }
}