﻿namespace fin_expert.Models
{
    public class ListPage<T>
    {
        public long Total { get; set; }
        public T[] PageItems { get; set; }
    }
}