﻿using System;

namespace fin_expert.Models
{
    public class Trade
    {
        public long Id { get; set; }
        public string Symbol { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Comment { get; set; }
        public decimal Weight { get; set; }
        public decimal Price { get; set; }
        public DateTime Time { get; set; }
        public decimal? RealizedPL { get; set; }

        public decimal? ExecPrice { get; set; }
        public decimal? ExecPL { get; set; }
        public decimal? ExecWeight { get; set; }

        public bool IsInProcess { get; set; }
        public int nExecPrice { get; set; }

        public double nExecuting { get; set; }
        public double nDone { get; set; }
        public double ExecutingPrt { get; set; }
        public double DonePrt { get; set; }
    }
}