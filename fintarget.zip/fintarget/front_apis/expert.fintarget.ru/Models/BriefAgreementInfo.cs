﻿using System;
using System.Linq;
using Newtonsoft.Json;

namespace fin_expert.Models
{
    public class BriefAgreementInfo
    {
        public BriefAgreementInfo()
        {
        }

        public BriefAgreementInfo(Guid id, string agreement, string firstName, string lastName, string middleName)
        {
            Id = id;
            Agreement = agreement;
            Fio = string.Join(
                " ",
                new[] { lastName, firstName, middleName }.Where(s => !string.IsNullOrEmpty(s)));
        }

        [JsonProperty("value")] public string Agreement { get; set; }
        public Guid Id { get; set; }
        [JsonProperty("name")] public string Fio { get; set; }
    }
}