﻿using System;
using System.Collections.Generic;
using System.Linq;
using CS.Balance.Interfaces;

namespace fin_expert.Models
{
    public class PortfolioClient
        : IClientAccount
    {
        private readonly List<Position> positions = new List<Position>();

        public PortfolioClient(decimal amount)
        {
            S = amount;
        }

        public IEnumerable<IClientAccountPosition> Positions => positions;

        public decimal S { get; set; }

        public decimal AddPositions(IEnumerable<IClientAccountPosition> pos, bool DeleteEmpty = true)
        {
            foreach (var p in pos)
            {
                var pp = positions.FirstOrDefault(ppp => ppp.SecurityKey == p.SecurityKey);
                if (pp != null)
                    throw new Exception("Update positions is Not realized");
                positions.Add(new Position(p));
            }

            return 0;
        }

        public object Clone()
        {
            return new PortfolioClient(S);
        }

        public IClientAccountPosition CreatePosition(IClientAccountPosition pos)
        {
            return pos;
        }

        public class Position
            : IClientAccountPosition
        {
            public Position()
            {
            }

            public Position(IClientAccountPosition pos)
            {
                SecurityKey = pos.SecurityKey;
                LastPrice = pos.LastPrice;
                Number = pos.Number;
                AvgPrice = pos.AvgPrice;
                RealizedPnL = pos.RealizedPnL;
                RealizedPnLValue = pos.RealizedPnLValue;
                Currency = pos.Currency;
            }

            public string SecurityKey { get; set; }

            public decimal AvgPrice { get; set; }

            public decimal LastPrice { get; set; }

            public decimal SumPrice => Number * AvgPrice;

            public decimal Number { get; set; }

            public decimal RealizedPnL { get; set; }

            public decimal RealizedPnLValue { get; set; }

            public string Currency { get; set; }

            public object Clone()
            {
                return this;
            }

            public override string ToString()
            {
                return $"{SecurityKey} {Number}@{AvgPrice}";
            }
        }
    }
}