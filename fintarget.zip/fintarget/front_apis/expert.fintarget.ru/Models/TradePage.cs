﻿namespace fin_expert.Models
{
    public class TradePage
    {
        public int TotalTrades { get; set; }
        public Trade[] PageTrades { get; set; }
    }
}