﻿namespace fin_expert.Models
{
    public class PaginationAndSort
    {
        public int PageSize { get; set; }
        public int PageNumber { get; set; }
        public string SortFieldName { get; set; }
        public int SortDirection { get; set; }
    }
}