﻿namespace fin_expert.Models
{
    public class ExternalQuery
    {
        public string ContractMask { get; set; }
    }
}