﻿using System;
using Expert.Models;

namespace fin_expert.Models
{
    public class StrategyDirectoryItem
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int ManagerId { get; set; }
        public bool IsChild { get; set; }
        public string ParentStrategy { get; set; }
        public StrategyStatus Status { get; set; }
        public int RecalcMode { get; set; }
        public bool IsAutofollow { get; set; }
        public bool IsAutoconsult { get; set; }
        public bool IsInvestbox { get; set; }
    }
}