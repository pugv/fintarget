﻿using System;
using System.Linq;
using Expert.Models;

namespace fin_expert.Models
{
    public class StrategyInfoPart
    {
        public string Title { get; set; }
        public string Value { get; set; }
    }

    public class AggregateStrategy
    {
        public AggregateStrategy()
        {
        }

        public AggregateStrategy(Strategy strat)
        {
            Id = strat.Id;
            ParentId = strat.ParentStrategy;
            ManagerId = strat.ManagerId;
            CreatorId = strat.CreatorId;
            MaxInstrumentWeight = strat.MaxInstrumentWeight;
            Name = strat.Name;
            Securities = strat.Securities;
            SubscriptionThreshold = strat.SubscriptionThreshold;
            Active = strat.Active != 0;
            Currency = strat.Currency;
            CreationDate = strat.CreateTime;
            RecalcMode = strat.RecalcMode;
            TradeType = strat.TradeType;
            Autofollow = strat.Autofollow;
            Autoconsult = strat.Autoconsult;
            IsPortfolio = strat.IsPortfolio;
            IIS = strat.Iis;
            IsAlgostrategy = strat.IsAlgo;
            Leverage = strat.Leverage ?? 0;
            TradesFrequency = strat.TradesFrequency;
            Tests = strat.Tests?.Select(t => t.TestId).ToArray() ?? new string[0];
            EvaParams = new EvaParamsDto(strat.StrategyEvaParams);
            MaxSignalWeight = strat.MaxSignalWeight;

            if (strat.Comiss != null)
            {
                RateLong = strat.Comiss.Long;
                RateShort = strat.Comiss.Short;
            }
        }

        public Guid? Id { get; set; }
        public Guid? ParentId { get; set; }
        public int ManagerId { get; set; }
        public int CreatorId { get; set; }
        public string ManagerName { get; set; }
        public DateTime CreationDate { get; set; }
        public string Currency { get; set; }
        public decimal Leverage { get; set; }
        [Obsolete] public int NoWeightCorrection { get; set; }
        public string Securities { get; set; }
        public string Comissions { get; set; }
        public decimal? MaxInstrumentWeight { get; set; }
        public string Name { get; set; }
        public decimal SubscriptionThreshold { get; set; }
        public int RecalcMode { get; set; }
        public int? TradeType { get; set; }
        public bool Active { get; set; }
        public decimal? MaxSignalWeight { get; set; }

        // FT
        public double Rating { get; set; }
        public string ApiKey { get; set; }
        public bool Autoconsult { get; set; }
        public bool Autofollow { get; set; }
        public string Category { get; set; } // not used
        public string ChartComment { get; set; }
        public decimal? Capacity { get; set; }
        public bool IsPortfolio { get; set; }
        public string DescriptionHtml { get; set; }
        public int DurationId { get; set; }
        public bool ForQualifiedInvestorsOnly { get; set; }
        public string Goal { get; set; }
        public bool HidePortfolio { get; set; }
        public bool HideRecentSignals { get; set; }
        public bool IIS { get; set; }
        public int? IndexId { get; set; }
        public bool HideIndexOnChart { get; set; }
        public bool HideIndexInWL { get; set; }
        public string InfoHtml { get; set; }
        public StrategyInfoPart[] InfoParts { get; set; }
        public bool IsAlgostrategy { get; set; }
        public decimal MaxIndustryWeight { get; set; }
        public decimal MaxPositionWeight { get; set; }
        public int? MinInvestProfileId { get; set; }
        public bool Open { get; set; }
        public int Order { get; set; }
        [Obsolete] public string PictureFormat { get; set; }
        [Obsolete] public string PictureBase64 { get; set; }
        public string Price { get; set; }
        public bool Recommended { get; set; }
        public bool IsRestricted { get; set; }
        public bool ShowFullPortfolio { get; set; }
        public DateTime? StartDate { get; set; }
        public string Tag { get; set; }
        public bool TestMode { get; set; }
        public string TradesFrequency { get; set; }
        public int? AfTariffId { get; set; }
        public int? AcTariffId { get; set; }
        public DateTime? PlStartDate { get; set; }
        public int[] MarketIds { get; set; }
        public int[] MarketToolIds { get; set; }
        public int[] BoardIds { get; set; }

        // leverage comission rates
        public double? RateShort { get; set; }
        public double? RateLong { get; set; }

        public BriefAgreementInfo[] Clients { get; set; }

        // tests
        public string[] Tests { get; set; }
        public EvaParamsDto EvaParams { get; set; }

        internal void SetStrategy(Api.Models.Strategy strat)
        {
            if (strat == null)
                return;

            // Autoconsult, Autofollow, IIS, IsAlgostrategy, Leverage, TradesFrequency - from Cabinet
            ApiKey = strat.ApiKey;
            //ManagerId = strat.AuthorId;
            //Autoconsult = strat.Autoconsult;
            //Autofollow = strat.Autofollow;
            Category = strat.Category;
            ChartComment = strat.ChartComment;
            Comissions = strat.Comissions;
            Capacity = strat.Capacity;
            DescriptionHtml = strat.DescriptionHtml;
            DurationId = strat.DurationId;
            ForQualifiedInvestorsOnly = strat.ForQualifiedInvestorsOnly;
            Goal = strat.Goal;
            HidePortfolio = strat.HidePortfolio;
            HideRecentSignals = strat.HideRecentSignals;
            //IIS = strat.IIS;
            IndexId = strat.IndexId;
            HideIndexOnChart = strat.HideIndexOnChart;
            HideIndexInWL = strat.HideIndexInWL;
            InfoHtml = strat.InfoHtml;
            InfoParts = strat.SalesPoints?
                .Select(p => new StrategyInfoPart { Title = p.Title, Value = p.Text })
                .ToArray() ?? new StrategyInfoPart[0];
            //IsAlgostrategy = strat.IsAlgostrategy;
            //Leverage = strat.Leverage;
            MaxIndustryWeight = strat.MaxIndustryWeight;
            MaxPositionWeight = strat.MaxPositionWeight;
            MinInvestProfileId = strat.MinInvestProfileId;
            Open = strat.Open;
            Order = strat.Order;
            Price = strat.Price;
            Rating = strat.Rating;
            Recommended = strat.Recommended;
            IsRestricted = strat.IsRestricted;
            ShowFullPortfolio = strat.ShowFullPortfolio;
            StartDate = strat.StartDate;
            PlStartDate = strat.PlStartDate;
            //SubscriptionThreshold = strat.SubscriptionThreshold;
            Tag = strat.Tag;
            TestMode = strat.TestMode;
            //TradesFrequency = strat.TradesFrequency;
        }
    }
    public class EvaParamsDto
    {
        public EvaParamsDto(StrategyEvaParams param)
        {
            if (param == null)
            {
                return;
            }
            StockMarketMMVB = param.StockMarketMMVB;
            FortsRTS = param.FortsRTS;
            CreditGO = param.CreditGO;
            CurrencyMarket = param.CurrencyMarket;
            SpbRTS = param.SpbRTS;
            CurrencyMarketEBS = param.CurrencyMarketEBS;
            StockMarketOffexchange = param.StockMarketOffexchange;
            MmvbUSD = param.MmvbUSD;
            FortsRTSEBS = param.FortsRTSEBS;
            Lse = param.Lse;
            UsMarkets = param.UsMarkets;
            EvaUpdatedAt = param.EvaUpdatedAt;
        }

        public bool StockMarketMMVB { get; set; }
        public bool FortsRTS { get; set; }
        public bool CreditGO { get; set; }
        public bool CurrencyMarket { get; set; }
        public bool SpbRTS { get; set; }
        public bool CurrencyMarketEBS { get; set; }
        public bool StockMarketOffexchange { get; set; }
        public bool MmvbUSD { get; set; }
        public bool FortsRTSEBS { get; set; }
        public bool Lse { get; set; }
        public bool UsMarkets { get; set; }
        public DateTime? EvaUpdatedAt { get; set; }
    }

}