﻿using System;

namespace fin_expert.Models
{
    public class InvestOfferDto
    {
        public bool Active { get; set; }
        public string Comment { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public Guid Id { get; set; }
        public string Subtitle { get; set; }
        public string Title { get; set; }
        public Position[] Positions { get; set; }

        public class Position
        {
            public string SecurityKey { get; set; }
            public decimal Weight { get; set; }
            public int OrderNum { get; set; }
            public decimal? TargetPrice { get; set; }
            public string FullDescription { get; set; }
            public string IssuerDescription { get; set; }
        }
    }
}