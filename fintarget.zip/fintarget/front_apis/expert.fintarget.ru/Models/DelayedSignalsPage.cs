﻿namespace fin_expert.Models
{
    public class DelayedSignalsPage
    {
        public int TotalSignals { get; set; }
        public DelayedSignal[] PageSignals { get; set; }
    }
}