﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace fin_expert.Models
{
    public class IIRInstrument
    {
        public long signalId { get; set; }
        [NLib.Excel.ExcelColumn(Order = 1, DisplayName = "Финансовый инструмент код")]
        public string Symbol { get; set; }
        [NLib.Excel.ExcelColumn(Order = 2, DisplayName = "Финансовый инструмент класс")]
        public string Classcode { get; set; }
        [NLib.Excel.ExcelColumn(Order = 5, DisplayName = "Цена финансового инструмента")]
        public decimal Price { get; set; }
        public decimal Count { get; set; }

        [NLib.Excel.ExcelColumn(Order = 3, DisplayName = "Вид сделки")]
        public string Type => Count < 0 ? "Продажа" : "Покупка";

        [NLib.Excel.ExcelColumn(Order = 4, DisplayName = "Количество финансового инструмента")]
        public decimal AbsCount => Math.Abs(Count);
    }
}
