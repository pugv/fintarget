﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace fin_expert.Models
{
    public class ProductStatRequest
        : PaginationAndSortAndFilter
    {
        public ProductType? ProductType { get; set; }
    }

    public enum ProductType
        : int
    {
        StrategyAutoFollow = 1,
        StrategyAutoConsult = 2,
        Moneybox = 3
    }
}
