﻿namespace fin_expert.Models
{
    public class PortfolioPage
    {
        public int Total { get; set; }
        public PortfolioDto[] PageItems { get; set; }
    }
}