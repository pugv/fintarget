﻿using System;

namespace fin_expert.Models
{
    public class StrategySummary
    {
        /// <summary>
        ///     Гуид
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        ///     Название
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        ///     Мин сумма для подключения
        /// </summary>
        public decimal SubscriptionThreshold { get; set; }

        /// <summary>
        ///     Валюта
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        ///     Доступно АК
        /// </summary>
        public bool Autoconsult { get; set; }

        /// <summary>
        ///     Доступно АС
        /// </summary>
        public bool Autofollow { get; set; }

        /// <summary>
        ///     Доступна инвесткопилка
        /// </summary>
        public bool IsInvestbox { get; set; }

        /// <summary>
        ///     Категория
        /// </summary>
        public string Category { get; set; }

        /// <summary>
        ///     Срок инвестиций
        /// </summary>
        public string Duration { get; set; }

        /// <summary>
        ///     Профиль
        /// </summary>
        public string MinInvestProfile { get; set; }

        /// <summary>
        ///     Оценка доходности
        /// </summary>
        public decimal EstimatedProfit { get; set; }

        /// <summary>
        ///     Оценка просадки
        /// </summary>
        public decimal EstimatedDrawdown { get; set; }

        /// <summary>
        ///     Только квал
        /// </summary>
        public bool ForQualifiedInvestorsOnly { get; set; }

        /// <summary>
        ///     Скрыть портфель
        /// </summary>
        public bool HidePortfolio { get; set; }

        /// <summary>
        ///     Скрыть сигнала
        /// </summary>
        public bool HideRecentSignals { get; set; }

        /// <summary>
        ///     ИИС
        /// </summary>
        public bool IIS { get; set; }

        /// <summary>
        ///     Бенчмарк
        /// </summary>
        public string Index { get; set; }

        /// <summary>
        ///     Тариф АС по категории
        /// </summary>
        public string PriceAF { get; set; }

        /// <summary>
        ///     Тариф АК по категории
        /// </summary>
        public string PriceAC { get; set; }

        /// <summary>
        ///     Показывать весь портфель
        /// </summary>
        public bool ShowFullPortfolio { get; set; }

        /// <summary>
        ///     Тестовая
        /// </summary>
        public bool TestMode { get; set; }

        /// <summary>
        ///     Закрытая
        /// </summary>
        public bool IsRestricted { get; set; }

        /// <summary>
        ///     Подключаемые тарифы
        /// </summary>
        public AvailableTariff[] AvailableTariffs { get; set; }

    }
}