﻿using System;
using CS.Balance.Interfaces;
using ExchangeHelpers.HS;

namespace fin_expert.Controllers
{
    internal class PortfolioSecurityProxy : ISecurity
    {
        private readonly decimal _priceMultiplier;
        private readonly SecurityRecord _securityRecord;

        public PortfolioSecurityProxy(SecurityRecord securityRecord, decimal priceMultiplier)
        {
            _securityRecord = securityRecord;
            _priceMultiplier = priceMultiplier;
        }

        public string Key => _securityRecord.Key;

        public string Symbol => _securityRecord.Symbol;

        public string Name => _securityRecord.Name;

        public decimal LastPrice => _securityRecord.LastPrice * _priceMultiplier ?? 0;

        public SecurityType Type => GetSecurityType(_securityRecord.Type);

        public string Currency => _securityRecord.Currency;

        public decimal? Bid => 0;

        public decimal? Ask => 0;

        public uint LotSize => _securityRecord.SharesInLot.Value;

        public decimal OneLotPrice => LastPrice * LotSize;

        public decimal PriceStep
        {
            get => _securityRecord.PriceStep ?? 0;
            set => throw new NotImplementedException();
        }

        public decimal SecAccruedint
        {
            get => _securityRecord.SecAccruedint ?? 0;
            set => throw new NotImplementedException();
        }

        public decimal FaceValue
        {
            get => _securityRecord.FaceValue ?? 0;
            set => throw new NotImplementedException();
        }

        public decimal LastQuotation
        {
            get => _securityRecord.LastQuotation ?? 0;
            set => throw new NotImplementedException();
        }

        private SecurityType GetSecurityType(string type)
        {
            switch (type)
            {
                case "Indices":
                    return SecurityType.Indices;
                case "Option":
                    return SecurityType.Option;
                case "SMSAlert":
                    return SecurityType.SMSAlert;
                case "Spread":
                    return SecurityType.Spread;
                case "Security":
                    return SecurityType.Security;
                case "FuturesContract":
                    return SecurityType.FuturesContract;
                case "Currency":
                    return SecurityType.Currency;
                case "Bond":
                    return SecurityType.Bond;
                default:
                    return SecurityType.Undefined;
            }
        }

        public override string ToString()
        {
            return $"{Key}@{LastPrice}";
        }
    }
}