﻿using System;
using System.Collections.Generic;
using System.Linq;
using CS.Kernel.Model;

// ReSharper disable MemberCanBePrivate.Global
// ReSharper disable UnusedAutoPropertyAccessor.Global

namespace fin_expert.Models
{
    public class ClientAccountInfo
    {
        public ClientAccountInfo(ClientAccount ca)
        {
            Id = ca.Id;
            ClientCode = ca.ClientCode;
            Agreement = ca.Client?.Agreement;
            FIO = ca.Client?.LastName + " " + ca.Client?.FirstName;
            ServiceDate = ca.Client?.ServiceDate;
            StrategyId = ca.StrategyId;
            Status = ca.Status ?? ClientAccount.StatusEnum.Unattached;
            Value = ca.Value;
            StrategyName = ca.Client?.StrategyName;
            if (ca.Portfolios?.Length > 0)
                Portfolio = ca.Portfolios[0];
            RealizedPnl = ca.RealizedPnL;
            RealizedPnlFunds = ca.RealizedPnLFunds;
            NeedFetch = ca.NeedFetch;
            NeedNotify = ca.NeedNotify;
            Block = ca.Block?.ToString();
            IsMarginal = ca.IsMarginal;
            BlockedPositions = ca.Positions.Where(p => p.Wait != null).ToDictionary(p => p.SecurityKey != "" ? p.SecurityKey : p.Currency, p => p.Wait!.Value);
            ChecksNeeded = ca.Checks?.Where(c => !c.Passed)?.Select(c => c.Name).ToArray();
            BlockSignalId = ca.Signals.OrderByDescending(s => s.Id).SkipWhile(s => s.Processed == ClientSignal.ProcessedEnum.Unprocessed)
                .FirstOrDefault(s => s.Processed == ClientSignal.ProcessedEnum.Processing)?.SignalId;
        }

        public int Id { get; set; }
        public string ClientCode { get; set; }
        public string Agreement { get; set; }
        public string FIO { get; set; }
        public DateTime? ServiceDate { get; set; }
        public Guid? StrategyId { get; set; }
        public string StrategyName { get; set; }
        public ClientAccount.StatusEnum Status { get; set; }
        public decimal Value { get; set; }
        public ClientAccount.Portfolio Portfolio { get; set; }
        public bool NeedFetch { get; set; }
        public bool NeedNotify { get; set; }
        public decimal RealizedPnl { get; set; }
        public decimal RealizedPnlFunds { get; set; }
        public string Block { get; set; }
        public string[] ChecksNeeded { get; set; }
        public int? BlockSignalId { get; set; }
        public Dictionary<string, long> BlockedPositions { get; set; }
        public bool IsMarginal { get; set; }
    }
}