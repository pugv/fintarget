﻿using Api.Models;

namespace fin_expert.Models
{
    public class AnalyticsPage
    {
        public int Total { get; set; }
        public Analytics[] PageItems { get; set; }
    }
}