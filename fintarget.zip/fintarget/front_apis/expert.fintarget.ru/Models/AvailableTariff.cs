﻿using System;

namespace fin_expert.Models
{
    public class AvailableTariff
    {
        /// <summary>
        ///     Гуид ТП клиента (если пусто - все остальные)
        /// </summary>
        public Guid? ClientTariff { get; set; }

        /// <summary>
        ///     Название тарифа
        /// </summary>
        public int AfTariff { get; set; }

        /// <summary>
        ///     ЕВА-ид тарифа АС
        /// </summary>
        public int AcTariff { get; set; }
    }
}