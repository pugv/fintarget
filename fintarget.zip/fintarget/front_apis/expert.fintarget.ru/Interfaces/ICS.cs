﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ExchangeHelpers;

namespace fin_expert.Interfaces
{
    public interface ICS
    {
        Task<ClientAccountFullTO> FetchClientLimits(string clientCode);
        Task<bool> Rebalance();
        Task<bool> Rebalance(string clientCode);
        Task<bool> BlockClient(string clientCode, TimeSpan time, CancellationToken cancellationToken);
        Task<ClientAccountFullTO[]> GetClientAccountByCodeAsync(string clientCodeOrFuturesCode);
        Task<bool> Exit();
        Task<string> Info();
        Task<SecurityTO> Security(string key);
        Task UpdateClientAccountAsync(ClientAccountTO account);
        Task<object> CalcRebalance(string clientCode);
        Task<Dictionary<int, string>> ProblemClients();
    }
}