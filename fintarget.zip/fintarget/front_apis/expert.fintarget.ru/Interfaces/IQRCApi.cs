﻿using System.Collections.Generic;
using System.Threading.Tasks;
using QRCApi;

namespace fin_expert.Interfaces
{
    public interface IQRCApi
    {
        Task<Dictionary<string, ClientPortfolio[]>> GetLimits(string[] clientCodes);
    }
}