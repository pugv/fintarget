﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ExchangeHelpers.HS;
using HS.Models;

namespace fin_expert.Interfaces
{
    public interface ISecurityCache
    {
        RMDS.ApiClient.Api Rmds { get; }
        string GetSecurityTypeInfo(string typeCode);

        bool InCache(string key);

        Task AddSecurities(IEnumerable<string> keys, bool immediateRefresh = true);

        /// <summary>
        /// Получение списка securities 
        /// </summary>
        /// <param name="allowedPatterns">список рег. выражений для security key</param>
        /// <param name="classCodes">список названий класс-кодов</param>
        /// <param name="pattern"></param>
        /// <param name="maxResuls"></param>
        /// <returns></returns>
        SecurityRecord[] SearchSecurities(string[] allowedPatterns, string[] classCodes, string pattern, int maxResuls);

        SecurityRecord GetSecuritiy(string key);

        Task<SecurityRecord> GetSecuritiyWithLatestPrice(string key);

        Task<bool> IsShortAllowed(string key);

        void ActualizeSecurities(IEnumerable<string> keys);

        Dictionary<string, string> GetUSACodes();
        Dictionary<string, string> GetLSECodes();

        SecurityRecord[] GetSecurities();

        (decimal, decimal) GetGammaTheta(string classCode);
        Task<PriceItem[]> EndOfDay(string key);
        Task<Dictionary<string, PriceItem>> EndOfDay(string[] keys, DateTime date);
        Dictionary<string, Split[]> GetSplits(string[] keys);
    }
}