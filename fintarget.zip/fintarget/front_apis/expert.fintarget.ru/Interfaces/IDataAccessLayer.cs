﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.Models;
using Expert.Models;
using LCS.Models;


namespace fin_expert.Interfaces
{
    public interface IDataAccessLayer
    {
        Task<(string ApiKey, int? AuthorId)> GetStrategyApiKey(Guid guid);

        int GetManagerId(string Login);

        Task<(int total, IEnumerable<DelayedSignalDTO>)> GetStrategyDelayedSignals(Guid strategyId,
            Func<IQueryable<DelayedSignalDTO>, IQueryable<DelayedSignalDTO>> sortFunc);

        Task<(int total, IEnumerable<SignalDTO> signals)> GetStrategyTradesAsync(Guid strategyId,
            Func<IQueryable<SignalDTO>, IQueryable<SignalDTO>> sortFunc);

        Task<DelayedSignalDTO> GetDelayedSignal(long signalId);

        Task<Api.Models.Strategy[]> GetApiStrategies();

        Task<SignalDTO[]> GetSnaboxSignals(Guid stratId);
        Task<SignalDTO> GetStrategyLastSignal(Guid strategyId, DateTime? date = null);
        Task<StrategyPL> GetStrategyHistory(Guid strategyId);

        Task<Api.Models.Strategy> GetApiStrategy(Guid id);

        Task<Expert.Models.Strategy> GetStrategy(Guid strategyId);

        Task<bool> SetStrategyStatus(Guid strategyId, StrategyStatus status);

        Task CopyStrategySignalsFromSandbox(Guid stratId);

        Task SaveSandboxRecalcMode(Expert.Models.Strategy strategy);

        Task<Dictionary<string, (decimal, decimal)>> GetGammaTheta();

        Task<InvestProfile[]> GetInvestProfiles();

        Task<IIR[]> GetIIRs(string clientLastName, string clientFirstName, string clientMiddleName, string agreementNumber, DateTime? iirStartDate,
            DateTime? iirEndDate, long? iirNumber, string strategyName, string symbol, string classCode);

        Task<Expert.Models.IIR[]> GetOrders(string clientLastName, string clientFirstName, string clientMiddleName, string agreementNumber, string orderNumber,
            DateTime? iirStartDate, DateTime? iirEndDate, long? iirNumber, string strategyName, string symbol, string classCode);
    }
}