﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace fin_expert.Interfaces
{
    public interface IStrategySandbox
    {
        public enum SignalsMarket
        {
            Moex = 1,
            Bonds = 2,
            Spbxm = 3,
            Futures = 4,
            Usa = 5,
            MoexUSD = 6,
            LSE = 7,
            Euro = 8,
            HKD = 9
        }

        public enum TrackType
        {
            Numbers = 0,
            Percents = 1
        }

        Task UploadData(Guid stratId, UploadDataRequest request);
        Task Clear(Guid stratId);
        Status GetStatus(Guid stratId);

        void Cancel(Guid stratId);

        public class UploadDataRequest
        {
            public Guid StratId { get; set; }
            public ICollection<SignalsMarket> Markets { get; set; }
            public bool CalcNkd { get; set; }
            public TrackType Type { get; set; }
            public decimal StartingFunds { get; set; }
            public string[] Lines { get; set; }
            public bool IsAlgo { get; set; }
        }

        public class Status
        {
            public bool Loading { get; set; }
            public string Error { get; set; }
            public int PercentsDone { get; set; }
        }
    }
}