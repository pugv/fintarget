﻿using System;
using System.Threading.Tasks;

namespace fin_expert.Interfaces
{
    public interface ISTS
    {
        Task<bool> UpdateHistory(Guid stratId);
    }
}