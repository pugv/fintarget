﻿using System;
using System.Threading.Tasks;
using ExchangeHelpers.LCS;
using LCS.Kernel.BusinessModel;
using LCS.Models;
using LifeCycleService.ApiClient;

namespace fin_expert.Interfaces
{
    public interface ILCS
    {
        Task<Signal> NewSignal(MarketSignal signal);
        Task<bool> NewSignals(MarketSignal[] signals);
        Task<bool> ConstructStrategy(ConstructStrategy construct);

        Task<Signal> NewChangeSignal(ChangeSignal signal);

        Task<Signal> NewReplaceSignal(ChangeSignal signal);
        Task<DelayedSignalDTO> NewDelayedSignal(DelayedSignal signal);


        Task CloseDelayedSignal(long delayedSignalId);

        Task CloseSignal(ClosingSignal signal);

        Task<bool> ReloadStrategy(Guid stratId);

        Task<bool> SetStrategy(Strategy strategy);

        Task<bool> PushToCS(Guid strategyId);

        Task<bool> SetUsers(User[] users);
    }
}