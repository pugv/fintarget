using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Api.Models;
using fin_expert.Interfaces;
using LinqToDB;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace fin_expert.Services
{
    public class StrategyRegisterService : BackgroundService
    {
        private readonly ILCS _lcs;
        private readonly ILogger<StrategyRegisterService> _logger;

        public StrategyRegisterService(ILCS lcs, ILogger<StrategyRegisterService> logger)
        {
            _lcs = lcs ?? throw new ArgumentNullException(nameof(lcs));
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken);

                    try
                    {
                        using (var db = new Database())
                        {
                            var strategies = await db.Strategies
                                .Where(s => s.UpdateLcs > 0)
                                .Take(100)
                                .ToArrayAsync(stoppingToken);

                            if (!strategies.Any()) continue;

                            using (var cabdb = new Expert.Models.Database())
                            {
                                var ids = strategies.Select(s => s.Id).ToArray();

                                var cabStrategies = await cabdb.Strategies
                                    .LoadWith(s => s.Tests)
                                    .LoadWith(s => s.Comiss)
                                    .Where(s => ids.Contains(s.Id))
                                    .ToArrayAsync(stoppingToken);

                                foreach (var cabStrategy in cabStrategies)
                                {
                                    var strategy = strategies.First(ss => ss.Id == cabStrategy.Id);

                                    if (!await TryPostStrategyToLcsAsync(cabStrategy, strategy.Open && strategy.UpdateCs))
                                        continue;

                                    await db.Strategies
                                        .Where(s => s.Id == cabStrategy.Id)
                                        .AsUpdatable()
                                        .Set(s => s.UpdateLcs, s => s.UpdateLcs - strategy.UpdateLcs)
                                        .Set(s => s.UpdateCs, !strategy.Open)
                                        .UpdateAsync(stoppingToken);
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        _logger?.LogError(e, "Worker");
                    }
                }
            }
            catch (TaskCanceledException)
            {
                _logger?.LogInformation("Canceled");
            }
            catch (Exception e)
            {
                _logger?.LogError(e, "Worker");
            }
        }

        private async Task<bool> TryPostStrategyToLcsAsync(Expert.Models.Strategy cabStrategy, bool pushToCs)
        {
            try
            {
                string[] securities = null;

                var sec = cabStrategy.Securities;
                if (sec != null)
                    try
                    {
                        securities = JsonConvert.DeserializeObject<string[]>(sec);
                    }
                    catch (Exception e)
                    {
                        _logger?.LogWarning(
                            $"Investbox to LCS id=|{cabStrategy.Id.ToString()}| deserialize securities {e.Message}");
                    }

                var lcsStrategy = new LCS.Models.Strategy
                {
                    Id = cabStrategy.Id,
                    Active = cabStrategy.Active > 0,
                    AllowedSecurities = securities ?? Array.Empty<string>(),
                    Created = cabStrategy.CreateTime,
                    CreatorId = cabStrategy.CreatorId,
                    Currency = cabStrategy.Currency,
                    Description = null,
                    ManagerId = cabStrategy.ManagerId,
                    Leverage = cabStrategy.Leverage,
                    IsAutoconsult = cabStrategy.Autoconsult,
                    IsAutofollow = cabStrategy.Autofollow,
                    IsInvestbox = cabStrategy.IsInvestbox,
                    IsPortfolio = cabStrategy.IsPortfolio,
                    RecalcMode = cabStrategy.RecalcMode,
                    Title = cabStrategy.Name,
                    MinSumm = cabStrategy.SubscriptionThreshold,
                    ShortComiss = (decimal?)cabStrategy.Comiss?.Short,
                    LongComiss = (decimal?)cabStrategy.Comiss?.Long,
                    ParentStrategy = cabStrategy.ParentStrategy,
                    ProfileId = cabStrategy.ProfileId,
                    TradeType = cabStrategy.TradeType,
                    RequiredTests = cabStrategy.Tests?.Select(s => s.TestId).ToArray() ?? Array.Empty<string>()
                };

                if (await _lcs.SetStrategy(lcsStrategy))
                {
                    if (!pushToCs || await _lcs.PushToCS(cabStrategy.Id))
                        return true;

                    _logger?.LogError($"Investbox Push to CS id=|{cabStrategy.Id.ToString()}| failed");
                }
                else
                {
                    _logger?.LogError($"Investbox to LCS id=|{cabStrategy.Id.ToString()}| failed");
                }
            }
            catch (Exception e)
            {
                _logger?.LogError(e, "Investbox to LCS");
            }

            return false;
        }
    }
}