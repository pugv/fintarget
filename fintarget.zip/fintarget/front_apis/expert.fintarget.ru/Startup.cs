using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using CS.Balance;
using Expert.Models;
using fin_expert.Controllers;
using fin_expert.Controllers.Admin;
using fin_expert.DTO;
using fin_expert.Interfaces;
using fin_expert.Services;
using fin_expert.Utilities;
using LinqToDB.Data;
using Mb.Logging;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.SpaServices.ReactDevelopmentServer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using NLib.Authorization;
using NLib.AuxTypes;
using NLib.Caching;
using NLib.Enum;
using NLib.Extensions.AspNet;
using NLib.Linq2dbExtensions;
using NLib.Migrations;
using NLib.Timers;
using ProxyKit;
using RMDS.ApiClient;
using ServiceBase;

namespace fin_expert
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;

            CultureInfo.CurrentCulture = new CultureInfo("ru-RU", false);

            UserVisibleException.DefaultMessage = "Система в данный момент не может обработать запрос";
        }

        public IConfiguration Configuration { get; }

        private string GetConnectionString(string name)
        {
            var connectionStringName = name;
            var isOSXPlatform = RuntimeInformation.IsOSPlatform(OSPlatform.OSX);

            if (isOSXPlatform) connectionStringName += "OSX";

            return Configuration.GetConnectionString(connectionStringName);
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddProxy();

            services.AddControllers().AddNewtonsoftJson(s =>
            {
                s.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                s.SerializerSettings.Formatting = Formatting.Indented;
            });

            services.AddSpaStaticFiles(configuration => { configuration.RootPath = "ClientApp/build"; });

            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "expert.fintarget.ru.Properties.BuildDate.txt";

            DateTime buildDate;

            using (var stream = assembly.GetManifestResourceStream(resourceName))
            using (var reader = new StreamReader(stream))
            {
                var result = reader.ReadToEnd().TrimEnd();
                buildDate = DateTime.Parse(result);
            }

            services.AddDistributedMemoryCache();
            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30);
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
                options.Cookie.Name = ".expert.fintarget.Session";
            });

            var evaAuthConfig = Configuration.GetSection("EvaAuthorization").Exists() ? new EvaAuthConfig(Configuration.GetSection("EvaAuthorization")) : null;

            services.AddSingleton(new AppConfig
            {
                AuthTwoFactor = Configuration.GetSection("Authorization").GetValue<bool>("TwoFactor"),
                AuthMaxOtpsPerInterval = Configuration.GetSection("Authorization").GetValue("MaxOtpsPerInterval", 20),
                AuthMaxOtpsInterval = Configuration.GetSection("Authorization").GetValue("MaxOtpsInterval", TimeSpan.FromHours(1)),
                AuthSmsExpiration = Configuration.GetSection("Authorization").GetValue<TimeSpan>("SmsExpiration"),
                AuthNoSmsWhiteList = Configuration.GetSection("Authorization").GetSection("NoSmsWhiteList")?.GetChildren().ToArray().Select(c => c.Value)
                    .ToArray(),
                AuthSessionExpiration = TimeSpan.FromSeconds(Configuration.GetSection("Authorization").GetValue<int>("SessionTimeout")),
                MockUnrealizedPL = Configuration.GetSection("Mocks").GetValue<bool>("UnrealizedPL"),
                MockSecurityCache = Configuration.GetSection("Mocks").GetValue<bool>("SecurityCache"),
                MaxHistoryPoints = Configuration.GetSection("History").GetValue<int>("MaxPoints"),
                MaxSecuritySearchResuls = Configuration.GetSection("Signals").GetValue<int>("MaxSecuritySearchResuls"),
                RecaptchaClientKey = Configuration.GetSection("GoogleReCaptcha").GetValue<string>("ClientKey"),
                BuildVersion = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                BuildDate = buildDate,
                UserSaltMinLength = Configuration.GetSection("Authorization").GetValue<int>("UserSaltMinLength"),
                UserSaltMaxLength = Configuration.GetSection("Authorization").GetValue<int>("UserSaltMaxLength"),
                FintargetWebRootPath = Configuration.GetSection("FileUpload").GetValue<string>("FintargetWebRootPath"),
                FintargetTestWebRootPath = Configuration.GetSection("FileUpload").GetValue<string>("FintargetTestWebRootPath"),
                FintargetHostAddress = Configuration.GetSection("FileUpload").GetValue<string>("FintargetHostAddress"),
                UploadedFilesLocation = Configuration.GetSection("FileUpload").GetSection("Analytics").GetValue<string>("Location"),
                UploadedPortfolioFilesLocation = Configuration.GetSection("FileUpload").GetSection("Portfolio").GetValue<string>("Location"),
                UploadedAuthorsFilesLocation = Configuration.GetSection("FileUpload").GetSection("Authors").GetValue<string>("Location"),
                PortfolioPriceMultiplier = Configuration.GetSection("PortfolioService").GetValue<decimal>("PricesMultiplier"),
                EvaApiUrl = Configuration.GetSection("EvaApi").GetValue<string>("StrategyCatalogUrl"),
                EvaTimeout = Configuration.GetSection("EvaApi").GetValue<TimeSpan>("Timeout"),
                EvaTraceRawResponses = Configuration.GetSection("EvaApi").GetValue<bool>("TraceRawResponses"),
                EvaBrokerRateStrategies = Configuration.GetSection("EvaApi").GetValue<int[]>("EvaBrokerRateStrategies", 
                    new[] { 23, 24, 25, 27, 40, 43, 46, 48, 50, 51, 52, 53, 54, 56, 64, 68, 69, 70, 75, 76, 88, 89, 90, 91, 92, 103 }),
            });

            services.AddGlobalDbProvider(LinqToDB.ProviderName.SqlServer);
            services.AddDbConfig<Api.Models.Database>(GetConnectionString(Api.Models.Database.ConfigurationName));
            services.AddDbConfig<Database>(GetConnectionString(Database.ConfigurationName));
            services.AddDbConfig<LCS.Models.Database>(GetConnectionString(LCS.Models.Database.ConfigurationName));
            services.AddDbConfig<CS.Kernel.Functionality.Database>(GetConnectionString(CS.Kernel.Functionality.Database.ConfigurationName));
            services.AddDbConfig<PS.Models.PortfolioDatabase>(GetConnectionString(PS.Models.PortfolioDatabase.ConfigurationName));
            services.AddDbConfig<MS.Models.Database>(GetConnectionString(MS.Models.Database.ConfigurationName));
            services.AddDbConfig<SandboxDatabase>(GetConnectionString(SandboxDatabase.ConfigurationName));
            services.AddDbConfig<HS.Models.Database>(GetConnectionString(HS.Models.Database.ConfigurationName));
            services.AddDbConfig<RiskAnalysisDatabase>(GetConnectionString(RiskAnalysisDatabase.ConfigurationName));
            services.AddDbConfig<ES.Models.Database>(GetConnectionString(ES.Models.Database.ConfigurationName));
            services.AddDbConfig<MS.Models.Database>(GetConnectionString(MS.Models.Database.ConfigurationName));

            services.AddMigrations<Api.Models.Database>();
            services.AddMigrations<Database>();
            services.AddMigrations<LCS.Models.Database>();
            services.AddMigrations<CS.Kernel.Functionality.Database>();
            services.AddMigrations<PS.Models.PortfolioDatabase>();
            services.AddMigrations<MS.Models.Database>();
            services.AddMigrations<SandboxDatabase>();
            services.AddMigrations<HS.Models.Database>();
            services.AddMigrations<RiskAnalysisDatabase>();
            services.AddMigrations<ES.Models.Database>();
            services.AddMigrations<MS.Models.Database>();

            var dataAccessLayer = new DataAccessLayer();
            services.AddSingleton<IDataAccessLayer>(dataAccessLayer);

            services.AddSingleton<ICS>(sp => new CSApi(
                Configuration.GetSection("ClientService").GetValue<string>("Url"),
                Configuration.GetSection("ClientService").GetValue<int>("Port")));

            services.AddSingleton<IOAuthManager>(sp =>
            {
                var authFactory = new OAuthFactory(
                    new NLogWrapper(sp.GetRequiredService<ILogger<OAuthFactory>>()),
                    evaAuthConfig);

                var auth = authFactory.Create(false);
                auth.Start();

                return auth;
            });

            services.AddSingleton<ISecurityCache>(sp =>
            {
                var secCache = new SecurityCache
                (Configuration.GetSection("HistoryService").GetValue<string>("Url"),
                    Configuration.GetSection("HistoryService").GetValue<int>("Port"),
                    new RMDSConfig(Configuration),
                    dataAccessLayer,
                    sp.GetRequiredService<ILogger<SecurityCache>>(),
                    TimeSpan.FromSeconds(Configuration.GetSection("HistoryService").GetValue<int>("ShortRefreshRate")),
                    TimeSpan.FromSeconds(Configuration.GetSection("HistoryService").GetValue<int>("FullRefreshRate")),
                    new CancellationTokenSource().Token,
                    Configuration.GetSection("Mocks").GetValue<bool>("SecurityCache")
                );

                new PeriodicTask().Run(() =>
                    {
                        var stratStates = WebCabinetController.GetAllOpenPositions();
                        secCache.ActualizeSecurities(stratStates.Values.SelectMany(s => s.ActivePositions).Select(p => p.Key.GetKey()).Distinct().ToArray());
                    }
                    , TimeSpan.FromHours(1));

                return secCache;
            });

            services.AddSingleton<IStrategySandbox>(sp => new StrategySandbox(sp.GetRequiredService<ISecurityCache>(),
                sp.GetRequiredService<ILogger<StrategySandbox>>(), dataAccessLayer, Configuration.GetSection("HistoryService").GetValue<string>("Url"),
                Configuration.GetSection("HistoryService").GetValue<int>("Port"),
                Configuration.GetSection("Sandbox").GetValue("ShortsComission", 0.14m),
                Configuration.GetSection("Sandbox").GetValue("LongsComission", 0.1675m),
                Configuration.GetSection("Sandbox").GetValue("USAComission", 0.07m),
                Configuration.GetSection("Mocks").GetValue<bool>("Sandbox")
            ));

            var cacheService = new CacheService(TimeSpan.FromSeconds(Configuration.GetSection("Features").GetValue("MyBrokerStrategiesCache", 60)));
            services.AddHostedService(sp => cacheService);
            services.AddSingleton<ICacheService>(sp => cacheService);

            FilesController.MaxFileSize = Configuration.GetSection("FileUpload").GetValue<long>("MaxFileSize", 10000000);
            //FilesController.AllowedExtentions = Configuration.GetSection("FileUpload").GetSection("Allowed")?.GetChildren()?.Select(c=>c.Value)?.ToArray()??new[] { ".jpg" };

            services.AddSingleton(new SignalsTimer(Configuration.GetSection("Signals").GetValue("DelayBetweenSignals", TimeSpan.FromMinutes(2))));

            services.AddSingleton(sp => new SMS.ApiClient.Api(
                Configuration.GetSection("SmsService").GetValue<string>("Url"),
                Configuration.GetSection("SmsService").GetValue<int>("Port")));

            services.AddSingleton<ILCS>(sp => new LCSApi(Configuration.GetSection("LifecycleService").GetValue<string>("Url"),
                Configuration.GetSection("LifecycleService").GetValue<int>("Port")));

            services.AddSingleton<ISTS>(sp => new STSApi(Configuration.GetSection("StatService").GetValue<string>("Url"),
                Configuration.GetSection("StatService").GetValue<int>("Port")));

            services.AddSingleton<IQRCApi>(sp => new Utilities.QRCApi(Configuration.GetSection("QRC").GetValue<string>("Host"),
                Configuration.GetSection("QRC").GetValue<int>("Port")));

            services.AddSingleton(new PortfolioBalancer());
            services.AddSingleton(sp => evaAuthConfig != null
                ? new ApiHelpers.StrategyCatalogHelper(
                    sp.GetRequiredService<AppConfig>().EvaApiUrl,
                    sp.GetRequiredService<IOAuthManager>(),
                    sp.GetRequiredService<AppConfig>().EvaTimeout,
                    new NLibLoggerWrapper(sp.GetRequiredService<ILogger<ApiHelpers.StrategyCatalogHelper>>()),
                    sp.GetRequiredService<AppConfig>().EvaTraceRawResponses)
                : (ApiHelpers.IStrategyCatalogApi)new StrategyCatalogHelperStub());

            // Authorization
            services
                .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
                {
                    options.SlidingExpiration = true;
                    options.ExpireTimeSpan = TimeSpan.FromSeconds(Configuration.GetSection("Authorization").GetValue<int>("SessionTimeout"));
                    options.Events.OnRedirectToLogin = context =>
                    {
                        context.Response.StatusCode = 401;
                        return Task.CompletedTask;
                    };
                });

            services.AddSingleton(sp => new LogHeadersActionFilter(sp.GetRequiredService<ILogger>()));

            services.AddSingleton(provider =>
            {
                var loggerFactory = provider.GetRequiredService<ILoggerFactory>();
                var logger = loggerFactory.CreateLogger<ServiceBase.ClientIpCheckActionFilter>();

                return new ClientIpCheckActionFilter(
                    Configuration.GetSection("IpFilter:AllowedSubnets").Get<string[]>(), logger);
            });

            services.AddSingleton((new MapperConfiguration(
                cfg =>
                {
                    cfg.CreateMap<IIR, Models.IIR>();
                    cfg.CreateMap<IIRInstrument, Models.IIRInstrument>();
                    cfg.CreateMap<IIRInstrument, Models.Order>();
                    cfg.CreateMap<IIR, Models.Order>();
                    cfg.CreateMap<Order, Models.Order>()
                        .ForMember(o=>o.OrderPrice, cfg => cfg.MapFrom(order => order.Price ));
                    
                })).CreateMapper());
            services.AddHealthChecks();
            services.AddHostedService<StrategyRegisterService>();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            var config = app.ApplicationServices.GetService<AppConfig>();
            var authorFolder = Path.GetFullPath(Path.Combine(config?.FintargetWebRootPath ?? string.Empty,
                config?.UploadedAuthorsFilesLocation ?? String.Empty));
            try
            {
                Directory.CreateDirectory(authorFolder);
            }
            catch
            {
            }

            var opts = new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(authorFolder),
                RequestPath = "/" + (config?.UploadedAuthorsFilesLocation ?? ".")
            };
            app.UseStaticFiles(opts);
            app.UseSpaStaticFiles();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            var httpClient = new HttpClient();

            var oldamd = "/oldadm";


            app.MapWhen(hc => hc.Request.Cookies.ContainsKey("oldadm") && hc.Request.Cookies["oldadm"] == "1" ||
                              hc.Request.Path.StartsWithSegments(oldamd)
                , c => c.RunProxy(async context =>
                    {
                        if (context.Request.Path.StartsWithSegments(oldamd))
                        {
                            context.Request.Path = context.Request.Path.Value.Remove(0, oldamd.Length);
                        }
                        else if (context.Request.Path == "/" || context.Request.Path == "")
                        {
                            var newres = new HttpResponseMessage(HttpStatusCode.Found);
                            newres.Headers.Location = new Uri("/", UriKind.Relative);
                            newres.Headers.Add("set-cookie", "oldadm=0; Path=/");
                            return newres;
                        }

                        var res = await
                            context
                                .ForwardTo(Configuration.GetSection("Admin").GetValue<string>("Old"))
                                .AddXForwardedHeaders()
                                .Send();

                        if (res.StatusCode == HttpStatusCode.Redirect)
                        {
                            if (res.Headers.Location.IsAbsoluteUri)
                                res.Headers.Location = new Uri(res.Headers.Location.GetLeftPart(UriPartial.Scheme) + context.Request.Host + oldamd +
                                                               res.Headers.Location.PathAndQuery);
                            else
                                res.Headers.Location = new Uri(context.Request.Scheme + "://" + context.Request.Host + oldamd + res.Headers.Location);
                        }

                        res.Headers.Add("Host", "oldadm." + context.Request.Host);
                        res.Headers.Add("set-cookie", "oldadm=1; Path=/");

                        return res;
                    }
                ));

            app.UseSession();

            app.UseLoggingEndpoint();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/health");
                endpoints.MapControllerRoute(
                    "default",
                    "{controller}/{action=Index}/{id?}");
            });

            app.UseGuardedSpa(spa =>
            {
                spa.Options.SourcePath = "ClientApp";

                if (env.IsDevelopment()) spa.UseReactDevelopmentServer("start");
            });
        }

        private class RMDSConfig : IApiConfig
        {
            private readonly IConfiguration config;

            public RMDSConfig(IConfiguration config)
            {
                this.config = config;
            }

            public string GrpcHost => config.GetSection("RMDS").GetValue<string>("GrpcHost");

            public int GrpcPort => config.GetSection("RMDS").GetValue<int>("GrpcPort");

            public bool GrpcUseSSL => config.GetSection("RMDS").GetValue("GrpcUseSSL", false);

            public TimeSpan GrpcReconnectTimeout => config.GetSection("RMDS").GetValue<TimeSpan>("GrpcReconnectTimeout");

            public object Get(string name)
            {
                return GetType().GetProperty(name).GetValue(this);
            }
        }
    }

    public class ClientIpCheckActionFilter : ActionFilterAttribute
    {
        private readonly ILogger logger;
        private readonly (uint, uint)[] safeList;

        public ClientIpCheckActionFilter(string[] safeSubnetList, ILogger logger)
        {
            this.logger = logger;

            var masks = new List<(uint, uint)>();

            if (safeSubnetList == null)
            {
                safeList = new[] { (0u, 0u) };
                return;
            }
            foreach (var subnetMask in safeSubnetList)
            {
                var slashIdx = subnetMask.IndexOf('/');
                if (slashIdx == -1)
                    throw new Exception($"Invalid subnet mask found {subnetMask}");
                var maskAddress = IPAddress.Parse(subnetMask.Substring(0, slashIdx));

                var maskLength = int.Parse(subnetMask.Substring(slashIdx + 1));

                var maskAddressBits = BitConverter.ToUInt32(maskAddress.GetAddressBytes().Reverse().ToArray(), 0);

                var mask = maskLength == 0 ? 0 : uint.MaxValue << (32 - maskLength);

                masks.Add((maskAddressBits & mask, mask));
            }

            safeList = masks.ToArray();
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var remoteIp = context.HttpContext.Connection.RemoteIpAddress;

            var inSubnet = false;

            if (remoteIp.IsIPv4MappedToIPv6)
                remoteIp = remoteIp.MapToIPv4();

            var ipAddressBits = BitConverter.ToUInt32(remoteIp.GetAddressBytes().Reverse().ToArray(), 0);

            foreach (var subnet in safeList)
                if (subnet.Item1 == (ipAddressBits & subnet.Item2))
                {
                    inSubnet = true;
                    break;
                }

            logger.LogInformation($"Filtering IP {remoteIp} : {(inSubnet ? "passed" : "blocked")}");

            if (!inSubnet)
            {
                context.Result = new StatusCodeResult(StatusCodes.Status403Forbidden);
                return;
            }

            base.OnActionExecuting(context);
        }
    }
}