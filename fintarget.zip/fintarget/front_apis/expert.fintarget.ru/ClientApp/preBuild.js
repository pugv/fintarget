const fs = require('fs');

fs.writeFile('./Properties/BuildDate.txt', new Date().toISOString(), (err) => {
  if (err) {
    return console.log(err);
  }
  console.log('The file was saved!');
});
