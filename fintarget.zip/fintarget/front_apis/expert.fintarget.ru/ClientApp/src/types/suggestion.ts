export type Suggestion = {
  key: string;
  symbol: string;
  classCode: string;
  name: string;
  isin: string;
  board: string;
};

export interface SuggestionDetails extends Suggestion {
  type: string;
  lotSize: number;
  price?: number;
  quotation?: number;
  shortAllowed: boolean;
  currency: string;
  minWeight?: number;
  maxWeight?: number;
  currentWeight: number;
  maxSignalWeight?: number;
  maxSLBuy?: number;
  minTPBuy?: number;
  minSLSell?: number;
  maxTPSell?: number;
  priceDigits: number;
  execCoef: number;
}
