export type StrategyIndex = {
  id: number;
  order?: number;
  symbol: string;
  name: string;
  value: number;
  prevValue: number;
  date: Date;
};
