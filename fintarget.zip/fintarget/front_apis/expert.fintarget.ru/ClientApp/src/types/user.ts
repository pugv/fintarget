import { UserRoles } from './userRoles';

export type User = {
  id: number;
  isActive: boolean;
  login: string;
  passwordHash: string;
  salt: string;
  name: string;
  role: UserRoles;
  createDate: string;
  isDeleted: boolean;
  draftPassword: number;
  unsuccessfullLogins: number;
  lastLogin?: string;
  phone: string;
};
