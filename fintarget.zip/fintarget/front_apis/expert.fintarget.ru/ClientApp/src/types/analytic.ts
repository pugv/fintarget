import { Nullable } from '../utils/types';
import { AnalyticsStrategy } from './analyticStrategy';
import { Author } from './author';
import { Option } from './option';

export type Analytic = {
  id: number;
  friendlyUrl?: string;
  strategies?: AnalyticsStrategy[];
  categories: Option[];
  title: string;
  seoTitle: string;
  seoDescription: string;
  cutHtml: string;
  fullHtml: string;
  date: string;
  strategiesTitle?: Nullable<string>;
  picture?: Nullable<string>;
  smallPicture?: Nullable<string>;
  active: boolean;
  subscription: boolean;
  author?: Partial<Author>;
};
