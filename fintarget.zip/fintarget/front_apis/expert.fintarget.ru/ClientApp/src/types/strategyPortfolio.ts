type PortfolioPosition = {
  symbol: string | null;
  name: string;
  weight: number;
};

export type StrategyPortfolio = {
  currency: string;
  currentBalance: number;
  currentFree: number;
  relizedPL: number;
  unrealizedPL: number;
  portfolioWeight: number;
  deviation: string;
  maxDeviation: string;
  npr1: number;
  positions: PortfolioPosition[];
};
