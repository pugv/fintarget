﻿export type ProblemClient = {
  id?: number;
  description: string;
};
