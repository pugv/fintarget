export type Profile = {
  id: number;
  profileId: string;
  name: string;
  description: string;
  drawdown: number;
};
