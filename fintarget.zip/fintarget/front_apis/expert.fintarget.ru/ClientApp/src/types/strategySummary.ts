import { Nullable } from '../utils/types';

type AvailableTariff = {
  clientTariff?: Nullable<string>;
  afTariff: number;
  acTariff: number;
};

export type StrategySummary = {
  id: string;
  name: string;
  subscriptionThreshold: number;
  currency: string;
  autoconsult: boolean;
  autofollow: boolean;
  category: Nullable<string>;
  duration: string;
  minInvestProfile: string;
  estimatedProfit: number;
  estimatedDrawdown: number;
  forQualifiedInvestorsOnly: boolean;
  hidePortfolio: boolean;
  hideRecentSignals: boolean;
  iis: boolean;
  index: string;
  priceAF: Nullable<string>;
  priceAC: Nullable<string>;
  showFullPortfolio: boolean;
  testMode: boolean;
  isRestricted: boolean;
  availableTariffs: AvailableTariff[];
};
