export type Position = {
  securityKey: string;
  symbol: string;
  name: string;
  comment: string;
  weight: number;
  openPrice: number;
  openTime: string;
  classCode: string;
  currentWeight: number;
  currentPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  realizedPL?: number;
  unrealizedPL?: number;
};
