export type ExecutionPosition = {
  ClientId: string;
  TradeAcc: string;
  Security: string;
  ClassCode: string;
  Symbol: string;
  Number: number;
  Price: number;
  PriceStep: number;
  ExecNumber: number;
  ExecPrice: number;
  ExecEndTime: Date;
  ExecValue: number;
};
