export type Error = {
  source: string;
  error: string;
  occurrences: number[];
};

export type StrategyError = Error & {
  strategy: string;
  strategyId: string;
};
