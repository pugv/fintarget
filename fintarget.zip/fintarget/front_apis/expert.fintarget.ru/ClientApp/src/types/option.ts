export type Option = {
  id: string;
  name: string;
};
