export type AggregateInvestbox = {
  id: string;
  title: string;
  parentId?: string;
  managerId: number;
  managerName: string;
  creatorId: number;
  creationDate: string;
  currency: string;
  leverage: number;
  subscriptionThreshold: number;
  securities: string;
  tests: string[];
  active: boolean;

  tag: string;
  tariffId: string;
  tariffName: string;
  isOpen: boolean;
};
