export type PortfolioPosition = {
  securityKey: string;
  weight: number;
  orderNum: number;
  targetPrice?: number;
};

export type Portfolio = {
  id: string;
  name: string;
  annotation: string;
  description: string;
  active: boolean;
  currency: string;
  positions: PortfolioPosition[];
  orderNum: number;
  imageUrl: string;
  minBalance: number;
  forecast: number;
  forecastSourceId: number;
  errorMessage: string;
};
