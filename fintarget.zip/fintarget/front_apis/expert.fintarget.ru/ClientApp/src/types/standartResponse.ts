export type StandartResponse<T> = {
  success: boolean;
  errorMessage: string;
  errorCode: number;
  result: T;
};

export type ResultPage<T> = {
  total: number;
  pageItems: T[];
};
