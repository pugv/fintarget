import { Nullable } from '../utils/types';

export type LimitPosition = {
  clientCode: string;
  security: string;
  number: number;
  price: number;
  currency: string;
  depo: string;
  kind: string;
  tag: string;
  varMargin: Nullable<string>;
  totalVarMargin: Nullable<number>;
  positionValue: Nullable<number>;
  symbol: string; // remove
  key: string; // remove
};
