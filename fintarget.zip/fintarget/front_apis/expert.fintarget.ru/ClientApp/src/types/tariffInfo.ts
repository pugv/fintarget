import { Nullable } from '../utils/types';

export type TariffInfo = {
  id: number;
  guid: string;
  evaId: number;
  description: string;
  category: Nullable<string>;
  kind: Nullable<number>;
};
