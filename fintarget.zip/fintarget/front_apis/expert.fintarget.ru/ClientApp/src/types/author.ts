export type Author = {
  id: number;
  friendlyUrl?: string;
  firstName: string;
  lastName: string;
  middleName?: string;
  company?: string;
  displayName?: string;
  position?: string;
  photoBase64?: string;
  photoFormat: string;
  infoHtml: string;
  shortInfoHtml: string;
  rating: number;
};
