export type ServicesConfig = {
  isEsAvailable: boolean;
  isEsDb: boolean;
};
