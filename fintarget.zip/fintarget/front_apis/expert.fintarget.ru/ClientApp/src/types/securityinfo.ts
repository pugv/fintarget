export type SecurityInfo = {
  securityInfo: {
    ticker: string;
    classCode: string;
    className: string;
    name: string;
    shortName: string;
    isin: string;
    currency: string;
    type: string;
    shortsAllowed: boolean;
    lotSize: number;
    priceStep: number;
    isCurrent: boolean;
    lastPrice: number;
    lastTime: number;
  };
};

export type SecurityBidAsk = {
  securityBidAsk: {
    bid: number;
    ask: number;
    lastPrice: number;
    futuresPrice: number;
    isOk: boolean;
    errorMessage: string;
    timeStamp: number;
  };
};

export type SecurityMarketData = {
  securityMarketData: {
    html: string;
  };
};

export type SecurityCS = {
  securityCS: {
    html: string;
  };
};
