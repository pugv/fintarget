export type ExecutionPortfolioPosition = {
  SecurityKey: string;
  Number: number;
  AvgPrice: number;
  Currency: string;
};
