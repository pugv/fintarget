export type AnalyticsStrategy = {
  analyticsId?: number;
  strategyId: string;
  showInStrategy: boolean;
};
