export enum ClientSignalType {
  strategy = 0,
  generated = 1,
  varMargin = 2,
}

export enum SignalProcessedType {
  Unprocessed = 0,
  Processed = 1,
  Processing = 2,
  TradeError = 3,
}

export type ClientSignal = {
  //client: ClientAccountInfo;
  type: ClientSignalType;
  stratId: string;
  processedType: SignalProcessedType;
  diffFromStrategy: number;
  realizedPnL: number;
  archived: boolean;
  clientId: number;
  dateTime: Date;
  signalId: number;
  portfolio: string;
  execution: string;
};
