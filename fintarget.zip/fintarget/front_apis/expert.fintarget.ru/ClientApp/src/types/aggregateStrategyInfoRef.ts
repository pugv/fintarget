import { Nullable } from '../utils/types';
import { Profile } from './profile';
import { StrategyIndex } from './strategyIndex';

export type Currency = {
  code: string;
  name: string;
  symbol: Nullable<string>;
};

export type MarketTool = {
  id: number;
  name: string;
};

export type StrategyDuration = {
  id: number;
  name: string;
  period: number;
};

export type TradeMarket = {
  id: number;
  name: string;
};

export type Board = {
  id: number;
  code: string;
};

export type TradeType = {
  id: number;
  description: string;
  enabled: boolean;
};

export type StrategyTestInfo = {
  id: string;
  name: string;
};

export type StrategyInfoHelper = {
  durations: StrategyDuration[];
  indexes: StrategyIndex[];
  markets: TradeMarket[];
  marketTools: MarketTool[];
  profiles: Profile[];
  boards: Board[];
  tests: StrategyTestInfo[];
  tradeTypes: TradeType[];
};
