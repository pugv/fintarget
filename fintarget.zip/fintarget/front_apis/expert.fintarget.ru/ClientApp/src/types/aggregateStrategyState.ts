export type AggregateStrategyState = {
  id: string;
  active: boolean;
  open: boolean;
};
