export type PortfolioStatistic = {
  uniqueListViews: number;
  totalUniqueViewers: number;
  totalPurchaseAttempts: number;
  totalPurchases: number;
  totalPurchaseSumInRubles: number;
  entries: PortfolioStatisticsEntry[];
};

export type PortfolioStatisticsEntry = {
  id: string;
  name: string;
  uniqueViewers: number;
  purchaseAttempts: number;
  purchases: number;
  purchaseSum: number;
  purchaseSumInRubles: number;
  currency: string;
};
