import { Nullable } from '../utils/types';

export type ChartPointEx = {
  t: number;
  v: number;
  vr: Nullable<number>;
};

export type ChartPoint = {
  id: number;
  t: number; // strategyDate
  security: string;
  weight: Nullable<number>;
  price: Nullable<number>;
  execPrice: Nullable<number>;
  priceDiff: string;
  timeDiff: string;
  stratPL: number;
  pL: Nullable<number>;
  v: number;
  vr: Nullable<number>;
};

export type Chart = {
  history: ChartPoint[];
  indexName: string;
};
