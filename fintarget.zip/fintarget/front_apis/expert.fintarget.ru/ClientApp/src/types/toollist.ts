export type ToolListType = {
  id: string;
  text: string;
};

export type ToolFormType = {
  lists: ToolListType[];
  handleToolCreate: (list: ToolListType) => void;
};

export type ToolListsType = {
  handleToolUpdate: (event: React.ChangeEvent<HTMLInputElement>, id: string) => void;
  handleToolRemove: (id: string) => void;
  lists: ToolListType[];
};

export type ToolItemType = {
  handleToolUpdate: (event: React.ChangeEvent<HTMLInputElement>, id: string) => void;
  handleToolRemove: (id: string) => void;
  list: ToolListType[];
};
