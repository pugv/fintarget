import { Nullable } from '../utils/types';

export type Config = {
  version: string;
  buildDate: string;
  rcKey: string;
  friendlyUrl: Nullable<string>;
};
