import { Nullable } from '../utils/types';

export type ClientPersInfo = {
  riskProfileName: string;
  riskProfileId: string;
  riskProfileDate: Nullable<Date>;
  investmentAdviceAgreementDate: Nullable<Date>;
  serviceDate: Nullable<Date>;
  isQualified: boolean;
  closeDate: Nullable<Date>;
  isOrganization: boolean;
  representativePosition: string;
  ogrn: string;
  name: string;
  firstName: string;
  lastName: string;
  middleName: string;
  orgName: string;
  email: string;
  address: string;
  strategyName: string;
  agreement: string;
  docFlowAgreementId: string;
  phone: string;
};

export type ClientAccountInfo = {
  clientCode: string;
  futuresCode: Nullable<string>;
  client: ClientPersInfo;
  strategyTariffId: Nullable<string>;
  strategyTariff: Nullable<string>;
};
