import { Nullable } from '../utils/types';

export type ExternalClient = {
  clientId: string;
  agreementId: string;
  contract: string;
  firstName: string;
  lastName: string;
  midName: string;
  tradeCode: string;
  futCode: Nullable<string>;
  isQual: Nullable<boolean>;
  riskName: Nullable<string>;
  strategyName: Nullable<string>;
  strategyStatus: Nullable<string>;
  strategyType: Nullable<string>;
  tariffId: Nullable<string>;
};
