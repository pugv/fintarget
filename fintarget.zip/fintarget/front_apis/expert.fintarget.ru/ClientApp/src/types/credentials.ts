export type Credentials = {
  userId: string;
  password: string;
};
