export enum RequestModerateAction {
  Yes = 'yes',
  No = 'no',
}

export type RequestModerate = {
  strategyId: string;
  action: RequestModerateAction;
};
