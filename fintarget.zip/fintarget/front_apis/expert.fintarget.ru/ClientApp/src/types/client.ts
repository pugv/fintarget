export type Client = {
  id: string;
  name: string;
  agreement: string;
  deviation: number;
  minDiff: number;
  clientCode: string;
  portfolio: number;
  positions: number;
  free: number;
  strategy: string;
  service: string;
  bindDate: string;
  historyUrl: string;
};
