import React from 'react';

export const Assembly: React.FC<{ description: string }> = ({ description }) => (
  <span className="assembly">{description}</span>
);
