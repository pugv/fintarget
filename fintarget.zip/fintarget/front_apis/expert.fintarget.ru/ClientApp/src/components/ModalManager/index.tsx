import React from 'react';

import { useStore } from 'effector-react';
import { SnackbarProvider } from 'notistack';

import { modalApi, Modals$ } from '../../effector/modals';
import { MODALS } from '../../utils/types';
import { AccCalcRebalance } from '../Forms/AccCalcRebalance';
import { AccountRebalance, AccountBlock, ServiceStopCS } from '../Forms/AccountManagementAction';
import { ActivateStrategy } from '../Forms/ActivateStrategy';
import { AddInvestboxForm } from '../Forms/AddInvestbox';
import { AddSignalForm } from '../Forms/AddSignal';
import { AddStrategyForm } from '../Forms/AddStrategy';
import { AddUser } from '../Forms/AddUser';
import { AnalyticForm } from '../Forms/Analytic';
import { BannerForm } from '../Forms/Banner';
import { ChangePasswordForm } from '../Forms/ChangePassword';
import { ChangePosition } from '../Forms/ChangePosition';
import { PortfolioForm } from '../Forms/Portfolio';
import { RemoveAnalytic } from '../Forms/RemoveAnalytic';
import { RemoveBanner } from '../Forms/RemoveBanner';
import { RemoveDelayedSignal } from '../Forms/RemoveDelayedSignal';
import { RemovePortfolio } from '../Forms/RemovePortfolio';
import { RemovePositionForm } from '../Forms/RemovePosition';
import { RemoveSchedule } from '../Forms/RemoveSchedule';
import { RemoveUserForm } from '../Forms/RemoveUserForm';
import { ScheduleAdd } from '../Forms/ScheduleAdd';
import { ScheduleAddWeekend } from '../Forms/ScheduleAddWeekend';
import { ScheduleEdit } from '../Forms/ScheduleEdit';
import { ScheduleRemoveWeekend } from '../Forms/ScheduleRemoveWeekend';
import { SignalApproved } from '../Forms/SignalApproved';
import { Split } from '../Forms/Split';
import { UpdateHistory } from '../Forms/UpdateHistory';
import { UploadTrack } from '../Forms/UploadTrack';
import { Modal } from '../Modal';

export const ModalManager: React.FC = ({}) => {
  const modalsState = useStore(Modals$);

  return (
    <>
      <Modal
        isOpen={modalsState[MODALS.REMOVE_POSITION]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Закрытие позиции"
      >
        <RemovePositionForm />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.CHANGE_PASSWORD]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Смена пароля"
      >
        <ChangePasswordForm />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.NEW_SIGNAL]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Новый сигнал"
      >
        <AddSignalForm />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.REMOVE_DELAYED_SIGNAL]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Закрытие отложенного сигнала"
      >
        <RemoveDelayedSignal />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.ANALYTIC]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Аналитика"
      >
        <AnalyticForm />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.PORTFOLIO]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Портфель"
      >
        <PortfolioForm />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.REMOVE_ANALYTIC]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Сменить статус"
      >
        <RemoveAnalytic />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.REMOVE_BANNER]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Сменить статус"
      >
        <RemoveBanner />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.REMOVE_PORTFOLIO]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Сменить статус"
      >
        <RemovePortfolio />
      </Modal>
      <Modal
        isOpen={modalsState[MODALS.CHANGE_POSITION]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Замена позиции"
      >
        <ChangePosition />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.SPLIT]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Сплит"
      >
        <Split />
      </Modal>

      <SnackbarProvider maxSnack={3}>
        <Modal
          isOpen={modalsState[MODALS.ADD_USER]}
          onRequestClose={() => {
            modalApi.hide('');
          }}
          title="Пользователь"
        >
          <AddUser />
        </Modal>
      </SnackbarProvider>

      <SnackbarProvider maxSnack={3}>
        <Modal
          isOpen={modalsState[MODALS.REMOVE_USER]}
          onRequestClose={() => {
            modalApi.hide('');
          }}
          title="Удаление пользователя"
        >
          <RemoveUserForm />
        </Modal>
      </SnackbarProvider>

      <Modal
        isOpen={modalsState[MODALS.BANNER]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Баннер"
      >
        <BannerForm />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.SIGNAL_APPROVED]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Подача сигнала"
      >
        <SignalApproved />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.UPLOAD_TRACK]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Загрузка трека"
      >
        <UploadTrack />
      </Modal>

      <SnackbarProvider maxSnack={3}>
        <Modal
          isOpen={modalsState[MODALS.ADD_STRATEGY]}
          onRequestClose={() => {
            modalApi.hide('');
          }}
          title="Стратегия"
        >
          <AddStrategyForm />
        </Modal>
      </SnackbarProvider>

      <Modal
        isOpen={modalsState[MODALS.OPEN_STRATEGY]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Параметры стратегии"
      >
        <ActivateStrategy />
      </Modal>

      <SnackbarProvider maxSnack={3}>
        <Modal
          isOpen={modalsState[MODALS.ADD_INVESTBOX]}
          onRequestClose={() => {
            modalApi.hide('');
          }}
          title="Инвест-копилка"
        >
          <AddInvestboxForm />
        </Modal>
      </SnackbarProvider>

      <Modal
        isOpen={modalsState[MODALS.UPDATE_HISTORY]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Стратегии"
      >
        <UpdateHistory />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.ACCOUNT_REBALANCE]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Управление аккаунтом"
      >
        <AccountRebalance />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.ACCOUNT_BLOCK]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Управление аккаунтом"
      >
        <AccountBlock />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.ACCOUNT_CALC_REBALANCE]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Балансировка клиента"
      >
        <AccCalcRebalance />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.SERVICE_STOP_CS]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Управление сервисом клиентов"
      >
        <ServiceStopCS />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.SCHEDULE_EDIT]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Редактирование расписания"
      >
        <ScheduleEdit />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.SCHEDULE_ADD]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Добавление расписания"
      >
        <ScheduleAdd />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.SCHEDULE_ADD_WEEKEND]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Добавление неторгового дня"
      >
        <ScheduleAddWeekend />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.SCHEDULE_REMOVE]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Удаление расписания"
      >
        <RemoveSchedule />
      </Modal>

      <Modal
        isOpen={modalsState[MODALS.SCHEDULE_REMOVE_WEEKEND]}
        onRequestClose={() => {
          modalApi.hide('');
        }}
        title="Удаление неторгового дня"
      >
        <ScheduleRemoveWeekend />
      </Modal>
    </>
  );
};
