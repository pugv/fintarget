/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from 'react';

import { Editor } from '@tinymce/tinymce-react';
import { FieldInputProps, useField } from 'formik';

type Props = {
  field: FieldInputProps<any>;
  placeholder: string;
  disabled?: boolean;
};

const api_key = 'gjxt7sntbzi809s5wsn4bb4umrzujlcmmetnotg21n4lno60';

export const TextEditor: React.FC<Props> = ({ field: fieldProp, placeholder }) => {
  const [, meta, helpers] = useField(fieldProp.name);
  const [content, setState] = useState(fieldProp.value);

  const isError = meta.touched && meta.error;

  const handleEditorChange = (content: React.SetStateAction<string>) => {
    setState(content);
    helpers.setValue(content);
  };

  const styles = {
    fontSize: '14px',
    fontWeight: 600,
    color: '#9598a7',
    marginBottom: '5px',
  };

  return (
    <div className="text-editor">
      <div style={styles} className="text-editor__placeholder">
        {placeholder}
      </div>
      <Editor
        value={content}
        onEditorChange={handleEditorChange}
        apiKey={api_key}
        init={{
          height: 200,
          menubar: false,
          language: 'ru',
          plugins: [
            'advlist',
            'autolink',
            'lists',
            'link',
            'image',
            'charmap',
            'print',
            'preview',
            'anchor',
            'searchreplace',
            'visualblocks',
            'code',
            'insertdatetime',
            'media',
            'table',
            'paste',
            'code',
            'wordcount',
          ],
          font_family_formats:
            'Andale Mono=andale mono,times; Arial=arial,helvetica,sans-serif; Arial Black=arial black,avant garde; Book Antiqua=book antiqua,palatino; Comic Sans MS=comic sans ms,sans-serif; Courier New=courier new,courier; Georgia=georgia,palatino; Helvetica=helvetica; Impact=impact,chicago; Symbol=symbol; Tahoma=tahoma,arial,helvetica,sans-serif; Terminal=terminal,monaco; Times New Roman=times new roman,times; Trebuchet MS=trebuchet ms,geneva; Verdana=verdana,geneva; Webdings=webdings; Wingdings=wingdings,zapf dingbats; Gilroy=Gilroy',
          toolbar:
            'undo redo | bold italic underline | fontfamily fontsize formatselect |  ' +
            'alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist checklist | ' +
            'forecolor backcolor | preview | insertfile image ',
        }}
      />
      {isError && <span className="form-control__message">{meta.error}</span>}
    </div>
  );
};
