import React from 'react';

import { ReactComponent as LogoIcon } from './logo.svg';

export const Logo: React.FC = () => (
  <div className="logo">
    <LogoIcon />
  </div>
);
