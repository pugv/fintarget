import React, { useCallback } from 'react';

import cn from 'classnames';
import update from 'immutability-helper';

import { PositionWithForecast } from './';
import { Position } from './Position';
import { PortfolioPosition } from '../../../types/portfolio';

type Props = {
  items: PositionWithForecast[];
  disabled: boolean;
  onMove: (name: string, value: PortfolioPosition[]) => void;
};

export const PositionList: React.FC<Props> = ({ items, disabled, onMove }) => {
  const moveCard = useCallback(
    (dragIndex: number, hoverIndex: number) => {
      const dragCard = items[dragIndex];

      onMove(
        'positions',
        update(items, {
          $splice: [
            [dragIndex, 1],
            [hoverIndex, 0, dragCard],
          ],
        }),
      );
    },
    [items],
  );

  const removeCard = useCallback(
    (securityKey: string) => {
      const positions = items.filter((item) => item.securityKey !== securityKey);

      onMove('positions', positions);
    },
    [items],
  );

  return (
    <div
      className={cn('portfolio-positions', {
        'portfolio-positions-disabled': disabled,
      })}
    >
      {items.map((card, i) => (
        <Position
          key={card.securityKey}
          index={i}
          id={card.securityKey}
          text={card.securityKey}
          currentPrice={card.currentPrice}
          targetPrice={card.targetPrice}
          forecast={card.forecast}
          moveCard={moveCard}
          removeCard={removeCard}
        />
      ))}
    </div>
  );
};
