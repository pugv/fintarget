/* eslint-disable @typescript-eslint/ban-ts-comment */
import React, { useEffect, useState } from 'react';

import { faTimes } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useStore } from 'effector-react';
import { Field, Form, Formik, FormikProps } from 'formik';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import * as Yup from 'yup';

import { PositionList } from './PositionList';
import { getPositionsForecast } from '../../../api';
import { ERRORS_TEXTS } from '../../../const/validation';
import { ForecastDictionary$ } from '../../../effector/forecastDictionary';
import { modalApi, Modals$, TModal$State } from '../../../effector/modals';
import { portfoliosApi } from '../../../effector/portfolios';
import { searchApi } from '../../../effector/search';
import { Option } from '../../../types/option';
import { Portfolio, PortfolioPosition } from '../../../types/portfolio';
import { roundNumber } from '../../../utils';
import { Nullable } from '../../../utils/types';
import { File } from '../../FormControls/File';
import { Input } from '../../FormControls/Input';
import { Select } from '../../FormControls/Select';
import { TextArea } from '../../FormControls/TextArea';
import { Search } from '../../Search';
import { Button, ButtonType } from '../../UIKit/Button';

const validationSchema = Yup.object().shape({
  name: Yup.string().required(ERRORS_TEXTS.required),
  anons: Yup.string().required(ERRORS_TEXTS.required),
  description: Yup.string().required(ERRORS_TEXTS.required),
  image: Yup.string(),
  currency: Yup.object().required(ERRORS_TEXTS.required),
  order: Yup.number().required(ERRORS_TEXTS.required).integer(ERRORS_TEXTS.number).typeError(ERRORS_TEXTS.number),
  forecasts: Yup.object().required(ERRORS_TEXTS.required),
  positions: Yup.array(
    Yup.object().shape({
      securityKey: Yup.string(),
      weight: Yup.number().min(0, ERRORS_TEXTS.positive).required(ERRORS_TEXTS.required).typeError(ERRORS_TEXTS.number),
      targetPrice: Yup.number().min(0, ERRORS_TEXTS.number).nullable().typeError(ERRORS_TEXTS.number),
      orderNum: Yup.number(),
    }),
  ).required(ERRORS_TEXTS.required),
});

export type PositionForecast = {
  securityKey: string;
  currentPrice: Nullable<number>;
  targetPrice: Nullable<number>;
  forecast: Nullable<number>;
};

export type PositionWithForecast = PortfolioPosition & PositionForecast;

type FormFields = {
  name: string;
  anons: string;
  description: string;
  image: string;
  currency: Nullable<Option>;
  order: number;
  forecasts: Option;
  positions: PositionWithForecast[];
};

type FormProps = {
  error: string;
  isUpdate: boolean;
  loading: boolean;
  isEditable: boolean;
} & FormikProps<FormFields>;

const initialValues = {
  name: '',
  anons: '',
  description: '',
  image: '',
  currency: undefined,
  order: '',
  forecasts: '',
  positions: [],
};

const currencyOptions: Option[] = [
  {
    id: '1',
    name: 'SUR',
  },
  {
    id: '2',
    name: 'USD',
  },
];

const FormTemplate: React.FC<FormProps> = ({
  values,
  errors,
  dirty,
  error,
  isUpdate,
  loading,
  isEditable,
  setFieldValue,
}) => {
  const [innerPositions, setInnerPositions] = useState<PortfolioPosition[]>([]);
  const forecastState = useStore(ForecastDictionary$);

  const getPositionsForecasts = (forecastId: string) => {
    const params = {
      sourceId: forecastId,
      securityKeys: values.positions.map((item) => item.securityKey),
    };

    getPositionsForecast(params).then((response) => {
      const { result } = response;

      const positions = values.positions;
      const updatedPositions = positions.map((item) => {
        // @ts-ignore
        const forecast = result.find((forecast) => forecast.securityKey === item.securityKey);

        return forecast ? { ...item, ...forecast } : item;
      });

      setFieldValue('positions', []);
      setFieldValue('positions', updatedPositions);
    });
  };

  useEffect(() => {
    getPositionsForecasts(values.forecasts?.id);
  }, [values.forecasts, innerPositions]);

  const onSearchClick = (securityKey: string) => {
    if (!values.positions.find((item) => item.securityKey === securityKey)) {
      const position: PortfolioPosition = {
        securityKey: securityKey,
        weight: 0,
        orderNum: 0,
        targetPrice: 0,
      };

      const newPositions = [...values.positions, position];

      setInnerPositions(newPositions);
      setFieldValue('positions', newPositions);
      // @ts-ignore
      searchApi.clearSuggestion();
    }
  };

  const positionsForecasts = values.positions.map((item) => (item.forecast ? item.weight * item.forecast : 0));
  const portfolioForecast = positionsForecasts.reduce((value, curValue) => {
    return value + curValue;
  }, 0);

  const disable = Object.keys(errors).length > 0 || !dirty || loading;

  return (
    <Form className="form portfolio-form" noValidate>
      <div className="form__group">
        <Field type="text" name="name" placeholder="Название" disabled={!isEditable} component={Input} />
      </div>

      <div className="form__group">
        <Field
          name="currency"
          component={Select}
          disabled={!isEditable}
          placeholder="Валюта"
          options={currencyOptions}
        />
      </div>

      {forecastState && (
        <div className="form__group">
          <Field
            name="forecasts"
            disabled={!isEditable}
            component={Select}
            placeholder="Источник прогноза"
            options={forecastState}
          />
        </div>
      )}

      {values.forecasts && (
        <div className="form__group">
          <div className="form-control__inline">
            <div className="form-control__inline-name">Текст дисклаймера:</div>
            <div>
              {
                // @ts-ignore
                values.forecasts.disclaimer
              }
            </div>
          </div>
        </div>
      )}

      <div className="form__group">
        <div className="form-control__inline">
          <div className="form-control__inline-name">Потенциал роста:</div>
          <div>{roundNumber(portfolioForecast)}%</div>
        </div>
      </div>

      <div className="form__group">
        <Field type="text" name="order" placeholder="Номер позиции" disabled={!isEditable} component={Input} />
      </div>

      <div className="form__group">
        <Search showSelectedValue={false} disabled={!isEditable} onSearchClick={onSearchClick} />
      </div>
      {values.positions?.length > 0 ? (
        <DndProvider backend={HTML5Backend}>
          <div className="portfolio-form__label">Позиции</div>
          <PositionList disabled={!isEditable} items={values.positions} onMove={setFieldValue} />
        </DndProvider>
      ) : null}

      <div className="form__group">
        <Field name="anons" rows={5} placeholder="Краткое описание" disabled={!isEditable} component={TextArea} />
      </div>

      <div className="form__group">
        <Field name="description" rows={5} placeholder="Полное описание" disabled={!isEditable} component={TextArea} />
      </div>

      {isUpdate && values.image ? (
        <div className="form__group">
          <div className="portfolio-form__label">Изображение</div>
          <div className="portfolio-form__image-wrapper">
            <span className="portfolio-form__image">{values.image}</span>
            {isEditable && (
              <span className="pointer action-icon">
                <FontAwesomeIcon icon={faTimes} className="fall" onClick={() => setFieldValue('image', '')} />
              </span>
            )}
          </div>
        </div>
      ) : (
        <div className="form__group">
          <Field
            name="image"
            placeholder="Изображение"
            fileTypes={['.png', '.jpg', '.jpeg', '.gif']}
            url="api/admin/files/upload_pf"
            onRemove={() => null}
            disabled={!isEditable}
            onUpload={setFieldValue}
            component={File}
          />
        </div>
      )}

      {isEditable && (
        <Button className="button__primary button__large button__wide" type={ButtonType.submit} disabled={disable}>
          {isUpdate ? 'Обновить' : 'Добавить'}
        </Button>
      )}

      {error && <p className="error-message">{error}</p>}
    </Form>
  );
};

export const PortfolioForm: React.FC = () => {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const modalsState = useStore<TModal$State<{ portfolio: Portfolio; isEditable: boolean }>>(Modals$);
  const forecastState = useStore(ForecastDictionary$);

  const portfolio = modalsState.data?.portfolio;
  const isEditable = modalsState.data?.isEditable;

  const isUpdate = !!portfolio;

  // @ts-ignore
  const errorHandler = (result) => {
    // @ts-ignore
    if (result.errorMessage) {
      // @ts-ignore
      setError(result.errorMessage);
    } else {
      // @ts-ignore
      modalApi.hide('');
    }
  };

  const getCreateData = (values: FormFields) => {
    const positions: PortfolioPosition[] = values.positions.map((item, index) => ({
      securityKey: item.securityKey,
      weight: Number(item.weight),
      orderNum: index + 1,
      targetPrice: Number(item.targetPrice),
    }));

    const data = {
      name: values.name,
      annotation: values.anons,
      description: values.description,
      currency: values.currency?.name,
      positions: positions,
      orderNum: Number(values.order),
      imageUrl: values.image,
      forecastSourceId: Number(values.forecasts?.id),
    };

    return data;
  };

  const getUpdateData = (values: FormFields) => {
    const data = {
      ...portfolio,
      ...getCreateData(values),
    };

    return data;
  };

  const onSubmit = (values: FormFields) => {
    const data = isUpdate ? getUpdateData(values) : getCreateData(values);

    setLoading(true);
    portfoliosApi
      .add(data)
      .then(errorHandler)
      .catch(errorHandler)
      .finally(() => {
        setLoading(false);
      });
  };

  const getInitData = () => {
    if (portfolio) {
      // @ts-ignore
      const forecast = forecastState?.find((item) => item.id === portfolio?.forecastSourceId);

      const data: Partial<FormFields> = {
        name: portfolio.name,
        anons: portfolio.annotation,
        description: portfolio.description,
        image: portfolio.imageUrl,
        currency: currencyOptions.find((item) => item.name === portfolio?.currency),
        order: portfolio.orderNum,
        forecasts: forecast,
        // @ts-ignore
        positions: portfolio.positions,
      };

      return data;
    }

    return initialValues;
  };

  const init = getInitData();

  return (
    <Formik
      // @ts-ignore
      initialValues={init}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
    >
      {(props) =>
        React.createElement(
          FormTemplate,
          // @ts-ignore
          {
            ...props,
            error,
            isUpdate,
            loading,
            // @ts-ignore
            isEditable,
          },
        )
      }
    </Formik>
  );
};
