import React, { useRef } from 'react';

import { faTimes } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { XYCoord } from 'dnd-core';
import { Field } from 'formik';
import { useDrag, useDrop, DropTargetMonitor, DragLayerMonitor } from 'react-dnd';

import { PositionForecast } from './';
import { roundNumber } from '../../../utils';
import { Input } from '../../FormControls/Input';

enum ItemTypes {
  CARD = 'card',
}

type Props = Partial<PositionForecast> & {
  id: string;
  text: string;
  index: number;
  moveCard: (dragIndex: number, hoverIndex: number) => void;
  removeCard: (securityKey: string) => void;
};

type DragItem = {
  index: number;
  id: string;
  type: string;
};

export const Position: React.FC<Props> = ({ id, text, currentPrice, forecast, index, moveCard, removeCard }) => {
  const ref = useRef<HTMLDivElement>(null);

  const [, drop] = useDrop<DragItem, DropTargetMonitor>({
    accept: ItemTypes.CARD,
    hover(item: DragItem, monitor: DropTargetMonitor) {
      if (!ref.current) {
        return;
      }

      const dragIndex = item.index;
      const hoverIndex = index;

      if (dragIndex === hoverIndex) {
        return;
      }

      const hoverBoundingRect = ref.current!.getBoundingClientRect();

      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;

      const clientOffset = monitor.getClientOffset();

      const hoverClientY = (clientOffset as XYCoord).y - hoverBoundingRect.top;

      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }

      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }

      moveCard(dragIndex, hoverIndex);

      item.index = hoverIndex;
    },
  });

  const [{ isDragging }, drag] = useDrag<DragItem, DragItem, { isDragging: boolean }>(
    {
      type: ItemTypes.CARD,
      item: { type: ItemTypes.CARD, id, index },
      collect: (monitor: DragLayerMonitor) => ({
        isDragging: monitor.isDragging(),
      }),
    },
    [],
  );

  const opacity = isDragging ? 0 : 1;

  drag(drop(ref));

  return (
    <div className="position-card" ref={ref} style={{ opacity }}>
      <div className="position-card__prices">
        <div className="position-card__prices-item">
          <span>Текущая цена:</span> <span>{currentPrice ? roundNumber(currentPrice, 2) : '-'}</span>
        </div>
        <div className="position-card__prices-item">
          <span>Потенциал:</span> <span>{forecast ? `${roundNumber(forecast * 100)}%` : '-'}</span>
        </div>
      </div>
      <div className="position-card__container">
        <div className="position-card__name">{text}</div>
        <div className="position-card__controls">
          <Field
            type="text"
            className="position-card__controls-weight"
            placeholder="Объем позиции, %"
            name={`positions[${index}].weight`}
            component={Input}
          />
          <Field type="text" placeholder="Целевая цена" name={`positions[${index}].targetPrice`} component={Input} />
        </div>
        <div className="position-card__icon" onClick={() => removeCard(id)}>
          <FontAwesomeIcon icon={faTimes} />
        </div>
      </div>
    </div>
  );
};
