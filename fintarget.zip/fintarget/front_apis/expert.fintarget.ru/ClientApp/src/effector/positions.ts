/* eslint-disable @typescript-eslint/ban-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { createStore, createApi, createEffect, forward } from 'effector';

import { modalApi } from './modals';
import { getPositions, closePosition, getSandboxPositions } from '../api';
import { SignalClose } from '../api/types/signal';
import { Position } from '../types/position';

type TPositions$State = {
  page: number;
  pageSize: number;
  totalPage: number;
  positions: Position[];
};

const initialState: TPositions$State = {
  page: 0,
  pageSize: 0,
  totalPage: 0,
  positions: [],
};

export const Positions$ = createStore<TPositions$State>(initialState);

const { set, add, close, update } = createApi(Positions$, {
  // @ts-ignore
  set: (state, { result }) => {
    if (result && result.success) {
      return { ...initialState, positions: result.result };
    }
    return initialState;
  },
  // @ts-ignore
  add: (state, position) => {
    if (position.result && position.result.success) {
      return {
        ...state,
        positions: [...state.positions, position],
      };
    }

    return state;
  },
  // @ts-ignore
  close: (state, { result, params }) => {
    const updatedState = { ...state };

    if (result.success) {
      // @ts-ignore
      updatedState.positions = updatedState.positions.filter((item) => item.securityKey !== params.securityKey);
      // @ts-ignore
      modalApi.hide('');
    }

    return updatedState;
  },
  // @ts-ignore
  update: (state, position) => {
    const updatedState = { ...state };
    // @ts-ignore
    const positions = updatedState.positions.filter((item) => item.securityKey !== position.securityKey2);

    updatedState.positions = [...positions, position];
    // @ts-ignore
    modalApi.hide('');

    return updatedState;
  },
});

export const positionsApi = {
  get: createEffect<string, { result: { success: boolean; result: any; errorMessage: string } }, {}>().use(
    getPositions,
  ),
  getSandbox: createEffect<string, { result: { success: boolean; result: any; errorMessage: string } }, {}>().use(
    getSandboxPositions,
  ),
  close: createEffect<SignalClose, {}, {}>().use(closePosition),
  add: createEffect(),
  update: createEffect(),
};

forward({
  from: positionsApi.get.done,
  to: set,
});

forward({
  from: positionsApi.getSandbox.done,
  to: set,
});

forward({
  from: positionsApi.close.done,
  to: close,
});

forward({
  from: positionsApi.add,
  to: add,
});

forward({
  from: positionsApi.update,
  to: update,
});
