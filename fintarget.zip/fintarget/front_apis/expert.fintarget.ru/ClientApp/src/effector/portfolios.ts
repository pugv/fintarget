/* eslint-disable @typescript-eslint/ban-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import { createStore, createApi, createEffect, forward } from 'effector';

import { modalApi } from './modals';
import { getPortfolios, updatePortfolio } from '../api';
import { PageParams } from '../components/TableGrid';
import { Portfolio } from '../types/portfolio';
import { Nullable } from '../utils/types';

type TPortfolios$State = {
  total: number;
  portfolios: Nullable<Portfolio[]>;
};

const initialState: TPortfolios$State = {
  total: 0,
  portfolios: [],
};

export const Portfolios$ = createStore<TPortfolios$State>(initialState);

const { set, add, remove } = createApi(Portfolios$, {
  // @ts-ignore
  set: (state, { result }) => {
    const data = {
      // @ts-ignore
      total: result.result.total,
      // @ts-ignore
      portfolios: result.result.pageItems,
    };

    return data;
  },
  // @ts-ignore
  add: (state, { result }) => {
    // @ts-ignore
    if (result.success) {
      // @ts-ignore
      const updated = state.portfolios.filter((item) => item.id !== result.result.id);

      // @ts-ignore
      return {
        ...state,
        // @ts-ignore
        portfolios: [...updated, result.result],
      };
    }
    return state;
  },
  // @ts-ignore
  remove: (state, { result, params }) => {
    if (result.success) {
      // @ts-ignore
      modalApi.hide('');
      // @ts-ignore
      return {
        ...state,
        // @ts-ignore
        portfolios: state.filter((item) => item.id !== params.id),
      };
    }

    return state;
  },
});

export const portfoliosApi = {
  get: createEffect<PageParams, {}, {}>().use(getPortfolios),
  remove: createEffect<Portfolio, {}, {}>().use(updatePortfolio),
  add: createEffect<Partial<Portfolio>, {}, {}>().use(updatePortfolio),
};

forward({
  from: portfoliosApi.get.done,
  to: set,
});

forward({
  from: portfoliosApi.remove.done,
  to: remove,
});

forward({
  from: portfoliosApi.add.done,
  to: add,
});
