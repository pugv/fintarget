/* eslint-disable @typescript-eslint/ban-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import { createStore, createApi, createEffect, forward } from 'effector';

import { getUtmDictionary } from '../api';
import { Option } from '../types/option';
import { Nullable } from '../utils/types';

type TUtmDictionary$State = Nullable<Option[]>;

export const UtmDictionary$ = createStore<TUtmDictionary$State>(null);

const { set } = createApi(UtmDictionary$, {
  // @ts-ignore
  set: (state, { result }) => result.result,
});

export const utmDictionaryApi = {
  get: createEffect().use(getUtmDictionary),
};

forward({
  from: utmDictionaryApi.get.done,
  to: set,
});
