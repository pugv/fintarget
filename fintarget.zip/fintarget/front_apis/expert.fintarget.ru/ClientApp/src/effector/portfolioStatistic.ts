/* eslint-disable @typescript-eslint/ban-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import { createStore, createApi, createEffect, forward } from 'effector';

import { getPortfolioStatistic } from '../api';
import { PortfolioStatistic } from '../types/portfolioStatistic';

type TMoney$State = PortfolioStatistic;

const initialState: TMoney$State = {
  uniqueListViews: 0,
  totalUniqueViewers: 0,
  totalPurchaseAttempts: 0,
  totalPurchases: 0,
  totalPurchaseSumInRubles: 0,
  entries: [],
};

export const PortfolioStatistic$ = createStore<TMoney$State>(initialState);

const { set } = createApi(PortfolioStatistic$, {
  // @ts-ignore
  set: (state, { result }) => {
    return result.result;
  },
});

export const portfolioStatisticApi = {
  get: createEffect<{}, {}, {}>().use(getPortfolioStatistic),
};

forward({
  from: portfolioStatisticApi.get.done,
  to: set,
});
