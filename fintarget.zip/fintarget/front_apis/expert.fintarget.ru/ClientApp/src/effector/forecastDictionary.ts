/* eslint-disable @typescript-eslint/ban-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import { createStore, createApi, createEffect, forward } from 'effector';

import { getForecastDictionary } from '../api';
import { Option } from '../types/option';
import { Nullable } from '../utils/types';

type TForecastDictionary$State = Nullable<Option[]>;

export const ForecastDictionary$ = createStore<TForecastDictionary$State>(null);

const { set } = createApi(ForecastDictionary$, {
  // @ts-ignore
  set: (state, { result }) => result.result,
});

export const forecastDictionaryApi = {
  get: createEffect().use(getForecastDictionary),
};

forward({
  from: forecastDictionaryApi.get.done,
  to: set,
});
