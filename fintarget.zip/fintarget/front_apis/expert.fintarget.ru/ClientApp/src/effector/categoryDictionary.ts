/* eslint-disable @typescript-eslint/ban-types */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import { createStore, createApi, createEffect, forward } from 'effector';

import { getCategoryDictionary } from '../api';
import { Option } from '../types/option';
import { Nullable } from '../utils/types';

type TCategoryDictionary$$State = Nullable<Option[]>;

export const CategoryDictionary$ = createStore<TCategoryDictionary$$State>(null);

const { set } = createApi(CategoryDictionary$, {
  // @ts-ignore
  set: (state, { result }) => result.result,
});

export const categoryDictionaryApi = {
  get: createEffect().use(getCategoryDictionary),
};

forward({
  from: categoryDictionaryApi.get.done,
  to: set,
});
