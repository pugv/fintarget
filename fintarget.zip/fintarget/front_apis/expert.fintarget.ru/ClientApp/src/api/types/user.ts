export type UserLogin = { userId: string; password: string };
export type LoginSmsCode = { smsCode: string };

export type UserChangePassword = {
  userId: string;
  oldPassword: string;
  newPassword: string;
  confirmNewPassword: string;
};
