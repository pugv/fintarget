import { Nullable } from '../../utils/types';

export type ApiDataResponse<RESPONSE> = {
  result: RESPONSE;
  success: boolean;
  errorMessage: Nullable<string>;
  errorCode: number;
};
