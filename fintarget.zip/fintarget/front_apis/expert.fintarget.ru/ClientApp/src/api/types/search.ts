import { Nullable } from '../../utils/types';

export type Search = {
  strategyId: Nullable<string>;
  classCodes: Nullable<string[]>;
  pattern: string;
};

export type SearchPosition = { securityKey: string; strategyId?: string };
