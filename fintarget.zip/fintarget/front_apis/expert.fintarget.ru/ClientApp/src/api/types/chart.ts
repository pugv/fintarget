export type Chart = { strategyId?: string; period: string };
