export type SignalClose = {
  strategyId?: string;
  securityKey?: string;
  comment: string;
};
