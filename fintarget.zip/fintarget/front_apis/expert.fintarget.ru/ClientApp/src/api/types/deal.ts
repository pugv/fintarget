import { PageParams } from '../../components/TableGrid';

export type Deal = {
  strategyId?: string;
  data: PageParams;
};
