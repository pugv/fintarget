/* eslint-disable @typescript-eslint/ban-ts-comment */
import React, { useEffect, useState } from 'react';

import { useStore } from 'effector-react';
import { Field, Form, Formik, FormikProps } from 'formik';
import moment from 'moment';
import { Link } from 'react-router-dom';
import * as Yup from 'yup';

import { Input } from '../../../components/FormControls/Input';
import { Select } from '../../../components/FormControls/Select';
import { Criteria, Filter, PageParams, TableGrid } from '../../../components/TableGrid';
import { Button, ButtonType } from '../../../components/UIKit/Button';
import { Clients$, clientsApi } from '../../../effector/clients';
import { StatisticFilters$ } from '../../../effector/statisticFilters';
import { Option } from '../../../types/option';
import { PAGE_STATISTIC_CLIENT_DETAILS_INFO } from '../../Routes';

const validationSchema = Yup.object().shape({
  strategy: Yup.array().of(
    Yup.object().shape({
      id: Yup.string(),
      name: Yup.string(),
    }),
  ),
  service: Yup.array().of(
    Yup.object().shape({
      id: Yup.string(),
      name: Yup.string(),
    }),
  ),
  agreement: Yup.string(),
});

type FormFields = {
  strategy: Option[];
  service: Option[];
  agreement: string;
};

type FormProps = {
  onFilterChanged: (filters: Filter) => void;
} & FormikProps<FormFields>;

const initialValues = {
  strategy: [],
  service: [],
  agreement: '',
};

const FormTemplate: React.FC<FormProps> = ({ values, resetForm, onFilterChanged }) => {
  const statisticFilters = useStore(StatisticFilters$);

  useEffect(() => {
    const filters = Object.keys(values)
      .map((item) => {
        // @ts-ignore
        const fieldValue = values[item];

        if (typeof fieldValue === 'string' && fieldValue.trim()) {
          return {
            fieldName: item,
            filterCriteria: Criteria.Contains,
            matches: [fieldValue],
          };
        }

        if (Array.isArray(fieldValue) && fieldValue.length) {
          return {
            fieldName: item,
            filterCriteria: Criteria.Equals,
            matches: fieldValue.map((item) => item.id),
          };
        }
      })
      .filter((item) => !!item);

    // @ts-ignore
    onFilterChanged(filters);
  }, [values]);

  return (
    <Form className="form" noValidate>
      <div className="form-control-row">
        <Field name="agreement" component={Input} placeholder="Г/С" />
      </div>
      <div className="form-control-group">
        {statisticFilters.strategies && (
          <div className="form-control-group__item">
            <Field
              name="strategy"
              component={Select}
              multiple={true}
              placeholder="Стратегии"
              options={statisticFilters.strategies}
            />
          </div>
        )}
        {statisticFilters.services && (
          <div className="form-control-group__item">
            <Field
              name="service"
              component={Select}
              multiple={true}
              placeholder="Услуги"
              options={statisticFilters.services}
            />
          </div>
        )}
      </div>
      <div className="table-filter__actions">
        <Button className="button__primary button__large" onClick={() => resetForm()} type={ButtonType.reset}>
          Сбросить
        </Button>
      </div>
    </Form>
  );
};

export const Clients: React.FC = () => {
  const [formFilters, setFormFilters] = useState<Filter[]>([]);
  const [forceReload, setForceReload] = useState<boolean>(false);

  const clientsStore = useStore(Clients$);

  const loadClients = (data: PageParams) => {
    // @ts-ignore
    clientsApi.get({ ...data, filters: formFilters });
    setForceReload(false);
  };

  const onFilterChanged = (filters: Filter[]) => {
    setFormFilters(filters);
    setForceReload(true);
  };

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  const onSubmit = () => {};

  const columns = [
    {
      Header: 'Г/С',
      accessor: 'agreement',
      className: 'table__column-left',
      // @ts-ignore
      Cell: ({ cell }) => {
        return (
          <Link to={`${PAGE_STATISTIC_CLIENT_DETAILS_INFO}/${cell?.row?.original?.id}`}>
            {cell?.row?.original?.agreement}
          </Link>
        );
      },
    },
    {
      Header: 'Портфель',
      accessor: 'portfolio',
      className: 'table__column-right',
      // @ts-ignore
      Cell: ({ cell }) => <span dangerouslySetInnerHTML={{ __html: cell?.row?.original?.portfolio }} />,
    },
    {
      Header: 'В инструментах',
      accessor: 'positions',
      className: 'table__column-right',
      // @ts-ignore
      Cell: ({ cell }) => <span dangerouslySetInnerHTML={{ __html: cell?.row?.original?.positions }} />,
    },
    {
      Header: 'Свободно',
      accessor: 'free',
      className: 'table__column-right',
      // @ts-ignore
      Cell: ({ cell }) => <span dangerouslySetInnerHTML={{ __html: cell?.row?.original?.free }} />,
    },
    {
      Header: 'Отклонение (%)',
      accessor: 'deviation',
      className: 'table__column-right',
      // @ts-ignore
      Cell: ({ cell }) => <span dangerouslySetInnerHTML={{ __html: cell?.row?.original?.deviation }} />,
    },
    {
      Header: 'Мин. откл.',
      accessor: 'minDiff',
      className: 'table__column-right',
      // @ts-ignore
      Cell: ({ cell }) => <span dangerouslySetInnerHTML={{ __html: cell?.row?.original?.minDiff }} />,
    },
    {
      Header: 'Стратегия',
      accessor: 'strategy',
      className: 'table__column-right',
    },
    {
      Header: 'Услуга',
      accessor: 'service',
      className: 'table__column-right',
    },
    {
      Header: 'Подключен',
      accessor: 'bindDate',
      className: 'table__column-right',
      // @ts-ignore
      Cell: ({ cell }) => <span>{moment(cell?.row?.original?.bindDate).format('DD.MM.YYYY HH:mm')}</span>,
    },
  ];

  return (
    <>
      <div className="table-filter">
        <div className="table-filter__title">Фильтры</div>
        <Formik
          // @ts-ignore
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
        >
          {(props) =>
            React.createElement(
              FormTemplate,
              // @ts-ignore
              {
                ...props,
                // @ts-ignore
                onFilterChanged,
              },
            )
          }
        </Formik>
      </div>
      <TableGrid
        columns={columns}
        data={clientsStore.clients}
        sortField="bindDate"
        isRecursiveFetch={false}
        forceReload={forceReload}
        pageSize={25}
        totalRecords={clientsStore.totalClients}
        onPageChange={loadClients}
      />
    </>
  );
};
