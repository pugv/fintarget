/* eslint-disable @typescript-eslint/ban-ts-comment */
import React, { useEffect, useMemo, useState } from 'react';

import { useStore } from 'effector-react';
import { Field, Form, Formik, FormikProps } from 'formik';
import * as Yup from 'yup';

import { Select } from '../../../components/FormControls/Select';
import { Criteria, Filter, PageParams, TableGrid } from '../../../components/TableGrid';
import { Button, ButtonType } from '../../../components/UIKit/Button';
import { Money$, moneyApi } from '../../../effector/money';
import { StatisticFilters$ } from '../../../effector/statisticFilters';
import { Option } from '../../../types/option';

const validationSchema = Yup.object().shape({
  author: Yup.array().of(
    Yup.object().shape({
      id: Yup.string(),
      name: Yup.string(),
    }),
  ),
  producttype: Yup.object()
    .shape({
      id: Yup.string(),
      name: Yup.string(),
    })
    .nullable(),
});

type FormFields = {
  author: Option[];
  producttype: Option;
};

type FormProps = {
  onFilterChanged: (filters: Filter[]) => void;
} & FormikProps<FormFields>;

const initialValues = {
  author: [],
};

const FormTemplate: React.FC<FormProps> = ({ values, resetForm, onFilterChanged }) => {
  const statisticFilters = useStore(StatisticFilters$);

  const productTypes = useMemo<Option[]>(
    () => [
      {
        id: '1',
        name: 'Автоследование',
      },
      {
        id: '2',
        name: 'Автоконсультирование',
      },
      {
        id: '3',
        name: 'Накопилка',
      },
    ],
    [],
  );

  useEffect(() => {
    const filters: Filter[] = [];
    if (values.author?.length) {
      filters.push({
        fieldName: 'author',
        filterCriteria: Criteria.Equals,
        matches: values.author?.map((item) => item.id),
      });
    }

    if (values.producttype?.id) {
      filters.push({
        fieldName: 'producttype',
        filterCriteria: Criteria.Equals,
        matches: [Number(values.producttype.id)],
      });
    }

    onFilterChanged(filters);
  }, [values.author, values.producttype]);

  return (
    <Form className="form" noValidate>
      {statisticFilters.authors && (
        <div className="form-control-group">
          <div className="form-control-group__item">
            <Field
              name="author"
              component={Select}
              multiple={true}
              placeholder="Авторы"
              options={statisticFilters.authors}
            />
          </div>
          <div className="form-control-group__item">
            <Field
              name="producttype"
              component={Select}
              placeholder="Тип продукта"
              isClearable
              options={productTypes}
            />
          </div>
        </div>
      )}

      <div className="table-filter__actions">
        <Button className="button__primary button__large" onClick={() => resetForm()} type={ButtonType.reset}>
          Сбросить
        </Button>
      </div>
    </Form>
  );
};

export const Money: React.FC = () => {
  const [formFilters, setFormFilters] = useState<Filter[]>([]);
  const [forceReload, setForceReload] = useState<boolean>(false);
  const moneyStore = useStore(Money$);

  const loadMoney = (data: PageParams) => {
    // @ts-ignore
    moneyApi.get({ ...data, filters: formFilters });
    setForceReload(false);
  };

  const onFilterChanged = (filters: Filter[]) => {
    setFormFilters(filters);
    setForceReload(true);
  };

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  const onSubmit = () => {};

  const columns = useMemo(() => {
    const hasSelection = formFilters.find(({ fieldName }) => fieldName === 'producttype');
    const hasCop = formFilters.find(({ matches }) => matches.includes(3));

    const headerName = hasSelection ? (hasCop ? 'Накопилка' : 'Стратегия') : 'Название';

    const cols = [
      {
        Header: headerName,
        Footer: () => 'Всего',
        accessor: 'name',
        className: 'table__column-left',
        order: 1,
      },
      {
        Header: 'Клиентов всего',
        Footer: () => <span dangerouslySetInnerHTML={{ __html: moneyStore.totalClients }} />,
        accessor: 'clientCount',
        className: 'table__column-right',
        order: 4,
        // @ts-ignore
        Cell: ({ cell }) => (
          <span
            dangerouslySetInnerHTML={{
              __html: cell?.row?.original?.clientCount,
            }}
          />
        ),
      },
      {
        Header: 'Денег всего (РУБ)',
        Footer: () => <span dangerouslySetInnerHTML={{ __html: moneyStore.totalSUR }} />,
        accessor: 'valueSUR',
        className: 'table__column-right',
        order: 5,
        // @ts-ignore
        Cell: ({ cell }) => (
          <span
            dangerouslySetInnerHTML={{
              __html: cell?.row?.original?.valueSUR,
            }}
          />
        ),
      },
      {
        Header: 'Денег всего (USD)',
        Footer: () => <span dangerouslySetInnerHTML={{ __html: moneyStore.totalUSD }} />,
        accessor: 'valueUSD',
        className: 'table__column-right',
        order: 6,
        // @ts-ignore
        Cell: ({ cell }) => (
          <span
            dangerouslySetInnerHTML={{
              __html: cell?.row?.original?.valueUSD,
            }}
          />
        ),
      },
    ];

    if (!hasSelection) {
      // @ts-ignore
      cols.push({
        Header: 'Тип продукта',
        accessor: 'productType',
        order: 2,
        className: 'table__column-left',
      });
    }

    if (!hasCop) {
      // @ts-ignore
      cols.push({
        Header: 'Автор',
        accessor: 'author',
        order: 3,
        className: 'table__column-left',
      });
    }

    return cols.sort((a, b) => a.order - b.order);
  }, [moneyStore]);

  return (
    <>
      <div className="table-filter">
        <div className="table-filter__title">Фильтры</div>
        <Formik
          // @ts-ignore
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
        >
          {(props) =>
            React.createElement(
              FormTemplate,
              // @ts-ignore
              {
                ...props,
                onFilterChanged,
              },
            )
          }
        </Formik>
      </div>
      <TableGrid
        columns={columns}
        data={moneyStore.pageStats}
        sortField="totalSUR"
        isRecursiveFetch={false}
        forceReload={forceReload}
        footer={true}
        pageSize={25}
        totalRecords={moneyStore.total}
        onPageChange={loadMoney}
      />
    </>
  );
};
