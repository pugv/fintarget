/* eslint-disable @typescript-eslint/ban-ts-comment */
import React from 'react';

import { useStore } from 'effector-react';
import { useNavigate } from 'react-router-dom';
import Select from 'react-select';

import { StrategyDictionary$ } from '../../effector/strategyDictionary';
import { PAGE_STRATEGIES, PAGE_STRATEGY_POSITIONS } from '../Routes';

export const Strategies: React.FC = () => {
  const navigate = useNavigate();
  const strategies = useStore(StrategyDictionary$);

  if (!strategies) return null;

  // @ts-ignore
  const onChange = (val) => {
    navigate(`${PAGE_STRATEGIES}/${val.id}/${PAGE_STRATEGY_POSITIONS}`);
  };

  return (
    <div className="strategies">
      <div className="strategies__selection">
        <Select
          placeholder="Выберите стратегию"
          options={strategies}
          getOptionLabel={(option) => option.name}
          onChange={onChange}
        />
      </div>
    </div>
  );
};
