/* eslint-disable @typescript-eslint/ban-ts-comment */
import React, { useEffect, useState } from 'react';

import { useStore } from 'effector-react';
import { Field, Form, Formik, FormikProps } from 'formik';
import moment from 'moment';
import * as Yup from 'yup';

import { DatePicker } from '../../../components/FormControls/DatePicker';
import { PageParams, SortType, TableGrid } from '../../../components/TableGrid';
import { ERRORS_TEXTS } from '../../../const/validation';
import { PortfolioStatistic$, portfolioStatisticApi } from '../../../effector/portfolioStatistic';
import { PortfolioStatisticsEntry } from '../../../types/portfolioStatistic';
import { formatMoney } from '../../../utils';
import { UserAction } from '../../../utils/permissions';

const validationSchema = Yup.object().shape({
  startDate: Yup.string().required(ERRORS_TEXTS.required),
  endDate: Yup.string().required(ERRORS_TEXTS.required),
});

type FormFields = {
  startDate: Date;
  endDate: Date;
};

type RequestData = {
  fromDate: string;
  toDate: string;
};

type FormProps = {
  loadData: (data: RequestData) => void;
} & FormikProps<FormFields>;

const initialValues = {
  startDate: moment().subtract(1, 'week').toDate(),
  endDate: moment().toDate(),
};

const DATE_FORMAT = 'YYYY-MM-DD';

const FormTemplate: React.FC<FormProps> = ({ values, loadData }) => {
  useEffect(() => {
    const data: RequestData = {
      fromDate: moment(values.startDate).format(DATE_FORMAT),
      toDate: moment(values.endDate).format(DATE_FORMAT),
    };

    loadData(data);
  }, [values.startDate, values.endDate]);

  return (
    <Form className="form" noValidate>
      <div className="form-control-group portfolios__date">
        <Field
          name="startDate"
          component={DatePicker}
          placeholder="Дата начала"
          dateFormat="dd.MM.yyyy"
          selectsStart
          startDate={values.startDate}
          endDate={values.endDate}
        />
        <Field
          name="endDate"
          component={DatePicker}
          placeholder="Дата окончания"
          dateFormat="dd.MM.yyyy"
          selectsEnd
          startDate={values.endDate}
          endDate={values.endDate}
          minDate={values.startDate}
          maxDate={moment().toDate()}
          className="portfolios__date-last"
        />
      </div>
    </Form>
  );
};

export const Statistic: React.FC = ({}) => {
  const [entries, setEntries] = useState<PortfolioStatisticsEntry[]>([]);
  const portfolioStatistic = useStore(PortfolioStatistic$);

  useEffect(() => {
    setEntries(portfolioStatistic.entries);
  }, [portfolioStatistic.entries]);

  const loadData = (data: RequestData) => {
    portfolioStatisticApi.get(data);
  };

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  const onSubmit = () => {};
  const onSort = (data: PageParams) => {
    const numberCompare = (a: number, b: number) => {
      if (data.sortDirection === SortType.Ask) {
        return a - b;
      } else {
        return b - a;
      }
    };

    const stringCompare = (a: string, b: string) => {
      if (a > b) {
        return data.sortDirection === SortType.Ask ? 1 : -1;
      } else if (b > a) {
        return data.sortDirection === SortType.Ask ? -1 : 1;
      }
      return 0;
    };

    const soretedEntries = entries.sort((a, b) => {
      const key = Object.keys(a).find((item) => item.toLocaleLowerCase() === data.sortFieldName);

      const compare =
        // @ts-ignore
        typeof a[key] === 'string' ? stringCompare : numberCompare;
      // @ts-ignore
      return compare(a[key], b[key]);
    });

    setEntries([...soretedEntries]);
  };

  const columns = [
    {
      Header: 'Название',
      Footer: () => 'Всего',
      accessor: 'name',
      className: 'table__column-left',
      action: UserAction.portfolio,
    },
    {
      Header: 'Просмотрело',
      Footer: () => <span>{portfolioStatistic.totalUniqueViewers}</span>,
      accessor: 'uniqueViewers',
      className: 'table__column-right',
      action: UserAction.portfolio,
    },
    {
      Header: 'Попыток купить',
      Footer: () => <span>{portfolioStatistic.totalPurchaseAttempts}</span>,
      accessor: 'purchaseAttempts',
      className: 'table__column-right',
      action: UserAction.portfolio,
    },
    {
      Header: 'Покупок',
      Footer: () => <span>{portfolioStatistic.totalPurchases}</span>,
      accessor: 'purchases',
      className: 'table__column-right',
      action: UserAction.portfolio,
    },
    {
      Header: 'Сумма покупок',
      accessor: 'purchaseSum',
      className: 'table__column-right',
      action: UserAction.portfolio,
      Cell: ({
        cell: {
          row: {
            // @ts-ignore
            original,
          },
        },
      }) => {
        return <>{formatMoney(original.purchaseSum, original.currency)}</>;
      },
    },
    {
      Header: 'Сумма покупок (РУБ)',
      Footer: () => <span>{formatMoney(portfolioStatistic.totalPurchaseSumInRubles)}</span>,
      accessor: 'purchaseSumInRubles',
      className: 'table__column-right',
      action: UserAction.portfolio,
      Cell: ({
        cell: {
          row: {
            // @ts-ignore
            original,
          },
        },
      }) => {
        return <>{formatMoney(original.purchaseSumInRubles)}</>;
      },
    },
  ];

  return (
    <>
      <div className="portfolios__filter">
        <Formik
          // @ts-ignore
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={onSubmit}
        >
          {(props) =>
            React.createElement(
              FormTemplate,
              // @ts-ignore
              {
                ...props,
                loadData,
              },
            )
          }
        </Formik>
      </div>
      <div className="portfolios__views">
        <div className="portfolios__views-label">Уникальных просмотров списка:</div>
        <div className="portfolios__views-value">{portfolioStatistic?.uniqueListViews}</div>
      </div>
      <TableGrid
        columns={columns}
        // @ts-ignore
        data={entries}
        sortField="name"
        isRecursiveFetch={false}
        footer={true}
        onPageChange={onSort}
      />
    </>
  );
};
