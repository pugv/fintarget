/* eslint-disable @typescript-eslint/ban-ts-comment */
import React, { useEffect, useMemo } from 'react';

import { faEdit, faPlus, faEye, faExchangeAlt, faExclamationCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useStore } from 'effector-react';
import { Tooltip } from 'react-tippy';

import { ProtectedComponent } from '../../../components/ProtectedComponent';
import { PageParams, TableGrid } from '../../../components/TableGrid';
import { Button, ButtonType } from '../../../components/UIKit/Button';
import { forecastDictionaryApi } from '../../../effector/forecastDictionary';
import { modalApi } from '../../../effector/modals';
import { Portfolios$, portfoliosApi } from '../../../effector/portfolios';
import { User$ } from '../../../effector/user';
import { checkPermissions, UserAction } from '../../../utils/permissions';
import { MODALS } from '../../../utils/types';

export const Portfolio: React.FC = ({}) => {
  //@ts-ignore
  const user = useStore(User$);
  const portfolios = useStore(Portfolios$);

  useEffect(() => {
    forecastDictionaryApi.get('');
  }, []);

  const loadData = (data: PageParams) => {
    portfoliosApi.get(data);
  };

  const onAddPortfolio = () => {
    modalApi.show({
      modalId: MODALS.PORTFOLIO,
      data: {
        isEditable: true,
      },
    });
  };

  // @ts-ignore
  const columns = [
    {
      Header: 'Название',
      accessor: 'name',
      className: 'table__column-left',
      action: UserAction.portfolio,
    },
    {
      Header: 'Потенциал',
      accessor: 'forecast',
      className: 'table__column-right',
      action: UserAction.portfolio,
    },
    {
      Header: 'Минимальная сумма',
      accessor: 'minBalance',
      className: 'table__column-right',
      action: UserAction.portfolio,
    },
    {
      Header: 'Валюта',
      accessor: 'currency',
      className: 'table__column-right',
      action: UserAction.portfolio,
    },
    {
      Header: 'Номер позиции',
      accessor: 'orderNum',
      className: 'table__column-right',
      action: UserAction.portfolio,
    },
    {
      Header: 'Статус',
      accessor: 'active',
      className: 'table__column-right',
      action: UserAction.portfolio,
      Cell: ({
        cell: {
          row: {
            // @ts-ignore
            original: { active },
          },
        },
      }) => {
        const name = active ? 'Активный' : 'Неактивный';

        return <span>{name}</span>;
      },
    },
    {
      Header: '',
      accessor: 'id',
      className: 'table__column-right table__column-action',
      action: UserAction.portfolioDetailsView,
      Cell: ({
        cell: {
          row: {
            // @ts-ignore
            original,
          },
        },
      }) => {
        return (
          <span className="pointer">
            <FontAwesomeIcon
              icon={faEye}
              onClick={() => {
                // @ts-ignore
                modalApi.show({
                  modalId: MODALS.PORTFOLIO,
                  data: {
                    portfolio: original,
                    isEditable: false,
                  },
                });
              }}
            />
          </span>
        );
      },
    },
    {
      Header: '',
      accessor: 'errorMessage',
      className: 'table__column-right table__column-action',
      action: UserAction.portfolio,
      Cell: ({
        cell: {
          row: {
            // @ts-ignore
            original: { errorMessage },
          },
        },
      }) => {
        return errorMessage ? (
          // eslint-disable-next-line @typescript-eslint/ban-ts-comment
          // @ts-ignore
          // tslint:disable-next-line: jsx-wrap-multiline
          <Tooltip theme="light" title={errorMessage} arrow={true} position="top" trigger="mouseenter">
            <span>
              <FontAwesomeIcon className="fall" icon={faExclamationCircle} />
            </span>
          </Tooltip>
        ) : (
          ''
        );
      },
    },
    {
      Header: '',
      accessor: 'id',
      className: 'table__column-right table__column-action',
      action: UserAction.portfolioEdit,
      Cell: ({
        cell: {
          row: {
            // @ts-ignore
            original,
          },
        },
      }) => {
        return (
          <span className="pointer">
            <FontAwesomeIcon
              icon={faEdit}
              onClick={() => {
                // @ts-ignore
                modalApi.show({
                  modalId: MODALS.PORTFOLIO,
                  data: {
                    portfolio: original,
                    isEditable: true,
                  },
                });
              }}
            />
          </span>
        );
      },
    },
    {
      Header: '',
      accessor: 'remove',
      className: 'table__column-right table__column-action',
      action: UserAction.portfolioRemove,
      Cell: ({
        cell: {
          row: {
            // @ts-ignore
            original,
          },
        },
      }) => {
        return (
          <span className="pointer">
            <FontAwesomeIcon
              icon={faExchangeAlt}
              className="fall"
              onClick={() => {
                // @ts-ignore
                modalApi.show({
                  modalId: MODALS.REMOVE_PORTFOLIO,
                  data: {
                    portfolio: original,
                  },
                });
              }}
            />
          </span>
        );
      },
    },
  ];

  const cols = useMemo(() => {
    if (user?.role) {
      const cols = columns.filter((item) => checkPermissions(user.role, item.action));

      return cols;
    }
    return [];
  }, [user]);

  return (
    <>
      <ProtectedComponent userAction={UserAction.portfolioAdd}>
        <Button
          className="button button__primary button__margin-top button__small"
          type={ButtonType.button}
          onClick={onAddPortfolio}
        >
          <FontAwesomeIcon icon={faPlus} /> Добавить
        </Button>
      </ProtectedComponent>
      <TableGrid
        columns={cols}
        // @ts-ignore
        data={portfolios.portfolios}
        sortField="date"
        pageSize={25}
        isRecursiveFetch={false}
        totalRecords={portfolios.total}
        onPageChange={loadData}
      />
    </>
  );
};
