import React, { useMemo } from 'react';

import { useStore } from 'effector-react';
import { Navigate, Route, Routes as RoutesComponent } from 'react-router-dom';

import { Portfolio } from './Portfolio';
import { Statistic } from './Statistic';
import { Navigation } from '../../components/Navigation';
import { User$ } from '../../effector/user';
import { checkPermissions, UserAction } from '../../utils/permissions';
import { PrivateRoute } from '../PrivateRoute';
import { PAGE_PORTFOLIOS_PORTFOLIO, PAGE_PORTFOLIOS_STATISTIC } from '../Routes';

export const Portfolios: React.FC = () => {
  const user = useStore(User$);

  const items = useMemo(
    () => [
      {
        name: 'Портфели',
        path: PAGE_PORTFOLIOS_PORTFOLIO,
        action: UserAction.portfolio,
      },
      {
        name: 'Статистика',
        path: PAGE_PORTFOLIOS_STATISTIC,
        action: UserAction.portfolioStatistic,
      },
    ],
    [],
  );

  const navigations = useMemo(() => {
    if (user?.role) {
      return items.filter((item) => checkPermissions(user.role, item.action));
    }

    return [];
  }, [user, items]);

  return (
    <div className="portfolios">
      <div className="portfolios__navigation">
        <Navigation items={navigations} />
      </div>
      <div>
        <RoutesComponent>
          <Route
            path={PAGE_PORTFOLIOS_PORTFOLIO}
            element={<PrivateRoute component={Portfolio} userAction={UserAction.portfolio} />}
          />
          <Route
            path={PAGE_PORTFOLIOS_STATISTIC}
            element={<PrivateRoute component={Statistic} userAction={UserAction.portfolioStatistic} />}
          />
          <Route path="*" element={<Navigate replace to={PAGE_PORTFOLIOS_PORTFOLIO} />} />
        </RoutesComponent>
      </div>
    </div>
  );
};
