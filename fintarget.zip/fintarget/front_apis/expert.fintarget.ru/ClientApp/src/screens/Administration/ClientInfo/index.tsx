import React from 'react';

export const EditClient: React.FC = () => {
  return <div className="client-params__item-name"></div>;
};
