/* eslint-disable @typescript-eslint/ban-ts-comment */
import React, { useCallback, useMemo } from 'react';

import { faEdit, faExchangeAlt, faPlus, faRecycle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import cs from 'classnames';
import { useStore } from 'effector-react';
import moment from 'moment';
import { Link, useNavigate } from 'react-router-dom';

import { ProtectedComponent } from '../../../components/ProtectedComponent';
import { PageParams, TableGrid } from '../../../components/TableGrid';
import { Button, ButtonType } from '../../../components/UIKit/Button';
import { AggregateStrategies$, aggregateStrategiesApi } from '../../../effector/aggregateStrategies';
import { modalApi } from '../../../effector/modals';
import { User$ } from '../../../effector/user';
import { UserRoles } from '../../../types/userRoles';
import { boolToString } from '../../../utils';
import { checkPermissions, UserAction } from '../../../utils/permissions';
import { MODALS } from '../../../utils/types';
import { PAGE_ADMINISTRATION, PAGE_ADMINISTRATION_STRATEGY_DETAILS } from '../../Routes';

export const Strategies: React.FC = () => {
  const navigate = useNavigate();
  const user = useStore(User$);

  const onEdit = useCallback(
    (val: string) => {
      navigate(val);
    },
    [navigate],
  );

  const aggregateStrategiesStore = useStore(AggregateStrategies$);

  const loadStrategies = (data: PageParams) => {
    aggregateStrategiesApi.get(data);
  };

  const onAddStrategy = () => {
    modalApi.show({
      modalId: MODALS.ADD_STRATEGY,
    });
  };

  const onSplit = () => {
    modalApi.show({
      modalId: MODALS.SPLIT,
    });
  };

  const onUpdateHistory = () => {
    modalApi.show({ modalId: MODALS.UPDATE_HISTORY });
  };

  const isDeveloper = user?.role && user.role === UserRoles.Developer;

  const columns = useMemo(() => {
    if (user) {
      const items = [
        {
          Header: 'Название',
          accessor: 'name',
          className: 'table__column-left',
          action: UserAction.administrationStrategies,
          Cell: ({
            cell: {
              row: {
                // @ts-ignore
                original,
              },
            },
          }) => {
            return (
              <Link to={`${PAGE_ADMINISTRATION}/${PAGE_ADMINISTRATION_STRATEGY_DETAILS}/${original?.id}`}>
                {original?.name}
              </Link>
            );
          },
        },
        {
          Header: 'Создана',
          accessor: 'creationDate',
          className: 'table__column-right',
          action: UserAction.administrationStrategies,
          Cell: ({
            cell: {
              row: {
                // @ts-ignore
                original: { creationDate },
              },
            },
          }) => {
            const timeFormated = moment(creationDate).format('DD.MM.YYYY HH:mm');

            return <span>{timeFormated}</span>;
          },
        },
        {
          Header: 'Плечо',
          accessor: 'leverage',
          className: 'table__column-right',
          action: UserAction.administrationStrategies,
          // @ts-ignore
          Cell: ({ cell }) => <span>{cell?.row?.original?.leverage}</span>,
        },
        {
          Header: 'Валюта',
          accessor: 'currency',
          className: 'table__column-left',
          action: UserAction.administrationStrategies,
        },
        {
          Header: 'Открыта',
          accessor: 'open',
          className: 'table__column-right',
          action: UserAction.administrationStrategies,
          // @ts-ignore
          Cell: ({ cell }) => <span>{boolToString(cell?.row?.original?.open)}</span>,
        },
        {
          Header: '',
          accessor: 'edit',
          className: 'table__column-right table__column-action',
          action: UserAction.administrationStrategiesAction,
          Cell: ({
            cell: {
              row: {
                // @ts-ignore
                original,
              },
            },
          }) => {
            return (
              <span className="pointer">
                <FontAwesomeIcon
                  icon={faEdit}
                  className={cs({ 'fa-disabled': isDeveloper && !original.testMode })}
                  onClick={() => {
                    onEdit(original.id);
                  }}
                />
              </span>
            );
          },
        },
        {
          Header: '',
          accessor: 'close',
          className: 'table__column-right table__column-action',
          action: UserAction.administrationStrategiesAction,
          Cell: ({
            cell: {
              row: {
                // @ts-ignore
                original,
              },
            },
          }) => {
            return (
              <span className="pointer">
                <FontAwesomeIcon
                  icon={faExchangeAlt}
                  className={cs({
                    fall: original.testMode || !isDeveloper,
                    'fa-disabled': isDeveloper && !original.testMode,
                  })}
                  onClick={() => {
                    // @ts-ignore
                    modalApi.show({
                      modalId: MODALS.OPEN_STRATEGY,
                      data: {
                        id: original.id,
                        open: original.open,
                      },
                    });
                  }}
                />
              </span>
            );
          },
        },
        {
          Header: '',
          accessor: 'remove',
          className: 'table__column-right table__column-action',
          action: UserAction.administrationStrategiesAction,
          Cell: ({
            cell: {
              row: {
                // @ts-ignore
                original,
              },
            },
          }) => {
            return (
              <span className="pointer">
                <FontAwesomeIcon
                  icon={faRecycle}
                  className={cs({ 'fa-disabled': isDeveloper && !original.testMode })}
                  onClick={() =>
                    modalApi.show({
                      modalId: MODALS.OPEN_STRATEGY,
                      data: {
                        id: original.id,
                        active: original.active,
                      },
                    })
                  }
                />
              </span>
            );
          },
        },
      ];
      return items.filter((item) => checkPermissions(user.role, item.action));
    }
    return [];
  }, [user, onEdit]);

  return (
    <>
      <ProtectedComponent userAction={UserAction.administrationDeveloper}>
        <div className="form__group">
          <br />
          <p>Для данного пользователя доступно редактирование только тестовых стратегий.</p>
          <br />
        </div>
      </ProtectedComponent>

      <div className="form__group">
        <ProtectedComponent userAction={UserAction.administrationStrategiesAction}>
          <Button
            className="button button__primary button__small form__button-inline"
            type={ButtonType.button}
            onClick={onAddStrategy}
          >
            <FontAwesomeIcon icon={faPlus} /> Добавить
          </Button>
        </ProtectedComponent>

        <Button
          className="button button__primary button__small form__button-inline"
          type={ButtonType.button}
          onClick={onUpdateHistory}
        >
          Пересчитать рейтинг
        </Button>

        <Button
          className="button button__primary button__small form__button-inline"
          type={ButtonType.button}
          onClick={onSplit}
        >
          Сплит
        </Button>
      </div>

      <TableGrid
        columns={columns}
        data={aggregateStrategiesStore.strategies}
        sortField="name"
        pageSize={25}
        totalRecords={aggregateStrategiesStore.total}
        onPageChange={loadStrategies}
      />
    </>
  );
};
