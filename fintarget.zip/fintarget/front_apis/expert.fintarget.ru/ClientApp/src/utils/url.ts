import { stringify } from 'qs';

export const getStringQuery = <T>(params: T): string =>
  stringify(params, {
    addQueryPrefix: true,
    skipNulls: true,
    encodeValuesOnly: true,
  });
