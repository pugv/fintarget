import { Nullable } from './types';
import { UserRoles } from '../types/userRoles';

export const formatMoney: (value: Nullable<number>, currency?: string, toFixed?: number) => string = (
  value,
  currency = 'RUB',
  toFixed = 2,
) => {
  if (!value) {
    return '';
  }

  const currencies = {
    RUB: '₽',
    SUR: '₽',
    USD: '$',
    EUR: '€',
    '%': '%',
    undefined: '',
    null: '',
  };

  const formatter = new Intl.NumberFormat('ru-RU', {
    minimumFractionDigits: toFixed,
    maximumFractionDigits: toFixed,
  });

  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  return `${formatter.format(value)} ${currencies[currency]}`;
};

export const roundNumber = (value: number, to = 2) => parseFloat(value.toFixed(to));

export const roundStringNumber = (value: number | string, to = 2) => Number(value).toFixed(to);

export const roleToText = (role: UserRoles) => {
  let textRole = '';

  switch (role) {
    case UserRoles.Manager:
      textRole = 'Управляющий';
      break;

    case UserRoles.Expert:
      textRole = 'Эксперт';
      break;

    case UserRoles.Administrator:
      textRole = 'Менеджер';
      break;

    case UserRoles.RiskManager:
      textRole = 'Риск-Менеджер';
      break;

    case UserRoles.Support:
      textRole = 'Поддержка';
      break;

    case UserRoles.ContentManager:
      textRole = 'Контент-менеджер';
      break;

    case UserRoles.DigitalExpert:
      textRole = 'Digital-эксперт';
      break;

    case UserRoles.Developer:
      textRole = 'Администратор';
      break;

    case UserRoles.Auditor:
      textRole = 'Аудитор';
      break;
  }

  return textRole;
};

export const boolToString = (value: boolean) => (value ? 'Да' : 'Нет');
