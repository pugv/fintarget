﻿namespace balancer_service.Objects
{
    /// <summary>
    ///     Результат вызова метода API с телом ответа
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ApiRequestResult<T>
        : ApiRequestResult
    {
        /// <summary>
        ///     Тело ответа
        /// </summary>
        public T Response { get; set; }
    }
}