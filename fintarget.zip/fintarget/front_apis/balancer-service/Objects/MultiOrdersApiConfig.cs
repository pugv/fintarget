﻿using System;
using Fintarget.Infrastructure.SecurityCache;

namespace balancer_service.Objects
{
    public class MultiOrdersApiConfig
    {
        public string FintargetApiUrl { get; set; }
        public decimal FreeFundsMultiplier { get; set; }
        public decimal PricesMultiplier { get; set; }

        public bool ReturnExceptions { get; set; }
        public SecurityCacheConfig SecurityCacheConfig { get; set; }
        public Guid TestAgreementId { get; set; }
        public TimeSpan PortfolioListCacheLifeTime { get; set; }
        public string MultiOrdersService { get; set; }
        public bool CallConfirmAfterCreate { get; set; }
    }

    public class AuthorizationConfig
    {
        public string MasterIdClaim { get; set; }
        public string MasterIdClaimAlternative { get; set; }
        public string ValidIssuer { get; set; }
    }
}