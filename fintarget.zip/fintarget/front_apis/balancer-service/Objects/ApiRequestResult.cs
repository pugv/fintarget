﻿using System;
using NLib.AuxTypes;

namespace balancer_service.Objects
{
    /// <summary>
    ///     Результат вызова метода API
    /// </summary>
    public class ApiRequestResult
    {
        /// <summary>
        ///     Флаг успеха выполнения вызова
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        ///     Сообщение об ошибке, если <see cref="Success" />==false
        /// </summary>
        public string ErrorMessage { get; set; }

        public UserVisibleException.StatusCode ErrorCode { get; set; }

        /// <summary>
        ///     Фабричный метод конструирования успешного пустого ответа
        /// </summary>
        /// <returns></returns>
        public static ApiRequestResult CreateSuccess()
        {
            return new ApiRequestResult
            {
                Success = true
            };
        }

        /// <summary>
        ///     Фабричный метод конструирования неуспешного ответа
        /// </summary>
        /// <param name="message">Сообщение об ошибке</param>
        /// <param name="code">Код ошибки</param>
        /// <returns></returns>
        public static ApiRequestResult CreateError(string message, UserVisibleException.StatusCode code = UserVisibleException.StatusCode.None)
        {
            return new ApiRequestResult
            {
                Success = false,
                ErrorMessage = message,
                ErrorCode = code
            };
        }

        /// <summary>
        ///     Фабричный метод конструирования неуспешного ответа
        /// </summary>
        /// <param name="exception">Исключение</param>
        /// <returns></returns>
        public static ApiRequestResult CreateError(Exception exception)
        {
            return new ApiRequestResult
            {
                Success = false,
                ErrorMessage = exception is UserVisibleException ? exception.Message : UserVisibleException.DefaultMessage,
                ErrorCode = exception is UserVisibleException
                    ? (UserVisibleException.StatusCode)((UserVisibleException)exception).ErrorCode
                    : UserVisibleException.StatusCode.None
            };
        }
    }
}