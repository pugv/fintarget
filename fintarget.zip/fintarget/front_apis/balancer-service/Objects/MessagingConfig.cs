﻿namespace balancer_service.Objects
{
    public class MessagingConfig
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public string InfoEmail { get; set; }
    }
}