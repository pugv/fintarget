﻿using System.Collections.Generic;
using System.Linq;
using CS.Balance.Interfaces;
using Fintarget.Infrastructure.SecurityCache;
using SecurityType = CS.Balance.Interfaces.SecurityType;

namespace balancer_service.Objects
{
    internal class PortfolioStrategy
        : IStrategyInfo
    {
        public PortfolioStrategy(string currency = "SUR")
        {
            Currency = currency;
        }

        public Dictionary<string, IStrategyPosition> Positions { get; } = new Dictionary<string, IStrategyPosition>();

        public string Currency { get; set; }

        public decimal? S => null;

        public bool AllowCell => false;

        public override string ToString()
        {
            return string.Join("; ", Positions.Select(c => $"{c.Key} - {c.Value.Weight}"));
        }

        internal class PortfolioStrategyPosition
            : IStrategyPosition
        {
            public PortfolioStrategyPosition(ISecurity security, decimal weight)
            {
                Security = security;
                Weight = weight;
            }

            public decimal Weight { get; }

            public ISecurity Security { get; }

            public override string ToString()
            {
                return $"{Security} - {Weight}";
            }
        }

        internal class PortfolioStrategySecurity : ISecurity
        {
            private readonly Security _security;

            public PortfolioStrategySecurity(Security security)
            {
                _security = security;
            }

            public string Key => _security.Key;

            public string Symbol => _security.Symbol;

            public string Name => _security.Name;

            public decimal LastPrice => _security.LastPrice ?? 0;

            public SecurityType Type => (SecurityType)(int)_security.Type;

            public string Currency => _security.Currency;

            public decimal? Bid => _security.Bid;

            public decimal? Ask => _security.Ask;

            public uint LotSize => _security.LotSize;

            public decimal OneLotPrice => _security.OneLotPrice ?? 0;

            public decimal PriceStep => _security.PriceStep;
            public decimal SecAccruedint => _security.SecAccruedint;
            public decimal FaceValue => _security.FaceValue;
            public decimal LastQuotation => _security.LastQuotation;
        }
    }
}