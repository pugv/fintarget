﻿using System;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Text;
using balancer_service.Objects;
using Fintarget.Infrastructure.TestClients;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ServiceBase;

namespace balancer_service.Controllers
{
    public class BaseAuthController : BaseController
    {
        protected AuthorizationConfig _authorizationConfig;
        private readonly ITestClientsRepository _testClientsRepository;

        public BaseAuthController(IServiceProvider serviceProvider,
            ITestClientsRepository testClientsRepository,
            IOptions<AuthorizationConfig> authorizationConfig,
            ILogger logger) : base(serviceProvider, logger)
        {
            _authorizationConfig = authorizationConfig.Value;
            _testClientsRepository = testClientsRepository;
        }

        protected Guid GetClientId()
        {
            if (!TryGetClientId(out var clientId))
            {
                if ((User.Identity as ClaimsIdentity)?.Claims != null)
                {
                    Logger.LogWarning($"Invalid JWT received. {string.Join("; ", (User.Identity as ClaimsIdentity).Claims)}");
                    throw new Exception("User id not found in identification token");
                }

                throw new Exception("No JWT present when trying to get User id");
            }

            return clientId;
        }

        protected bool TryGetClientName(out string clientName)
        {
            var claim = (User.Identity as ClaimsIdentity)?.Claims.FirstOrDefault(x => x.Type == "name");
            if (claim == null)
            {
                clientName = default;
                return false;
            }

            clientName = claim.Value;
            return true;
        }

        protected bool TryGetClientId(out Guid clientId)
        {
            clientId = default;
            var claim = (User.Identity as ClaimsIdentity)?.Claims.FirstOrDefault(x => x.Type == _authorizationConfig.MasterIdClaim);

            if (claim == null)
                claim = (User.Identity as ClaimsIdentity)?.Claims.FirstOrDefault(x => x.Type == _authorizationConfig.MasterIdClaimAlternative);

            if (claim == null) return false;

            var id = Guid.Empty;
            if (!Guid.TryParse(claim.Value, out clientId))
                throw new Exception("Failed to parse user id");

            return true;
        }

        protected bool IsTester()
        {
            return TryGetClientId(out var clientId) && _testClientsRepository.IsTestClient(clientId);
        }

        protected new ActionResult Error(Exception ex, [CallerMemberName] string caller = "")
        {
            var clientIdStr = "missing";
            if (TryGetClientId(out var clientId))
                clientIdStr = clientId.ToString();
            else
                try
                {
                    var jwt = HttpContext.GetTokenAsync("access_token").Result;
                    if (jwt != null)
                    {
                        var payload = jwt.Split('.').Skip(1).FirstOrDefault();
                        clientIdStr = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(payload));
                    }
                }
                catch (Exception ex1)
                {
                    Logger?.LogError(ex1, "Failed to parse jwt");
                }

            Logger?.LogError(ex, $"{caller} by '{clientIdStr}' using '{Request.Headers["User-Agent"]}'");
            return ToJson(RequestResult.CreateError(ex, ReturnExceptions), RequestResult.StatusCode(ex));
        }
    }
}