﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using balancer_service.Controllers;
using balancer_service.Functionality;
using balancer_service.Objects;
using BalancerModels;
using CS.Balance;
using Fintarget.Infrastructure.SecurityCache;
using Fintarget.Infrastructure.TestClients;
using LinqToDB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NLib.Caching;
using PS.Models;
using ServiceBase;

namespace portfolio_service.Controllers
{
    [Route("api/portfolio-service/v1")]
    [ApiController]
    public class PortfolioController
        : BaseAuthController
    {
        private readonly ICache _cache;
        private readonly PortfolioModel _model;
        private readonly MultiOrdersApiConfig _multiOrdersApiConfig;
        private readonly ISecurityCache _securityCache;

        public PortfolioController(IServiceProvider serviceProvider,
            IOptions<MultiOrdersApiConfig> multiOrdersApiConfig,
            IOptions<AuthorizationConfig> authorizationConfig,
            ISecurityCache securityCache,
            ICacheService cacheService,
            ITestClientsRepository testClientsRepository,
            ILogger<PortfolioController> logger)
            : base(serviceProvider, testClientsRepository, authorizationConfig, logger)
        {
            _securityCache = securityCache;
            _multiOrdersApiConfig = multiOrdersApiConfig.Value;
            ReturnExceptions = _multiOrdersApiConfig.ReturnExceptions;

            _model = new PortfolioModel();
            _cache = cacheService.Cache;
        }

        /// <summary>
        ///     GET api/portfolio-service/v1
        ///     Возвращает информацию о версии сервиса
        /// </summary>
        /// <returns>Строка версии</returns>
        /// <response code="200">Успешно</response>
        /// <response code="500">Что-то пошло не так</response>
        [HttpGet]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(500)]
        public ActionResult<string> GetVersion()
        {
            return $"Fintarget PORTFOLIO service v1/{GetType().Assembly.GetName().Version}";
        }

        /// <summary>
        ///     GET api/portfolio-service/v1/portfolios
        ///     Возвращает список портфелей
        /// </summary>
        /// <returns>Список портфелей</returns>
        /// <response code="200">Успешно</response>
        /// <response code="500">Что-то пошло не так</response>
        [HttpGet("portfolios")]
        [ProducesResponseType(typeof(RequestResult<PortfolioDto[]>), 200)]
        [ProducesResponseType(500)]
        public async Task<IActionResult> GetPortfolios()
        {
            try
            {
                var result = await _cache.GetOrAdd("v1.PortfolioController.list", GetPortfoliosIntAsync, _multiOrdersApiConfig.PortfolioListCacheLifeTime);
                if (!IsTester())
                    result = result
                        .Where(p => p.Active);

                TryGetClientId(out var clientId);
                await _model.PortfolioListRequestedAsync(clientId, Request.Headers["User-Agent"]);

                return Success(result);
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private async Task<IEnumerable<PortfolioDto>> GetPortfoliosIntAsync(CancellationToken cancellationToken)
        {
            Portfolio[] portfolios;
            using (var db = new PortfolioDatabase())
            {
                var query = (IQueryable<Portfolio>)db
                    .Portfolios
                    .LoadWith(p => p.Positions)
                    .LoadWith(p => p.SecurityForecastsSource);

                portfolios = await query
                    .OrderBy(c => c.OrderNum)
                    .ToArrayAsync(cancellationToken);
            }

            Dictionary<(string SecurityKey, int SourceId), decimal> forecasts;
            using (var db = new PortfolioDatabase())
            {
                forecasts = await db.SecurityForecasts.ToDictionaryAsync(c => (c.SecurityKey, c.SourceId), c => c.Forecast, cancellationToken);
            }

            var result = new List<PortfolioDto>(portfolios.Length);
            foreach (var portfolio in portfolios)
            {
                portfolio.Positions = portfolio.Positions.Where(c => c.Weight > 0).ToArray();
                if (portfolio.Positions.Length < 2) continue;
                try
                {
                    var strategy = await StrategyCreators.CreateStrategy(portfolio, _securityCache, _multiOrdersApiConfig.PricesMultiplier);

                    var balancer = GetService<PortfolioBalancer>();
                    var minBalance = balancer.CalcMinSum(strategy);
                    var dto = CreatePorfolioDto(portfolio);
                    dto.MinBalance = balancer.BalanceClientToMatchStrategy(new PortfolioClient(minBalance), strategy).Sum(c => c.AvgPrice * c.Number);
                    dto.Forecast = portfolio.Positions.Sum(c =>
                        forecasts.TryGetValue((c.SecurityKey, portfolio.ForecastSourceId), out var forecast) ? c.Weight * forecast : 0);
                    dto.ForecastDisclaimer = portfolio.SecurityForecastsSource?.Disclaimer;
                    dto.ForecastTitle = portfolio.SecurityForecastsSource?.Title;
                    result.Add(dto);
                }
                catch (Exception ex)
                {
                    NLib.Logger.MonitoringService.Log($"Failed to instantiate portfolio {portfolio.Name} ({portfolio.Id}");
                    Logger.LogError(ex, $"Failed to instantiate portfolio {portfolio.Name} ({portfolio.Id}");
                }
            }

            return result;
        }

        private PortfolioDto CreatePorfolioDto(Portfolio p)
        {
            return new PortfolioDto
            {
                Id = p.Id,
                Active = p.Active,
                Annotation = p.Annotation,
                Currency = p.Currency,
                Description = p.Description,
                ImageUrl = p.ImageUrl,
                Name = p.Name,
                OrderNum = p.OrderNum,
                ReadyForIIS = p.ReadyForIIS,
                SecurityForecastsSource = p.SecurityForecastsSource != null
                    ? new SecurityForecastsSourceDto
                    {
                        Id = p.SecurityForecastsSource.Id,
                        Disclaimer = p.SecurityForecastsSource.Disclaimer,
                        Name = p.SecurityForecastsSource.Name,
                        Title = p.SecurityForecastsSource.Title
                    }
                    : null,
                Positions = p.Positions.OrderBy(c => c.OrderNum).Select(c => new PositionShort
                {
                    SecurityKey = c.SecurityKey,
                    Weight = c.Weight,
                    OrderNum = c.OrderNum
                }).ToArray()
            };
        }
        /*
/// <summary>
/// GET api/portfolio-service/v1/portfolio/<id>
/// Возвращает состав портфеля
/// </summary>
/// <returns>Состав портфеля</returns>
/// <response code="200">Успешно</response>
/// <response code="500">Что-то пошло не так</response>
[HttpGet("portfolio/{id}")]
[ProducesResponseType(typeof(RequestResult<Portfolio>), 200)]
[ProducesResponseType(500)]
public async Task<IActionResult> GetPortfolio(Guid id)
{
try
{
using (var db = new PortfolioDatabase())
{
   var portfolio = await db
           .Portfolios
           .Where(p => p.Id == id && p.Active)
           .FirstOrDefaultAsync();
   if (portfolio == null)
   {
       throw new Exception("Portfolio not found");
   }

   portfolio.Positions = await db.PortfolioPositions
       .Where(c => c.PortfolioId == id)
       .OrderBy(c => c.OrderNum).ToArrayAsync();

   return Success(portfolio);
}
}
catch (Exception ex)
{
return Error(ex);
}
}*/
    }
}