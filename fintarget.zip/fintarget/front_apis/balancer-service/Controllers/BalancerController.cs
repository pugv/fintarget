﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Api.Models;
using ApiHelpers;
using ApiHelpers.Dto;
using balancer_service.Functionality;
using balancer_service.Objects;
using BalancerModels;
using CS.Balance;
using CS.Balance.Interfaces;
using ExchangeHelpers;
using ExchangeHelpers.LS;
using Fintarget.Infrastructure.SecurityCache;
using Fintarget.Infrastructure.TestClients;
using LinqToDB;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PS.Models;
using ServiceBase;
using Client = LS.Api.Client;
using FormFormat = BalancerModels.FormFormat;

namespace balancer_service.Controllers
{
    [Route("api/balancer-service/v1")]
    [ApiController]
    public sealed class BalancerController : BaseAuthController, IDisposable
    {
        private readonly MultiOrdersApiConfig _config;
        private readonly HttpClient _httpClient;
        private readonly Client _lsClient;
        private readonly MessagingConfig _messagingConfig;
        private readonly SMS.ApiClient.Api _messagingHelper;
        private readonly PortfolioModel _model;
        private readonly IMultiOrdersApi _multiOrdersHelper;
        private readonly ISecurityCache _securityCache;

        public BalancerController(IServiceProvider serviceProvider,
            IOptions<MultiOrdersApiConfig> multiOrdersApiConfig,
            IOptions<AuthorizationConfig> authorizationConfig,
            IOptions<MessagingConfig> messagingConfig,
            InterfaceResolver<IMultiOrdersApi> multiOrdersApiResolver,
            ISecurityCache securityCache,
            Client lsClient,
            ITestClientsRepository testClientsRepository,
            ILogger<BalancerController> logger)
            : base(serviceProvider, testClientsRepository, authorizationConfig, logger)
        {
            _config = multiOrdersApiConfig.Value;
            if (_config.PricesMultiplier == 0) throw new Exception("Portfolio price multiplier should be positive!");
            _securityCache = securityCache;
            _lsClient = lsClient;
            _authorizationConfig = authorizationConfig.Value;
            _messagingConfig = messagingConfig.Value;
            ReturnExceptions = _config.ReturnExceptions;
            _httpClient = new HttpClient
            {
                Timeout = TimeSpan.FromSeconds(30)
            };

            _multiOrdersHelper = multiOrdersApiResolver[_config.MultiOrdersService];

            _messagingHelper = new SMS.ApiClient.Api(_messagingConfig.Host, _messagingConfig.Port);

            _model = new PortfolioModel();
        }

        public void Dispose()
        {
            _httpClient?.Dispose();
            _messagingHelper?.Dispose();
        }

        /// <summary>
        ///     GET api/balancer-service/v1
        ///     Возвращает информацию о версии сервиса
        /// </summary>
        /// <returns>Строка версии</returns>
        /// <response code="200">Успешно</response>
        /// <response code="500">Что-то пошло не так</response>
        [HttpGet]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(500)]
        public ActionResult<string> GetVersion()
        {
            return $"Fintarget BALANCER service v1/{GetType().Assembly.GetName().Version}";
        }

        /// <summary>
        ///     Возвращает список счетов клиента, не подключенных к автоследованию, упорядоченный  по остатку в указанной валюте
        /// </summary>
        /// <returns></returns>
        [HttpGet("clientAccounts")]
        [ProducesResponseType(typeof(RequestResult<ShortClientAccount[]>), 200)]
        [ProducesResponseType(500)]
        [Authorize]
        public async Task<ActionResult> ClientAccounts()
        {
            try
            {
                if (!TryGetClientId(out _)) return Unauthorized();
                var accounts = await GetAccounts();

                return Success(accounts.Select(c => new ShortClientAccount
                {
                    AgreementId = c.AgreementId,
                    AgreementTitle = c.AgreementName,
                    ClientCode = c.ClientCode,
                    ClientTariffId = c.ClientTariffId,
                    CurrencyPortfolios = new ClientAccountPortfolio[0],
                    InvestmentAdviceAgreementDate = c.InvestmentAdviceAgreementDate,
                    IsQualifiedInvestor = c.IsQualifiedInvestor,
                    LimitsTime = c.LimitsTime,
                    Profile = c.Profile,
                    ProfileDate = c.ProfileDate,
                    ProfileId = c.ProfileId,
                    Service = c.Service,
                    State = c.State,
                    Status = c.Status.ToString()
                }).ToArray());
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        /// <summary>
        ///     GET api/balancer-service/v1/balance
        ///     Балансирует указанную сумму по указанному портфелю
        ///     Предельная сумма определяется следующим образом:
        ///     Иначе если указан agreementId - используется свободная сумма на данном счету
        ///     Иначе - используется счет с максимальной свободной суммой
        ///     Если данная сумма меньше минимальной стоимости портфеля, или к счету подключено автоследование - используется минимальная стоимость портфеля
        /// </summary>
        /// <returns>Сбалансированный на указанную сумму портфель  в <see cref="RequestResult{T}" />&lt;BalancedPortfolio&gt;</returns>
        /// <response code="200">Успешно</response>
        /// <response code="500">Что-то пошло не так</response>
        [HttpGet("balance")]
        [ProducesResponseType(typeof(RequestResult<BalancedPortfolio>), 200)]
        [ProducesResponseType(500)]
        [Authorize]
        public async Task<ActionResult> Balance(Guid portfolioId, decimal freeFunds)
        {
            try
            {
                var portfolio = await GetPortfolioAsync(portfolioId);

                if (portfolio == null) throw new Exception($"Портфель {portfolioId} не найден");
                portfolio.Positions = portfolio.Positions.Where(c => c.Weight > 0).ToArray();
                if (portfolio.Positions.Length < 2) throw new Exception("Portfolio should contain at least 2 securities with positive weights");

                var strategy = await StrategyCreators.CreateStrategy(portfolio, _securityCache, _config.PricesMultiplier);

                return Success(await BalanceByStrategyAsync(portfolioId, strategy, freeFunds, freeFunds, true));
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        /// <summary>
        ///     Рассчитывает портфель в соответствии с переданными в запросе весами
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("balance-weighted")]
        [ProducesResponseType(typeof(RequestResult<BalancedPortfolio>), 200)]
        [ProducesResponseType(500)]
        [Authorize]
        public async Task<ActionResult> BalanceWeighted(WeightedBalanceRequest request)
        {
            try
            {
                var strategy = await StrategyCreators.CreateStrategyAsync(request.Positions, _securityCache, _config.PricesMultiplier);

                return Success(await BalanceByStrategyAsync(request.PortfolioId, strategy, request.FreeFunds, request.ExpectedValue, false));
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        /// <summary>
        ///     Рассчитывает портфель, в соответствии с переданными в запросе количествами
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost("calc-weighted")]
        [ProducesResponseType(typeof(RequestResult<BalancedPortfolio>), 200)]
        [ProducesResponseType(500)]
        [Authorize]
        public async Task<ActionResult> CalcWeighted(CalcWeightedRequest request)
        {
            try
            {
                var (strategy, balanced) = await CreateStrategy(request.Positions);

                return Success(await RecalcByQtyAsync(request.PortfolioId, strategy, request.FreeFunds, balanced));
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [HttpPost("create-execution-request")]
        [ProducesResponseType(typeof(RequestResult<Guid>), 200)]
        [ProducesResponseType(500)]
        [Authorize]
        public async Task<ActionResult> CreateExecutionRequest(CreateExecutionRequest request)
        {
            try
            {
                var positions = new List<ExecutionRequestPosition>(request?.Positions?.Length ?? 0);
                var index = 0;
                var sumInRubles = 0m;
                foreach (var position in request?.Positions ?? Array.Empty<ExecuteRequestPosition>())
                {
                    if (position.PriceVal <= 0) throw new Exception($"Following position has non positive price: {position}");
                    if (position.Qty < 0) throw new Exception($"Following position has negative quantity: {position}");
                    if (position.Qty == 0) continue;
                    var securityInfo = await _securityCache.GetSecurityAsync(position.SecurityKey);
                    if (position.Qty % securityInfo.LotSize != 0)
                        throw new Exception($"Following position has quanitity that is not multiple of lot size ({securityInfo.LotSize}): {position}");
                    var orderPrice = securityInfo.GetOrderPrice(position.PriceVal);
                    orderPrice -= orderPrice % securityInfo.PriceStep;

                    sumInRubles += (await _securityCache.ConvertCurrencyAsync(securityInfo.Currency, "SUR", _config.PricesMultiplier) ?? 0) * position.Qty *
                                   position.PriceVal;

                    positions.Add(new ExecutionRequestPosition
                    {
                        OrderId = index,
                        SecurityKey = position.SecurityKey,
                        Quantity = position.Qty,
                        Price = position.PriceVal,
                        OrderPrice = orderPrice
                    });
                    index++;
                }

                if (positions.Count == 0) throw new Exception("There should be at least one positive quantity in positions list");

                var minBalance = await CalcMinBalance(request.PortfolioId);

                var packetOrderId = await _model.CreateExecutionRequestAsync(new ExecutionRequest
                {
                    AgreementId = request.AgreementId,
                    Created = DateTime.Now,
                    PortfolioId = request.PortfolioId,
                    MinBalance = minBalance,
                    HistoryRecordId = await _model.LastRequestIdAsync(request.PortfolioId, GetClientId()),
                    ExecutionRequestPositions = positions,
                    SumInRubles = sumInRubles
                });

                var moRequest = new CreateMultiOrderRequest
                {
                    PacketOrderId = packetOrderId.ToString(),
                    AgreementId = request.AgreementId,
                    SubaccountCode = "0MAIN",
                    SmsSource = "BCS Broker",
                    Orders = positions.Select(c =>
                        new Order
                        {
                            TypeOfOrder = TypeOfOrder.Limit,
                            OrderId = c.OrderId.ToString(),
                            Ticker = c.SecurityKey.Split(' ')[0],
                            Price = c.OrderPrice,
                            Side = Side.Buy,
                            Quantity = c.Quantity,
                            ExDestination = c.SecurityKey.Split(' ')[1]
                        }).ToList()
                };

                Logger.LogInformation($"Creating multiorder: {request}");
                var executionRequestId = await _multiOrdersHelper.CreateMultiOrderAsync(moRequest);

                await _model.UpdateExecutionRequestIdAsync(packetOrderId, executionRequestId);

                if (_config.CallConfirmAfterCreate) await _multiOrdersHelper.ConfirmMultiOrderAsync(executionRequestId, null);
                return Success(executionRequestId);
            }
            catch (ApiException ex)
            {
                return Error(ex.InnerException ?? ex);
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        private async Task<decimal> CalcMinBalance(Guid portfolioId)
        {
            var portfolio = await GetPortfolioAsync(portfolioId);

            if (portfolio == null) throw new Exception($"Портфель {portfolioId} не найден");
            portfolio.Positions = portfolio.Positions.Where(c => c.Weight > 0).ToArray();
            if (portfolio.Positions.Length < 2) throw new Exception("Portfolio should contain at least 2 securities with positive weights");

            var strategy = await StrategyCreators.CreateStrategy(portfolio, _securityCache, _config.PricesMultiplier);
            var balancer = GetService<PortfolioBalancer>();
            var minValue = balancer.CalcMinSum(strategy);
            minValue = balancer.BalanceClientToMatchStrategy(new PortfolioClient(minValue), strategy).Sum(c => c.AvgPrice * c.Number);
            return minValue;
        }

        [HttpPost("confirm-execution-request")]
        [ProducesResponseType(typeof(RequestResult<bool>), 200)]
        [ProducesResponseType(500)]
        [Authorize]
        public async Task<ActionResult> ConfirmExecutionRequest(Guid executionRequestId, string smsCode, CancellationToken cancellationToken)
        {
            try
            {
                Logger.LogInformation($"Confirming order with id {executionRequestId}");
                var clientAccounts = new ClientAccountDto[0];
                try
                {
                    clientAccounts = await _lsClient.GetClient(GetClientId());
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex, $"Failed to get client limits for {GetClientId()}");
                }

                await _multiOrdersHelper.ConfirmMultiOrderAsync(executionRequestId, smsCode);
                _model.Puchased(executionRequestId, clientAccounts);

                var (portfolioName, sum, agreementId) = _model.GetExecutionInfo(executionRequestId);
                TryGetClientName(out var name);
                await _messagingHelper.SendEmailsAsync(new[]
                {
                    new Email
                    {
                        Sender = _messagingConfig.InfoEmail,
                        Address = _messagingConfig.InfoEmail,
                        BodyType = "text/plain; charset=UTF-8",
                        Subject = $"Покупка портфеля '{portfolioName}'",
                        Body = $"Клиент {name} ({{{GetClientId()}}}) генсог {{{agreementId}}} купил портфель '{portfolioName}' на сумму {sum:n2}"
                    }
                }, cancellationToken);
                return Success(true);
            }
            catch (ApiException ex)
            {
                return Error(ex.InnerException ?? ex);
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [HttpGet("check-execution-request")]
        [ProducesResponseType(typeof(RequestResult<CheckExecutionReportResponse>), 200)]
        [ProducesResponseType(500)]
        [Authorize]
        public async Task<ActionResult> CheckExecutionRequest(Guid executionRequestId)
        {
            try
            {
                Logger.LogInformation($"Checking status of order with id {executionRequestId}");
                var status = await _multiOrdersHelper.CheckStatusAsync(executionRequestId);

                return Success(new CheckExecutionReportResponse
                {
                    PacketOrderId = status.PacketOrderId,
                    Orders = status.Orders
                        .Select(c => new CheckExecutionReportResponse.OrderInfo
                        {
                            OrderId = c.OrderId,
                            Status = c.Status,
                            OrderNum = c.OrderNum,
                            Text = c.Text
                        }).ToArray()
                });
            }
            catch (ApiException ex)
            {
                return Error(ex.InnerException ?? ex);
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [HttpPost("resend-sms")]
        [ProducesResponseType(typeof(RequestResult<bool>), 200)]
        [ProducesResponseType(500)]
        [Authorize]
        public async Task<ActionResult> ResendSms(Guid executionRequestId)
        {
            try
            {
                Logger.LogInformation($"Resending SMS code with id {executionRequestId}");
                await _multiOrdersHelper.ResendSmsAsync(executionRequestId);
                return Success(true);
            }
            catch (ApiException ex)
            {
                return Error(ex.InnerException ?? ex);
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }

        [HttpPost("generate-form")]
        [ProducesResponseType(typeof(RequestResult<GenerateFormResponse>), 200)]
        [ProducesResponseType(500)]
        [Authorize]
        public async Task<ActionResult> GenerateForm(Guid executionRequestId, FormFormat formFormat)
        {
            try
            {
                Logger.LogTrace($"Generating {formFormat} form for request with id {executionRequestId}");

                var result = await _multiOrdersHelper.GenerateFormAsync(executionRequestId,
                    formFormat == FormFormat.Pdf ? ApiHelpers.FormFormat.Pdf : ApiHelpers.FormFormat.Html);

                return Success(new GenerateFormResponse { FileName = result.FileName, FileData = result.FileData });
            }
            catch (ApiException ex)
            {
                return Error(ex.InnerException ?? ex);
            }
            catch (Exception ex)
            {
                return Error(ex);
            }
        }


        private async Task<BalancedPortfolio> BalanceByStrategyAsync(Guid portfolioId, IStrategyInfo strategy, decimal freeFunds, decimal expectedValue,
            bool initialBalancing)
        {
            var correctedFreeFunds = freeFunds * _config.FreeFundsMultiplier;
            if (expectedValue < 0 && freeFunds > 0) throw new Exception($"expectedValue ({expectedValue}) should be non negative");
            var balancer = GetService<PortfolioBalancer>();
            var minValue = balancer.CalcMinSum(strategy);
            minValue = balancer.BalanceClientToMatchStrategy(new PortfolioClient(minValue), strategy).Sum(c => c.AvgPrice * c.Number);

            var targetValue = correctedFreeFunds;
            if (!initialBalancing && expectedValue < correctedFreeFunds) targetValue = expectedValue;
            targetValue = Math.Max(minValue, targetValue);

            var balanced = balancer.BalanceClientToMatchStrategy(new PortfolioClient(targetValue), strategy);
            var value = balanced.Sum(c => c.Number * c.AvgPrice);

            var fullBalanced = balanced;
            if (targetValue < correctedFreeFunds) fullBalanced = balancer.BalanceClientToMatchStrategy(new PortfolioClient(correctedFreeFunds), strategy);
            var fullValue = fullBalanced.Sum(c => c.Number * c.AvgPrice);

            var balancedPorfolio = new BalancedPortfolio
            {
                Value = value,
                TargetValue = targetValue,
                MinValue = minValue,
                AvailableValue = fullValue - value,
                FreeFunds = freeFunds,
                PortfolioId = portfolioId
            };
            Dictionary<string, decimal> forecasts;
            using (var db = new PortfolioDatabase())
            {
                forecasts = (from f in db.SecurityForecasts
                        join p in db.Portfolios on f.SourceId equals p.ForecastSourceId
                        where p.Id == portfolioId &&
                              balanced.Select(b => b.SecurityKey).Contains(f.SecurityKey)
                        select f)
                    .ToDictionary(c => c.SecurityKey, c => c.Forecast);
            }

            var balancedPositions = new List<Position>();
            foreach (var position in balanced)
            {
                var securityInfo = await _securityCache.GetSecurityAsync(position.SecurityKey);

                balancedPositions.Add(new Position
                {
                    SecurityKey = position.SecurityKey,
                    Name = securityInfo.Name,
                    PriceVal = position.AvgPrice,
                    Qty = (int)position.Number,
                    Weight = strategy.Positions[position.SecurityKey].Weight,
                    MaxQty = (int)(Math.Round(correctedFreeFunds / position.AvgPrice / securityInfo.LotSize) * securityInfo.LotSize),
                    MaxAvailableQty = (int)(position.Number + (correctedFreeFunds > value
                        ? Math.Floor((correctedFreeFunds - value) / position.AvgPrice / securityInfo.LotSize) * securityInfo.LotSize
                        : 0)),
                    Forecast = forecasts.TryGetValue(position.SecurityKey, out var forecast) ? forecast : 0,
                    LotSize = securityInfo.LotSize,
                    Currency = securityInfo.Currency
                });
            }

            balancedPorfolio.Positions = balancedPositions.ToArray();
            balancedPorfolio.Forecast = balancedPorfolio.Positions.Sum(c => c.Weight * c.Forecast);

            // MyBroker as at 05.06.2020 doesn't use balance anymore. Initial balancing is performed with equal freeFunds and expectedValue
            if (initialBalancing || freeFunds == expectedValue)
            {
                decimal? liquidPrice = null;
                await _model.BalanceRequestedAsync(portfolioId, GetClientId(), freeFunds, liquidPrice, Request.Headers["User-Agent"]);
            }
            else
            {
                await _model.RebalanceRequestedAsync(portfolioId, GetClientId());
            }

            return balancedPorfolio;
        }

        private async Task<BalancedPortfolio> RecalcByQtyAsync(Guid portfolioId, IStrategyInfo strategy, decimal freeFunds,
            IEnumerable<IClientAccountPosition> balanced)
        {
            var correctedFreeFunds = freeFunds * _config.FreeFundsMultiplier;
            var balancer = GetService<PortfolioBalancer>();
            var minValue = balancer.CalcMinSum(strategy);
            minValue = balancer.BalanceClientToMatchStrategy(new PortfolioClient(minValue), strategy).Sum(c => c.AvgPrice * c.Number);

            var value = balanced.Sum(c => c.Number * c.AvgPrice);
            //            (var targetValue, var targetAgreementId, var freeFunds, var liquidPrice) = await CalcTargetValueAsync(minValue, agreementId, strategy.Currency, value);

            var fullBalanced = balanced;
            if (value < correctedFreeFunds) fullBalanced = balancer.BalanceClientToMatchStrategy(new PortfolioClient(correctedFreeFunds), strategy);
            var fullValue = fullBalanced.Sum(c => c.Number * c.AvgPrice);

            var balancedPorfolio = new BalancedPortfolio
            {
                Value = value,
                TargetValue = value,
                MinValue = minValue,
                AvailableValue = fullValue - value,
                FreeFunds = freeFunds,
                PortfolioId = portfolioId
            };
            Dictionary<string, decimal> forecasts;
            using (var db = new PortfolioDatabase())
            {
                forecasts = (from f in db.SecurityForecasts
                        join p in db.Portfolios on f.SourceId equals p.ForecastSourceId
                        where p.Id == portfolioId &&
                              balanced.Select(b => b.SecurityKey).Contains(f.SecurityKey)
                        select f)
                    .ToDictionary(c => c.SecurityKey, c => c.Forecast);
            }

            var balancedPositions = new List<Position>();
            foreach (var position in balanced)
            {
                var securityInfo = await _securityCache.GetSecurityAsync(position.SecurityKey);
                balancedPositions.Add(new Position
                {
                    SecurityKey = position.SecurityKey,
                    Name = securityInfo.Name,
                    PriceVal = position.AvgPrice,
                    Qty = (int)position.Number,
                    Weight = strategy.Positions[position.SecurityKey].Weight,
                    MaxQty = (int)(Math.Round(correctedFreeFunds / position.AvgPrice / securityInfo.LotSize) * securityInfo.LotSize),
                    MaxAvailableQty = (int)(position.Number + (correctedFreeFunds > value
                        ? Math.Floor((correctedFreeFunds - value) / position.AvgPrice / securityInfo.LotSize) * securityInfo.LotSize
                        : 0)),
                    Forecast = forecasts.TryGetValue(position.SecurityKey, out var forecast) ? forecast : 0,
                    LotSize = securityInfo.LotSize,
                    Currency = securityInfo.Currency
                });
            }

            balancedPorfolio.Positions = balancedPositions.ToArray();
            balancedPorfolio.Forecast = balancedPorfolio.Positions.Sum(c => c.Weight * c.Forecast);

            await _model.RebalanceRequestedAsync(portfolioId, GetClientId());

            return balancedPorfolio;
        }

        private async Task<ClientAccount[]> GetAccounts()
        {
            using var db = new Database();

            var clientId = GetClientId();

            var accounts = await db.ClientAccounts.Where(c => c.ClientId == clientId && c.CloseDate == null).OrderBy(c => c.AgreementStartDate).ToArrayAsync();

            if (accounts.Length > 0) return accounts;

            _httpClient.BaseAddress = new Uri(_config.FintargetApiUrl);
            var result = await GetAsync("api/account/clientaccounts",
                null, c => JsonConvert.DeserializeObject<ApiRequestResult<ClientAccount[]>>(c));

            if (!result.Success) throw new Exception($"Failed to get client account info - {result.ErrorCode}: {result.ErrorMessage}");
            return result.Response.OrderBy(c => c.AgreementStartDate).ToArray();
        }

        async Task<T> GetAsync<T>(string method, string queryParams, Func<string, T> responseParser)
        {
            var uri = method;
            if (!string.IsNullOrEmpty(queryParams)) uri += '?' + queryParams;

            Logger?.LogTrace($"Invoking GET {uri}");

            try
            {
                var httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, uri);
                httpRequestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", await HttpContext.GetTokenAsync("access_token"));

                var response = await _httpClient.SendAsync(httpRequestMessage);

                var message = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == HttpStatusCode.GatewayTimeout) throw new Exception("Превышено время ожидания ответа от информационной системы");
                    if (response.StatusCode == HttpStatusCode.Unauthorized) throw new UnauthorizedAccessException("Unauthorized");
                    throw new Exception($"Response code={response.StatusCode} message=|{message ?? "empty"}|rq={_httpClient.BaseAddress}{uri}");
                }

                return responseParser(message);
            }
            catch (Exception ex)
            {
                Logger?.LogError(ex, $"Get|{method}|{ex.Message}");

                throw;
            }
        }

        private async Task<(IStrategyInfo strategy, IEnumerable<IClientAccountPosition> balanced)> CreateStrategy(CalcWeightedPosition[] positions)
        {
            var strat = new PortfolioStrategy();
            var balanced = new List<IClientAccountPosition>();

            foreach (var pos in positions)
            {
                var securityInfo = await _securityCache.GetSecurityAsync(pos.SecurityKey, _config.PricesMultiplier);

                strat.Positions[pos.SecurityKey] =
                    new PortfolioStrategy.PortfolioStrategyPosition(new PortfolioStrategy.PortfolioStrategySecurity(securityInfo), 0);

                if (pos.Qty < 0) throw new Exception($"Negative Qty in {pos}");
                if (securityInfo.LastPrice == null) throw new Exception($"Missing price for {pos}");
                balanced.Add(new PortfolioClient.Position
                {
                    SecurityKey = pos.SecurityKey,
                    AvgPrice = securityInfo.LastPrice.Value,
                    Number = pos.Qty
                });
            }

            var balancer = GetService<PortfolioBalancer>();
            balanced = balancer.TruncateToLots(balanced, strat).ToList();

            var sum = balanced.Sum(c => c.AvgPrice * c.Number);

            if (sum == 0) return (strat, balanced);
            // Recalc weights
            foreach (var pos in balanced)
                strat.Positions[pos.SecurityKey] = new PortfolioStrategy.PortfolioStrategyPosition(
                    strat.Positions[pos.SecurityKey].Security,
                    pos.Number * pos.AvgPrice / sum);
            var steps = balanced.Count;
            while (strat.Positions.Sum(c => c.Value.Weight) < 1 && steps > 0)
            {
                var max = strat.Positions.OrderByDescending(c => c.Value.Weight).First();
                strat.Positions[max.Key] =
                    new PortfolioStrategy.PortfolioStrategyPosition(max.Value.Security, max.Value.Weight + new decimal(1, 0, 0, false, 28));
                steps--;
            }

            while (strat.Positions.Sum(c => c.Value.Weight) > 1 && steps > 0)
            {
                var max = strat.Positions.OrderByDescending(c => c.Value.Weight).First();
                strat.Positions[max.Key] =
                    new PortfolioStrategy.PortfolioStrategyPosition(max.Value.Security, max.Value.Weight - new decimal(1, 0, 0, false, 28));
            }

            return (strat, balanced);
        }


        private async Task<Portfolio> GetPortfolioAsync(Guid portfolioId)
        {
            using (var db = new PortfolioDatabase())
            {
                IQueryable<Portfolio> data = db
                    .Portfolios
                    .LoadWith(p => p.Positions);

                if (!IsTester()) data = data.Where(c => c.Active);

                return await data.FirstOrDefaultAsync(p => p.Id == portfolioId);
            }
        }
    }
}