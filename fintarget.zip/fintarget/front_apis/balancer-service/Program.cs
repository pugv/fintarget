using System.Reflection;
using Mb.Configuration.Vault;
using Mb.Tracing;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using NLib.Extensions.AspNet;

namespace balancer_service
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }
        
        public static IHostBuilder CreateWebHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseStartup<Startup>();
                webBuilder.UseTracing(options =>
                {
                    options.LocalServiceName = Assembly.GetExecutingAssembly().GetName().Name;
                    options.UseTraceIdResponseHeaderMiddleware = true;
                });
                webBuilder.UseVaultSecrets(HttpClientDelegateFactory.CreateWithoutCertValidation());
            });
        }
    }
}