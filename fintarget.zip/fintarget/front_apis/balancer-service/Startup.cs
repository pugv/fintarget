using System.Collections.Generic;
using balancer_service.Objects;
using CS.Balance;
using Fintarget.Infrastructure.SecurityCache;
using LinqToDB.Data;
using LS.Api;
using Mb.Logging;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using NLib.Linq2dbExtensions;

namespace balancer_service
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<MultiOrdersApiConfig>(Configuration.GetSection("MultiOrdersApi"));
            services.Configure<MessagingConfig>(Configuration.GetSection("Messaging"));
            services.Configure<AuthorizationConfig>(Configuration.GetSection("Authorization"));

            services
                //.AddControllers()
                .AddMvc();

            services
                .AddSwaggerGen(options =>
                {
                    options.SwaggerDoc("v1", new OpenApiInfo
                    {
                        Title = "Fintarget PORTFOLIO service",
                        Version = "v1",
                        Description = "Fintarget PORTFOLIO service"
                    });
                });

            services.Configure<SecurityCacheConfig>(Configuration.GetSection("SecurityCacheConfig"));
            services.AddSingleton<SecurityCache>();
            services.AddSingleton<ISecurityCache>(sp => sp.GetRequiredService<SecurityCache>());
            services.AddHostedService(sp => sp.GetRequiredService<SecurityCache>());

            services
                .AddSingleton(new PortfolioBalancer());

            var dbs = new DBSettings(new Dictionary<string, string>
            {
                { Configuration.GetConnectionString("PortfolioService"), "PortfolioService" },
                { Configuration.GetConnectionString("HistoryService"), "HistoryService" }
            });

            var limitsService = new Client(Configuration.GetSection("LimitsService").GetValue<string>("Host"),
                Configuration.GetSection("LimitsService").GetValue<int>("Port"));
            services.AddSingleton(limitsService);

            DataConnection.DefaultSettings = dbs;

            services.AddAuthentication(x =>
                {
                    x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(options =>
                {
                    options.Authority = "https://auth-ext.usvc.bcs.ru/auth/realms/Broker";
                    options.RequireHttpsMetadata = false;
                    options.SaveToken = true;
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        ValidateLifetime = true,
                        ValidateAudience = false,
                        //ValidAudience = "fintarget",
                        ValidateIssuer = true,
                        ValidIssuer = Configuration.GetValue<AuthorizationConfig>("Authorization").ValidIssuer
                    };
                });
            services.AddHealthChecks();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app,
            IWebHostEnvironment env,
            IOptions<MultiOrdersApiConfig> multiOrdersApiConfig)
        {
            if (env.IsDevelopment())
                app.UseDeveloperExceptionPage();
            else
                app.UseHsts();

            app.UseHttpsRedirection();
            //app.UseRouting();

            //app.UseAuthorization();

            app.UseLoggingEndpoint();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/health");
            });

            app.UseSwagger()
                .UseSwaggerUI(c => { c.SwaggerEndpoint("/swagger/v1/swagger.json", "BALANCER API V1"); });
        }
    }
}