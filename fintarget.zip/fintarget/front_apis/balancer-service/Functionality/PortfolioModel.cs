﻿using System;
using System.Linq;
using System.Threading.Tasks;
using ExchangeHelpers.LS;
using LinqToDB;
using PS.Models;

namespace balancer_service.Functionality
{
    internal class PortfolioModel
    {
        internal async Task PortfolioListRequestedAsync(Guid clientId, string userAgent)
        {
            using (var db = new PortfolioDatabase())
            {
                await db.InsertAsync(new HistoryListView
                {
                    ClientId = clientId,
                    RequestDate = DateTime.Now,
                    UserAgent = userAgent?.Substring(0, Math.Min(userAgent.Length, 300))
                });
            }
        }

        internal async Task BalanceRequestedAsync(Guid portfolioId, Guid clientId, decimal freeFunds, decimal? liquidPrice, string userAgent)
        {
            using (var db = new PortfolioDatabase())
            {
                await db.InsertAsync(new HistoryRecord
                {
                    ClientId = clientId,
                    FirstRequest = DateTime.Now,
                    FreeFunds = freeFunds,
                    LastRequest = DateTime.Now,
                    PortfolioId = portfolioId,
                    LiquidPrice = liquidPrice,
                    UserAgent = userAgent?.Substring(0, Math.Min(userAgent.Length, 300))
                });
            }
        }

        internal async Task RebalanceRequestedAsync(Guid portfolioId, Guid clientId)
        {
            using (var db = new PortfolioDatabase())
            {
                await db.HistoryRecords
                    .Where(c => c.PortfolioId == portfolioId && c.ClientId == clientId)
                    .OrderByDescending(c => c.FirstRequest)
                    .Take(1)
                    .Set(c => c.LastRequest, DateTime.Now)
                    .UpdateAsync();
            }
        }

        internal async Task<int?> LastRequestIdAsync(Guid portfolioId, Guid clientId)
        {
            using (var db = new PortfolioDatabase())
            {
                return (await db.HistoryRecords.Where(c => c.PortfolioId == portfolioId && c.ClientId == clientId).OrderByDescending(c => c.FirstRequest)
                    .FirstOrDefaultAsync())?.Id;
            }
        }

        internal async Task<int> CreateExecutionRequestAsync(ExecutionRequest request)
        {
            using (var db = new PortfolioDatabase())
            {
                var packetOrderId = await db.InsertWithInt32IdentityAsync(request);
                foreach (var position in request.ExecutionRequestPositions ?? Enumerable.Empty<ExecutionRequestPosition>())
                {
                    position.PacketOrderId = packetOrderId;
                    await db.InsertAsync(position);
                }

                return packetOrderId;
            }
        }

        internal async Task<int> UpdateExecutionRequestIdAsync(int packetOrderId, Guid executionRequestId)
        {
            using (var db = new PortfolioDatabase())
            {
                return await db.ExecutionRequests.Where(c => c.PacketOrderId == packetOrderId).Set(c => c.ExecutionRequestId, executionRequestId).UpdateAsync();
            }
        }

        internal void Puchased(Guid executionRequestId, ClientAccountDto[] clientAccounts)
        {
            using (var db = new PortfolioDatabase())
            {
                var request = db.ExecutionRequests.LoadWith(c => c.ExecutionRequestPositions)
                    .Where(c => c.ExecutionRequestId == executionRequestId).FirstOrDefault();
                if (request == null) return;
                var account = clientAccounts.FirstOrDefault(c => c.AgreementId == request.AgreementId);
                if (account != null)
                    foreach (var position in request.ExecutionRequestPositions)
                    {
                        var limit = account.Positions?.FirstOrDefault(c => c.SecurityKey == position.SecurityKey);
                        db.ExecutionRequestPositions.Where(c => c.OrderId == position.OrderId && c.PacketOrderId == position.PacketOrderId)
                            .Set(c => c.InitialClientQty, (int)(limit?.Number ?? 0))
                            .Set(c => c.MinReportedQty, c => c.Quantity)
                            .Update();
                    }

                db.ExecutionRequests.Where(c => c.ExecutionRequestId == executionRequestId).Set(c => c.Purchased, true).Update();
            }
        }

        internal (string PortfolioName, decimal? Sum, Guid? agreementId) GetExecutionInfo(Guid executionRequestId)
        {
            using (var db = new PortfolioDatabase())
            {
                var result = (from pos in db.ExecutionRequestPositions
                    join r in db.ExecutionRequests on pos.PacketOrderId equals r.PacketOrderId
                    join p in db.Portfolios on r.PortfolioId equals p.Id
                    where r.ExecutionRequestId == executionRequestId
                    group new { pos, r, p } by new { r.ExecutionRequestId, r.AgreementId, p.Name }
                    into grp
                    select new { PortfolioName = grp.Key.Name, grp.Key.AgreementId, Sum = grp.Sum(c => c.pos.Price * c.pos.Quantity) }).FirstOrDefault();
                return (result?.PortfolioName, result?.Sum, result?.AgreementId);
            }
        }
    }
}