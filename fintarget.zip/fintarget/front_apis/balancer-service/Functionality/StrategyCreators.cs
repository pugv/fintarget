﻿using System;
using System.Linq;
using System.Threading.Tasks;
using balancer_service.Objects;
using BalancerModels;
using CS.Balance.Interfaces;
using Fintarget.Infrastructure.SecurityCache;
using PS.Models;

namespace balancer_service.Functionality
{
    public class StrategyCreators
    {
        /*
                public static async Task<IStrategyInfo> CreateStrategy(PortfolioPosition[] positions)
                {
                    var strat = new PortfolioStrategy();
        
                    foreach (var pos in positions ?? Array.Empty<PortfolioPosition>())
                    {
                        strat.Positions.Add(
                            pos.SecurityKey,
                            new PortfolioStrategy.PortfolioStrategyPosition(
                                await SecurityCache.GetSecurity(pos.SecurityKey),
                                pos.Weight
                            )
                        );
                    }
        
                    return strat;
                }*/

        public static async Task<IStrategyInfo> CreateStrategy(Portfolio portfolio, ISecurityCache securityCache, decimal pricesMultiplier)
        {
            var strat = new PortfolioStrategy(portfolio.Currency);

            foreach (var pos in portfolio.Positions)
                strat.Positions.Add(
                    pos.SecurityKey,
                    new PortfolioStrategy.PortfolioStrategyPosition(
                        new PortfolioStrategy.PortfolioStrategySecurity(await securityCache.GetSecurityAsync(pos.SecurityKey, pricesMultiplier)),
                        pos.Weight
                    )
                );

            return strat;
        }

        public static async Task<IStrategyInfo> CreateStrategyAsync(WeightedPosition[] positions, ISecurityCache securityCache, decimal pricesMultiplier)
        {
            var strat = new PortfolioStrategy();

            var normalizer = positions.Sum(c => c.Weight);

            foreach (var pos in positions)
            {
                if (pos.Weight < 0) throw new Exception($"Position {pos} has negative weight");
                strat.Positions.Add(
                    pos.SecurityKey,
                    new PortfolioStrategy.PortfolioStrategyPosition(
                        new PortfolioStrategy.PortfolioStrategySecurity(await securityCache.GetSecurityAsync(pos.SecurityKey, pricesMultiplier)),
                        normalizer != 0 ? pos.Weight / normalizer : 0m
                    )
                );
            }

            if (normalizer == 0) return strat;

            var steps = positions.Length;
            while (strat.Positions.Sum(c => c.Value.Weight) < 1 && steps > 0)
            {
                var max = strat.Positions.OrderByDescending(c => c.Value.Weight).First();
                strat.Positions[max.Key] =
                    new PortfolioStrategy.PortfolioStrategyPosition(max.Value.Security, max.Value.Weight + new decimal(1, 0, 0, false, 28));
                steps--;
            }

            while (strat.Positions.Sum(c => c.Value.Weight) > 1 && steps > 0)
            {
                var max = strat.Positions.OrderByDescending(c => c.Value.Weight).First();
                strat.Positions[max.Key] =
                    new PortfolioStrategy.PortfolioStrategyPosition(max.Value.Security, max.Value.Weight - new decimal(1, 0, 0, false, 28));
                steps--;
            }

            return strat;
        }
    }
}