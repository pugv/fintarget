﻿using System;
using NLib.Authorization;

namespace balancer_service.Functionality
{
    public class SimpleAuthManager : IOAuthManager
    {
        public string Token { get; set; }

        public bool IsAuthorized => true;

        public string GetOAuthHeader()
        {
            throw new NotImplementedException();
        }

        public string GetTokenValue()
        {
            return Token;
        }
    }
}