import { POP_UP } from '../const';
import { Config$ } from '../effector/configStore';
import { modalApi } from '../effector/modals';
import { AuthenticationService } from '../services/authenticationService';

const FORBIDDEN = 403;
const UNAUTHORIZED = 401;
const NO_CONTENT = 204;

const PROFILE_API = 'https://ent.bcs.ru/ef-proxy/invest-profile-questionnaire/api/v1';

type Config = {
  basePath: string;
  agent: (input: RequestInfo, options: RequestInit) => Promise<Response>;
  errorCatcher: (err: Error) => void;
};

export enum RequestTypes {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  DELETE = 'DELETE',
}

export type Options = {
  headers: Record<string, string>;
  method: RequestTypes;
  body?: string;
};

const config: Config = {
  basePath: '/api/',
  agent: fetch.bind(window),
  errorCatcher: (err: Error) => console.log('log error:', err),
};

const createEndpoint = (endpoint: string) => `${config.basePath}${endpoint}`;
const createProfileEndpoint = (endpoint: string) => `${PROFILE_API}${endpoint}`;
const createOptions: (method: RequestTypes, body?: string) => Options = (method, body) => {
  const defaultOptions = {
    headers: {
      Authorization: AuthenticationService.headerAccessToken,
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'X-App-Name': 'FTWft',
    },
    method,
  };

  if (method === RequestTypes.GET) {
    return defaultOptions;
  }

  return {
    ...defaultOptions,
    body,
  };
};

const checkResponseOk = (response: Response) => {
  if (!response.ok) {
    throw new Error(
      JSON.stringify({
        type: 'api',
        url: response.url,
        status: response.status,
        statusText: response.statusText,
      }),
    );
  }

  return response;
};

const checkAppVersion = (response: Response) => {
  const headerKey = 'X-App-Version';
  const storageKey = 'appVersion';
  const appVersion = response.headers.get(headerKey);
  const currentAppVersion = localStorage.getItem(storageKey);

  if (currentAppVersion && appVersion !== currentAppVersion) {
    localStorage.setItem(storageKey, appVersion as string);
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    window.location.reload(true);
  } else {
    localStorage.setItem(storageKey, appVersion as string);
  }

  return response;
};

const checkResponseCode = (response: Response) => {
  switch (response.status) {
    case NO_CONTENT:
      return new Response('{}');

    default:
      return response;
  }
};

const createRequestByType =
  (type: RequestTypes, isInternal = true) =>
  (endpoint: string, body?: Record<string, unknown>) => {
    const options: Options = createOptions(type, JSON.stringify(body));

    return tryFetch(endpoint, options, isInternal);
  };

const request = (url: string, options: Options, isInternal: boolean) => {
  if (isInternal) {
    return config
      .agent(createEndpoint(url), options)
      .then(checkResponseOk)
      .then(checkAppVersion)
      .then(checkResponseCode)
      .then((res) => res.json());
  }

  return config
    .agent(createProfileEndpoint(url), options)
    .then(checkResponseOk)
    .then(checkResponseCode)
    .then(async (res) => {
      const response = await res.json();
      return { headers: res.headers, response };
    });
};

const tryFetch = async (url: string, options: Options, isInternal: boolean) => {
  try {
    return await request(url, options, isInternal);
  } catch (err) {
    try {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      const status = JSON.parse(err.message).status;
      const inTokenError = status === FORBIDDEN || status === UNAUTHORIZED;

      if (!inTokenError) {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        throw Error(err);
      }

      const token = AuthenticationService.refreshToken;

      if (!token) {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        throw Error(err);
      }

      const result = await refreshToken(token);

      AuthenticationService.accessToken = result?.access_token || '';
      AuthenticationService.refreshToken = result?.refresh_token || '';

      return await request(
        url,
        {
          ...options,
          headers: {
            ...options.headers,
            Authorization: AuthenticationService.headerAccessToken,
          },
        },
        isInternal,
      );
    } catch (err) {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      const status = JSON.parse(err.message).status;
      const inTokenError = status === FORBIDDEN || status === UNAUTHORIZED;

      if (!inTokenError) {
        if (AuthenticationService.accessToken || AuthenticationService.refreshToken) {
          modalApi.show({
            modalId: POP_UP.AUTHORIZATION,
          });
        }
        AuthenticationService.clearAccessToken();
        AuthenticationService.clearRefreshToken();
      }

      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      //@ts-ignore
      config.errorCatcher(err);
      return {
        errorMessage: 'Произошла непредвиденная ошибка',
        success: false,
        response: null,
      };
    }
  }
};

export const get = createRequestByType(RequestTypes.GET);

export const post = createRequestByType(RequestTypes.POST);

export const put = createRequestByType(RequestTypes.PUT);

export const deleteRequest = createRequestByType(RequestTypes.DELETE);

const refreshToken = (token: string) => {
  const conf = Config$.getState();
  const options: Options = {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    method: RequestTypes.POST,
    body:
      `grant_type=refresh_token&refresh_token=${token}&client_id=${conf.clientId}` +
      ((conf.clientSecret && `&client_secret=${conf.clientSecret}`) || ''),
  };

  return config
    .agent(conf.authorizationUrl, options)
    .then(checkResponseOk)
    .then(checkResponseCode)
    .then((res) => res.json())
    .catch(config.errorCatcher);
};

// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
export const auth = (data) => {
  const conf = Config$.getState();
  const options: Options = {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    method: RequestTypes.POST,
    body: data,
  };

  // tslint:disable-next-line:max-line-length
  return config
    .agent(conf.authorizationUrl, options)
    .then(checkResponseOk)
    .then(checkResponseCode)
    .then((res) => res.json())
    .catch(config.errorCatcher);
};

export const profileApi = {
  get: createRequestByType(RequestTypes.GET, false),
  post: createRequestByType(RequestTypes.POST, false),
};
