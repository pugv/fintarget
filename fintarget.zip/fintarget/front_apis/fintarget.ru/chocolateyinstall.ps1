Import-Module IISAdministration
$manager = Get-IISServerManager
# This is for chocolately installer
$toolsDir = "$(Split-Path -Parent $MyInvocation.MyCommand.Definition)"
$binFldr = (Join-Path $toolsDir "..\bin" -Resolve)
$pp = Get-PackageParameters

$sname = "fintarget_preprod"
if ($pp['Name']) { $sname = $pp['Name'] }

Stop-IISSite -Name $sname -Confirm:$false
#$Site = Get-IISSite $sname
#$poolname = $site.Applications[0].ApplicationPoolName
#$pool = $manager.ApplicationPools[$poolname]

#$path = $site.Applications[0].VirtualDirectories[0].PhysicalPath
if ($env:API_P_CONFIG_PATH) { $pp['Config'] = $env:API_P_CONFIG_PATH }

if ($pp['Config'])
{
	Copy-Item -Path (Join-Path $pp['Config'] "*.*") -Destination $binFldr -Force
}

$manager.Sites[$sname].Applications["/"].VirtualDirectories["/"].PhysicalPath = $binFldr 
$manager.CommitChanges()


Start-IISSite -Name $sname
