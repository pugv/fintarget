$sname = "fintarget_preprod"

Stop-IISSite -Name $sname -Confirm:$false