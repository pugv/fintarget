﻿namespace LifeCycleService.ApiClient
{
    public class ChangeSignal : MarketSignal
    {
        public string SecurityKey2 { get; set; }
    }
}