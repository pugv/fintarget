using System;

namespace ES.ApiClient.Dto
{
    public class StrategyResultDto
    {
        public Guid Id { get; set; }
        
        public string Message { get; set; }
    }
}