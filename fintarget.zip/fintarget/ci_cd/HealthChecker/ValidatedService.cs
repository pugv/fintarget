using System;

namespace HealthChecker
{
    internal class ValidatedService
    {
        public string ServiceName { get; set; }
        public Uri Url { get; set; }
    }
}