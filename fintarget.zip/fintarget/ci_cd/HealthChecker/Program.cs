﻿using System;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Dasync.Collections;
using Microsoft.Extensions.Configuration;

namespace HealthChecker
{
    /// <summary>
    ///     Сервис делает http запросы, проверяя статус 200. Возвращает разницу общего кол. от успешных.
    /// </summary>
    internal class Program
    {
        private static readonly int MaxDegreeOfParallelism = Environment.ProcessorCount * 10;

        private static async Task<int> Main(string[] args)
        {
            var configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            var validatedServices = configuration.Get<HealthCheckerOptions>();
            var successRequest = 0;
            using var client = new HttpClient();
            await validatedServices.ValidatedServices.ParallelForEachAsync(async service =>
            {
                try
                {
                    var result = await client.GetAsync(service.Url);
                    if (result.IsSuccessStatusCode)
                        Interlocked.Increment(ref successRequest);
                    else
                        Console.WriteLine($"{service.ServiceName} invalid response");
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Unexpected error while checking: {service.ServiceName}, Exception: {e.Message}");
                }
            }, MaxDegreeOfParallelism);

            return validatedServices.ValidatedServices.Count() - successRequest;
        }
    }
}