using System.Collections.Generic;

namespace HealthChecker
{
    internal class HealthCheckerOptions
    {
        public IEnumerable<ValidatedService> ValidatedServices { get; set; }
    }
}