﻿using System;
using System.IO;
using System.Text.RegularExpressions;

namespace prepareForBuild
{
    internal class Program
    {
        private static int Main(string[] args)
        {
            var path = Directory.GetCurrentDirectory();

            Console.WriteLine("Searching assemblies in " + path);
            var Ver = Environment.GetEnvironmentVariable("BUILD_VERSION");
            if (Ver == null)
            {
                Console.WriteLine("No BUILD_VERSION env");
                return -1;
            }

            Console.WriteLine("Migrate to ver " + Ver);

            foreach (var f in Directory.EnumerateFiles(path, "AssemblyInfo.cs", new EnumerationOptions { RecurseSubdirectories = true }))
            {
                var str = File.ReadAllText(f);
                str = Regex.Replace(str, @"assembly: AssemblyVersion\(""(.+)""\)", d => { return $"assembly: AssemblyVersion(\"{Ver}\")"; });
                str = Regex.Replace(str, @"assembly: AssemblyFileVersion\(""(.+)""\)", d => { return $"assembly: AssemblyFileVersion(\"{Ver}\")"; });

                File.WriteAllText(f, str);
            }

            return 0;
        }
    }
}