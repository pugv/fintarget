USE [MonitoringService]
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (1, N'w3wp', N'Неверный код подтверждения', N'Неверный код подтверждения', 1)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (2, N'TS.CoreConsoleHost', N'InvalidClientCode, неверный код клиента', N'InvalidClientCode', 1)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (2, N'w3wp', N'Соглашение не акцептовано', N'не акцептовано', 2)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (3, N'TS.CoreConsoleHost', N'CreditLimitExceeded не хватает плеча', N'CreditLimitExceeded', 2)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (3, N'w3wp', N'Доп.услуга не доступна для тарифа', N'Доп.услуга не доступна для тарифа', 3)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (4, N'TS.CoreConsoleHost', N'TradingForbiddenForClassCode, код класса запрещен к торговле', N'TradingForbiddenForClassCode', 3)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (4, N'w3wp', N'Невозможно определить Ваш риск-профиль', N'Невозможно определить Ваш риск-профиль', 4)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (5, N'TS.CoreConsoleHost', N'SecurityLimitReached, достигнут лимит по бумаге', N'SecurityLimitReached', 4)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (5, N'w3wp', N'Нет необходимой площадки', N'необходимо подключить площадку', 5)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (6, N'TS.CoreConsoleHost', N'NonPositivePrice, отрицательная цена', N'NonPositivePrice', 5)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (7, N'TS.CoreConsoleHost', N'MoneyLimitExceeded: Превышена позиция по деньгам', N'MoneyLimitExceeded', 6)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (8, N'TS.CoreConsoleHost', N'TransactionLimitExceeded, лимит количества транзакций', N'TransactionLimitExceeded', 7)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (10, N'TS.CoreConsoleHost', N'ShortPositionsAreForbidden, шорты запрещены', N'ShortPositionsAreForbidden', 8)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (11, N'TS.CoreConsoleHost', N'SecurityIsLocked, бумага заблокирована', N'SecurityIsLocked', 9)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (12, N'TS.CoreConsoleHost', N'UnknownSecurity, неизвестная бумага', N'UnknownSecurity', 10)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (13, N'TS.CoreConsoleHost', N'OrderRejectedByExchange, отклонено биржей', N'OrderRejectedByExchange', 11)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (22, N'TS.CoreConsoleHost', N'Вам запрещена работа по данному торговому счету', N'AccountForbidden', 12)
GO
INSERT [dbo].[ErrorCodes] ([Id], [Source], [Description], [Mask], [OrderNum]) VALUES (23, N'TS.CoreConsoleHost', N'По данному инструменту разрешено только закрытие позиции', N'OnlyClosingAllowed', 13)
GO
SET IDENTITY_INSERT [dbo].[HeartbeatSettings] ON 
GO
INSERT [dbo].[HeartbeatSettings] ([Id], [HostName], [Source], [MaxHeartbeatInterval], [CheckHeartbeats]) VALUES (1, N's-follow-app-02', N'TS.CoreConsoleHost', 120000, 1)
GO
INSERT [dbo].[HeartbeatSettings] ([Id], [HostName], [Source], [MaxHeartbeatInterval], [CheckHeartbeats]) VALUES (3, N's-follow-app-02', N'CS.CoreConsoleHost', 120000, 1)
GO
INSERT [dbo].[HeartbeatSettings] ([Id], [HostName], [Source], [MaxHeartbeatInterval], [CheckHeartbeats]) VALUES (4, N's-follow-app-02', N'ES.WinServiceHost', 120000, 1)
GO
INSERT [dbo].[HeartbeatSettings] ([Id], [HostName], [Source], [MaxHeartbeatInterval], [CheckHeartbeats]) VALUES (5, N's-follow-app-02', N'SMS.CoreConsoleHost', 120000, 1)
GO
INSERT [dbo].[HeartbeatSettings] ([Id], [HostName], [Source], [MaxHeartbeatInterval], [CheckHeartbeats]) VALUES (6, N's-follow-app-02', N'FDS.CoreConsoleHost', 120000, 1)
GO
INSERT [dbo].[HeartbeatSettings] ([Id], [HostName], [Source], [MaxHeartbeatInterval], [CheckHeartbeats]) VALUES (7, N's-follow-app-02', N'RMDS.GrpcHost', 120000, 1)
GO
SET IDENTITY_INSERT [dbo].[HeartbeatSettings] OFF
GO
INSERT [dbo].[Sources] ([SourceId], [Name]) VALUES (N'testhost', N'testhost')
GO
INSERT [dbo].[Sources] ([SourceId], [Name]) VALUES (N'TS.CoreConsoleHost', N'Ошибки ТС')
GO
INSERT [dbo].[Sources] ([SourceId], [Name]) VALUES (N'w3wp', N'Ошибки сайта')
GO
