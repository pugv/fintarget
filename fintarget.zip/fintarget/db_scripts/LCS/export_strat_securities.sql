begin
	
	DECLARE @list VARCHAR(MAX) = '', @strat_id uniqueidentifier, @sec_key varchar(64);
	
	DECLARE cur_strategies CURSOR for select id from strategies;
	
	OPEN cur_strategies;

	FETCH NEXT FROM cur_strategies
	INTO @strat_id;

	WHILE @@FETCH_STATUS = 0    
	BEGIN    
		
		DECLARE cur_signals CURSOR for select distinct security_key from signals where strategy_id = @strat_id;
      
		OPEN cur_signals;

		FETCH NEXT FROM cur_signals
		INTO @sec_key;

		set @list = '[';

		WHILE @@FETCH_STATUS = 0    
		BEGIN    

			set @list = @list + '"' + @sec_key + '"';

			FETCH NEXT FROM cur_signals
			INTO @sec_key;
   
			if @@FETCH_STATUS = 0 set @list = @list + ',';
		END    

		set @list = @list + ']';

		print 'update strategies set securities = ''' + @list + ''' where id = ''' + cast(@strat_id as varchar(64)) + ''';';

		CLOSE cur_signals;    
		DEALLOCATE cur_signals;  
		
		FETCH NEXT FROM cur_strategies
		INTO @strat_id;  
	end 

	CLOSE cur_strategies;    
	DEALLOCATE cur_strategies;    
 end