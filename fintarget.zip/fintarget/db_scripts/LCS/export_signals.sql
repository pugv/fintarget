SELECT 'insert into signals (manager_id, type, strategy_id, execution_type, security_key, lots, shares_in_lot, open_price, open_time, is_closed, currency, security_type, margin_buy, margin_sell, open_time_s, weight, save_time, execution_status) values (1,'+
      coalesce(convert(varchar, [type]), 'NULL') + ',''' +
	  convert(varchar(64), [strategy_id]) + ''',' +
      convert(varchar, [execution_type]) + ',''' +
      convert(varchar, [security_key]) + ''',' +
      convert(varchar, [lots]) + ',' +
      convert(varchar, [shares_in_lot]) + ',' +
      convert(varchar,[open_price],113) + ', convert(datetime2, ''' + 
      convert(varchar, [open_time],113) + ''', 113),0,''' +
      [currency] + ''',''' +
      [security_type] + ''',' +
      convert(varchar, [margin_buy]) + ',' +
      convert(varchar, [margin_sell]) + ', convert(datetime2, ''' +
      convert(varchar,[open_time_s],113) + ''', 113),' +
      convert(varchar, [weight]) + ', convert(datetime2, ''' +
      convert(varchar,[save_time],113) + ''', 113),' +
      convert(varchar, [execution_status]) + ');'
  FROM [Signals]
 ORDER BY id