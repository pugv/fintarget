﻿using System;
using System.Net;
using System.Threading.Tasks;
using NLib.Http;

namespace CreateTestData
{
    public class HttpServer : HttpServerBase
    {
        public HttpServer(int httpPort) : base(httpPort)
        {
        }

        protected override Task<(string Response, HttpStatusCode HttpCode)> ProcessRequest(UrlPath url, string body)
        {
            return Task.FromResult(("Ok", HttpStatusCode.OK));
        }
    }
}