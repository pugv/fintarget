# Overview
Linux docker container with SQL server & test DBs with data

## Publish .NET project

```
dotnet publish CreateTestData.csproj -c Release -r linux-x64 --self-contained
```

## Build the image 
Build with `docker build`:
```
docker build . -t fintarget/test-dbs
```

## Run the container

Then spin up a new container using `docker run`
(On Windows first run can be made from Docker UI to allow opening port in Windows Brandmauer)

```
docker run -d fintarget/test-dbs -p 1433:<port>
```
wait 1-2 minutes until console outputs 'Finished creating data'

## Connect

Connect to localhost,<port> with user SA:StrongPassw0rd
