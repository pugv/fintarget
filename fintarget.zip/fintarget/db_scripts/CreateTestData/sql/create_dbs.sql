USE [master]
GO

/****** Object:  Database [CabinetDB]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'CabinetDB')
BEGIN
 DROP DATABASE [CabinetDB]
END 
CREATE DATABASE [CabinetDB]
GO

/****** Object:  Database [ClientService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'ClientService')
BEGIN
 DROP DATABASE [ClientService]
END
CREATE DATABASE [ClientService]
GO

/****** Object:  Database [ExternalService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'ExternalService')
BEGIN
 DROP DATABASE [ExternalService]
END
CREATE DATABASE [ExternalService]
GO

/****** Object:  Database [fintarget]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'fintarget')
BEGIN
 DROP DATABASE [fintarget]
END
CREATE DATABASE [fintarget]
GO

/****** Object:  Database [HistoryService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'HistoryService')
BEGIN
 DROP DATABASE [HistoryService]
END
CREATE DATABASE [HistoryService]
GO

/****** Object:  Database [LifecycleService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'LifecycleService')
BEGIN
 DROP DATABASE [LifecycleService]
END
CREATE DATABASE [LifecycleService]
GO

/****** Object:  Database [MetrixService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'MetrixService')
BEGIN
 DROP DATABASE [MetrixService]
END

CREATE DATABASE [MetrixService]
GO

/****** Object:  Database [MonitoringService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'MonitoringService')
BEGIN
 DROP DATABASE [MonitoringService]
END

CREATE DATABASE [MonitoringService]
GO

/****** Object:  Database [PortfolioService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'PortfolioService')
BEGIN
 DROP DATABASE [PortfolioService]
END

CREATE DATABASE [PortfolioService]
GO

/****** Object:  Database [QuikExport]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'QuikExport')
BEGIN
 DROP DATABASE [QuikExport]
END

CREATE DATABASE [QuikExport]
GO

/****** Object:  Database [QuikExportOrders]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'QuikExportOrders')
BEGIN
 DROP DATABASE [QuikExportOrders]
END

CREATE DATABASE [QuikExportOrders]
GO

/****** Object:  Database [RiskAnalysis]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'RiskAnalysis')
BEGIN
 DROP DATABASE [RiskAnalysis]
END

CREATE DATABASE [RiskAnalysis]
GO

/****** Object:  Database [Sandbox]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'Sandbox')
BEGIN
 DROP DATABASE [Sandbox]
END

CREATE DATABASE [Sandbox]
GO

/****** Object:  Database [SMSService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'SMSService')
BEGIN
 DROP DATABASE [SMSService]
END

CREATE DATABASE [SMSService]
GO

/****** Object:  Database [StatService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'StatService')
BEGIN
 DROP DATABASE [StatService]
END

CREATE DATABASE [StatService]
GO

/****** Object:  Database [TradeService]    Script Date: 24.11.2021 13:47:28 ******/
IF EXISTS(SELECT * FROM sys.databases WHERE name = 'TradeService')
BEGIN
 DROP DATABASE [TradeService]
END

CREATE DATABASE [TradeService]
GO

IF EXISTS(SELECT * FROM sys.databases WHERE name = 'FDS')
BEGIN
 DROP DATABASE [FDS]
END

CREATE DATABASE [FDS]
GO

