/* CS */

/* ES */
USE [ExternalService]
GO
/****** Object:  Table [dbo].[Accounts]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Accounts](
	[Id] [int] NOT NULL,
	[ClientCode] [nvarchar](64) NOT NULL,
	[StrategyId] [uniqueidentifier] NULL,
	[StrategyType] [nvarchar](24) NULL,
	[StrategyName] [nvarchar](64) NULL,
	[MinBalance] [decimal](19, 10) NULL,
	[TariffId] [uniqueidentifier] NULL,
	[Active] [bit] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[UpdateTime] [smalldatetime] NOT NULL,
	[FutCode] [nvarchar](64) NULL,
	[ChangeTime] [datetime] NULL,
	[Phone] [nvarchar](24) NULL,
	[Qual] [bit] NULL,
	[ClientTariffId] [uniqueidentifier] NULL,
	[is_marginal] [bit] NULL,
	[partner_id] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Branches]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Branches](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[branch_code] [uniqueidentifier] NOT NULL,
	[branch_name] [nvarchar](256) NULL,
	[ois_name] [nvarchar](256) NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_branch_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[client_examination]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[client_examination](
	[client_id] [uniqueidentifier] NOT NULL,
	[code] [varchar](64) NOT NULL,
	[status] [int] NOT NULL,
	[timestamp] [datetime2](7) NOT NULL,
 CONSTRAINT [pk_client_exam_client_id] PRIMARY KEY NONCLUSTERED 
(
	[client_id] ASC,
	[code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientPackage](
	[ClientId] [int] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Clients]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Clients](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [uniqueidentifier] NOT NULL,
	[AgreementId] [uniqueidentifier] NOT NULL,
	[ContractNum] [nvarchar](64) NOT NULL,
	[Login] [nvarchar](64) NULL,
	[Sex] [char](1) NULL,
	[FirstName] [nvarchar](64) NULL,
	[LastName] [nvarchar](64) NULL,
	[MiddleName] [nvarchar](64) NULL,
	[Address] [nvarchar](max) NULL,
	[EventTime] [datetime] NOT NULL,
	[UpdateTime] [smalldatetime] NOT NULL,
	[Confirm] [tinyint] NOT NULL,
	[OrgName] [nvarchar](512) NULL,
	[Phone] [varchar](128) NULL,
	[Email] [varchar](512) NULL,
	[ClientCode] [nvarchar](64) NULL,
	[CloseDate] [smalldatetime] NULL,
	[RiskId] [uniqueidentifier] NULL,
	[RiskTime] [datetime2](7) NULL,
	[InvestAdviceAgreementDate] [smalldatetime] NULL,
	[RiskProfileName] [nvarchar](64) NULL,
	[subaccount_main] [UNIQUEIDENTIFIER] NULL,
	[position] [nvarchar](128) NULL,
	[org_register] [tinyint] NULL,
	[org_register_date] [date] NULL,
        [qual] [bit] NULL,
	[is_org] [bit] NOT NULL,
	[org_ogrn] [nvarchar](16) NULL,
	[branch_id] [int] NULL,
	[contract_date] [date] NULL,
 CONSTRAINT [PK_ClientAgreementId] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [AK_ClientAgreementId] UNIQUE NONCLUSTERED 
(
	[ClientId] ASC,
	[AgreementId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientTariffExports]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientTariffExports](
	[AgreementId] [uniqueidentifier] NOT NULL,
	[TariffId] [uniqueidentifier] NULL,
	[Expired] [tinyint] NOT NULL,
 CONSTRAINT [PK_AgreementId] PRIMARY KEY NONCLUSTERED 
(
	[AgreementId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Contacts]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Contacts](
	[ContactId] [uniqueidentifier] NOT NULL,
	[Type] [tinyint] NULL,
	[Sms] [tinyint] NULL,
	[Value] [nvarchar](128) NULL,
	[SaveTime] [smalldatetime] NOT NULL,
 CONSTRAINT [PK_Contacts] PRIMARY KEY NONCLUSTERED 
(
	[ContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ContractPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ContractPackage](
	[ClientId] [int] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[IIRs]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[IIRs](
	[masterId] [uniqueidentifier] NOT NULL,
	[time] [datetime2](7) NOT NULL,
	[iir_id] [bigint] NOT NULL,
	[sent] [bit] NOT NULL,
	[service_type] [tinyint] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[message_agreement]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[message_agreement](
	[client_id] [int] NOT NULL,
	[message_id] [uniqueidentifier] NOT NULL,
	[event_type] [tinyint] NOT NULL,
	[event_time] [datetime2](7) NOT NULL,
	[add] [bit] NOT NULL,
	[order] [smallint] NOT NULL,
	[xpath] [varchar](256) NULL,
	[value] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[message_contract]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[message_contract](
	[client_id] [int] NOT NULL,
	[message_id] [uniqueidentifier] NOT NULL,
	[event_type] [tinyint] NOT NULL,
	[event_time] [datetime2](7) NOT NULL,
	[order] [smallint] NOT NULL,
	[add] [bit] NOT NULL,
	[xpath] [varchar](256) NULL,
	[value] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[message_errors]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[message_errors](
	[client_id] [int] NULL,
	[message_type] [tinyint] NULL,
	[message_id] [uniqueidentifier] NULL,
	[save_time] [datetime2](7) NOT NULL,
	[data] [nvarchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[messages_raw]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[messages_raw](
	[client_id] [int] NOT NULL,
	[general_agreement] [xml] NULL,
	[subject_contract] [xml] NULL,
	[service_change] [xml] NULL,
	[subject] [xml] NULL,
	[qualification] [xml] NULL,
	[trade_advice] [xml] NULL,
	[risk_profile] [xml] NULL,
	[errors] [int] NOT NULL,
	[save_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_messages_client_id] PRIMARY KEY NONCLUSTERED 
(
	[client_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](256) NOT NULL,
	[active] [bit] NOT NULL,
	[min_balance] [decimal](19, 10) NULL,
	[updated] [int] NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK__portfoli__3213E83F804131E8] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_execution]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_execution](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[exec_id] [uniqueidentifier] NOT NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[portfolio_id] [uniqueidentifier] NOT NULL,
	[contract_num] [nvarchar](64) NULL,
	[date] [datetime] NOT NULL,
	[min_balance] [decimal](20, 10) NULL,
	[price] [decimal](20, 10) NOT NULL,
	[confirmed] [bit] NOT NULL,
	[sum_in_rubles] [decimal](20, 10) NOT NULL,
 CONSTRAINT [PK__portfoli__3213E83F4EBD6157] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_execution_position]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_execution_position](
	[id] [int] NOT NULL,
	[exec_id] [int] NOT NULL,
	[symbol] [varchar](64) NOT NULL,
	[price] [decimal](20, 10) NOT NULL,
	[volume] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_leftover]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_leftover](
	[id] [int] NOT NULL,
	[exec_id] [int] NOT NULL,
	[symbol] [varchar](64) NOT NULL,
	[volume] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_leftovers]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_leftovers](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[exec_id] [uniqueidentifier] NOT NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[portfolio_id] [uniqueidentifier] NOT NULL,
	[contract_num] [nvarchar](64) NULL,
	[date] [datetime] NOT NULL,
	[event_id] [uniqueidentifier] NOT NULL,
	[confirmed] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_position]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_position](
	[portfolio_id] [uniqueidentifier] NOT NULL,
	[symbol] [varchar](64) NOT NULL,
	[weight] [decimal](20, 10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[QualPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QualPackage](
	[ClientId] [int] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RiskPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RiskPackage](
	[Id] [int] NOT NULL,
	[ClientId] [uniqueidentifier] NOT NULL,
	[RiskId] [uniqueidentifier] NULL,
	[EventTime] [datetime2](7) NULL,
	[SaveTime] [datetime] NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ServicePackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ServicePackage](
	[ClientId] [int] NOT NULL,
	[ServiceId] [uniqueidentifier] NULL,
	[AgreementId] [uniqueidentifier] NULL,
	[State] [varchar](36) NULL,
	[EventTime] [datetime] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Strategies]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Strategies](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StrategyId] [uniqueidentifier] NOT NULL,
	[StrategyName] [nvarchar](max) NOT NULL,
	[StrategyType] [smallint] NOT NULL,
	[ManagerId] [int] NOT NULL,
	[CreateTime] [datetime2](7) NOT NULL,
	[Confirm] [tinyint] NOT NULL,
	[UpdateTime] [datetime2](7) NOT NULL,
	[state] [tinyint] NOT NULL,
	[strategy_props] [int] NULL,
 CONSTRAINT [FK_StrategyId] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_manager_audit]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_manager_audit](
	[id] [int] NOT NULL,
	[updated] [tinyint] NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [pk_manager_audit_id] PRIMARY KEY NONCLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_manager_info]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_manager_info](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[employee_id] [nvarchar](32) NULL,
	[is_org] [bit] NOT NULL,
	[full_name] [nvarchar](256) NULL,
	[is_insider_fintarget] [bit] NOT NULL,
	[insider_date] [date] NULL,
	[passport_no] [nvarchar](16) NULL,
	[passport_id] [nvarchar](16) NULL,
	[passport_issued_whom] [nvarchar](256) NULL,
	[passport_issued_when] [date] NULL,
	[birth_date] [date] NULL,
	[citizenship] [nvarchar](64) NULL,
	[org_ogrn] [nvarchar](16) NULL,
	[org_inn] [nvarchar](16) NULL,
	[updated] [tinyint] NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
	[event_id] [uniqueidentifier] NOT NULL,
	[agreement_num] [nvarchar](32) NULL,
	[commission] [tinyint] NULL,
	[author_id] [int] NULL,
	[is_representative] [bit] NOT NULL,
	[org_kpp] [nvarchar](16) NULL,
	[parent_id] [int] NULL,
	[state] [tinyint] NOT NULL,
 CONSTRAINT [pk_manager_id] PRIMARY KEY NONCLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [ak_event_id] UNIQUE NONCLUSTERED 
(
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_managers]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_managers](
	[strategy_id] [int] NOT NULL,
	[manager_id] [int] NOT NULL,
	[update_time] [datetime2](7) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SubjectPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SubjectPackage](
	[ClientId] [uniqueidentifier] NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Subscriptions]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Subscriptions](
	[Id] [int] NOT NULL,
	[AgreementId] [uniqueidentifier] NOT NULL,
	[ContractNum] [nvarchar](64) NULL,
	[StrategyType] [smallint] NOT NULL,
	[Status] [tinyint] NOT NULL,
	[Date] [datetime2](7) NULL,
	[EventId] [uniqueidentifier] NOT NULL,
	[Deleted] [bit] NOT NULL,
	[Confirm] [tinyint] NOT NULL,
	[ClientCode] [varchar](64) NOT NULL,
	[FutCode] [varchar](64) NULL,
	[state] [tinyint] NOT NULL,
 CONSTRAINT [PK_EventId] PRIMARY KEY NONCLUSTERED 
(
	[EventId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tmp_contract_bcs_partner]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tmp_contract_bcs_partner](
	[client_id] [int] NOT NULL,
	[event_time] [datetime] NULL,
	[xml_data] [xml] NULL,
	[partner_id] [uniqueidentifier] NULL,
	[partner_name] [nvarchar](256) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TradePackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TradePackage](
	[ClientId] [int] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TradePortfolio]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TradePortfolio](
	[Id] [int] NOT NULL,
	[ClientId] [uniqueidentifier] NOT NULL,
	[AgreementId] [uniqueidentifier] NOT NULL,
	[StrategyId] [uniqueidentifier] NOT NULL,
	[Active] [bit] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[updated] [tinyint] NOT NULL,
 CONSTRAINT [PK_AgreementStrategyId] PRIMARY KEY NONCLUSTERED 
(
	[AgreementId] ASC,
	[StrategyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Clients] ADD  CONSTRAINT [df_is_org]  DEFAULT ((0)) FOR [is_org]
GO
ALTER TABLE [dbo].[ClientTariffExports] ADD  DEFAULT ((0)) FOR [Expired]
GO
ALTER TABLE [dbo].[IIRs] ADD  CONSTRAINT [DF_IIRs_sent]  DEFAULT ((0)) FOR [sent]
GO
ALTER TABLE [dbo].[message_agreement] ADD  DEFAULT ((0)) FOR [add]
GO
ALTER TABLE [dbo].[message_contract] ADD  DEFAULT ((0)) FOR [add]
GO
ALTER TABLE [dbo].[portfolio] ADD  CONSTRAINT [DF__portfolio__updat__02FC7413]  DEFAULT ((0)) FOR [updated]
GO
ALTER TABLE [dbo].[portfolio] ADD  CONSTRAINT [DF__portfolio__updat__03F0984C]  DEFAULT ('1900-01-01') FOR [update_time]
GO
ALTER TABLE [dbo].[portfolio_execution] ADD  CONSTRAINT [DF__portfolio__confi__08B54D69]  DEFAULT ((0)) FOR [confirmed]
GO
ALTER TABLE [dbo].[portfolio_execution] ADD  CONSTRAINT [DF__portfolio__sumIn__1F98B2C1]  DEFAULT ((0)) FOR [sum_in_rubles]
GO
ALTER TABLE [dbo].[portfolio_leftovers] ADD  DEFAULT ((0)) FOR [confirmed]
GO
ALTER TABLE [dbo].[RiskPackage] ADD  DEFAULT ((0)) FOR [Id]
GO
ALTER TABLE [dbo].[Strategies] ADD  DEFAULT ((0)) FOR [ManagerId]
GO
ALTER TABLE [dbo].[Strategies] ADD  DEFAULT ((0)) FOR [Confirm]
GO
ALTER TABLE [dbo].[Strategies] ADD  DEFAULT ((0)) FOR [state]
GO
ALTER TABLE [dbo].[strategy_manager_audit] ADD  DEFAULT ((0)) FOR [updated]
GO
ALTER TABLE [dbo].[strategy_manager_audit] ADD  DEFAULT ('1900-01-01') FOR [update_time]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  DEFAULT ((0)) FOR [is_org]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  DEFAULT ((0)) FOR [is_insider_fintarget]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  DEFAULT ((0)) FOR [updated]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  DEFAULT ('1900-01-01') FOR [update_time]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  CONSTRAINT [df_manager_info_state]  DEFAULT ((0)) FOR [state]
GO
ALTER TABLE [dbo].[Subscriptions] ADD  DEFAULT ((0)) FOR [Status]
GO
ALTER TABLE [dbo].[Subscriptions] ADD  DEFAULT ((0)) FOR [Deleted]
GO
ALTER TABLE [dbo].[Subscriptions] ADD  DEFAULT ((0)) FOR [Confirm]
GO
ALTER TABLE [dbo].[Subscriptions] ADD  CONSTRAINT [df_subscriptions_state]  DEFAULT ((0)) FOR [state]
GO
ALTER TABLE [dbo].[Accounts]  WITH CHECK ADD  CONSTRAINT [FK_Client_Account] FOREIGN KEY([Id])
REFERENCES [dbo].[Clients] ([Id])
GO
ALTER TABLE [dbo].[Accounts] CHECK CONSTRAINT [FK_Client_Account]
GO
ALTER TABLE [dbo].[Clients]  WITH CHECK ADD  CONSTRAINT [fk_branch_id] FOREIGN KEY([branch_id])
REFERENCES [dbo].[Branches] ([id])
GO
ALTER TABLE [dbo].[Clients] CHECK CONSTRAINT [fk_branch_id]
GO
ALTER TABLE [dbo].[portfolio_execution_position]  WITH CHECK ADD  CONSTRAINT [fk_execution] FOREIGN KEY([exec_id])
REFERENCES [dbo].[portfolio_execution] ([id])
GO
ALTER TABLE [dbo].[portfolio_execution_position] CHECK CONSTRAINT [fk_execution]
GO
ALTER TABLE [dbo].[portfolio_leftover]  WITH NOCHECK ADD  CONSTRAINT [fk_leftover] FOREIGN KEY([exec_id])
REFERENCES [dbo].[portfolio_leftovers] ([id])
GO
ALTER TABLE [dbo].[portfolio_leftover] CHECK CONSTRAINT [fk_leftover]
GO
ALTER TABLE [dbo].[portfolio_position]  WITH CHECK ADD  CONSTRAINT [fk_portfolio_position] FOREIGN KEY([portfolio_id])
REFERENCES [dbo].[portfolio] ([id])
GO
ALTER TABLE [dbo].[portfolio_position] CHECK CONSTRAINT [fk_portfolio_position]
GO
ALTER TABLE [dbo].[strategy_managers]  WITH CHECK ADD  CONSTRAINT [fk_strategy_managers_manager_id] FOREIGN KEY([manager_id])
REFERENCES [dbo].[strategy_manager_info] ([id])
GO
ALTER TABLE [dbo].[strategy_managers] CHECK CONSTRAINT [fk_strategy_managers_manager_id]
GO
ALTER TABLE [dbo].[strategy_managers]  WITH CHECK ADD  CONSTRAINT [fk_strategy_managers_strategy_id] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[Strategies] ([Id])
GO
ALTER TABLE [dbo].[strategy_managers] CHECK CONSTRAINT [fk_strategy_managers_strategy_id]
GO

-- replicated from LastingOrderService
IF NOT EXISTS (
	SELECT * FROM sysobjects
	WHERE name='lasting_order_info' AND xtype='U')
CREATE TABLE [dbo].[lasting_order_info] (
	[id] [int] NOT NULL,
	[agreement_id] [UNIQUEIDENTIFIER] NOT NULL,
	[isin] [Varchar](32) NULL,
	[class_code] [Varchar](64) NULL,
	[currency_id] [Varchar](20) NULL,
	[initiator_id] [NVarchar](100) NULL,
	[order_temp_id] [Varchar](100) NULL,
	[processed] [Smallint] NOT NULL DEFAULT(0),
	[save_time] [Datetime2] NOT NULL,
	CONSTRAINT [pk_lasting_order_info] PRIMARY KEY NONCLUSTERED ([id] ASC)
);
GO

-- ES investbox orders
IF NOT EXISTS (
	SELECT * FROM sysobjects
	WHERE name='lasting_order_assignements' AND xtype='U')
CREATE TABLE [dbo].[lasting_order_assignements] (
	[id] [int] identity(1,1) NOT NULL,
	[info_id] [int] NOT NULL,
	[client_id] [int] NOT NULL,
	[correlation_id] [UNIQUEIDENTIFIER] NOT NULL,
	[isin] [nvarchar](32) NOT NULL,
	[class_code] [varchar](64) NOT NULL,
	[currency_code] [nvarchar](16) NOT NULL,
	[initiator_id] [NVarchar](100) NOT NULL,
	[temp_id] [Varchar](100) NOT NULL,
	[guid] [UNIQUEIDENTIFIER] NULL,
	[number] [nvarchar](32) NULL,
	[date] [date] NOT NULL,
	[number_per_day] [int] NULL,
	[close_date] [date] NULL,
	[validity_date] [date] NULL,
	[operation_type] [tinyint] NOT NULL,
	[originator_uid] [int] NOT NULL,
	[comment] [nvarchar](256) NULL,
	[subaccount_guid] [UNIQUEIDENTIFIER] NULL,
	[event_id] [UNIQUEIDENTIFIER] NOT NULL,
	[updated] [int] NOT NULL DEFAULT(0),
	[save_time] [datetime2] NOT NULL,
	[error_id] [nvarchar](256) NULL,
	[error_text] [nvarchar](MAX) NULL,
	[status] [Smallint] NOT NULL DEFAULT(0),
	[processed] [Smallint] NOT NULL DEFAULT(0),
	CONSTRAINT [pk_lasting_order_assignements] PRIMARY KEY NONCLUSTERED ([id] ASC)
);
GO

IF NOT EXISTS(
	SELECT *
	FROM sys.indexes
	WHERE name='ix_lasting_order_assignements_event_id' AND object_id=OBJECT_ID('lasting_order_assignements'))
CREATE NONCLUSTERED INDEX 
	ix_lasting_order_assignements_event_id ON lasting_order_assignements ([event_id]);
GO

/* EXPERT */

USE [Sandbox]
GO
/****** Object:  Table [dbo].[CalcTypeHistory]    Script Date: 24.11.2021 12:53:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CalcTypeHistory](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[date] [datetime2](7) NULL,
	[type] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Signals]    Script Date: 24.11.2021 12:53:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Signals](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[manager_id] [int] NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[execution_type] [int] NOT NULL,
	[security_key] [nvarchar](128) NULL,
	[lots] [int] NOT NULL,
	[shares_in_lot] [int] NOT NULL,
	[open_price] [decimal](20, 10) NOT NULL,
	[open_time] [datetime] NOT NULL,
	[is_closed] [bit] NOT NULL,
	[close_price] [decimal](20, 10) NULL,
	[close_time] [datetime] NULL,
	[closed_by_user_id] [int] NULL,
	[type] [int] NULL,
	[currency] [varchar](16) NULL,
	[security_type] [varchar](32) NULL,
	[margin_buy] [decimal](19, 10) NOT NULL,
	[margin_sell] [decimal](19, 10) NOT NULL,
	[open_time_s] [datetime2](0) NULL,
	[weight] [decimal](19, 10) NULL,
	[save_time] [datetime2](0) NULL,
	[execution_status] [int] NOT NULL,
	[comment] [nvarchar](max) NULL,
	[stop_loss] [decimal](20, 10) NULL,
	[take_profit] [decimal](20, 10) NULL,
	[realized_pnl] [decimal](20, 15) NULL,
	[state] [nvarchar](max) NULL,
	[quotation] [decimal](20, 10) NULL,
	[security_key2] [nvarchar](128) NULL,
	[execprice] [decimal](20, 10) NULL,
	[nexecprice] [int] NULL,
	[execpl] [decimal](20, 10) NULL,
	[execweight] [decimal](20, 10) NULL,
	[nexecuting] [int] NULL,
	[nexecdone] [int] NULL,
	[minexecprice] [decimal](20, 10) NULL,
	[maxexecprice] [decimal](20, 10) NULL,
 CONSTRAINT [PK_Signals] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_pl]    Script Date: 24.11.2021 12:53:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_pl](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[history] [varchar](max) NOT NULL,
	[MeanYear] [decimal](20, 10) NULL,
	[FromStart] [decimal](20, 10) NULL,
	[Reduced_History_Small] [varchar](max) NULL,
	[Reduced_History_Large] [varchar](max) NULL,
	[MeanYear_noc] [decimal](20, 10) NULL,
	[FromStart_noc] [decimal](20, 10) NULL,
	[LastWeek] [decimal](20, 10) NULL,
 CONSTRAINT [PK_strategy_pl] PRIMARY KEY CLUSTERED 
(
	[strategy_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF_Signals_lots]  DEFAULT ((1)) FOR [lots]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF_Signals_shares_in_lot]  DEFAULT ((1)) FOR [shares_in_lot]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__is_clos__38996AB5]  DEFAULT ((0)) FOR [is_closed]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__closed___398D8EEE]  DEFAULT ((0)) FOR [closed_by_user_id]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__type__3A81B327]  DEFAULT ((0)) FOR [type]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF_Signals_margin_buy]  DEFAULT ((0)) FOR [margin_buy]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF_Signals_margin_sell]  DEFAULT ((0)) FOR [margin_sell]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__save_ti__3D5E1FD2]  DEFAULT (getdate()) FOR [save_time]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__executi__3E52440B]  DEFAULT ((0)) FOR [execution_status]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__quotati__5AEE82B9]  DEFAULT ((0)) FOR [quotation]
GO
ALTER TABLE [dbo].[strategy_pl] ADD  DEFAULT ((0)) FOR [FromStart]
GO
ALTER TABLE [dbo].[strategy_pl] ADD  DEFAULT ((0)) FOR [FromStart_noc]
GO

USE [CabinetDB]
GO
/****** Object:  Table [dbo].[AuditData]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditData](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[IPAddress] [varchar](45) NULL,
	[Date] [datetime] NOT NULL,
	[UserId] [int] NULL,
	[Action] [varchar](50) NOT NULL,
	[Info] [varchar](max) NULL,
 CONSTRAINT [PK_AuditData] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CalcTypeHistory]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CalcTypeHistory](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[date] [datetime2](7) NULL,
	[type] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Comissions]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Comissions](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[long] [float] NULL,
	[short] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Securities]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Securities](
	[symbol] [nvarchar](50) NOT NULL,
	[class_code] [nvarchar](50) NOT NULL,
	[board] [nvarchar](50) NOT NULL,
	[description] [nvarchar](max) NULL,
	[add_time] [datetime] NOT NULL,
	[last_price] [decimal](20, 10) NULL,
	[last_price_time] [datetime] NULL,
	[name] [nvarchar](500) NULL,
	[lot_size] [int] NULL,
	[key] [nvarchar](128) NOT NULL,
	[price_step] [decimal](20, 10) NULL,
PRIMARY KEY CLUSTERED 
(
	[key] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Strategies]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Strategies](
	[id] [uniqueidentifier] NOT NULL,
	[manager_id] [int] NOT NULL,
	[name] [nvarchar](100) NOT NULL,
	[create_time] [datetime] NOT NULL,
	[create_by_expert_id] [int] NOT NULL,
	[description] [text] NULL,
	[is_active] [int] NOT NULL,
	[currency] [nvarchar](8) NULL,
	[leverage] [decimal](20, 10) NULL,
	[recalcMode] [int] NOT NULL,
	[securities] [varchar](max) NOT NULL,
	[value_sur] [decimal](20, 10) NULL,
	[value_usd] [decimal](20, 10) NULL,
	[client_count] [int] NULL,
	[af_value_sur] [decimal](20, 10) NULL,
	[af_value_usd] [decimal](20, 10) NULL,
	[ac_value_sur] [decimal](20, 10) NULL,
	[ac_value_usd] [decimal](20, 10) NULL,
	[af_client_count] [int] NULL,
	[ac_client_count] [int] NULL,
	[comissions] [varchar](max) NULL,
	[rating] [int] NULL,
	[iis] [tinyint] NULL,
	[autofollow] [tinyint] NULL,
	[trades_frequency] [varchar](32) NULL,
	[auto_consult] [tinyint] NULL,
	[max_instrument_fraq] [decimal](20, 10) NOT NULL,
	[is_algo] [tinyint] NULL,
	[tarif] [int] NULL,
	[subscription_threshold] [decimal](20, 10) NOT NULL,
	[parent_strategy] [uniqueidentifier] NULL,
	[index_id] [int] NULL,
	[risk_profile_id] [uniqueidentifier] NULL,
	[risk_profile_name] [nvarchar](128) NULL,
	[for_report] [bit] NOT NULL,
	[rating_adjust] [float] NULL,
	[Status] [int] NOT NULL,
	[is_portfolio] [bit] NOT NULL,
	[risk_profile] [int] NULL,
	[is_investbox] [tinyint] NULL,
 CONSTRAINT [PK__Strategi__3213E83F6341136C] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_managers]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_managers](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[manager_id] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_securities_history]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_securities_history](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[old_value] [varchar](max) NULL,
	[new_value] [varchar](max) NULL,
	[update_time] [datetime2](7) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_tests]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_tests](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[test_id] [varchar](64) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Users]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[is_active] [int] NOT NULL,
	[login] [nvarchar](50) NOT NULL,
	[pass_hash] [nvarchar](200) NULL,
	[salt] [nvarchar](64) NULL,
	[fio] [nvarchar](50) NULL,
	[role] [nvarchar](32) NOT NULL,
	[create_date] [datetime] NOT NULL,
	[is_deleted] [int] NOT NULL,
	[draft_password] [int] NOT NULL,
	[unsuccessfull_logins] [int] NOT NULL,
	[last_login] [datetime2](7) NULL,
	[phone] [varchar](32) NULL,
	[last_name] [nvarchar](64) NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[first_name] [nvarchar](64) NULL,
	[middle_name] [nvarchar](64) NULL,
	[org_name] [nvarchar](128) NULL,
	[update_time] [datetime2](7) NULL,
	[master_id] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Variables]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Variables](
	[name] [nvarchar](64) NOT NULL,
	[value] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[Securities] ADD  DEFAULT (getdate()) FOR [add_time]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__creat__398D8EEE]  DEFAULT (getdate()) FOR [create_time]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__is_ac__3A81B327]  DEFAULT ((0)) FOR [is_active]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__lever__4222D4EF]  DEFAULT ((200)) FOR [leverage]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__recal__4316F928]  DEFAULT ((0)) FOR [recalcMode]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__secur__440B1D61]  DEFAULT ('[]') FOR [securities]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_max_instrument_fraq]  DEFAULT ((100)) FOR [max_instrument_fraq]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_subscription_threshold]  DEFAULT ((1000)) FOR [subscription_threshold]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_for_report]  DEFAULT ((0)) FOR [for_report]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__Statu__02084FDA]  DEFAULT ((0)) FOR [Status]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_is_portfolio]  DEFAULT ((0)) FOR [is_portfolio]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF__Users__create_da__3D5E1FD2]  DEFAULT (getdate()) FOR [create_date]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_is_deleted]  DEFAULT ((0)) FOR [is_deleted]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF__Users__draft_pas__3E52440B]  DEFAULT ((0)) FOR [draft_password]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_unsuccessfull_logins]  DEFAULT ((0)) FOR [unsuccessfull_logins]
GO
ALTER TABLE [dbo].[CalcTypeHistory]  WITH CHECK ADD  CONSTRAINT [FK_CalcTypeHistory_Strategies] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[Strategies] ([id])
GO
ALTER TABLE [dbo].[CalcTypeHistory] CHECK CONSTRAINT [FK_CalcTypeHistory_Strategies]
GO

/* FINTARGET */

/* HS */

USE [HistoryService]
GO
/****** Object:  Table [dbo].[accs]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[accs](
	[cc] [varchar](50) NOT NULL,
	[fut] [varchar](50) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AllCoupons]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AllCoupons](
	[SecurityId] [int] NOT NULL,
	[Date] [smalldatetime] NOT NULL,
	[FaceValue] [decimal](19, 8) NOT NULL,
	[CouponValue] [decimal](19, 6) NOT NULL,
 CONSTRAINT [PK_DateSecurityId] PRIMARY KEY CLUSTERED 
(
	[Date] ASC,
	[SecurityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AllDividends]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AllDividends](
	[SecurityId] [int] NOT NULL,
	[Date] [datetime2](7) NOT NULL,
	[Value] [decimal](19, 10) NOT NULL,
	[action_date] [date] NULL,
	[state] [nvarchar](32) NULL,
	[source] [smallint] NOT NULL,
	[update_time] [smalldatetime] NULL,
 CONSTRAINT [PkAllDivs] PRIMARY KEY CLUSTERED 
(
	[SecurityId] ASC,
	[Date] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AllowedClasses]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AllowedClasses](
	[ClassCode] [varchar](64) NOT NULL,
	[Exchange] [nvarchar](64) NULL,
 CONSTRAINT [PK_AllowedClasses] PRIMARY KEY CLUSTERED 
(
	[ClassCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClassCodes]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClassCodes](
	[Depo] [nvarchar](64) NOT NULL,
	[SecType] [int] NOT NULL,
	[ClassCode] [varchar](64) NOT NULL,
	[priority_level] [smallint] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientPortfolio2]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientPortfolio2](
	[ClientCode] [varchar](16) NOT NULL,
	[SecurityKey] [varchar](64) NOT NULL,
	[Qty] [bigint] NOT NULL,
	[AvgPrice] [decimal](30, 10) NOT NULL,
	[UpdateTime] [datetime2](7) NOT NULL,
	[Confirmed] [bit] NULL,
	[Currency] [varchar](4) NOT NULL,
	[Depo] [varchar](16) NULL,
	[Kind] [varchar](5) NOT NULL,
	[Tag] [varchar](16) NOT NULL,
 CONSTRAINT [PK_ClientPortfolio2KindTag] PRIMARY KEY CLUSTERED 
(
	[ClientCode] ASC,
	[SecurityKey] ASC,
	[Currency] ASC,
	[Kind] ASC,
	[Tag] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Currency]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Currency](
	[currency_from] [varchar](32) NOT NULL,
	[currency_to] [varchar](32) NOT NULL,
	[Key] [varchar](32) NOT NULL,
	[Key_small] [varchar](32) NULL,
	[trade_time_code] [varchar](64) NULL,
	[key_tomorrow] [varchar](64) NULL,
 CONSTRAINT [PK_Currency] PRIMARY KEY CLUSTERED 
(
	[currency_from] ASC,
	[currency_to] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Dismissed]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dismissed](
	[Symbol] [varchar](64) NOT NULL,
	[Description] [nvarchar](256) NULL,
 CONSTRAINT [AK_Dismissed] UNIQUE NONCLUSTERED 
(
	[Symbol] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EndOfDay]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EndOfDay](
	[Date] [int] NOT NULL,
	[SecurityId] [int] NOT NULL,
	[Price] [decimal](19, 10) NOT NULL,
	[Source] [tinyint] NULL,
 CONSTRAINT [PK_DayData] PRIMARY KEY CLUSTERED 
(
	[Date] ASC,
	[SecurityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EndOfDayOrig]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EndOfDayOrig](
	[Date] [int] NOT NULL,
	[SecurityId] [int] NOT NULL,
	[Price] [decimal](19, 10) NOT NULL,
	[Source] [tinyint] NULL,
 CONSTRAINT [PK_DayDataOrig] PRIMARY KEY CLUSTERED 
(
	[Date] ASC,
	[SecurityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[forced_shorts]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[forced_shorts](
	[SecurityId] [int] NOT NULL,
	[Allowed] [bit] NOT NULL,
	[UpdateTime] [smalldatetime] NOT NULL,
	[qual] [bit] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Futures]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Futures](
	[Symbol] [varchar](32) NOT NULL,
	[Currency] [varchar](32) NOT NULL,
	[Coeff] [decimal](19, 10) NOT NULL,
 CONSTRAINT [Pk_Futures] PRIMARY KEY CLUSTERED 
(
	[Symbol] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[nqi_test_catalog]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[nqi_test_catalog](
	[complexproduct] [int] NOT NULL,
	[test_id] [varchar](64) NULL,
	[name] [nvarchar](max) NULL,
	[id_moex] [varchar](64) NULL,
 CONSTRAINT [pk_nqi_test_catalog] PRIMARY KEY CLUSTERED 
(
	[complexproduct] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[schedule_markets]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[schedule_markets](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](1024) NOT NULL,
	[class_codes] [varchar](1024) NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [pk_schedule_markets] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[schedule_times]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[schedule_times](
	[id] [int] NOT NULL,
	[type] [smallint] NOT NULL,
	[start_time] [time](7) NOT NULL,
	[end_time] [time](7) NOT NULL,
	[description] [nvarchar](1024) NULL,
	[save_time] [datetime2](7) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Securities]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Securities](
	[SecurityKey] [varchar](128) NOT NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[Symbol] [varchar](64) NOT NULL,
	[ClassCode] [varchar](64) NOT NULL,
	[Name] [nvarchar](256) NULL,
	[ClassName] [nvarchar](256) NULL,
	[Type] [varchar](32) NULL,
	[ISINCode] [nvarchar](32) NULL,
	[Currency] [nvarchar](16) NULL,
	[LastPrice] [decimal](30, 10) NULL,
	[LastTime] [datetime2](7) NULL,
	[LotSize] [int] NULL,
	[PriceStep] [decimal](30, 10) NULL,
	[BuyMargin] [decimal](30, 10) NULL,
	[SellMargin] [decimal](30, 10) NULL,
	[updated] [int] NOT NULL,
	[FaceValue] [decimal](30, 8) NULL,
	[CouponValue] [decimal](30, 6) NULL,
	[MatDate] [datetime2](7) NULL,
	[SecAccruedint] [decimal](30, 8) NULL,
	[TradeDate] [datetime2](7) NULL,
	[CouponPeriod] [int] NULL,
	[FaceUnit] [nvarchar](16) NULL,
	[SubType] [int] NULL,
	[ShortName] [nvarchar](128) NULL,
	[UpdateTime] [datetime2](7) NOT NULL,
	[Current] [bit] NOT NULL,
	[volatility] [decimal](10, 8) NULL,
	[turnover] [decimal](18, 2) NULL,
	[curr_stepprice] [varchar](32) NULL,
	[currency_id] [varchar](32) NULL,
	[RealPriceStep] [decimal](19, 10) NULL,
	[realminstep] [decimal](19, 10) NULL,
	[required_test] [varchar](64) NULL,
	[complexproduct] [int] NULL,
 CONSTRAINT [PK_Securities] PRIMARY KEY CLUSTERED 
(
	[SecurityKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Shorts]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Shorts](
	[SecurityId] [int] NOT NULL,
	[Allowed] [bit] NOT NULL,
	[UpdateTime] [smalldatetime] NOT NULL,
 CONSTRAINT [PK_ShortSecurity] PRIMARY KEY CLUSTERED 
(
	[SecurityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[splits]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[splits](
	[Date] [datetime2](7) NULL,
	[Security] [varchar](64) NULL,
	[SecurityTo] [varchar](64) NULL,
	[Coef] [decimal](20, 10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Synonyms]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Synonyms](
	[SecurityKey] [nvarchar](128) NOT NULL,
	[SecurityId] [int] NOT NULL,
 CONSTRAINT [AK_SecurityKey] UNIQUE NONCLUSTERED 
(
	[SecurityKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tmp_portfolio]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tmp_portfolio](
	[pf_symbol] [varchar](64) NULL,
	[SecurityKey] [varchar](128) NOT NULL,
	[pf_currency] [varchar](8) NULL,
	[Currency] [nvarchar](16) NULL,
	[tag] [varchar](16) NULL,
	[ClassCode] [varchar](64) NOT NULL,
	[kind] [varchar](5) NULL,
	[depo] [varchar](16) NULL,
	[last_time] [datetime2](7) NULL,
	[last_price] [decimal](19, 10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TradeDays]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TradeDays](
	[Date] [smalldatetime] NOT NULL,
	[ClassCode] [varchar](64) NOT NULL,
	[TimeRule] [varchar](512) NULL,
	[UpdateTime] [datetime2](7) NOT NULL,
	[SignalTimeRule] [varchar](512) NULL,
	[RebalanceTimeRule] [varchar](512) NULL,
 CONSTRAINT [PK_TradeDays_Date_ClassCode] PRIMARY KEY CLUSTERED 
(
	[Date] ASC,
	[ClassCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[WorkTime]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[WorkTime](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Date] [datetime2](7) NOT NULL,
	[ClassCode] [varchar](64) NOT NULL,
	[TimeRule] [varchar](512) NOT NULL,
	[SignalTimeRule] [varchar](512) NULL,
	[RebalanceTimeRule] [varchar](512) NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AllDividends] ADD  CONSTRAINT [df_source]  DEFAULT ((1)) FOR [source]
GO
ALTER TABLE [dbo].[ClientPortfolio2] ADD  CONSTRAINT [D_ClientPortfolio2_Confirmed]  DEFAULT ((0)) FOR [Confirmed]
GO
ALTER TABLE [dbo].[schedule_markets] ADD  DEFAULT ('1900-01-01') FOR [update_time]
GO
ALTER TABLE [dbo].[schedule_times] ADD  DEFAULT ('1900-01-01') FOR [save_time]
GO
ALTER TABLE [dbo].[Securities] ADD  CONSTRAINT [DF__Securitie__updat__5DCAEF64]  DEFAULT ((1)) FOR [updated]
GO
ALTER TABLE [dbo].[Securities] ADD  CONSTRAINT [DF__Securitie__Updat__3D2915A8]  DEFAULT ('1900-01-01') FOR [UpdateTime]
GO
ALTER TABLE [dbo].[Securities] ADD  CONSTRAINT [DF__Securitie__Curre__607251E5]  DEFAULT ((0)) FOR [Current]
GO
ALTER TABLE [dbo].[Shorts] ADD  DEFAULT ((0)) FOR [Allowed]
GO
/****** Object:  Trigger [dbo].[update_securities]    Script Date: 24.11.2021 12:42:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[update_securities]
   ON  [dbo].[Securities] 
   FOR INSERT, UPDATE 
AS 
BEGIN
	if UPDATE(SecurityKey) or
	UPDATE(Name) or UPDATE(ClassName) or UPDATE(Type) or 
	UPDATE(ISINCode) or UPDATE(Currency) or UPDATE(LastPrice) or 
	UPDATE(LastTime) or UPDATE(LotSize) or UPDATE(PriceStep) or UPDATE(Currency)
		update securities set updated = 1 where id in (select id from inserted)
END
GO
ALTER TABLE [dbo].[Securities] ENABLE TRIGGER [update_securities]
GO


IF NOT EXISTS (
	SELECT * FROM sysobjects
	WHERE name='corp_actions' AND xtype='U')
CREATE TABLE [dbo].[corp_actions] (
	[id] [int] identity(1,1) NOT NULL,
	[action_id] [int] NOT NULL,
	[action_type] [nvarchar](64) NOT NULL,
	[isin] [nvarchar](32) NOT NULL,
	[currency_id] [nvarchar](16) NOT NULL,
	[record_date] [Date] NULL,
	[action_date] [Date] NULL,
	[action_state] [varchar](16) NOT NULL,
	[exdividend_date] [Date] NULL,
	[dividend_size] [decimal](19,10) NULL,
	[repayment_part] [decimal](19,10) NULL,
	[coupon_size] [decimal](19,10) NULL,
	[updated] [SmallInt] NOT NULL Default(0),
	[update_time] [Datetime2] NOT NULL,
	CONSTRAINT [pk_corp_actions_id] PRIMARY KEY NONCLUSTERED ([id] ASC),
	CONSTRAINT [ak_corp_actions_action_id] UNIQUE NONCLUSTERED ([action_id] ASC)
);
GO

/* LCS */

USE [LifecycleService]
GO
/****** Object:  Table [dbo].[DelayedSignals]    Script Date: 24.11.2021 12:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DelayedSignals](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[manager_id] [int] NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[security_key] [nvarchar](128) NOT NULL,
	[open_price] [decimal](20, 10) NOT NULL,
	[open_time] [datetime2](7) NOT NULL,
	[quotation] [decimal](20, 10) NULL,
	[currency] [varchar](16) NULL,
	[weight] [decimal](20, 15) NULL,
	[comment] [nvarchar](512) NULL,
	[stop_loss] [decimal](20, 10) NULL,
	[take_profit] [decimal](20, 10) NULL,
	[exec_price] [decimal](20, 10) NULL,
	[exec_quotation] [decimal](20, 10) NULL,
	[executed] [int] NULL,
	[type] [int] NULL,
 CONSTRAINT [PK__DelayedS__3213E83F3F93F550] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[idea_authors]    Script Date: 24.11.2021 12:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[idea_authors](
	[ID] [bigint] NOT NULL,
	[Name] [varchar](64) NOT NULL,
	[Type] [int] NOT NULL,
	[Methods] [int] NOT NULL,
	[Competence] [int] NOT NULL,
	[Info] [varchar](max) NULL,
	[Rating] [decimal](18, 10) NULL,
	[Level] [varchar](64) NULL,
	[Role_id] [int] NULL,
	[Position] [varchar](128) NULL,
	[middle_profitability] [decimal](18, 10) NULL,
	[middle_profitability_year] [decimal](18, 10) NULL,
	[Type_str] [varchar](128) NULL,
	[Methods_str] [varchar](128) NULL,
	[CompetencesStr] [varchar](1024) NOT NULL,
	[Photo] [varchar](max) NULL,
	[PhotoType] [varchar](64) NULL,
	[Role_str] [varchar](128) NULL,
	[MyBroker] [bit] NOT NULL,
	[PersBrok] [bit] NOT NULL,
	[IsHidden] [bit] NOT NULL,
 CONSTRAINT [PK_idea_authors] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[invest_ideas]    Script Date: 24.11.2021 12:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[invest_ideas](
	[dateOpen] [datetime2](0) NOT NULL,
	[dateClose] [datetime2](0) NULL,
	[priceOpen] [decimal](18, 10) NOT NULL,
	[priceClose] [decimal](18, 10) NULL,
	[horizon] [int] NOT NULL,
	[profit] [decimal](18, 10) NOT NULL,
	[profitFact] [decimal](18, 10) NULL,
	[ProfitPotential] [decimal](18, 10) NULL,
	[recommend] [varchar](128) NOT NULL,
	[strategy] [varchar](512) NULL,
	[risk_level] [varchar](64) NOT NULL,
	[market] [varchar](64) NOT NULL,
	[range] [varchar](32) NOT NULL,
	[isClosed] [bit] NOT NULL,
	[classcode] [varchar](16) NOT NULL,
	[instrumenttype] [varchar](32) NOT NULL,
	[author_type] [int] NOT NULL,
	[author_id] [bigint] NOT NULL,
	[idea_status] [int] NOT NULL,
	[close_reason] [int] NULL,
	[stop_loss] [decimal](18, 10) NULL,
	[price_on_close] [decimal](18, 10) NULL,
	[author_comment] [varchar](max) NULL,
	[recommend_portfolio_part] [decimal](18, 10) NULL,
	[author_comment_date] [datetime2](0) NULL,
	[ticker_groups] [varchar](512) NOT NULL,
	[id] [bigint] NOT NULL,
	[timestamp] [bigint] NOT NULL,
	[type] [int] NOT NULL,
	[date] [datetime2](0) NOT NULL,
	[title] [varchar](256) NOT NULL,
	[announce] [varchar](max) NULL,
	[body] [varchar](max) NULL,
	[tickersStr] [varchar](max) NOT NULL,
	[idea_status_str] [varchar](64) NOT NULL,
	[close_reason_str] [varchar](256) NULL,
	[Current_Cost] [decimal](18, 10) NOT NULL,
	[Percent_Before_Activation] [decimal](18, 10) NULL,
	[Plan_Profit_Abs] [decimal](18, 10) NULL,
	[Fact_Profit_Abs] [decimal](18, 10) NULL,
	[Potential_Profit_Abs] [decimal](18, 10) NULL,
	[Close_Profit_Abs] [decimal](18, 10) NULL,
	[Percent_Of_Execution] [decimal](18, 10) NULL,
	[Plan_Profit_Year] [decimal](18, 10) NULL,
	[Fact_Profit_Year] [decimal](18, 10) NULL,
	[Potential_Profit_Year] [decimal](18, 10) NULL,
	[Close_Profit_Year] [decimal](18, 10) NULL,
	[Potential_More_Than_Year] [decimal](18, 10) NULL,
 CONSTRAINT [PK_invest_ideas] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Portfolios]    Script Date: 24.11.2021 12:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Portfolios](
	[Id] [int] NOT NULL,
	[CSId] [uniqueidentifier] NULL,
	[AgreementId] [uniqueidentifier] NOT NULL,
	[UserId] [uniqueidentifier] NOT NULL,
	[ParentId] [uniqueidentifier] NULL,
	[Date] [datetime2](7) NULL,
	[Positions] [varchar](max) NULL,
	[SL] [decimal](18, 10) NULL,
	[TP] [decimal](18, 10) NULL,
	[CurrentPL] [decimal](18, 10) NULL,
	[S] [decimal](18, 6) NULL,
	[active] [bit] NULL,
	[CloseDate] [datetime2](7) NULL,
	[AllowCell] [tinyint] NULL,
	[ClosingReason] [int] NULL,
 CONSTRAINT [PkPortfolios] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[restricted_securities]    Script Date: 24.11.2021 12:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[restricted_securities](
	[security_key] [varchar](128) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Signals]    Script Date: 24.11.2021 12:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Signals](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[manager_id] [int] NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[execution_type] [int] NOT NULL,
	[security_key] [nvarchar](128) NULL,
	[lots] [int] NOT NULL,
	[shares_in_lot] [int] NOT NULL,
	[open_price] [decimal](20, 10) NOT NULL,
	[open_time] [datetime] NOT NULL,
	[is_closed] [bit] NOT NULL,
	[close_price] [decimal](20, 10) NULL,
	[close_time] [datetime] NULL,
	[closed_by_user_id] [int] NULL,
	[type] [int] NULL,
	[currency] [varchar](16) NULL,
	[security_type] [varchar](32) NULL,
	[margin_buy] [decimal](19, 10) NOT NULL,
	[margin_sell] [decimal](19, 10) NOT NULL,
	[open_time_s] [datetime2](0) NULL,
	[weight] [decimal](19, 10) NULL,
	[save_time] [datetime2](0) NULL,
	[execution_status] [int] NOT NULL,
	[comment] [nvarchar](max) NULL,
	[stop_loss] [decimal](20, 10) NULL,
	[take_profit] [decimal](20, 10) NULL,
	[realized_pnl] [decimal](20, 15) NULL,
	[state] [nvarchar](max) NULL,
	[quotation] [decimal](20, 10) NULL,
	[security_key2] [nvarchar](128) NULL,
	[execprice] [decimal](20, 10) NULL,
	[nexecprice] [int] NULL,
	[execpl] [decimal](20, 10) NULL,
	[execweight] [decimal](20, 10) NULL,
	[nexecuting] [int] NULL,
	[nexecdone] [int] NULL,
	[minexecprice] [decimal](20, 10) NULL,
	[maxexecprice] [decimal](20, 10) NULL,
 CONSTRAINT [PK_Signals] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Strategies]    Script Date: 24.11.2021 12:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Strategies](
	[Id] [uniqueidentifier] NOT NULL,
	[value] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_Strategies] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Users]    Script Date: 24.11.2021 12:44:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[Id] [int] NOT NULL,
	[value] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[DelayedSignals] ADD  CONSTRAINT [DF__DelayedSi__quota__5DCAEF64]  DEFAULT ((0)) FOR [quotation]
GO
ALTER TABLE [dbo].[DelayedSignals] ADD  CONSTRAINT [DF__DelayedSi__weigh__5EBF139D]  DEFAULT ((0)) FOR [weight]
GO
ALTER TABLE [dbo].[DelayedSignals] ADD  DEFAULT ((0)) FOR [type]
GO
ALTER TABLE [dbo].[Portfolios] ADD  CONSTRAINT [DF__Portfolio__Allow__2739D489]  DEFAULT ((0)) FOR [AllowCell]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF_Signals_execution_type]  DEFAULT ((0)) FOR [execution_type]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF_Signals_lots]  DEFAULT ((0)) FOR [lots]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF_Signals_shares_in_lot]  DEFAULT ((0)) FOR [shares_in_lot]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__is_clos__38996AB5]  DEFAULT ((0)) FOR [is_closed]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__closed___398D8EEE]  DEFAULT ((0)) FOR [closed_by_user_id]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__type__3A81B327]  DEFAULT ((0)) FOR [type]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF_Signals_margin_buy]  DEFAULT ((0)) FOR [margin_buy]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF_Signals_margin_sell]  DEFAULT ((0)) FOR [margin_sell]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__save_ti__3D5E1FD2]  DEFAULT (getdate()) FOR [save_time]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__executi__3E52440B]  DEFAULT ((0)) FOR [execution_status]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__quotati__5AEE82B9]  DEFAULT ((0)) FOR [quotation]
GO
ALTER TABLE [dbo].[DelayedSignals]  WITH CHECK ADD  CONSTRAINT [FK__DelayedSi__execu__5FB337D6] FOREIGN KEY([executed])
REFERENCES [dbo].[Signals] ([id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[DelayedSignals] CHECK CONSTRAINT [FK__DelayedSi__execu__5FB337D6]
GO

/* MS */

USE [MonitoringService]
GO
/****** Object:  Table [dbo].[ErrorCodes]    Script Date: 24.11.2021 12:46:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ErrorCodes](
	[Id] [int] NOT NULL,
	[Source] [varchar](128) NOT NULL,
	[Description] [varchar](256) NOT NULL,
	[Mask] [varchar](256) NOT NULL,
	[OrderNum] [int] NOT NULL,
 CONSTRAINT [PK_ErrorCodes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC,
	[Source] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Heartbeats]    Script Date: 24.11.2021 12:46:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Heartbeats](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[HostName] [varchar](100) NOT NULL,
	[Source] [varchar](100) NOT NULL,
	[LastHeartbeat] [datetime] NOT NULL,
 CONSTRAINT [PK_Heartbeats_1] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[HeartbeatSettings]    Script Date: 24.11.2021 12:46:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[HeartbeatSettings](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[HostName] [varchar](128) NOT NULL,
	[Source] [varchar](100) NOT NULL,
	[MaxHeartbeatInterval] [int] NOT NULL,
	[CheckHeartbeats] [bit] NOT NULL,
 CONSTRAINT [PK_Heartbeats] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Messages]    Script Date: 24.11.2021 12:46:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Messages](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateTime] [datetime] NOT NULL,
	[HostName] [varchar](50) NOT NULL,
	[HostAddress] [varchar](30) NOT NULL,
	[Source] [varchar](128) NOT NULL,
	[Message] [varchar](max) NOT NULL,
	[Severity] [int] NOT NULL,
	[StrategyId] [uniqueidentifier] NULL,
	[ErrorCode] [int] NULL,
	[IsSentToRc] [bit] NOT NULL,
 CONSTRAINT [PK_Messages] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Sources]    Script Date: 24.11.2021 12:46:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Sources](
	[SourceId] [varchar](128) NOT NULL,
	[Name] [varchar](128) NOT NULL,
 CONSTRAINT [PK_Sources] PRIMARY KEY CLUSTERED 
(
	[SourceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ErrorCodes] ADD  CONSTRAINT [DF_ErrorCodes_Mask]  DEFAULT ('') FOR [Mask]
GO
ALTER TABLE [dbo].[ErrorCodes] ADD  CONSTRAINT [DF_ErrorCodes_OrderNum]  DEFAULT ((0)) FOR [OrderNum]
GO
ALTER TABLE [dbo].[Messages] ADD  CONSTRAINT [DF_Messages_IsSentToRc]  DEFAULT ((0)) FOR [IsSentToRc]
GO

 /* RISK */

USE [RiskAnalysis]
GO
/****** Object:  Table [dbo].[ClientExecutions]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientExecutions](
	[client_id] [int] NOT NULL,
	[signal_id] [bigint] NOT NULL,
	[signal_price] [decimal](18, 6) NULL,
	[client_price] [decimal](18, 6) NULL,
	[signal_weight] [decimal](10, 8) NULL,
	[client_weight] [decimal](10, 8) NULL,
	[client_value] [decimal](12, 2) NULL,
	[signal_date] [datetime2](7) NULL,
	[client_date] [datetime2](7) NULL,
	[ticker] [varchar](64) NULL,
 CONSTRAINT [clientexec_prk] PRIMARY KEY CLUSTERED 
(
	[client_id] ASC,
	[signal_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[GammaTheta]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GammaTheta](
	[ClassCode] [varchar](32) NOT NULL,
	[Date] [datetime2](7) NULL,
	[Gamma] [decimal](10, 6) NULL,
	[Theta] [decimal](10, 6) NULL,
PRIMARY KEY CLUSTERED 
(
	[ClassCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[index_history]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[index_history](
	[index_id] [int] NOT NULL,
	[date] [datetime] NOT NULL,
	[value] [decimal](20, 10) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Index_Volatility]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Index_Volatility](
	[date] [datetime] NOT NULL,
	[index_id] [int] NOT NULL,
	[value] [decimal](18, 6) NOT NULL,
 CONSTRAINT [PK_Index_Volatility] PRIMARY KEY CLUSTERED 
(
	[date] ASC,
	[index_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[indexes]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[indexes](
	[id] [int] NOT NULL,
	[symbol] [varchar](64) NOT NULL,
	[name] [nvarchar](64) NOT NULL,
	[value] [decimal](20, 10) NOT NULL,
	[inc] [decimal](20, 2) NOT NULL,
	[inc_pct] [decimal](20, 2) NOT NULL,
	[date] [datetime2](7) NOT NULL,
	[prev_value] [decimal](20, 10) NOT NULL,
	[order] [int] NULL,
	[kind] [int] NOT NULL,
	[script] [varchar](max) NULL,
	[futures_period] [int] NULL,
	[security_class] [int] NOT NULL,
 CONSTRAINT [PK_indexes] PRIMARY KEY CLUSTERED 
(
	[symbol] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_positions]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_positions](
	[portfolioId] [uniqueidentifier] NOT NULL,
	[orderNum] [int] NOT NULL,
	[securityKey] [varchar](64) NOT NULL,
	[weight] [decimal](20, 10) NOT NULL,
 CONSTRAINT [PK_portfolio_positions] PRIMARY KEY CLUSTERED 
(
	[portfolioId] ASC,
	[orderNum] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_stat]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_stat](
	[portfolio_id] [uniqueidentifier] NOT NULL,
	[mu] [decimal](18, 2) NULL,
	[sigma] [decimal](18, 2) NULL,
	[sigma_EWMA] [decimal](18, 2) NULL,
	[var95] [decimal](18, 2) NULL,
	[var95_EWMA] [decimal](18, 2) NULL,
	[var99] [decimal](18, 2) NULL,
	[var99_EWMA] [decimal](18, 2) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolios]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolios](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](256) NOT NULL,
	[description] [nvarchar](max) NOT NULL,
	[active] [bit] NOT NULL,
	[annotation] [nvarchar](max) NULL,
	[currency] [varchar](16) NOT NULL,
	[orderNum] [int] NOT NULL,
	[image] [varchar](max) NULL,
	[forecastSourceId] [int] NULL,
	[image_url] [varchar](256) NULL,
	[ready_for_iis] [bit] NOT NULL,
	[forecast] [decimal](20, 10) NULL,
	[minBalance] [decimal](20, 10) NULL,
	[paramsRecalcDate] [datetime2](7) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Ratios]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Ratios](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[period] [int] NOT NULL,
	[sharp] [float] NULL,
	[info] [float] NULL,
	[risk] [float] NULL,
	[client] [float] NULL,
 CONSTRAINT [raprk] PRIMARY KEY CLUSTERED 
(
	[strategy_id] ASC,
	[period] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RiskFree]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RiskFree](
	[date] [datetime] NOT NULL,
	[currency] [varchar](8) NOT NULL,
	[value] [decimal](18, 6) NOT NULL,
 CONSTRAINT [PK_RiskFree] PRIMARY KEY CLUSTERED 
(
	[date] ASC,
	[currency] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Securities]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Securities](
	[SecurityKey] [varchar](128) NOT NULL,
	[Symbol] [varchar](64) NOT NULL,
	[ClassCode] [varchar](64) NOT NULL,
	[Name] [nvarchar](256) NULL,
	[ClassName] [nvarchar](256) NULL,
	[Type] [varchar](32) NULL,
	[ISINCode] [nvarchar](32) NULL,
	[Currency] [nvarchar](16) NULL,
	[LastPrice] [decimal](30, 10) NULL,
	[LastTime] [datetime2](7) NULL,
	[LotSize] [int] NULL,
	[PriceStep] [decimal](30, 10) NULL,
	[BuyMargin] [decimal](30, 10) NULL,
	[SellMargin] [decimal](30, 10) NULL,
	[id] [int] NOT NULL,
	[updated] [int] NOT NULL,
	[FaceValue] [decimal](30, 8) NULL,
	[CouponValue] [decimal](30, 6) NULL,
	[MatDate] [datetime2](7) NULL,
	[SecAccruedint] [decimal](30, 8) NULL,
	[TradeDate] [datetime2](7) NULL,
	[CouponPeriod] [int] NULL,
	[FaceUnit] [nvarchar](16) NULL,
	[SubType] [int] NULL,
	[ShortName] [nvarchar](128) NULL,
	[UpdateTime] [datetime2](7) NOT NULL,
	[Current] [bit] NOT NULL,
	[volatility] [decimal](10, 8) NULL,
	[turnover] [decimal](18, 2) NULL,
	[curr_stepprice] [varchar](32) NULL,
	[currency_id] [varchar](32) NULL,
	[RealPriceStep] [decimal](19, 10) NULL,
	[realminstep] [decimal](19, 10) NULL,
 CONSTRAINT [PK_Securities] PRIMARY KEY CLUSTERED 
(
	[SecurityKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[security_forecasts]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[security_forecasts](
	[securityKey] [varchar](64) NOT NULL,
	[sourceId] [int] NOT NULL,
	[forecast] [decimal](20, 10) NOT NULL,
	[currentPrice] [decimal](20, 10) NULL,
	[targetPrice] [decimal](20, 10) NULL,
	[forecastDate] [datetime] NULL,
	[isFixedForecast] [bit] NOT NULL,
 CONSTRAINT [PK_security_forecasts] PRIMARY KEY CLUSTERED 
(
	[securityKey] ASC,
	[sourceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[security_forecasts_sources]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[security_forecasts_sources](
	[id] [int] NOT NULL,
	[name] [varchar](200) NOT NULL,
	[title] [varchar](max) NOT NULL,
	[disclaimer] [varchar](max) NOT NULL,
 CONSTRAINT [PK_security_forecasts_sources] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SignalExecutions]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SignalExecutions](
	[signal_id] [int] NOT NULL,
	[signal_price] [decimal](12, 4) NULL,
	[signal_weight] [decimal](10, 8) NULL,
	[signal_date] [datetime2](7) NULL,
	[ticker] [varchar](64) NULL,
	[last_client_date] [datetime2](7) NULL,
	[ave_exec_price] [decimal](20, 6) NULL,
	[min_exec_price] [decimal](20, 6) NULL,
	[max_exec_price] [decimal](20, 6) NULL,
	[signal_value] [decimal](20, 4) NULL,
	[Direction]  AS (case when [signal_weight]>=(0) then 'B' else 'S' end),
 CONSTRAINT [signalsexec_prk] PRIMARY KEY CLUSTERED 
(
	[signal_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Signals]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Signals](
	[id] [int] NOT NULL,
	[manager_id] [int] NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[execution_type] [int] NOT NULL,
	[security_key] [nvarchar](128) NULL,
	[lots] [int] NOT NULL,
	[shares_in_lot] [int] NOT NULL,
	[open_price] [decimal](20, 10) NOT NULL,
	[open_time] [datetime] NOT NULL,
	[is_closed] [bit] NOT NULL,
	[close_price] [decimal](20, 10) NULL,
	[close_time] [datetime] NULL,
	[closed_by_user_id] [int] NULL,
	[type] [int] NULL,
	[currency] [varchar](16) NULL,
	[security_type] [varchar](32) NULL,
	[margin_buy] [decimal](19, 10) NOT NULL,
	[margin_sell] [decimal](19, 10) NOT NULL,
	[open_time_s] [datetime2](0) NULL,
	[weight] [decimal](19, 10) NULL,
	[save_time] [datetime2](0) NULL,
	[execution_status] [int] NOT NULL,
	[comment] [nvarchar](max) NULL,
	[stop_loss] [decimal](20, 10) NULL,
	[take_profit] [decimal](20, 10) NULL,
	[realized_pnl] [decimal](20, 15) NULL,
	[state] [nvarchar](max) NULL,
	[quotation] [decimal](20, 10) NULL,
	[security_key2] [nvarchar](128) NULL,
	[execprice] [decimal](20, 10) NULL,
	[nexecprice] [int] NULL,
	[execpl] [decimal](20, 10) NULL,
	[execweight] [decimal](20, 10) NULL,
	[nexecuting] [int] NULL,
	[nexecdone] [int] NULL,
	[minexecprice] [decimal](20, 6) NULL,
	[maxexecprice] [decimal](20, 6) NULL,
 CONSTRAINT [PK_Signals] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Strategies]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Strategies](
	[id] [uniqueidentifier] NOT NULL,
	[manager_id] [int] NOT NULL,
	[name] [nvarchar](100) NOT NULL,
	[create_time] [datetime] NOT NULL,
	[create_by_expert_id] [int] NOT NULL,
	[description] [text] NULL,
	[is_active] [int] NOT NULL,
	[currency] [nvarchar](8) NULL,
	[leverage] [decimal](20, 10) NULL,
	[recalcMode] [int] NOT NULL,
	[securities] [varchar](max) NOT NULL,
	[value_sur] [decimal](20, 10) NULL,
	[value_usd] [decimal](20, 10) NULL,
	[client_count] [int] NULL,
	[af_value_sur] [decimal](20, 10) NULL,
	[af_value_usd] [decimal](20, 10) NULL,
	[ac_value_sur] [decimal](20, 10) NULL,
	[ac_value_usd] [decimal](20, 10) NULL,
	[af_client_count] [int] NULL,
	[ac_client_count] [int] NULL,
	[comissions] [varchar](max) NULL,
	[rating] [int] NULL,
	[iis] [tinyint] NULL,
	[autofollow] [tinyint] NULL,
	[trades_frequency] [varchar](32) NULL,
	[auto_consult] [tinyint] NULL,
	[max_instrument_fraq] [decimal](20, 10) NOT NULL,
	[is_algo] [tinyint] NULL,
	[tarif] [int] NULL,
	[subscription_threshold] [decimal](20, 10) NOT NULL,
	[parent_strategy] [uniqueidentifier] NULL,
	[index_id] [int] NULL,
	[risk_profile_id] [uniqueidentifier] NULL,
	[risk_profile_name] [nvarchar](128) NULL,
	[for_report] [bit] NOT NULL,
	[rating_adjust] [float] NULL,
	[Status] [int] NULL,
	[is_portfolio] [bit] NOT NULL,
	[risk_profile] [int] NULL,
 CONSTRAINT [PK__Strategi__3213E83F6341136C] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_pl]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_pl](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[history] [varchar](max) NOT NULL,
	[mean_year] [decimal](20, 10) NULL,
 CONSTRAINT [PK_strategy_pl] PRIMARY KEY CLUSTERED 
(
	[strategy_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_pl_period]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_pl_period](
	[StratId] [uniqueidentifier] NOT NULL,
	[Date] [datetime] NULL,
	[Period] [char](1) NOT NULL,
	[PL] [decimal](18, 6) NULL,
	[Drawdown] [decimal](18, 6) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_stats]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_stats](
	[StratId] [uniqueidentifier] NOT NULL,
	[Risk] [float] NULL,
	[Sharp] [float] NULL,
	[Info] [float] NULL,
	[Drawdown] [decimal](20, 10) NULL,
	[Volatility] [decimal](20, 10) NULL,
	[BechmarkPL] [decimal](20, 10) NULL,
	[Alpha] [decimal](20, 10) NULL,
	[Beta] [decimal](20, 10) NULL,
	[R2] [decimal](20, 10) NULL,
	[Trades] [int] NULL,
	[TradesPerWeek] [float] NULL,
	[MeanTradeValue] [decimal](20, 5) NULL,
	[PercentProfitTrades] [float] NULL,
	[MeanPorfitOnTrade] [decimal](20, 5) NULL,
	[MeanLossOnTrade] [decimal](20, 5) NULL,
	[PercentLossTrades] [float] NULL,
	[DrawdownY] [decimal](20, 10) NULL,
	[TradesPerWeekLastYear] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[StrategyRatings]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[StrategyRatings](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[total] [float] NULL,
	[init_rating] [float] NULL,
	[corr_rating] [float] NULL,
	[rating] [float] NULL,
 CONSTRAINT [srprk] PRIMARY KEY CLUSTERED 
(
	[strategy_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TermPortfoliosHistory]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TermPortfoliosHistory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TermPortfolioId] [uniqueidentifier] NOT NULL,
	[ModificationDate] [datetime2](7) NOT NULL,
	[Name] [varchar](256) NOT NULL,
	[StopDate] [datetime2](7) NOT NULL,
	[Portfolio] [varchar](max) NOT NULL,
	[EndPricesFilled] [bit] NOT NULL,
 CONSTRAINT [PK_TermPortfoliosHistory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Volatility]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Volatility](
	[date] [datetime] NOT NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[value] [decimal](18, 6) NOT NULL,
 CONSTRAINT [PK_Volatility] PRIMARY KEY CLUSTERED 
(
	[date] ASC,
	[strategy_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[indexes] ADD  CONSTRAINT [DF_indexes_kind]  DEFAULT ((0)) FOR [kind]
GO
ALTER TABLE [dbo].[indexes] ADD  CONSTRAINT [DF_indexes_security_class]  DEFAULT ((0)) FOR [security_class]
GO
ALTER TABLE [dbo].[portfolio_positions] ADD  CONSTRAINT [DF__portfolio__order__3E52440B]  DEFAULT ((0)) FOR [orderNum]
GO
ALTER TABLE [dbo].[portfolios] ADD  DEFAULT ('SUR') FOR [currency]
GO
ALTER TABLE [dbo].[portfolios] ADD  DEFAULT ((0)) FOR [orderNum]
GO
ALTER TABLE [dbo].[portfolios] ADD  CONSTRAINT [DF_portfolios_ready_for_iis]  DEFAULT ((0)) FOR [ready_for_iis]
GO
ALTER TABLE [dbo].[Securities] ADD  CONSTRAINT [DF__Securitie__updat__5DCAEF64]  DEFAULT ((1)) FOR [updated]
GO
ALTER TABLE [dbo].[Securities] ADD  CONSTRAINT [DF__Securitie__Updat__5FB337D6]  DEFAULT ('1900-01-01') FOR [UpdateTime]
GO
ALTER TABLE [dbo].[Securities] ADD  CONSTRAINT [DF__Securitie__Curre__60A75C0F]  DEFAULT ((0)) FOR [Current]
GO
ALTER TABLE [dbo].[security_forecasts] ADD  CONSTRAINT [DF_security_forecasts_isFixedForecast]  DEFAULT ((0)) FOR [isFixedForecast]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__is_clos__3F466844]  DEFAULT ((0)) FOR [is_closed]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__closed___403A8C7D]  DEFAULT ((0)) FOR [closed_by_user_id]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__type__412EB0B6]  DEFAULT ((0)) FOR [type]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__save_ti__4222D4EF]  DEFAULT (getdate()) FOR [save_time]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__executi__4316F928]  DEFAULT ((0)) FOR [execution_status]
GO
ALTER TABLE [dbo].[Signals] ADD  CONSTRAINT [DF__Signals__quotati__440B1D61]  DEFAULT ((0)) FOR [quotation]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__creat__398D8EEE]  DEFAULT (getdate()) FOR [create_time]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__is_ac__3A81B327]  DEFAULT ((0)) FOR [is_active]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__lever__4222D4EF]  DEFAULT ((200)) FOR [leverage]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__recal__4316F928]  DEFAULT ((0)) FOR [recalcMode]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__secur__440B1D61]  DEFAULT ('[]') FOR [securities]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_max_instrument_fraq]  DEFAULT ((100)) FOR [max_instrument_fraq]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_subscription_threshold]  DEFAULT ((1000)) FOR [subscription_threshold]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_for_report]  DEFAULT ((0)) FOR [for_report]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_is_portfolio]  DEFAULT ((0)) FOR [is_portfolio]
GO
/****** Object:  Trigger [dbo].[UPDATE_VOLATILITY_INDEX]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[UPDATE_VOLATILITY_INDEX]  
   ON  [dbo].[Index_Volatility]
   instead of insert 
AS 
BEGIN
DECLARE @date datetime, @index_id CHAR(256), @value decimal(18,6)
SELECT @date = date, @index_id = index_id, @value=value   FROM inserted 
merge [dbo].[Index_Volatility] 
   as target 
using (values(@date, @index_id,@value)) as source (date, index_id, value) 
   on target.date = source.date 
  and target.index_id = source.index_id  
 when matched then 
      update 
         set value = @value 
 when not matched then 
      insert (date, index_id, value) 
      values (@date, @index_id, @value);
END
GO
ALTER TABLE [dbo].[Index_Volatility] ENABLE TRIGGER [UPDATE_VOLATILITY_INDEX]
GO
/****** Object:  Trigger [dbo].[CLEAR_PORTFOLIO_STAT]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[CLEAR_PORTFOLIO_STAT] 
   ON  [dbo].[portfolio_stat] 
   instead of insert 
AS 
BEGIN
delete from [dbo].[portfolio_stat] where portfolio_id=(select portfolio_id from inserted)
insert into [dbo].[portfolio_stat] (portfolio_id,mu, sigma, sigma_EWMA, var95, var95_EWMA,var99, var99_EWMA) select portfolio_id,mu, sigma, sigma_EWMA, var95, var95_EWMA,var99, var99_EWMA from inserted


    -- Insert statements for trigger here

END
GO
ALTER TABLE [dbo].[portfolio_stat] ENABLE TRIGGER [CLEAR_PORTFOLIO_STAT]
GO
/****** Object:  Trigger [dbo].[UPDATE_RiskFree]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[UPDATE_RiskFree]  
   ON  [dbo].[RiskFree]
   instead of insert 
AS 
BEGIN
DECLARE @date datetime, @currency varchar(8), @value decimal(18,6)
SELECT @date = date, @currency = currency, @value=value   FROM inserted 
merge [dbo].[RiskFree] 
   as target 
using (values(@date, @currency, @value)) as source (date, currency, value) 
   on target.date = source.date 
  and target.currency = source.currency
 when matched then 
      update 
         set value = @value
 when not matched then 
      insert (date, currency, value) 
      values (@date, @currency, @value);
END
GO
ALTER TABLE [dbo].[RiskFree] ENABLE TRIGGER [UPDATE_RiskFree]
GO
/****** Object:  Trigger [dbo].[UPDATE_VOLATILITY]    Script Date: 24.11.2021 12:52:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER  [dbo].[UPDATE_VOLATILITY]  
   ON  [dbo].[Volatility]
   instead of insert 
AS 
BEGIN
DECLARE @date datetime, @strategy_id CHAR(256), @value decimal(18,6)
SELECT @date = date, @strategy_id = strategy_id, @value=value   FROM inserted 
merge [dbo].[Volatility] 
   as target 
using (values(@date, @strategy_id,@value)) as source (date, strategy_id, value) 
   on target.date = source.date 
  and target.strategy_id = source.strategy_id  
 when matched then 
      update 
         set value = @value
 when not matched then 
      insert (date, strategy_id, value) 
      values (@date, @strategy_id, @value);


	SET NOCOUNT ON;

    -- Insert statements for trigger here

END
GO
ALTER TABLE [dbo].[Volatility] ENABLE TRIGGER [UPDATE_VOLATILITY]
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������������� ���������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_pl', @level2type=N'COLUMN',@level2name=N'strategy_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������ ���������� � JSON' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_pl', @level2type=N'COLUMN',@level2name=N'history'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������� ���������� �� ����������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_pl'
GO

/* SMS */

USE [SMSService]
GO

ALTER DATABASE [SMSService] COLLATE Cyrillic_General_CI_AS

/****** Object:  Table [dbo].[AccountHistory]    Script Date: 24.11.2021 12:54:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AccountHistory](
	[archiveDate] [datetime2](7) NOT NULL,
	[ClientCode] [varchar](16) NOT NULL,
	[SendTypes] [int] NOT NULL,
	[bindConfirmationCode] [varchar](6) NOT NULL,
	[bindPhone] [varchar](64) NOT NULL,
	[bindDate] [datetime2](7) NOT NULL,
	[bindIp] [varchar](32) NOT NULL,
	[unbindPhone] [varchar](64) NULL,
	[unbindDate] [datetime2](7) NULL,
	[unbindIp] [varchar](32) NULL,
	[unbindConfirmationCode] [varchar](6) NULL,
	[bindCodeValidSeconds] [int] NULL,
	[unbindCodeValiSeconds] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Accounts]    Script Date: 24.11.2021 12:54:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Accounts](
	[ClientCode] [varchar](16) NOT NULL,
	[SendTypes] [int] NOT NULL,
	[bindConfirmationCode] [varchar](6) NULL,
	[bindPhone] [varchar](64) NULL,
	[bindDate] [datetime2](7) NULL,
	[bindIp] [varchar](32) NULL,
	[unbindPhone] [varchar](64) NULL,
	[unbindDate] [datetime2](7) NULL,
	[unbindIp] [varchar](32) NULL,
	[unbindConfirmationCode] [varchar](6) NULL,
 CONSTRAINT [PK_Accounts] PRIMARY KEY CLUSTERED 
(
	[ClientCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmailAttachment]    Script Date: 24.11.2021 12:54:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmailAttachment](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[EmailId] [bigint] NOT NULL,
	[FileName] [varchar](256) NOT NULL,
	[Type] [varchar](128) NOT NULL,
	[Base64] [varchar](max) NOT NULL,
	[ContentId] [varchar](100) NULL,
 CONSTRAINT [PK_EmailAttachment] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Emails]    Script Date: 24.11.2021 12:54:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Emails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[BatchId] [uniqueidentifier] NOT NULL,
	[Subject] [nvarchar](128) NOT NULL,
	[Body] [nvarchar](max) NOT NULL,
	[Sender] [varchar](128) NOT NULL,
	[Address] [varchar](128) NOT NULL,
	[IsSent] [bit] NOT NULL,
	[SendTime] [datetime2](7) NULL,
	[AddTime] [datetime2](7) NOT NULL,
	[BodyType] [varchar](128) NULL,
 CONSTRAINT [PK_Emails] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[IIRs]    Script Date: 24.11.2021 12:54:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[IIRs](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[BatchId] [uniqueidentifier] NOT NULL,
	[SignalId] [bigint] NOT NULL,
	[Data] [varchar](max) NOT NULL,
	[AddTime] [datetime2](7) NOT NULL,
	[IsSent] [bit] NOT NULL,
	[SentTypes] [int] NOT NULL,
	[MessageType] [int] NOT NULL,
	[xbrl_sent] [bit] NOT NULL,
	[TemplateVersion] [int] NULL,
	[TemplateName] [varchar](100) NULL,
 CONSTRAINT [PK_IIRs] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Messages]    Script Date: 24.11.2021 12:54:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Messages](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[BatchId] [uniqueidentifier] NOT NULL,
	[Subject] [varchar](512) NOT NULL,
	[Text] [varchar](max) NULL,
	[Address] [varchar](512) NOT NULL,
	[IsSent] [bit] NOT NULL,
	[SendTime] [datetime2](7) NULL,
	[AddTime] [datetime2](7) NOT NULL,
	[MessageId] [uniqueidentifier] NULL,
	[Status] [varchar](30) NULL,
	[StatusChanged] [datetime2](7) NULL,
 CONSTRAINT [PK_Messages] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Profiling]    Script Date: 24.11.2021 12:54:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Profiling](
	[client_id] [uniqueidentifier] NOT NULL,
	[questionary_id] [uniqueidentifier] NOT NULL,
	[document_id] [uniqueidentifier] NOT NULL,
	[confirmation_code] [varchar](16) NOT NULL,
	[confirmed] [bit] NOT NULL,
	[confirm_limit] [datetime2](7) NOT NULL,
	[confirm_time] [datetime2](7) NULL,
	[create_time] [datetime2](7) NOT NULL,
	[confirm_phone] [varchar](64) NULL,
 CONSTRAINT [PK_Profiling] PRIMARY KEY CLUSTERED 
(
	[questionary_id] ASC,
	[document_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[IIRs] ADD  DEFAULT ((0)) FOR [IsSent]
GO
ALTER TABLE [dbo].[IIRs] ADD  DEFAULT ((0)) FOR [MessageType]
GO
ALTER TABLE [dbo].[IIRs] ADD  DEFAULT ((0)) FOR [xbrl_sent]
GO
ALTER TABLE [dbo].[Profiling] ADD  CONSTRAINT [DF_Profiling_confirmed]  DEFAULT ((0)) FOR [confirmed]
GO
ALTER TABLE [dbo].[EmailAttachment]  WITH CHECK ADD  CONSTRAINT [FK_EmailAttachment_Emails] FOREIGN KEY([EmailId])
REFERENCES [dbo].[Emails] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmailAttachment] CHECK CONSTRAINT [FK_EmailAttachment_Emails]
GO


/* STS */

USE [StatService]
GO
/****** Object:  Table [dbo].[Strategies]    Script Date: 24.11.2021 12:55:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Strategies](
	[id] [uniqueidentifier] NOT NULL,
	[RealizedPL] [decimal](18, 10) NOT NULL,
	[UnrealizedPL] [decimal](18, 10) NOT NULL,
	[Profit] [decimal](18, 10) NOT NULL,
 CONSTRAINT [PK_Strategies] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[StrategyHistory]    Script Date: 24.11.2021 12:55:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[StrategyHistory](
	[StrategyId] [uniqueidentifier] NOT NULL,
	[History] [varchar](max) NOT NULL,
 CONSTRAINT [PK_StrategyHistory_1] PRIMARY KEY CLUSTERED 
(
	[StrategyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[StrategyPositions]    Script Date: 24.11.2021 12:55:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[StrategyPositions](
	[StrategyId] [uniqueidentifier] NOT NULL,
	[Symbol] [varchar](32) NOT NULL,
	[Name] [nvarchar](256) NULL,
	[AvgPrice] [decimal](20, 10) NOT NULL,
	[EntryTime] [datetime2](7) NOT NULL,
	[Weight] [decimal](20, 10) NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_Profit]  DEFAULT ((0)) FOR [Profit]
GO


/* TS */


