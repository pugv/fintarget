﻿using System;
using System.Collections.Generic;
using System.Linq;
using Api.Models;
using CS.Kernel.DBO;
using CS.Kernel.Model;
using ExchangeHelpers;
using Expert.Models;
using HS.Models;
using LinqToDB;
using LinqToDB.Data;
using Newtonsoft.Json;
using NLib.Helpers;
using NLib.Migrations;
using NLib.ParsersFormatters.DateTime;
using Unidecode.NET;
using PositionCalculator;
using ClientAccountPosition = Api.Models.ClientAccountPosition;

namespace CreateTestData
{
    public class TestDataBuilder
    {
        public const string _USDCURR = "USDTORUB";
        public const string _EURCURR = "EURTORUB";
        public const string _CURRCLASS = "CETS";

        public const string _PRICE_CAT_FREE = "A ";
        public const string _PRICE_CAT_10 = "B ";

        public int _MOEX_INDEX = 1;
        public const int _DURATION_YEAR = 4;
        public const int _STRAT_KIND_STANDARD = 1;

        protected Api.Models.Database _apiDB;
        protected Expert.Models.Database _cabDB;
        protected CS.Kernel.Functionality.Database _csDB;
        protected HS.Models.Database _hsDB;
        protected LCS.Models.Database _lcsDB;
        protected TS.Models.Database _tsDB;
        protected ES.Models.Database _esDB;

        private System.Random _rnd;

        public static Guid NewGuid(Random rnd)
        {
            byte[] bytes = new byte[8];
            rnd.NextBytes(bytes);
            return new Guid(rnd.Next(), (short) rnd.Next(32000), (short) rnd.Next(32000), bytes);
        }

        public TestDataBuilder(int seed = 0)
        {
            _csDB = new CS.Kernel.Functionality.Database().Migrated();
            _lcsDB = new LCS.Models.Database().Migrated();
            _apiDB = new Api.Models.Database().Migrated();
            _hsDB = new HS.Models.Database().Migrated();
            _cabDB = new Expert.Models.Database().Migrated();
            _tsDB = new TS.Models.Database().Migrated();
            _esDB = new ES.Models.Database().Migrated();

            Securities = new System.Collections.Generic.Dictionary<string, SecurityInfo>();
            PriceItemsMap = new System.Collections.Generic.Dictionary<string, STS.Kernel.Objects.PriceItem[]>();
            Authors = new System.Collections.Generic.Dictionary<int, User>();
            _clients = new Dictionary<string, CS.Kernel.Model.ClientAccount>();

            if (seed == 0) seed = System.Environment.TickCount;
            _rnd = new System.Random(seed);


            Prepare();
        }

        protected TestDataBuilder(TestDataBuilder builder)
        {
            _csDB = builder._csDB;
            _lcsDB = builder._lcsDB;
            _apiDB = builder._apiDB;
            _cabDB = builder._cabDB;
            _hsDB = builder._hsDB;
            _rnd = builder._rnd;

            Securities = builder.Securities;
            PriceItemsMap = builder.PriceItemsMap;
            Authors = builder.Authors;
            _clients = builder._clients;
            Strategies = builder.Strategies;
        }

        public System.Random Random => _rnd;

        public Dictionary<string, SecurityInfo> Securities { get; protected set; }
        protected Dictionary<string, STS.Kernel.Objects.PriceItem[]> PriceItemsMap { get; set; }

        protected readonly Dictionary<string, CS.Kernel.Model.ClientAccount> _clients;

        protected readonly Dictionary<Guid, StrategyTestDataBuilder.Strategy> Strategies = new();

        public IEnumerable<CS.Kernel.Model.ClientAccount> Clients => _clients.Values.AsEnumerable();

        public Dictionary<int, Expert.Models.User> Authors { get; set; }

        void Prepare()
        {
            _apiDB.Insert(new Api.Models.Currency() {Symbol = "Р", Name = "Руб", DbId = "SUR"});
            _apiDB.Insert(new Api.Models.Currency() {Symbol = "$", Name = "USD", DbId = "USD"});

            _hsDB.Insert(new HS.Models.Currency()
            {
                ClassCode = _CURRCLASS, From = "USD", To = "SUR", Key = $"{_USDCURR} {_CURRCLASS} QUIK",
                KeySmall = $"{_USDCURR}_SMALL {_CURRCLASS} QUIK"
            });
            _hsDB.Insert(new HS.Models.Currency()
            {
                ClassCode = _CURRCLASS, From = "EUR", To = "SUR", Key = $"{_EURCURR} {_CURRCLASS} QUIK",
                KeySmall = $"{_EURCURR}_SMALL {_CURRCLASS} QUIK"
            });

            _hsDB.InsertWithInt32Identity(new SecurityInfo()
            {
                ClassCode = _CURRCLASS, Symbol = _USDCURR, Currency = "SUR", Key = $"{_USDCURR} {_CURRCLASS} QUIK",
                LotSize = 1000, Type = "Currency", LastPrice = 80, PriceStep = 0.1m, IsCurrent = true,
                ISINCode = _USDCURR, LastTime = DateTime.Now
            });
            _hsDB.InsertWithInt32Identity(new SecurityInfo()
            {
                ClassCode = _CURRCLASS, Symbol = _USDCURR + "_SMALL", Currency = "SUR",
                Key = $"{_USDCURR}_SMALL {_CURRCLASS} QUIK", LotSize = 1, Type = "Currency", LastPrice = 81,
                PriceStep = 0.1m, IsCurrent = true, ISINCode = _USDCURR + "_SMALL", LastTime = DateTime.Now
            });
            _hsDB.InsertWithInt32Identity(new SecurityInfo()
            {
                ClassCode = _CURRCLASS, Symbol = _EURCURR, Currency = "SUR", Key = $"{_EURCURR} {_CURRCLASS} QUIK",
                LotSize = 1000, Type = "Currency", LastPrice = 100, PriceStep = 0.1m, IsCurrent = true,
                ISINCode = _EURCURR, LastTime = DateTime.Now
            });
            _hsDB.InsertWithInt32Identity(new SecurityInfo()
            {
                ClassCode = _CURRCLASS, Symbol = _EURCURR + "_SMALL", Currency = "SUR",
                Key = $"{_EURCURR}_SMALL {_CURRCLASS} QUIK", LotSize = 1, Type = "Currency", LastPrice = 110,
                PriceStep = 0.1m, IsCurrent = true, ISINCode = _EURCURR + "_SMALL", LastTime = DateTime.Now
            });

            _apiDB.Insert(new Market() {Id = 1, Name = "США"});
            _apiDB.Insert(new Market() {Id = 2, Name = "РФ"});
            _apiDB.Insert(new Service() {Name = "Автоследование", Id = 1});
            _apiDB.Insert(new Service() {Name = "Автоконсультирование", Id = 2});

            AddClasscode("TQBR", 1);
            AddClasscode("TQOB", 2);
            AddClasscode("SPBFUT", 3);

            _apiDB.Insert(new Api.Models.StrategyKind()
            {
                Name = "Стандарт", Description = "Классический подход в управлении активами", Id = _STRAT_KIND_STANDARD
            });
            _apiDB.Insert(new Api.Models.Duration() {Id = _DURATION_YEAR, Name = "1 Года", Days = 366});

            _apiDB.Insert(new Test() {Id = "MARGIN_TRADING", Name = "Margin"});
            _apiDB.Insert(new Test() {Id = "DERIVATIVES", Name = "Futures"});

            _apiDB.Insert(new Api.Models.PriceCategory() {Id = _PRICE_CAT_10, MF = 0.01m, SF = 0.1m});
            _apiDB.Insert(new Api.Models.PriceCategory() {Id = _PRICE_CAT_FREE, MF = 0.0m, SF = 0.0m});

            _apiDB.Insert(new Api.Models.Tariff() {TariffId = Guid.NewGuid(), Description = "Free", CategoryId = _PRICE_CAT_FREE, EvaId = 0});
            _apiDB.Insert(new Api.Models.Tariff() {TariffId = Guid.NewGuid(), Description = "MF + SF 10%", CategoryId = _PRICE_CAT_10, EvaId = 1});

            _MOEX_INDEX = _apiDB.InsertWithInt32Identity(new Api.Models.Index()
            {
                Name = "МосБиржи", Symbol = "IMOEX", Value = 3932, PrevValue = 3932,
                Date = System.DateTime.Now, Order = 10, Kind = Api.Models.IndexKind.Express,
                SecurityClass = Api.Models.SecurityClass.RussianSharesHighFrequency
            });

            var investProfile = new Api.Models.InvestProfile()
            {
                Id = 1, ProfileId = System.Guid.NewGuid(), Description = "Консервативный", Name = "Консервативный риск",
                EstimatedDrawdown = 5
            };
            _apiDB.Insert(investProfile);
            _csDB.Insert(new ProfileDBO()
                {Id = investProfile.Id, Guid = investProfile.ProfileId, Name = investProfile.Name});
            investProfile = new Api.Models.InvestProfile()
            {
                Id = 2, ProfileId = System.Guid.NewGuid(), Description = "Рациональный", Name = "Рациональный",
                EstimatedDrawdown = 5
            };
            _apiDB.Insert(investProfile);
            _csDB.Insert(new ProfileDBO()
                {Id = investProfile.Id, Guid = investProfile.ProfileId, Name = investProfile.Name});
            investProfile = new Api.Models.InvestProfile()
            {
                Id = 3, ProfileId = System.Guid.NewGuid(), Description = "Профессиональный", Name = "Профессиональный",
                EstimatedDrawdown = 5
            };
            _apiDB.Insert(investProfile);
            _csDB.Insert(new ProfileDBO()
                {Id = investProfile.Id, Guid = investProfile.ProfileId, Name = investProfile.Name});

            _apiDB.Insert(new Utm() {Id = "general", Name = "Общие"});
        }

        void AddClasscode(string name, int secType)
        {
            _hsDB.Insert(new ClassCodes() {Depo = "L01-00000F00", SecurityType = secType, Code = $"{name} QUIK", Level = 0});
            _apiDB.Insert(new Tool() {Name = name, Id = secType});

            var scheduleSaveTime = DateTime.Now;
            // trade times
            var marketId1 = _hsDB.InsertWithInt32Identity(new HS.Models.ScheduleMarket
            {
                ClassCodes = name,
                Name = name,
                UpdateTime = DateTime.Now
            });

            _hsDB.Insert(new HS.Models.ScheduleTime
            {
                Id = marketId1,
                Type = SchedType.trade,
                Start = new TimeSpan(0, 0, 1),
                End = new TimeSpan(23, 59, 59),
                SaveTime = scheduleSaveTime
            });
            _hsDB.Insert(new HS.Models.ScheduleTime
            {
                Id = marketId1,
                Type = SchedType.signal,
                Start = new TimeSpan(0, 0, 1),
                End = new TimeSpan(23, 59, 59),
                SaveTime = scheduleSaveTime
            });
            _hsDB.Insert(new HS.Models.ScheduleTime
            {
                Id = marketId1,
                Type = SchedType.rebalance,
                Start = new TimeSpan(0, 0, 1),
                End = new TimeSpan(23, 59, 59),
                SaveTime = scheduleSaveTime
            });
        }

        public ClientTestDataBuilder AddClient(decimal? value, System.Guid? strategy = null,
            System.Action<CS.Kernel.Model.ClientAccount> setter = null)
        {
            return new ClientTestDataBuilder(this, value, strategy, setter);
        }

        public int AddAuthor(string login, string name = null, System.Action<Expert.Models.User> setter = null)
        {
            login = login ?? "admin";
            // def pass: A12345678b
            var author = new Expert.Models.User()
            {
                FirstName = name ?? login,
                LastName = "Иванов",
                UserType = Api.Models.AuthorType.Representative,
                IsActive = 1,
                CreateDate = System.DateTime.Now,
                Role = "Administrator",
                FullName = $"{(name ?? login)} Иванов",
                Login = login,
                PasswordHash =
                    "63-1F-EF-1E-26-D2-50-35-C9-59-04-F6-4F-65-B2-BD-0F-CE-40-8C-4A-E1-FC-B0-84-59-6A-3B-5D-B5-21-37-FE-62-A9-15-B3-54-84-EB-48-48-4F-4B-A8-AC-C4-53-3F-CE-8F-63-7E-D7-86-45-A5-10-A5-42-F1-2F-21-62",
                Salt = @"\g&f#PDGjIgnlC]HB0;og"
            };
            setter?.Invoke(author);

            author.Id = _cabDB.InsertWithInt32Identity(author);
            _lcsDB.Insert(new LCS.Models.UserDTO() {Id = author.Id, Json = Newtonsoft.Json.JsonConvert.SerializeObject(author)});
            _apiDB.Insert(new Api.Models.Author()
            {
                Id = author.Id,
                FriendlyUrl = $"author_{author.Id}",
                FirstName = author.FirstName,
                LastName = author.LastName,
                DisplayName = author.FullName,
                PhotoFormat = "jpeg",
                Email = "author@Email.com",
                InfoHtml = author.FullName,
                ShortInfoHtml = author.FullName,
                ImageUrl = "https://fintarget.ru/images/author/7.jpg"
            });

            _apiDB.InsertWithInt32Identity(new Analytics
            {
                FriendlyUrl = $"article_{author.Id}_1",
                AuthorId = author.Id,
                Title = "Анализ ситуации на рынках",
                CutHtml = "<p>Доходность стратегии за июль составила <strong>+0.8% </strong>с учетом реальных цен исполнения и издержек стратегии.</p>",
                FullHtml =
                    "<p>Практически весь июль валютная пара USD/RUB торговалась в узком ценовом диапазоне 70.5 &ndash; 72.5 рублей за доллар. Лишь в конце месяца произошел выход из консолидации, и курс USD/RUB вырос до отметки 74.5 рублей за доллар.</p>\n<p>&nbsp;</p>\n<p>Из-за боковой динамики валютной пары две первые сделки Валютной стратегии в начале июля оказались убыточными, доходность по каждой из них составила -0.4%.</p>\n<p>Однако 16 июля стратегия открыла длинную позицию по цене приблизительно 71.5 рублей за доллар, которую удерживала до 5 августа, и поймала краткосрочный скачок курса USD/RUB после выхода из длительного бокового диапазона.</p>\n<p>Доходность стратегии за июль составила <strong>+0.8% </strong>с учетом реальных цен исполнения и издержек стратегии.</p>\n<p>&nbsp;</p>\n<p>На среднесрочном горизонте по валютной паре USD/RUB наблюдается медленный растущий тренд, начавшийся с начала июня. В текущей динамике курса преобладает низкий уровень волатильности, а длительные консолидации чередуются с краткосрочными импульсными движениями.</p>\n<p>&nbsp;</p>\n<p>На наш взгляд, наиболее вероятным сценарием является сохранение текущей тенденции в ближайшие несколько недель. После консолидации курса в диапазоне 72.5 &ndash; 74.5 вероятен новый импульс в зону 76-78, где с большой вероятностью следует ожидать турбулентности и роста волатильности валютной пары.</p>\n<p>&nbsp;</p>\n<p>Валютная стратегия ориентирована на трендовые движения продолжительностью от нескольких дней до нескольких недель, независимо от их направления. Резкие движения курса и большой диапазон колебаний на валютном рынке являются самой благоприятной фазой для стратегии.</p>",
                Date = DateTime.Now,
                StrategiesTitle = "Стратегия автора",
                Picture = "https://fintarget.ru/images/val02.jpg",
                SmallPicture = "https://fintarget.ru/images/val02.jpg",
                Active = true,
                Subscription = false,
            });
            _apiDB.InsertWithInt32Identity(new Analytics
            {
                FriendlyUrl = $"article_{author.Id}_2",
                AuthorId = author.Id,
                Title = "Обзор Валютной стратегии за июль",
                CutHtml = "<p>Доходность стратегии за июль составила <strong>+0.8% </strong>с учетом реальных цен исполнения и издержек стратегии.</p>",
                FullHtml =
                    "<p>Практически весь июль валютная пара USD/RUB торговалась в узком ценовом диапазоне 70.5 &ndash; 72.5 рублей за доллар. Лишь в конце месяца произошел выход из консолидации, и курс USD/RUB вырос до отметки 74.5 рублей за доллар.</p>\n<p>&nbsp;</p>\n<p>Из-за боковой динамики валютной пары две первые сделки Валютной стратегии в начале июля оказались убыточными, доходность по каждой из них составила -0.4%.</p>\n<p>Однако 16 июля стратегия открыла длинную позицию по цене приблизительно 71.5 рублей за доллар, которую удерживала до 5 августа, и поймала краткосрочный скачок курса USD/RUB после выхода из длительного бокового диапазона.</p>\n<p>Доходность стратегии за июль составила <strong>+0.8% </strong>с учетом реальных цен исполнения и издержек стратегии.</p>\n<p>&nbsp;</p>\n<p>На среднесрочном горизонте по валютной паре USD/RUB наблюдается медленный растущий тренд, начавшийся с начала июня. В текущей динамике курса преобладает низкий уровень волатильности, а длительные консолидации чередуются с краткосрочными импульсными движениями.</p>\n<p>&nbsp;</p>\n<p>На наш взгляд, наиболее вероятным сценарием является сохранение текущей тенденции в ближайшие несколько недель. После консолидации курса в диапазоне 72.5 &ndash; 74.5 вероятен новый импульс в зону 76-78, где с большой вероятностью следует ожидать турбулентности и роста волатильности валютной пары.</p>\n<p>&nbsp;</p>\n<p>Валютная стратегия ориентирована на трендовые движения продолжительностью от нескольких дней до нескольких недель, независимо от их направления. Резкие движения курса и большой диапазон колебаний на валютном рынке являются самой благоприятной фазой для стратегии.</p>",
                Date = DateTime.Now,
                StrategiesTitle = "Стратегия автора",
                Picture = "https://fintarget.ru/images/q2.jpg",
                SmallPicture = "https://fintarget.ru/images/q2.jpg",
                Active = true,
                Subscription = false
            });

            return author.Id;
        }

        public TestDataBuilder AddSecurity(string symbol, string classCode = null, string currency="SUR", decimal? lastPrice = 0)
        {
            var sec = new SecurityInfo()
            {
                Symbol = symbol,
                LastPrice = lastPrice ?? 100,
                ClassCode = classCode ?? "TQBR",
                Currency = currency,
                LotSize = 1,
                PriceStep = 0.1m,
                Type = "Security",
                Name = symbol,
                ISINCode = "ISIN" + symbol,
                IsCurrent = true,
                ClassName = classCode,
                LastTime = DateTime.Now,
                Key = $"{symbol} {(classCode ?? "TQBR")} QUIK"
            };

            Securities[symbol] = sec;
            var prices = new System.Collections.Generic.List<STS.Kernel.Objects.PriceItem>();
            sec.Id = _hsDB.InsertWithInt32Identity(sec);
            for (var date = System.DateTime.Now.AddYears(-1); date < System.DateTime.Now; date = date.AddDays(1))
            {
                // A * sin( B*t + C)
                double A = (0.1 + _rnd.NextDouble()) / 4;
                double B = (0.1 + _rnd.NextDouble()) / 200;
                double C = _rnd.NextDouble() * 6;
                double NoiseLevel = 1 / 100.0;
                var priceItem = new STS.Kernel.Objects.PriceItem()
                {
                    Date = date,
                    Price = (decimal) ((double) (sec.LastPrice ?? 0) * (1 + A *
                        (Math.Sin((System.DateTime.Now - date).TotalDays * B + C) + _rnd.NextDouble() * NoiseLevel)))
                };
                prices.Add(priceItem);
                _hsDB.Insert(new HS.Models.EndOfDayRow()
                {
                    Date = date.ToIntYYYYMMDD(),
                    SecurityId = sec.Id,
                    Price = priceItem.Price
                });
            }

            PriceItemsMap[sec.Key] = prices.ToArray();

            return this;
        }

        public StrategyTestDataBuilder AddStrategy(int authorId, string name, string currency,
            System.Action<Api.Models.Strategy, Expert.Models.Strategy> setter = null)
        {
            return new StrategyTestDataBuilder(this, authorId, name, currency, 1, setter);
        }

        public StrategyTestDataBuilder AddStrategyWithLeverage(int authorId, string name, int leverage, string currency,
            System.Action<Api.Models.Strategy, Expert.Models.Strategy> setter = null)
        {
            return new StrategyTestDataBuilder(this, authorId, name,  currency, leverage, setter);
        }
    }

    public class StrategyTestDataBuilder : TestDataBuilder
    {
        private readonly Strategy _strategy;
        private static readonly Random GuidRandom = new(100);
        private TestDataBuilder _parent;

        public StrategyTestDataBuilder(TestDataBuilder builder, int authorId, string name, string currency, int leverage, 
            System.Action<Api.Models.Strategy, Expert.Models.Strategy> setter) : base(builder)
        {
            _parent = builder;
            var strategy1 = new Api.Models.Strategy()
            {
                Name = name,
                Id = NewGuid(GuidRandom),
                DescriptionText =
                    "Портфель подходит для умеренных инвесторов с горизонтом от трех лет, которые хотят инвестировать в российские рынки акций и облигаций, не имея статуса квалифицированного инвестора и не осуществляя операций по конвертации валюты",
                FriendlyUrl = name.Unidecode().Replace(" ", "-").ToLower(),
                AuthorId = authorId,
                IIS = true,
                Tag = "Использует волатильность рынка для получения доходности даже в кризис",
                DescriptionHtml =
                    "<p>Валютная стратегия &ndash; одна из старейших в департаменте автоследования. Ее целью всегда было заработать больше пассивного прироста курса доллара США.</p>\n<p>Во многом результаты стратегии зависели от рыночной волатильности. Чем выше была волатильность, тем больше возможностей открывалось для локальных сделок. Однако, в сегодняшних реалиях бокового движения базового актива возникла необходимость в обновлении стратегии.</p>\n<p>Команда экспертов потратила месяцы исследований и тестирований, чтобы подобрать оптимальный формат для новых условий. Благодаря этому Валютная стратегия работает даже тогда, когда доллар не двигается или снижается. При этом сохраняются защитные функции на случай резкого роста курса базового актива.</p>\n<p><span style=\"font-size: 8pt;\">При подключении услуги \"Автоконсультирование\"/\"Автоследование\" клиент подтверждает факт ознакомления с информацией, предусмотренной подпунктами 1.9, 1.10 и пунктом 2 Указания Банка России от 03.06.2021 № 5809-У \"О требованиях к программам для электронных вычислительных машин, используемым для оказания услуг по инвестиционному консультированию\".</span></p>",
                InfoHtml =
                    "<p><b>Защита от девальвации</b></p><p>Задача стратегии – показывать результат на уровне банковских ставок и ОФЗ в периоды стабильного валютного курса USD/RUB и повышенные показатели в периоды сильного роста доллара США.  </p><info-separator/><p><b>Облигации с валютной защитой</b></p><p>В основе стратегии лежат рублевые облигации или облигационные фонды. Они регулярно прирастают за счёт купонных выплат по облигациям. В периоды затишья на рынках большая часть портфеля состоит из БПИФ высокодоходных облигаций. Когда же риски начинают возрастать, то происходит переход в защитные инструменты краткосрочные облигации Минфина РФ (ОФЗ) с хеджированием валютного курса фьючерсом на пару USDRUB.</p><info-separator/><p><b>Повышенный доход в кризис</b></p><p>Во время активного роста курса доллара США стратегия открывает длинные позиции на фьючерсе USD/RUB для получения доходности, покрывающей падение рубля. Важно, что использование фьючерсов не означает выход из облигационных фондов.</p>",
                PictureFormat = "jpeg",
                CardImageUrl = "https://fintarget.ru/images/strat/D42A372A-4973-41EB-B2A8-4B072E30D971.png",
                ImageUrl = "https://295628.selcdn.ru/Premier/Vs_MI.png",
                BackColor = "ffa300",
                MinInvestProfileId = 1,
                MaxIndustryWeight = 90 * leverage,
                Rating = 4.5,
                MaxPositionWeight = 90 * leverage,
                MaxInstrumentFraq = 0.9m * leverage,
                ActualDrawdown = 30,
                CurrencyId = currency,
                Leverage = leverage,
                Autofollow = true,
                Autoconsult = true,
                StartDate = DateTime.Now.AddYears(-1),
                Open = true,
                Order = 1,
                Category = _PRICE_CAT_10,
                KindId = _STRAT_KIND_STANDARD,
                DurationId = _DURATION_YEAR,
                IndexId = _MOEX_INDEX,
                Securities = "[\".*\"]"
            };
            var strategyCabinet = new Expert.Models.Strategy()
            {
                Id = strategy1.Id,
                RecalcMode = 2,
                ManagerId = authorId,
                CreatorId = authorId,
                Securities = "[\".*\"]",
                CreateTime = System.DateTime.Now.AddYears(-1),
                MaxInstrumentWeight = strategy1.MaxIndustryWeight,
                Currency = strategy1.CurrencyId,
                SubscriptionThreshold = 100000,
                Active = 1,
                Autoconsult = strategy1.Autofollow,
                Autofollow = strategy1.Autoconsult,
                Leverage = strategy1.Leverage,
                Name = strategy1.Name,
                Status = Expert.Models.StrategyStatus.Standard
            };
            setter?.Invoke(strategy1, strategyCabinet);

            _apiDB.Insert(strategy1);
            _cabDB.Insert(strategyCabinet);
            _lcsDB.Insert(new LCS.Models.StrategyDTO()
            {
                Id = strategy1.Id,
                Json = Newtonsoft.Json.JsonConvert.SerializeObject(new LCS.Models.Strategy()
                {
                    Id = strategy1.Id,
                    Title = strategyCabinet.Name,
                    ManagerId = strategyCabinet.ManagerId,
                    CreatorId = strategyCabinet.CreatorId,
                    ProfileId = strategyCabinet.ProfileId,
                    RecalcMode = strategyCabinet.RecalcMode,
                    Currency = strategyCabinet.Currency,
                    IsPortfolio = strategyCabinet.IsPortfolio,
                    IsAutofollow = strategyCabinet.Autofollow,
                    IsAutoconsult = strategyCabinet.Autoconsult,
                    AllowCell = true,
                    Active = strategyCabinet.Active == 1,
                    AllowedSecurities = strategyCabinet.AllowedSecuritiesArray,
                    Leverage = strategyCabinet.Leverage
                })
            });

            _strategy = new Strategy()
            {
                SignalProcessor =
                    new PositionCalculator.SignalProcessor(1, PositionCalculator.SignalProcessor.CalcMode.CurrentPrice),
                Signals = new System.Collections.Generic.List<LCS.Models.SignalDTO>(),
                ApiStrategy = strategy1,
                CabinetStrategy = strategyCabinet
            };

            foreach (var articleId in _apiDB.Analytics.Where(a => a.AuthorId == strategy1.AuthorId).Select(a => a.Id).ToArray())
            {
                _apiDB.Insert(new AnalyticsStrategy
                {
                    AnalyticsId = articleId,
                    StrategyId = strategy1.Id,
                    ShowInStrategy = true
                });
            }

            _apiDB.Insert(new StrategySalesPoints
            {
                StrategyId = strategy1.Id,
                Title = "Защита от девальвации",
                Text =
                    "Задача стратегии – показывать результат на уровне банковских ставок и ОФЗ в периоды стабильного валютного курса USD/RUB и повышенные показатели в периоды сильного роста доллара США."
            });
            _apiDB.Insert(new StrategySalesPoints
            {
                StrategyId = strategy1.Id,
                Title = "Облигации с валютной защитой",
                Text =
                    "В основе стратегии лежат рублевые облигации или облигационные фонды. Они регулярно прирастают за счёт купонных выплат по облигациям. В периоды затишья на рынках большая часть портфеля состоит из БПИФ высокодоходных облигаций. Когда же риски начинают возрастать, то происходит переход в защитные инструменты краткосрочные облигации Минфина РФ (ОФЗ) с хеджированием валютного курса фьючерсом на пару USDRUB."
            });

            Strategies[strategy1.Id] = _strategy;
        }

        public StrategyTestDataBuilder AddSignal(string security, System.DateTime date, decimal? weight = null,
            decimal? price = null, System.Action<LCS.Models.SignalDTO> setter = null)
        {
            var security1 = Securities[security];
            var signal1 = new LCS.Models.SignalDTO()
            {
                SecurityKey = security1.Key,
                OpenTime = date,
                OpenPrice = price ?? (security1.LastPrice.Value) * 0.9m,
                Weight = weight ?? 0.2m,
                ManagerId = _strategy.ApiStrategy.AuthorId,
                StrategyId = _strategy.ApiStrategy.Id,
            };
            setter?.Invoke(signal1);

            _strategy.SignalProcessor.AddSignal(new PositionCalculator.Signal()
            {
                Security = new PositionCalculator.Security(signal1.SecurityKey),
                Weight = signal1.Weight,
                OpenPrice = signal1.OpenPrice,
                OpenQuotation = signal1.OpenPrice,
                OpenTime = signal1.OpenTime,
            });
            var state1 = _strategy.SignalProcessor.GetPositionBundles();
            signal1.State = LCS.Models.SignalDTO.StateToJson(state1);
            signal1.RealizedPnl = state1.RealizedPnL;

            signal1.Id = _lcsDB.InsertWithInt32Identity(signal1);
            _csDB.InsertWithInt32Identity(new CS.Kernel.Model.StrategySignalDBO()
            {
                InitId = signal1.Id,
                StartegyId = _strategy.ApiStrategy.Id,
                Date = signal1.OpenTime,
                Portfolio = Newtonsoft.Json.JsonConvert.SerializeObject(state1.ActivePositions.ToDictionary(
                    p => p.Key.GetKey(),
                    p => new LCS.Kernel.Objects.StrategySignal.PortfolioEntry()
                        {Weight = p.Value.Weight, AvgWeightedEntryPrice = p.Value.OpenPrice})),
                Processed = CS.Kernel.Model.StrategySignal.ProcessedEnum.Processed,
                SecurityKey = signal1.SecurityKey,
                SignalWeight = signal1.Weight
            });

            _apiDB.Insert(new Api.Models.StrategySignal()
            {
                Symbol = security1.Symbol,
                StrategyId = _strategy.ApiStrategy.Id,
                Name = security1.Name,
                StrategyName = _strategy.ApiStrategy.Name,
                Isin = security1.ISINCode,
                Time = signal1.OpenTime,
                Id = signal1.Id
            });

            return this;
        }

        public Strategy AddHistory()
        {
            var state1 = _strategy.SignalProcessor.GetPositionBundles();

            foreach (var position in state1.ActivePositions.Values)
            {
                var sec = Securities[position.Security.Symbol];

                _apiDB.Insert(new Api.Models.StrategyPosition()
                {
                    StrategyId = _strategy.ApiStrategy.Id,
                    AvgPrice = position.OpenPrice,
                    Symbol = position.Security.Symbol,
                    Isin = sec.ISINCode,
                    ClassCode = sec.ClassName,
                    LastPrice = sec.LastPrice ?? 0,
                    Name = sec.Name,
                    TypeName = sec.Type
                });
            }

            var history1 = STS.Kernel.StsService.CalculateStrategyHistory(_strategy.SignalProcessor.Signals.Select(s =>
                new STS.Kernel.Objects.Signal()
                {
                    Weight = s.Weight,
                    Security = s.Security,
                    Security2 = s.Security2,
                    State = s.State,
                    Type = s.Type,
                    OpenPrice = s.OpenPrice,
                    OpenQuotation = s.OpenQuotation,
                    OpenTime = s.OpenTime
                }).ToArray(), PriceItemsMap, PositionCalculator.SignalProcessor.CalcMode.CurrentPrice, 0.01m, 0.1m);

            var historyJson = Newtonsoft.Json.JsonConvert.SerializeObject(history1.Select(h =>
                new Api.Models.HistoryPoint() {t = h.Time.ToJsonTime(), v = h.Value, vc = h.Vc, vr = h.Vr}));

            _apiDB.Insert(new Api.Models.StrategyPL()
            {
                StrategyId = _strategy.ApiStrategy.Id,
                HistoryJson = historyJson
            });

            _apiDB.StrategyHistorySummary.Where(s => s.StrategyId == _strategy.ApiStrategy.Id).Update(s =>
                new Api.Models.StrategyPLSummary()
                {
                    FromStart = 0.2m,
                    MeanYear = 0.3m,
                    FromStartClear = 0.4m,
                    ReducedHistoryLarge = historyJson,
                    ReducedHistorySmall = historyJson,
                    LastWeek = 0.01m,
                    MeanYearClear = 0.4m
                });

            return _strategy;
        }

        public class Strategy
        {
            internal PositionCalculator.SignalProcessor SignalProcessor;
            public Api.Models.Strategy ApiStrategy { get; set; }
            public Expert.Models.Strategy CabinetStrategy { get; set; }
            public List<LCS.Models.SignalDTO> Signals { get; set; }

            public SignalProcessor.State ActiveState => SignalProcessor.GetPositionBundles();
        }
    }

    public class ClientTestDataBuilder : TestDataBuilder
    {
        private readonly CS.Kernel.Model.ClientAccount _clientAccount;
        private static Random _guidRandom = new Random(100);
        private static readonly Random _clientCodeRandom = new Random(200);
        private TestDataBuilder _parent;

        public ClientTestDataBuilder(TestDataBuilder builder, decimal? value, System.Guid? strategy = null,
            System.Action<CS.Kernel.Model.ClientAccount> setter = null) : base(builder)
        {
            var clientCode = "";
            _parent = builder;
            do
            {
                clientCode = "" + (100000 + _clientCodeRandom.Next(989999));
            } while (_clients.ContainsKey(clientCode));


            var client = new CS.Kernel.Model.ClientAccount()
            {
                AgreementId = NewGuid(_guidRandom),
                ClientId = NewGuid(_guidRandom),
                ClientCode = clientCode,
                Status = strategy != null
                    ? CS.Kernel.Model.ClientAccount.StatusEnum.AutoFollow
                    : CS.Kernel.Model.ClientAccount.StatusEnum.Unattached,
                StrategyId = strategy,
                Value = value ?? (decimal) ((int) System.Math.Pow(Random.Next(100) + 5, 2) * 1000 ^ 100000000),
            };

            client.InitialValue = client.Value;

            _clientAccount = client;
            var clientInfo = new CS.Kernel.Model.ClientInfo()
            {
                ClientId = client.ClientId,
                AgreementId = client.AgreementId,
                FirstName = new[] {"Алексей", "Сергей", "Иван", "Петр"}.TakeRandom(1).First(),
                LastName = new[] {"Иванов", "Петров", "Васечкин", "Овечкин", "Смит", "Шнеркель"}.TakeRandom(1).First(),
                MiddleName = new[] {"Иванович", "Петрович", "Игоревич", "Наумович", "Викторович", "Ньютонович"}.TakeRandom(1).First(),
                Agreement = $"{10000 + Random.Next(99999)}/{Random.Next(30)}-м",
                InvestmentAdviceAgreementDate = DateTime.Now.AddDays(-Random.NextDouble() * 10),
                Profile = "Normal",
                Phone = "8(495)45" + 10000 + Random.Next(89999),
                Email = $"a{Random.Next()}@gmail.com",
                AgreementStartDate = System.DateTime.Now.Date.AddDays(-1),
                ServiceDate = client.IsAttached
                    ? System.DateTime.Now.AddDays(-Random.Next(2, 200))
                    : null,
                StrategyName = strategy != null ? Strategies[strategy.Value].ApiStrategy.Name : null
            };
            client.Client = clientInfo;
            setter?.Invoke(client);
            client.Id = _csDB.InsertWithInt32Identity(client);
            _csDB.ClientAccounts.Where(c => c.Id == client.Id).Set(c => c.Value, client.Value).Update();
            _csDB.Insert(clientInfo);

            client.Client = clientInfo;
            _clients[client.ClientCode] = client;

            _apiDB.Insert(new Api.Models.Client()
            {
                FirstName = clientInfo.FirstName,
                LastName = clientInfo.LastName,
                Id = client.ClientId,
                Phone = clientInfo.Phone,
                Email = clientInfo.Email
            });

            _apiDB.Insert(new Api.Models.ClientAccount()
            {
                Id = client.Id,
                AgreementId = client.AgreementId,
                ClientId = client.ClientId,
                ClientCode = client.ClientCode,
                StrategyId = client.StrategyId,
                AgreementName = client.Client.Agreement,
                AgreementStartDate = client.Client.AgreementStartDate,
                StrategyName = client.Client.StrategyName,
                Status = (Api.Models.ServiceKind?) (int?) client.Status,
                SubscriptionRequestDate = client.Client.ServiceDate,
                InvestmentAdviceAgreementDate = client.Client.ServiceDate
            });

            _csDB.Insert(new CS.Kernel.Model.ClientAccountPosition()
            {
                Currency = "SUR",
                SecurityKey = "",
                ClientCode = client.ClientCode,
                Number = client.Value,
                AvgPrice = 1,
            });

            _apiDB.Insert(new Api.Models.AccountPortfolio()
            {
                AccountId = client.Id, Currency = "SUR", FreeFunds = client.Value, LiquidPrice = client.Value,
                PortfolioPrice = 0, PositionsCost = 0
            });
            _apiDB.Insert(new Api.Models.AccountPortfolio()
            {
                AccountId = client.Id, Currency = "USD", FreeFunds = client.Value / 100,
                LiquidPrice = client.Value / 100,
                PortfolioPrice = 0, PositionsCost = 0
            });
            _apiDB.Insert(new Api.Models.AccountPortfolio()
            {
                AccountId = client.Id, Currency = "EUR", FreeFunds = client.Value / 100,
                LiquidPrice = client.Value / 100,
                PortfolioPrice = 0, PositionsCost = 0
            });

            if (client.StrategyId != null)
            {
                int sId = _csDB.StrategySignals.Where(s => s.StartegyId == client.StrategyId).OrderByDescending(s => s.Id).FirstOrDefault()?.Id ?? 1;
                var positions = (Strategies[client.StrategyId.Value].ActiveState ?? new SignalProcessor.State()).ActivePositions;
                long lastCSigId = 0;
                for (int q = 0; q < 2; q++)
                {
                    long cSigId = 0;
                    cSigId = _csDB.InsertWithInt64Identity(new ClientSignal()
                    {
                        DateTime = client.Client.ServiceDate!.Value.AddHours(1),
                        ClientId = client.Id,
                        SignalId = sId,
                        Processed = ClientSignal.ProcessedEnum.Processed,
                        Portfolio = JsonConvert.SerializeObject(new {Value = client.Value, Positions = Array.Empty<int>()}),
                    });

                    var exec = JsonConvert.SerializeObject(
                        new ClientSignalExecution()
                        {
                            Positions = positions.Select(p =>
                            {
                                var sec = Securities[p.Key.Symbol];
                                return new TradeSignal.TradeSignalPosition()
                                {
                                    Security = sec.Key,
                                    ClientId = client.ClientCode,
                                    ExecNumber = (long) (client.Value / sec.LastPrice!.Value),
                                    Number = (long) (client.Value / sec.LastPrice!.Value),
                                    ExecValue = client.Value,
                                    ExecPrice = sec.LastPrice!.Value,
                                    ExecEndTime = client.Client.ServiceDate,
                                };
                            }),
                            SignalId = cSigId,
                        });

                    _csDB.ClientSignals.Where(s => s.Id == cSigId).Set(s => s.Execution, exec).Update();
                    lastCSigId = cSigId;
                }

                // some positions & signals
                foreach (var pos in positions)
                {
                    var sec = Securities[pos.Key.Symbol];
                    int q = (int) (client.Value / sec.LastPrice!.Value);
                    _apiDB.Insert(new ClientAccountPosition()
                    {
                        SecurityKey = pos.Key.GetKey(), Currency = "SUR", Name = sec.Name, Quantity = q, Weight = pos.Value.Weight, AccountId = client.Id,
                        AvgPrice = sec.LastPrice!.Value, CurrentPrice = sec.LastPrice, CurrentValue = client.Value * pos.Value.Weight,
                        UnrealizedPnl = 0.2m, TotalPnL = 0.5m
                    });

                    _apiDB.Insert(new Api.Models.AccountSignal()
                    {
                        Id = lastCSigId, Currency = "SUR", Date = pos.Value.OpenTime, AccountId = client.Id, ExecCount = q,
                        ExecValue = client.Value * pos.Value.Weight, ExecPrice = sec.LastPrice!.Value, SecurityKey = sec.Key, RealizedPL = 0.1m,
                        RealizedPLPct = 0.2m, RealizedPLPctPortfolio = 0.2m
                    });
                }

                // client PL
                double prev = 0;
                List<AccountPL> pls = new List<AccountPL>();
                for (DateTime date = client.Client.ServiceDate!.Value; date <= DateTime.Now; date += TimeSpan.FromDays(1))
                {
                    var next = Random.NextDouble() - prev / 2;
                    pls.Add(new AccountPL() {Date = date.ToJsonTime(), AccountId = client.Id, PnL = (decimal) (prev + next)});
                    prev += next;
                }

                _apiDB.BulkCopy(pls);
            }
        }

        public ClientTestDataBuilder AddPosition(string symbol, int number, decimal price)
        {
            _csDB.Insert(new CS.Kernel.Model.ClientAccountPosition()
            {
                Currency = "SUR",
                SecurityKey = Securities[symbol].Key,
                ClientCode = _clientAccount.ClientCode,
                Number = number,
                AvgPrice = price,
            });

            return this;
        }
    }
}