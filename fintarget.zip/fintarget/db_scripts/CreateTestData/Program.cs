﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Threading;
using LinqToDB.Configuration;
using LinqToDB.Data;
using NLib.Linq2dbExtensions;

#nullable enable

namespace CreateTestData
{
    class DbSettings : ILinqToDBSettings
    {
        public DbSettings(string connection)
        {
            _connection = connection;
        }

        private readonly string _connection;

        public IEnumerable<IDataProviderSettings> DataProviders => null;
        public string DefaultConfiguration => null;
        public string DefaultDataProvider => "SqlServer";

        public IEnumerable<IConnectionStringSettings> ConnectionStrings { get 
            {
                var svcs = new[]
                    {"ClientService", "LifeCycleService", "StatService", "CabinetDB", "FinTarget", "HistoryService", "ExternalService", "TradeService"};
                

                return svcs.Select(s => new DBConnectionStringSettings()
                {
                    ProviderName = "SqlServer",
                    ConnectionString = _connection + $";Database={s}",
                    Name = s
                });
            }
        }
    }
    
    class Program
    {
        static int Main(string[] args)
        {
            try
            {
                if (args.Length < 1) throw new ArgumentException("Must be at least one argument: server connection");
                string server = args[0];

                var conBuilder = new SqlConnectionStringBuilder()
                {
                    DataSource = server,
                    UserID = args.Length > 1 ? args[1] : "SA",
                    Password = args.Length > 2 ? args[2] : "",
                    IntegratedSecurity = false,
                    TrustServerCertificate = true
                };
                var dbSettings = new DbSettings(conBuilder.ConnectionString);
                DataConnection.DefaultSettings = dbSettings;

                Console.WriteLine("Applying migrations...");

                int seed = args.Length > 3 ? int.Parse(args[3]) : Environment.TickCount;
                TestDataBuilder builder = new TestDataBuilder(seed);

                Console.WriteLine("Writing test data...");

                /* AUTHORS */

                int authorId = builder.AddAuthor("admin");

                /* SECURITIES */

                builder.AddSecurity("GAZP", "TQBR", "SUR", 100)
                    .AddSecurity("LKOH", "TQBR", "SUR", 5000)
                    .AddSecurity("MOEX", "TQBR", "SUR",123)
                    .AddSecurity("ROSN", "TQBR", "SUR", 256)
                    .AddSecurity("MAGN", "TQBR", "SUR", 123)
                    .AddSecurity("TATN", "TQBR", "SUR", 567)
                    .AddSecurity("AAPL","SPBXM","USD",105)
                    .AddSecurity("TSLA","SPBXM","USD",201);

                /* STRATEGIES */

                var strategy1 = builder.AddStrategy(authorId, "А. Уверенный рост", "SUR")
                    .AddSignal("GAZP", DateTime.Now.AddDays(-365), 0.5m, 90)
                    .AddSignal("LKOH", DateTime.Now.AddDays(-5), 0.2m, 3000)
                    .AddHistory()
                    .ApiStrategy;

                var strategy2 = builder.AddStrategyWithLeverage(authorId, "Б. Акции с плечом", 2, "SUR")
                    .AddSignal("GAZP", DateTime.Now.AddDays(-365), 0.6m, 90)
                    .AddSignal("MOEX", DateTime.Now.AddDays(-5), 0.6m, 120)
                    .AddHistory()
                    .ApiStrategy;

                var strategy3 = builder.AddStrategy(authorId, "Best of USA", "USD", (strategy, _) => strategy.DescriptionHtml += "Подключен клиент 0236e5f6-d04d-4b93-9c71-dff0bd2f66a8" )
                    .AddSignal("AAPL", DateTime.Now.AddDays(-365), 0.5m, 90)
                    .AddSignal("TSLA", DateTime.Now.AddDays(-5), 0.2m, 150)
                    .AddHistory()
                    .ApiStrategy;
                
                /* CLIENTS */

                int NClients = 100;
                int NAttached = 20;


                for (int q = 0; q < NAttached; q++)
                {
                    decimal value = (q + 5) * (q + 5) * 10000m;
                    builder
                        .AddClient(value, strategy1.Id, c=>c.Client.ServiceDate = DateTime.Now.AddDays(-builder.Random.Next(10,50)))
                        .AddPosition("GAZP", (int) (value / 1000), 100);
                }

                builder.AddClient(500000, strategy1.Id, (c) => { c.ClientId = c.Client.ClientId = Guid.Parse("a4c232d9-3078-4b8c-bd78-7685571180dc"); });
                builder.AddClient(500000, strategy1.Id, (c) => { c.ClientId = c.Client.ClientId = Guid.Parse("3ff29ea3-156e-479e-a08c-8c827f3abf23"); });
                builder.AddClient(50000, strategy3.Id, (c) => { c.ClientId = c.Client.ClientId = Guid.Parse("0236e5f6-d04d-4b93-9c71-dff0bd2f66a8"); });

                for (int q = 0; q < NClients - NAttached; q++)
                {
                    builder.AddClient((q + 5) * (q + 5) * 10000 );
                }
                builder.AddClient(500000, null, (c) => { c.ClientId = c.Client.ClientId = Guid.Parse("2FB63077-CEE1-49A8-9F09-33EC33FFD6ED"); });
            
                Console.WriteLine("Finished create test data");

                if (args.Any(a => a == "-hc"))
                {
                    using (var httpServer = new HttpServer(14000))
                    {
                        httpServer.OnRequest += (o, e) => { Console.WriteLine($"HC Request {e.ClientIp} {e.RequestUrl}"); };
                        httpServer.Listen();
                        Console.WriteLine("Healthcheck is listening on 14000 now");
                        while (true)
                        {
                            Thread.Sleep(1000);
                        }
                    }
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Error: "+e.Message + " "+e.StackTrace);
                return 1;
            }

            return 0;
        }
    }

    
}