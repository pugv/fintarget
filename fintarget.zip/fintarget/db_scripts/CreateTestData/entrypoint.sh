#!/bin/bash

# Start the script to create the DB and user
if [ ! -f /opt/mssql/data/CabinetDB.mdf ]; then
./configure-db.sh &
fi

# Start SQL Server
./opt/mssql/bin/sqlservr --accept-eula


