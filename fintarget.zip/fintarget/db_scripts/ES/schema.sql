﻿USE [ExternalService]
GO
/****** Object:  Table [dbo].[Accounts]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Accounts](
	[Id] [int] NOT NULL,
	[ClientCode] [nvarchar](64) NOT NULL,
	[StrategyId] [uniqueidentifier] NULL,
	[StrategyType] [nvarchar](24) NULL,
	[StrategyName] [nvarchar](64) NULL,
	[MinBalance] [decimal](19, 10) NULL,
	[TariffId] [uniqueidentifier] NULL,
	[Active] [bit] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[UpdateTime] [smalldatetime] NOT NULL,
	[FutCode] [nvarchar](64) NULL,
	[ChangeTime] [datetime] NULL,
	[Phone] [nvarchar](24) NULL,
	[Qual] [bit] NULL,
	[ClientTariffId] [uniqueidentifier] NULL,
	[is_marginal] [bit] NULL,
	[partner_id] [uniqueidentifier] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Branches]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Branches](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[branch_code] [uniqueidentifier] NOT NULL,
	[branch_name] [nvarchar](256) NULL,
	[ois_name] [nvarchar](256) NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_branch_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[client_examination]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[client_examination](
	[client_id] [uniqueidentifier] NOT NULL,
	[code] [varchar](64) NOT NULL,
	[status] [int] NOT NULL,
	[timestamp] [datetime2](7) NOT NULL,
 CONSTRAINT [pk_client_exam_client_id] PRIMARY KEY NONCLUSTERED 
(
	[client_id] ASC,
	[code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientPackage](
	[ClientId] [int] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Clients]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Clients](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ClientId] [uniqueidentifier] NOT NULL,
	[AgreementId] [uniqueidentifier] NOT NULL,
	[ContractNum] [nvarchar](64) NOT NULL,
	[Login] [nvarchar](64) NULL,
	[Sex] [char](1) NULL,
	[FirstName] [nvarchar](64) NULL,
	[LastName] [nvarchar](64) NULL,
	[MiddleName] [nvarchar](64) NULL,
	[Address] [nvarchar](max) NULL,
	[EventTime] [datetime] NOT NULL,
	[UpdateTime] [smalldatetime] NOT NULL,
	[Confirm] [tinyint] NOT NULL,
	[OrgName] [nvarchar](512) NULL,
	[Phone] [varchar](128) NULL,
	[Email] [varchar](512) NULL,
	[ClientCode] [nvarchar](64) NULL,
	[CloseDate] [smalldatetime] NULL,
	[RiskId] [uniqueidentifier] NULL,
	[RiskTime] [datetime2](7) NULL,
	[InvestAdviceAgreementDate] [smalldatetime] NULL,
	[RiskProfileName] [nvarchar](64) NULL,
	[subaccount_main] [UNIQUEIDENTIFIER] NULL,
	[position] [nvarchar](128) NULL,
	[org_register] [tinyint] NULL,
	[org_register_date] [date] NULL,
	[is_org] [bit] NOT NULL,
	[org_ogrn] [nvarchar](16) NULL,
	[branch_id] [int] NULL,
	[contract_date] [date] NULL,
 CONSTRAINT [PK_ClientAgreementId] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [AK_ClientAgreementId] UNIQUE NONCLUSTERED 
(
	[ClientId] ASC,
	[AgreementId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientTariffExports]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientTariffExports](
	[AgreementId] [uniqueidentifier] NOT NULL,
	[TariffId] [uniqueidentifier] NULL,
	[Expired] [tinyint] NOT NULL,
 CONSTRAINT [PK_AgreementId] PRIMARY KEY NONCLUSTERED 
(
	[AgreementId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Contacts]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Contacts](
	[ContactId] [uniqueidentifier] NOT NULL,
	[Type] [tinyint] NULL,
	[Sms] [tinyint] NULL,
	[Value] [nvarchar](128) NULL,
	[SaveTime] [smalldatetime] NOT NULL,
 CONSTRAINT [PK_Contacts] PRIMARY KEY NONCLUSTERED 
(
	[ContactId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ContractPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ContractPackage](
	[ClientId] [int] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[IIRs]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[IIRs](
	[masterId] [uniqueidentifier] NOT NULL,
	[time] [datetime2](7) NOT NULL,
	[iir_id] [bigint] NOT NULL,
	[sent] [bit] NOT NULL,
	[service_type] [tinyint] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[message_agreement]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[message_agreement](
	[client_id] [int] NOT NULL,
	[message_id] [uniqueidentifier] NOT NULL,
	[event_type] [tinyint] NOT NULL,
	[event_time] [datetime2](7) NOT NULL,
	[add] [bit] NOT NULL,
	[order] [smallint] NOT NULL,
	[xpath] [varchar](256) NULL,
	[value] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[message_contract]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[message_contract](
	[client_id] [int] NOT NULL,
	[message_id] [uniqueidentifier] NOT NULL,
	[event_type] [tinyint] NOT NULL,
	[event_time] [datetime2](7) NOT NULL,
	[order] [smallint] NOT NULL,
	[add] [bit] NOT NULL,
	[xpath] [varchar](256) NULL,
	[value] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[message_errors]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[message_errors](
	[client_id] [int] NULL,
	[message_type] [tinyint] NULL,
	[message_id] [uniqueidentifier] NULL,
	[save_time] [datetime2](7) NOT NULL,
	[data] [nvarchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[messages_raw]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[messages_raw](
	[client_id] [int] NOT NULL,
	[general_agreement] [xml] NULL,
	[subject_contract] [xml] NULL,
	[service_change] [xml] NULL,
	[subject] [xml] NULL,
	[qualification] [xml] NULL,
	[trade_advice] [xml] NULL,
	[risk_profile] [xml] NULL,
	[errors] [int] NOT NULL,
	[save_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_messages_client_id] PRIMARY KEY NONCLUSTERED 
(
	[client_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](256) NOT NULL,
	[active] [bit] NOT NULL,
	[min_balance] [decimal](19, 10) NULL,
	[updated] [int] NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [PK__portfoli__3213E83F804131E8] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_execution]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_execution](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[exec_id] [uniqueidentifier] NOT NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[portfolio_id] [uniqueidentifier] NOT NULL,
	[contract_num] [nvarchar](64) NULL,
	[date] [datetime] NOT NULL,
	[min_balance] [decimal](20, 10) NULL,
	[price] [decimal](20, 10) NOT NULL,
	[confirmed] [bit] NOT NULL,
	[sum_in_rubles] [decimal](20, 10) NOT NULL,
 CONSTRAINT [PK__portfoli__3213E83F4EBD6157] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_execution_position]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_execution_position](
	[id] [int] NOT NULL,
	[exec_id] [int] NOT NULL,
	[symbol] [varchar](64) NOT NULL,
	[price] [decimal](20, 10) NOT NULL,
	[volume] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_leftover]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_leftover](
	[id] [int] NOT NULL,
	[exec_id] [int] NOT NULL,
	[symbol] [varchar](64) NOT NULL,
	[volume] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_leftovers]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_leftovers](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[exec_id] [uniqueidentifier] NOT NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[portfolio_id] [uniqueidentifier] NOT NULL,
	[contract_num] [nvarchar](64) NULL,
	[date] [datetime] NOT NULL,
	[event_id] [uniqueidentifier] NOT NULL,
	[confirmed] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[portfolio_position]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[portfolio_position](
	[portfolio_id] [uniqueidentifier] NOT NULL,
	[symbol] [varchar](64) NOT NULL,
	[weight] [decimal](20, 10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[QualPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QualPackage](
	[ClientId] [int] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RiskPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RiskPackage](
	[Id] [int] NOT NULL,
	[ClientId] [uniqueidentifier] NOT NULL,
	[RiskId] [uniqueidentifier] NULL,
	[EventTime] [datetime2](7) NULL,
	[SaveTime] [datetime] NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ServicePackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ServicePackage](
	[ClientId] [int] NOT NULL,
	[ServiceId] [uniqueidentifier] NULL,
	[AgreementId] [uniqueidentifier] NULL,
	[State] [varchar](36) NULL,
	[EventTime] [datetime] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Strategies]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Strategies](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StrategyId] [uniqueidentifier] NOT NULL,
	[StrategyName] [nvarchar](max) NOT NULL,
	[StrategyType] [smallint] NOT NULL,
	[ManagerId] [int] NOT NULL,
	[CreateTime] [datetime2](7) NOT NULL,
	[Confirm] [tinyint] NOT NULL,
	[UpdateTime] [datetime2](7) NOT NULL,
	[state] [tinyint] NOT NULL,
	[strategy_props] [int] NULL,
 CONSTRAINT [FK_StrategyId] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_manager_audit]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_manager_audit](
	[id] [int] NOT NULL,
	[updated] [tinyint] NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
 CONSTRAINT [pk_manager_audit_id] PRIMARY KEY NONCLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_manager_info]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_manager_info](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[employee_id] [nvarchar](32) NULL,
	[is_org] [bit] NOT NULL,
	[full_name] [nvarchar](256) NULL,
	[is_insider_fintarget] [bit] NOT NULL,
	[insider_date] [date] NULL,
	[passport_no] [nvarchar](16) NULL,
	[passport_id] [nvarchar](16) NULL,
	[passport_issued_whom] [nvarchar](256) NULL,
	[passport_issued_when] [date] NULL,
	[birth_date] [date] NULL,
	[citizenship] [nvarchar](64) NULL,
	[org_ogrn] [nvarchar](16) NULL,
	[org_inn] [nvarchar](16) NULL,
	[updated] [tinyint] NOT NULL,
	[update_time] [datetime2](7) NOT NULL,
	[event_id] [uniqueidentifier] NOT NULL,
	[agreement_num] [nvarchar](32) NULL,
	[commission] [tinyint] NULL,
	[author_id] [int] NULL,
	[is_representative] [bit] NOT NULL,
	[org_kpp] [nvarchar](16) NULL,
	[parent_id] [int] NULL,
	[state] [tinyint] NOT NULL,
 CONSTRAINT [pk_manager_id] PRIMARY KEY NONCLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [ak_event_id] UNIQUE NONCLUSTERED 
(
	[event_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_managers]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_managers](
	[strategy_id] [int] NOT NULL,
	[manager_id] [int] NOT NULL,
	[update_time] [datetime2](7) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SubjectPackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SubjectPackage](
	[ClientId] [uniqueidentifier] NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Subscriptions]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Subscriptions](
	[Id] [int] NOT NULL,
	[AgreementId] [uniqueidentifier] NOT NULL,
	[ContractNum] [nvarchar](64) NULL,
	[StrategyType] [smallint] NOT NULL,
	[Status] [tinyint] NOT NULL,
	[Date] [datetime2](7) NULL,
	[EventId] [uniqueidentifier] NOT NULL,
	[Deleted] [bit] NOT NULL,
	[Confirm] [tinyint] NOT NULL,
	[ClientCode] [varchar](64) NOT NULL,
	[FutCode] [varchar](64) NULL,
	[state] [tinyint] NOT NULL,
 CONSTRAINT [PK_EventId] PRIMARY KEY NONCLUSTERED 
(
	[EventId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tmp_contract_bcs_partner]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tmp_contract_bcs_partner](
	[client_id] [int] NOT NULL,
	[event_time] [datetime] NULL,
	[xml_data] [xml] NULL,
	[partner_id] [uniqueidentifier] NULL,
	[partner_name] [nvarchar](256) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TradePackage]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TradePackage](
	[ClientId] [int] NOT NULL,
	[SaveTime] [datetime] NOT NULL,
	[XmlData] [xml] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TradePortfolio]    Script Date: 24.11.2021 12:26:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TradePortfolio](
	[Id] [int] NOT NULL,
	[ClientId] [uniqueidentifier] NOT NULL,
	[AgreementId] [uniqueidentifier] NOT NULL,
	[StrategyId] [uniqueidentifier] NOT NULL,
	[Active] [bit] NOT NULL,
	[EventTime] [datetime] NOT NULL,
	[updated] [tinyint] NOT NULL,
 CONSTRAINT [PK_AgreementStrategyId] PRIMARY KEY NONCLUSTERED 
(
	[AgreementId] ASC,
	[StrategyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Clients] ADD  CONSTRAINT [df_is_org]  DEFAULT ((0)) FOR [is_org]
GO
ALTER TABLE [dbo].[ClientTariffExports] ADD  DEFAULT ((0)) FOR [Expired]
GO
ALTER TABLE [dbo].[IIRs] ADD  CONSTRAINT [DF_IIRs_sent]  DEFAULT ((0)) FOR [sent]
GO
ALTER TABLE [dbo].[message_agreement] ADD  DEFAULT ((0)) FOR [add]
GO
ALTER TABLE [dbo].[message_contract] ADD  DEFAULT ((0)) FOR [add]
GO
ALTER TABLE [dbo].[portfolio] ADD  CONSTRAINT [DF__portfolio__updat__02FC7413]  DEFAULT ((0)) FOR [updated]
GO
ALTER TABLE [dbo].[portfolio] ADD  CONSTRAINT [DF__portfolio__updat__03F0984C]  DEFAULT ('1900-01-01') FOR [update_time]
GO
ALTER TABLE [dbo].[portfolio_execution] ADD  CONSTRAINT [DF__portfolio__confi__08B54D69]  DEFAULT ((0)) FOR [confirmed]
GO
ALTER TABLE [dbo].[portfolio_execution] ADD  CONSTRAINT [DF__portfolio__sumIn__1F98B2C1]  DEFAULT ((0)) FOR [sum_in_rubles]
GO
ALTER TABLE [dbo].[portfolio_leftovers] ADD  DEFAULT ((0)) FOR [confirmed]
GO
ALTER TABLE [dbo].[RiskPackage] ADD  DEFAULT ((0)) FOR [Id]
GO
ALTER TABLE [dbo].[Strategies] ADD  DEFAULT ((0)) FOR [ManagerId]
GO
ALTER TABLE [dbo].[Strategies] ADD  DEFAULT ((0)) FOR [Confirm]
GO
ALTER TABLE [dbo].[Strategies] ADD  DEFAULT ((0)) FOR [state]
GO
ALTER TABLE [dbo].[strategy_manager_audit] ADD  DEFAULT ((0)) FOR [updated]
GO
ALTER TABLE [dbo].[strategy_manager_audit] ADD  DEFAULT ('1900-01-01') FOR [update_time]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  DEFAULT ((0)) FOR [is_org]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  DEFAULT ((0)) FOR [is_insider_fintarget]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  DEFAULT ((0)) FOR [updated]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  DEFAULT ('1900-01-01') FOR [update_time]
GO
ALTER TABLE [dbo].[strategy_manager_info] ADD  CONSTRAINT [df_manager_info_state]  DEFAULT ((0)) FOR [state]
GO
ALTER TABLE [dbo].[Subscriptions] ADD  DEFAULT ((0)) FOR [Status]
GO
ALTER TABLE [dbo].[Subscriptions] ADD  DEFAULT ((0)) FOR [Deleted]
GO
ALTER TABLE [dbo].[Subscriptions] ADD  DEFAULT ((0)) FOR [Confirm]
GO
ALTER TABLE [dbo].[Subscriptions] ADD  CONSTRAINT [df_subscriptions_state]  DEFAULT ((0)) FOR [state]
GO
ALTER TABLE [dbo].[Accounts]  WITH CHECK ADD  CONSTRAINT [FK_Client_Account] FOREIGN KEY([Id])
REFERENCES [dbo].[Clients] ([Id])
GO
ALTER TABLE [dbo].[Accounts] CHECK CONSTRAINT [FK_Client_Account]
GO
ALTER TABLE [dbo].[Clients]  WITH CHECK ADD  CONSTRAINT [fk_branch_id] FOREIGN KEY([branch_id])
REFERENCES [dbo].[Branches] ([id])
GO
ALTER TABLE [dbo].[Clients] CHECK CONSTRAINT [fk_branch_id]
GO
ALTER TABLE [dbo].[portfolio_execution_position]  WITH CHECK ADD  CONSTRAINT [fk_execution] FOREIGN KEY([exec_id])
REFERENCES [dbo].[portfolio_execution] ([id])
GO
ALTER TABLE [dbo].[portfolio_execution_position] CHECK CONSTRAINT [fk_execution]
GO
ALTER TABLE [dbo].[portfolio_leftover]  WITH NOCHECK ADD  CONSTRAINT [fk_leftover] FOREIGN KEY([exec_id])
REFERENCES [dbo].[portfolio_leftovers] ([id])
GO
ALTER TABLE [dbo].[portfolio_leftover] CHECK CONSTRAINT [fk_leftover]
GO
ALTER TABLE [dbo].[portfolio_position]  WITH CHECK ADD  CONSTRAINT [fk_portfolio_position] FOREIGN KEY([portfolio_id])
REFERENCES [dbo].[portfolio] ([id])
GO
ALTER TABLE [dbo].[portfolio_position] CHECK CONSTRAINT [fk_portfolio_position]
GO
ALTER TABLE [dbo].[strategy_managers]  WITH CHECK ADD  CONSTRAINT [fk_strategy_managers_manager_id] FOREIGN KEY([manager_id])
REFERENCES [dbo].[strategy_manager_info] ([id])
GO
ALTER TABLE [dbo].[strategy_managers] CHECK CONSTRAINT [fk_strategy_managers_manager_id]
GO
ALTER TABLE [dbo].[strategy_managers]  WITH CHECK ADD  CONSTRAINT [fk_strategy_managers_strategy_id] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[Strategies] ([Id])
GO
ALTER TABLE [dbo].[strategy_managers] CHECK CONSTRAINT [fk_strategy_managers_strategy_id]
GO

-- replicated from LastingOrderService
IF NOT EXISTS (
	SELECT * FROM sysobjects
	WHERE name='lasting_order_info' AND xtype='U')
CREATE TABLE [dbo].[lasting_order_info] (
	[id] [int] NOT NULL,
	[agreement_id] [UNIQUEIDENTIFIER] NOT NULL,
	[isin] [Varchar](32) NULL,
	[class_code] [Varchar](64) NULL,
	[currency_id] [Varchar](20) NULL,
	[initiator_id] [NVarchar](100) NULL,
	[order_temp_id] [Varchar](100) NULL,
	[processed] [Smallint] NOT NULL DEFAULT(0),
	[save_time] [Datetime2] NOT NULL,
	CONSTRAINT [pk_lasting_order_info] PRIMARY KEY NONCLUSTERED ([id] ASC)
);
GO

-- ES investbox orders
IF NOT EXISTS (
	SELECT * FROM sysobjects
	WHERE name='lasting_order_assignements' AND xtype='U')
CREATE TABLE [dbo].[lasting_order_assignements] (
	[id] [int] identity(1,1) NOT NULL,
	[info_id] [int] NOT NULL,
	[client_id] [int] NOT NULL,
	[correlation_id] [UNIQUEIDENTIFIER] NOT NULL,
	[isin] [nvarchar](32) NOT NULL,
	[class_code] [varchar](64) NOT NULL,
	[currency_code] [nvarchar](16) NOT NULL,
	[initiator_id] [NVarchar](100) NOT NULL,
	[temp_id] [Varchar](100) NOT NULL,
	[guid] [UNIQUEIDENTIFIER] NULL,
	[number] [nvarchar](32) NULL,
	[date] [date] NOT NULL,
	[number_per_day] [int] NULL,
	[close_date] [date] NULL,
	[validity_date] [date] NULL,
	[operation_type] [tinyint] NOT NULL,
	[originator_uid] [int] NOT NULL,
	[comment] [nvarchar](256) NULL,
	[subaccount_guid] [UNIQUEIDENTIFIER] NULL,
	[event_id] [UNIQUEIDENTIFIER] NOT NULL,
	[updated] [int] NOT NULL DEFAULT(0),
	[save_time] [datetime2] NOT NULL,
	[error_id] [nvarchar](256) NULL,
	[error_text] [nvarchar](MAX) NULL,
	[status] [Smallint] NOT NULL DEFAULT(0),
	[processed] [Smallint] NOT NULL DEFAULT(0),
	CONSTRAINT [pk_lasting_order_assignements] PRIMARY KEY NONCLUSTERED ([id] ASC)
);
GO

IF NOT EXISTS(
	SELECT *
	FROM sys.indexes
	WHERE name='ix_lasting_order_assignements_event_id' AND object_id=OBJECT_ID('lasting_order_assignements'))
CREATE NONCLUSTERED INDEX 
	ix_lasting_order_assignements_event_id ON lasting_order_assignements ([event_id]);
GO