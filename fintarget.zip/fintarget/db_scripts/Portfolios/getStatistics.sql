/****** Script for SelectTopNRows command from SSMS  ******/
SELECT convert(date, firstRequest), count(distinct clientId)
  FROM [PortfolioService].[dbo].[history_records]
  group by convert(date, firstRequest)
  order by convert(date, firstRequest)

  select convert(date, created), count(*)
  from execution_requests
  group by convert(date, created)
  order by convert(date, created)

  select convert(date, created), count(*)
  from execution_requests
  where purchased=1
  group by convert(date, created)
  order by convert(date, created)

  select p.name, sum(rp.price * quantity) as [sum], count(distinct r.packetOrderId) as [clients]
  from execution_requests r JOIN portfolios p ON r.portfolioId=p.id
  JOIN execution_request_positions rp ON rp.packetOrderId=r.packetOrderId
  where purchased=1
  group by r.portfolioId, p.name

