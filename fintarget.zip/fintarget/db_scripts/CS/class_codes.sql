IF NOT EXISTS 
	(SELECT * 
	   FROM sysobjects 
	  WHERE name='ClassCodes' 
	    AND xtype='U')
CREATE TABLE [dbo].[ClassCodes](
        [depo] [nvarchar](64),
        [sec_type] [int],
		[classcode] [varchar](64),
 )
GO
	
delete  FROM ClientService.dbo.[ClassCodes]
GO

INSERT INTO ClientService.dbo.[ClassCodes] (depo, sec_type, classcode) values
('L01-00000F00', 1, 'TQBR QUIK'),
('L01-00000F00', 2,'TQOB QUIK'),
('L01-00000F00', 2,	'EQOB QUIK'),
('M20067800001', 7 ,'CETS QUIK'),
('SP01-CL00000', 1 ,'SPBXM QUIK'),
('SP01-CL00000', 2 ,'SPBBND QUIK'),
('SP01-CL00000', 3 ,'SPBFUT QUIK'),
('SPBFUT', 3 ,'SPBFUT QUIK'),
('S0-USA', 1 ,'NASDAQ QUIK'),
('S0-USA',	1,	'NYSE QUIK'),	
('S0-USA',	1,	'NYSE_BEST QUIK'),	
('S0-USA',	1,	'NYSE_MKT QUIK'),	
('S0-USA',	1,	'NYSE_ARCA QUIK'),
('S0-USA',	1,	'NASDAQ_BEST')	 
GO


drop table [dbo].[Exchange];
GO

IF NOT EXISTS 
	(SELECT * 
	   FROM sysobjects 
	  WHERE name='Exchange' 
	    AND xtype='U')
CREATE TABLE [dbo].[Exchange](
        [currency] [varchar](8),
        [target] [varchar](8),
        [exchange] [varchar](64),
		[small] [varchar](64),
 )
GO
	
delete FROM ClientService.dbo.[Exchange]
GO


INSERT INTO ClientService.dbo.[Exchange] (currency, target, exchange, small) values
( 'USD', 'SUR', 'USD000000TOD CETS QUIK','USD000SMALL CETS_S1 QUIK'),
( 'EUR', 'SUR', 'EUR_RUB__TOD CETS QUIK','EUR000SMALL CETS_S1 QUIK'),
( 'CHF', 'SUR', 'CHFRUB_TOD CETS QUIK',null),
( 'CNY', 'SUR', 'CNY000000TOD CETS QUIK',null),
( 'GBP', 'SUR', 'GBPRUB_TOD CETS QUIK',null),
( 'JPY', 'SUR', 'JPYRUB_TOD CETS QUIK',null),
( 'EUR', 'USD', 'EURUSD000TOD CETS QUIK',null)
GO

