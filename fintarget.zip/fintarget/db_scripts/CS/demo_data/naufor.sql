insert into clients (id, sex, first_name, last_name, middle_name, org, org_name, phone, email, address)
values ('3ff29ea3-156e-479e-a08c-8c827f3abf23', 'M', 'Иван', 'Иванов', 
'Иванович', 'Y', 'ООО "Компания БКС"', '+79067033744', 'VaninAV@msk.bcs.ru', 
'ул. Ленина, 1')
insert into clientaccounts(client_id, client_code, initial_value, free_funds, agreement, invest, docfollow, profile, realized_pnl)
values ('3ff29ea3-156e-479e-a08c-8c827f3abf23', '123456', 500000, 500000, 
'123456/19-м', '123456/19-м', '123456/19-м', 'Умеренно-агрессивный', 0)