SELECT TOP(1) WITh TIES CA.client_code, H.date, S.name, (case when H.status=1 then '��������������' else '������������' end)
 FROM [ClientService].[dbo].[ClientAccountHistory] H
  JOIN [ClientService].[dbo].[ClientAccounts] CA ON H.client_id=CA.id 
  LEFT JOIN [CAbinetDB].[dbo].Strategies S ON H.strategy_id=S.id
 where CA.client_code in (
'270409',
'66794',
'575597',
'590838',
'590113',
'587818',
'591050',
'251049',
'591362',
'571535',
'163652',
'585408',
'410233')
and H.strategy_id is not null and H.status <> 0
order by 
    case 
        when row_number() over(partition by H.client_id order by date desc) <= 1 
        then 0 
        else 1 
    end


