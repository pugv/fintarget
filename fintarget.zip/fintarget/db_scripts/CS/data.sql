delete FROM ClientService.dbo.[ClientSignals];
delete FROM ClientService.dbo.ClientAccountHistory;
delete FROM ClientService.dbo.PortfolioHistory;
delete FROM ClientService.dbo.[ClientAccounts];
delete FROM ClientService.dbo.[Clients];
delete FROM ClientService.dbo.[ClientAccountPositions];

INSERT INTO ClientService.dbo.[Clients] (id, agreement_id, first_name, phone ) values ('10000000-0000-0000-0000-9DD4947B301A','10000000-0000-0000-0000-9DD4947B301A','Alexey','+79251331436')
INSERT INTO ClientService.dbo.[Clients] (id, agreement_id, first_name, phone) values ('20000000-0000-0000-0000-9DD4947B301A','20000000-0000-0000-0000-9DD4947B301A','Sergey','+79167025727')
INSERT INTO ClientService.dbo.[Clients] (id, agreement_id, first_name, phone) values ('30000000-0000-0000-0000-9DD4947B301A','30000000-0000-0000-0000-9DD4947B301A','Andrey','+7916000000')

INSERT INTO ClientService.dbo.[ClientAccounts] (client_id, agreement_id, strategy_id, client_code, futures_code,  [status],realized_pnl) values ('10000000-0000-0000-0000-9DD4947B301A','10000000-0000-0000-0000-9DD4947B301A','280CAF67-1C43-4948-BC61-ADC4D8553C28', 'TEST021','82A',1,0)
INSERT INTO ClientService.dbo.[ClientAccounts] (client_id, agreement_id, strategy_id, client_code, futures_code,  [status],realized_pnl) values ('20000000-0000-0000-0000-9DD4947B301A','20000000-0000-0000-0000-9DD4947B301A','280CAF67-1C43-4948-BC61-ADC4D8553C28', 'TEST022','82B',1,0)
INSERT INTO ClientService.dbo.[ClientAccounts] (client_id, agreement_id, strategy_id, client_code, futures_code,  [status],realized_pnl) values ('30000000-0000-0000-0000-9DD4947B301A','30000000-0000-0000-0000-9DD4947B301A','280CAF67-1C43-4948-BC61-ADC4D8553C28', 'C','82C',2,0)

INSERT INTO ClientService.dbo.[ClientAccountPositions] (client_code, security_key, avg_price, number, currency)  VALUES
('TEST021','',1,1000000,'SUR'),
('TEST021','GAZP TQBR QUIK',60,100,'SUR'),

('TEST022','',1,2000000,'SUR'),
('TEST022','',1,1000,'USD'),

('82A','SIZ9 SPBFUT QUIK',1,100000,'SUR'),
('C','',1,3000000,'SUR'),
('82C','SIZ9 SPBFUT QUIK',10,1000000,'SUR')
GO


