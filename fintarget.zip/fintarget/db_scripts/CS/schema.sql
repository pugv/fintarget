﻿USE [ClientService]
GO
/****** Object:  Table [dbo].[_TestClientAccountIds]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[_TestClientAccountIds](
	[Id] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClassCodes]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClassCodes](
	[depo] [nvarchar](64) NULL,
	[sec_type] [int] NULL,
	[classcode] [varchar](64) NULL,
	[currency] [varchar](32) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientAccountHistory]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientAccountHistory](
	[client_id] [int] NULL,
	[date] [datetime2](7) NULL,
	[strategy_id] [uniqueidentifier] NULL,
	[status] [int] NULL,
	[updated] [tinyint] NULL,
	[profile] [nvarchar](64) NULL,
	[Portfolio] [decimal](20, 5) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientAccountPositions]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientAccountPositions](
	[security_key] [varchar](64) NOT NULL,
	[avg_price] [decimal](30, 10) NOT NULL,
	[number] [decimal](30, 10) NULL,
	[weight] [decimal](30, 15) NULL,
	[wait] [bigint] NULL,
	[currency] [varchar](8) NOT NULL,
	[avg_nkd] [decimal](30, 10) NULL,
	[client_code] [varchar](64) NOT NULL,
	[VarMargin] [decimal](20, 10) NULL,
	[total_varmargin] [decimal](20, 10) NULL,
	[total_pl] [decimal](20, 10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientAccounts]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientAccounts](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[client_id] [uniqueidentifier] NULL,
	[strategy_id] [uniqueidentifier] NULL,
	[client_code] [varchar](64) NOT NULL,
	[initial_value] [decimal](30, 10) NULL,
	[avail_funds] [decimal](30, 10) NULL,
	[realized_pnl] [decimal](30, 10) NULL,
	[realized_pnl_funds] [decimal](30, 10) NULL,
	[status] [int] NULL,
	[need_rebalance] [tinyint] NULL,
	[need_notify] [tinyint] NULL,
	[diff_from_strategy] [decimal](30, 15) NULL,
	[min_balance] [decimal](30, 10) NULL,
	[value] [decimal](30, 10) NULL,
	[updated] [int] NOT NULL,
	[futures_code] [varchar](64) NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[strategy_name] [nvarchar](128) NULL,
	[value_sur] [decimal](30, 10) NULL,
	[value_usd] [decimal](30, 10) NULL,
	[need_fetch] [tinyint] NULL,
	[min_diff] [decimal](20, 15) NULL,
	[initial_upl] [decimal](20, 10) NULL,
	[update_pos_time] [datetime2](7) NULL,
	[is_marginal] [bit] NOT NULL,
	[block] [datetime2](7) NULL,
        [waiting_for] int NULL,
 CONSTRAINT [PK_ClientAccounts_1] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientExams]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientExams](
	[ClientId] [int] NOT NULL,
	[Code] [varchar](32) NOT NULL,
	[Passed] [tinyint] NOT NULL,
	[Date] [datetime2](7) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Clients]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Clients](
	[id] [uniqueidentifier] NOT NULL,
	[org] [char](1) NULL,
	[sex] [char](1) NULL,
	[first_name] [nvarchar](64) NULL,
	[last_name] [nvarchar](64) NULL,
	[middle_name] [nvarchar](64) NULL,
	[org_name] [varchar](512) NULL,
	[phone] [varchar](512) NULL,
	[email] [varchar](512) NULL,
	[address] [nvarchar](256) NULL,
	[contract] [nvarchar](256) NULL,
	[updated] [int] NOT NULL,
	[exchange_id] [bigint] IDENTITY(1,1) NOT NULL,
	[temp] [varchar](128) NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[strategy_name] [nvarchar](128) NULL,
	[agreement] [nvarchar](32) NULL,
	[docfollow] [nvarchar](64) NULL,
	[profile] [nvarchar](64) NULL,
	[service] [nvarchar](64) NULL,
	[software] [nvarchar](64) NULL,
	[service_date] [datetime2](7) NULL,
	[profile_date] [datetime2](0) NULL,
	[investment_advice_agreement_date] [datetime2](0) NULL,
	[client_tariff_id] [uniqueidentifier] NULL,
	[strategy_tariff_id] [uniqueidentifier] NULL,
	[is_qualified_investor] [tinyint] NOT NULL,
	[close_date] [datetime2](7) NULL,
	[profile_guid] [uniqueidentifier] NULL,
	[is_organization] [tinyint] NULL,
	[RepresentativePosition] [nvarchar](256) NULL,
	[OrgDocument] [tinyint] NULL,
	[Ogrn] [nvarchar](64) NULL,
	[OrgRegisterDate] [datetime2](7) NULL,
	[agreement_start_date] [datetime2](7) NOT NULL,
	[partner_id] [uniqueidentifier] NULL,
 CONSTRAINT [PK_Client_1] PRIMARY KEY CLUSTERED 
(
	[id] ASC,
	[agreement_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ClientSignals]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ClientSignals](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[date] [datetime2](7) NULL,
	[client_id] [int] NOT NULL,
	[strategy_signal_id] [int] NULL,
	[realized_pnl] [decimal](20, 15) NOT NULL,
	[execution] [varchar](max) NULL,
	[processed] [int] NOT NULL,
	[type] [int] NULL,
	[archived] [tinyint] NULL,
	[diff_from_strategy] [decimal](20, 15) NULL,
	[message_sent] [tinyint] NULL,
	[updated] [int] NOT NULL,
	[portfolio] [varchar](max) NULL,
 CONSTRAINT [PK_ClientSignals_1] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Messages]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Messages](
	[signal_id] [bigint] NOT NULL,
	[gen_date] [datetime2](7) NULL,
	[message] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[signal_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PortfolioHistory]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PortfolioHistory](
	[date] [datetime2](7) NOT NULL,
	[client_id] [int] NOT NULL,
	[portfolio] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Portfolios]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Portfolios](
	[date] [datetime2](7) NOT NULL,
	[client_id] [int] NOT NULL,
	[currency] [varchar](32) NOT NULL,
	[price] [decimal](20, 8) NOT NULL,
	[liquid_price] [decimal](20, 8) NOT NULL,
	[positions_cost] [decimal](20, 8) NOT NULL,
	[free_funds] [decimal](20, 8) NOT NULL,
 CONSTRAINT [Portfolios_Key] PRIMARY KEY CLUSTERED 
(
	[client_id] ASC,
	[currency] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Profiles]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Profiles](
	[Id] [int] NOT NULL,
	[Name] [nvarchar](max) NULL,
	[Guid] [uniqueidentifier] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[StrategySignals]    Script Date: 24.11.2021 12:25:18 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[StrategySignals](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[initial_id] [int] NULL,
	[date] [datetime2](7) NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[signal_weight] [decimal](20, 15) NULL,
	[security_key] [varchar](64) NULL,
	[reference_price] [decimal](20, 10) NULL,
	[portfolio] [varchar](max) NULL,
	[processed] [int] NOT NULL,
	[report_sent] [tinyint] NOT NULL,
	[dividend] [tinyint] NULL,
	[summ] [decimal](18, 6) NULL,
	[AllowCell] [tinyint] NULL,
 CONSTRAINT [PK_StrategySignals_1] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[ClientAccountHistory] ADD  DEFAULT ((0)) FOR [status]
GO
ALTER TABLE [dbo].[ClientAccountHistory] ADD  DEFAULT ((1)) FOR [updated]
GO
ALTER TABLE [dbo].[ClientAccountPositions] ADD  DEFAULT ((0)) FOR [VarMargin]
GO
ALTER TABLE [dbo].[ClientAccountPositions] ADD  DEFAULT ((0)) FOR [total_varmargin]
GO
ALTER TABLE [dbo].[ClientAccountPositions] ADD  DEFAULT ((0)) FOR [total_pl]
GO
ALTER TABLE [dbo].[ClientAccounts] ADD  CONSTRAINT [DF__ClientAcc__avail__38996AB5]  DEFAULT ((0)) FOR [avail_funds]
GO
ALTER TABLE [dbo].[ClientAccounts] ADD  CONSTRAINT [DF__ClientAcc__statu__398D8EEE]  DEFAULT ((0)) FOR [status]
GO
ALTER TABLE [dbo].[ClientAccounts] ADD  CONSTRAINT [DF__ClientAcc__need___3A81B327]  DEFAULT ((0)) FOR [need_rebalance]
GO
ALTER TABLE [dbo].[ClientAccounts] ADD  CONSTRAINT [DF__ClientAcc__need___3B75D760]  DEFAULT ((0)) FOR [need_notify]
GO
ALTER TABLE [dbo].[ClientAccounts] ADD  CONSTRAINT [DF__ClientAcc__updat__4BAC3F29]  DEFAULT ((1)) FOR [updated]
GO
ALTER TABLE [dbo].[ClientAccounts] ADD  CONSTRAINT [DF__ClientAcc__agree__5BE2A6F2]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [agreement_id]
GO
ALTER TABLE [dbo].[ClientAccounts] ADD  DEFAULT ((0)) FOR [min_diff]
GO
ALTER TABLE [dbo].[ClientExams] ADD  DEFAULT ((0)) FOR [Passed]
GO
ALTER TABLE [dbo].[Clients] ADD  CONSTRAINT [DF__Clients__updated__49C3F6B7]  DEFAULT ((1)) FOR [updated]
GO
ALTER TABLE [dbo].[Clients] ADD  CONSTRAINT [DF__Clients__agreeme__5AEE82B9]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [agreement_id]
GO
ALTER TABLE [dbo].[Clients] ADD  CONSTRAINT [DF_Clients_is_qualified_investor]  DEFAULT ((0)) FOR [is_qualified_investor]
GO
ALTER TABLE [dbo].[Clients] ADD  DEFAULT ((0)) FOR [is_organization]
GO
ALTER TABLE [dbo].[Clients] ADD  CONSTRAINT [DF_Clients_agreement_start_date]  DEFAULT ('2000-01-01') FOR [agreement_start_date]
GO
ALTER TABLE [dbo].[ClientSignals] ADD  DEFAULT ((1)) FOR [updated]
GO
ALTER TABLE [dbo].[Portfolios] ADD  DEFAULT ((0)) FOR [price]
GO
ALTER TABLE [dbo].[Portfolios] ADD  DEFAULT ((0)) FOR [liquid_price]
GO
ALTER TABLE [dbo].[Portfolios] ADD  DEFAULT ((0)) FOR [positions_cost]
GO
ALTER TABLE [dbo].[Portfolios] ADD  DEFAULT ((0)) FOR [free_funds]
GO
ALTER TABLE [dbo].[StrategySignals] ADD  DEFAULT ((0)) FOR [processed]
GO
ALTER TABLE [dbo].[StrategySignals] ADD  DEFAULT ((0)) FOR [report_sent]
GO
ALTER TABLE [dbo].[StrategySignals] ADD  DEFAULT ((0)) FOR [AllowCell]
GO
ALTER TABLE [dbo].[ClientAccountHistory]  WITH CHECK ADD  CONSTRAINT [FK_ClientAccountHistory_Client] FOREIGN KEY([client_id])
REFERENCES [dbo].[ClientAccounts] ([id])
GO
ALTER TABLE [dbo].[ClientAccountHistory] CHECK CONSTRAINT [FK_ClientAccountHistory_Client]
GO
ALTER TABLE [dbo].[ClientSignals]  WITH CHECK ADD  CONSTRAINT [FK__ClientSig__clien__47DBAE45] FOREIGN KEY([client_id])
REFERENCES [dbo].[ClientAccounts] ([id])
GO
ALTER TABLE [dbo].[ClientSignals] CHECK CONSTRAINT [FK__ClientSig__clien__47DBAE45]
GO
ALTER TABLE [dbo].[PortfolioHistory]  WITH CHECK ADD  CONSTRAINT [FK__Portfolio__clien__52593CB8] FOREIGN KEY([client_id])
REFERENCES [dbo].[ClientAccounts] ([id])
GO
ALTER TABLE [dbo].[PortfolioHistory] CHECK CONSTRAINT [FK__Portfolio__clien__52593CB8]
GO
ALTER TABLE [dbo].[Portfolios]  WITH CHECK ADD CONSTRAINT [FK__Portfolios__ClientAccounts_1] FOREIGN KEY([client_id])
REFERENCES [dbo].[ClientAccounts] ([id])
GO
/****** Object:  Trigger [dbo].[update_clientaccount]    Script Date: 24.11.2021 12:37:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[update_clientaccount]
   ON  [dbo].[ClientAccounts] 
   FOR INSERT, UPDATE 
AS 
BEGIN
	if ( UPDATE(id) or UPDATE(client_id)
	or UPDATE(strategy_id) or UPDATE(client_code) or UPDATE(initial_value)
	or UPDATE(realized_pnl) Or UPDATE(realized_pnl_funds)
	OR UPDATE(status) OR UPDATE (diff_from_strategy) OR UPDATE (futures_code)
	OR UPDATE (agreement_id) OR UPDATE (strategy_name) OR UPDATE (min_diff)
	OR UPDATE (initial_upl)
	OR UPDATE (is_marginal))
	update clientaccounts set updated = 1 where id in (select id from inserted)
END
GO
/****** Object:  Trigger [dbo].[update_client]    Script Date: 24.11.2021 12:38:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[update_client]
   ON  [dbo].[Clients] 
   FOR INSERT, UPDATE 
AS 
BEGIN
	if not UPDATE(updated)
		update clients set updated = 1 where id in (select id from inserted)
END
GO
/****** Object:  Trigger [dbo].[update_clientsignals]    Script Date: 24.11.2021 12:40:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[update_clientsignals]
   ON  [dbo].[ClientSignals] 
   FOR UPDATE 
AS 
BEGIN
	IF UPDATE(execution) or UPDATE(message_sent)
		UPDATE ClientSignals SET updated = 1 WHERE id in (SELECT id FROM inserted)
END
