USE [master]
GO


/****** Object:  Database [CabinetDB]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [CabinetDB]
GO

/****** Object:  Database [ClientService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [ClientService]
GO

/****** Object:  Database [ExternalService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [ExternalService]
GO

/****** Object:  Database [fintarget]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [fintarget]
GO

/****** Object:  Database [HistoryService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [HistoryService]
GO

/****** Object:  Database [LifecycleService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [LifecycleService]
GO

/****** Object:  Database [MetrixService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [MetrixService]
GO

/****** Object:  Database [MonitoringService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [MonitoringService]
GO

/****** Object:  Database [PortfolioService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [PortfolioService]
GO

/****** Object:  Database [QuikExport]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [QuikExport]
GO

/****** Object:  Database [QuikExportOrders]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [QuikExportOrders]
GO

/****** Object:  Database [RiskAnalysis]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [RiskAnalysis]
GO

/****** Object:  Database [Sandbox]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [Sandbox]
GO

/****** Object:  Database [SMSService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [SMSService]
GO

/****** Object:  Database [StatService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [StatService]
GO

/****** Object:  Database [TradeService]    Script Date: 24.11.2021 13:47:28 ******/
CREATE DATABASE [TradeService]
GO

