﻿USE [CabinetDB]
GO
/****** Object:  Table [dbo].[AuditData]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditData](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[IPAddress] [varchar](45) NULL,
	[Date] [datetime] NOT NULL,
	[UserId] [int] NULL,
	[Action] [varchar](50) NOT NULL,
	[Info] [varchar](max) NULL,
 CONSTRAINT [PK_AuditData] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CalcTypeHistory]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CalcTypeHistory](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[date] [datetime2](7) NULL,
	[type] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Comissions]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Comissions](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[long] [float] NULL,
	[short] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Securities]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Securities](
	[symbol] [nvarchar](50) NOT NULL,
	[class_code] [nvarchar](50) NOT NULL,
	[board] [nvarchar](50) NOT NULL,
	[description] [nvarchar](max) NULL,
	[add_time] [datetime] NOT NULL,
	[last_price] [decimal](20, 10) NULL,
	[last_price_time] [datetime] NULL,
	[name] [nvarchar](500) NULL,
	[lot_size] [int] NULL,
	[key] [nvarchar](128) NOT NULL,
	[price_step] [decimal](20, 10) NULL,
PRIMARY KEY CLUSTERED 
(
	[key] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Strategies]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Strategies](
	[id] [uniqueidentifier] NOT NULL,
	[manager_id] [int] NOT NULL,
	[name] [nvarchar](100) NOT NULL,
	[create_time] [datetime] NOT NULL,
	[create_by_expert_id] [int] NOT NULL,
	[description] [text] NULL,
	[is_active] [int] NOT NULL,
	[currency] [nvarchar](8) NULL,
	[leverage] [decimal](20, 10) NULL,
	[recalcMode] [int] NOT NULL,
	[securities] [varchar](max) NOT NULL,
	[value_sur] [decimal](20, 10) NULL,
	[value_usd] [decimal](20, 10) NULL,
	[client_count] [int] NULL,
	[af_value_sur] [decimal](20, 10) NULL,
	[af_value_usd] [decimal](20, 10) NULL,
	[ac_value_sur] [decimal](20, 10) NULL,
	[ac_value_usd] [decimal](20, 10) NULL,
	[af_client_count] [int] NULL,
	[ac_client_count] [int] NULL,
	[comissions] [varchar](max) NULL,
	[rating] [int] NULL,
	[iis] [tinyint] NULL,
	[autofollow] [tinyint] NULL,
	[trades_frequency] [varchar](32) NULL,
	[auto_consult] [tinyint] NULL,
	[max_instrument_fraq] [decimal](20, 10) NOT NULL,
	[is_algo] [tinyint] NULL,
	[tarif] [int] NULL,
	[subscription_threshold] [decimal](20, 10) NOT NULL,
	[parent_strategy] [uniqueidentifier] NULL,
	[index_id] [int] NULL,
	[risk_profile_id] [uniqueidentifier] NULL,
	[risk_profile_name] [nvarchar](128) NULL,
	[for_report] [bit] NOT NULL,
	[rating_adjust] [float] NULL,
	[Status] [int] NOT NULL,
	[is_portfolio] [bit] NOT NULL,
	[risk_profile] [int] NULL,
	[is_investbox] [tinyint] NULL,
 CONSTRAINT [PK__Strategi__3213E83F6341136C] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_managers]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_managers](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[manager_id] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_securities_history]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_securities_history](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[old_value] [varchar](max) NULL,
	[new_value] [varchar](max) NULL,
	[update_time] [datetime2](7) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_tests]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_tests](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[test_id] [varchar](64) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Users]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[is_active] [int] NOT NULL,
	[login] [nvarchar](50) NOT NULL,
	[pass_hash] [nvarchar](200) NULL,
	[salt] [nvarchar](64) NULL,
	[fio] [nvarchar](50) NULL,
	[role] [nvarchar](32) NOT NULL,
	[create_date] [datetime] NOT NULL,
	[is_deleted] [int] NOT NULL,
	[draft_password] [int] NOT NULL,
	[unsuccessfull_logins] [int] NOT NULL,
	[last_login] [datetime2](7) NULL,
	[phone] [varchar](32) NULL,
	[last_name] [nvarchar](64) NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[first_name] [nvarchar](64) NULL,
	[middle_name] [nvarchar](64) NULL,
	[org_name] [nvarchar](128) NULL,
	[update_time] [datetime2](7) NULL,
	[master_id] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Variables]    Script Date: 24.11.2021 12:23:24 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Variables](
	[name] [nvarchar](64) NOT NULL,
	[value] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[Securities] ADD  DEFAULT (getdate()) FOR [add_time]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__creat__398D8EEE]  DEFAULT (getdate()) FOR [create_time]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__is_ac__3A81B327]  DEFAULT ((0)) FOR [is_active]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__lever__4222D4EF]  DEFAULT ((200)) FOR [leverage]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__recal__4316F928]  DEFAULT ((0)) FOR [recalcMode]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__secur__440B1D61]  DEFAULT ('[]') FOR [securities]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_max_instrument_fraq]  DEFAULT ((100)) FOR [max_instrument_fraq]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_subscription_threshold]  DEFAULT ((1000)) FOR [subscription_threshold]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_for_report]  DEFAULT ((0)) FOR [for_report]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF__Strategie__Statu__02084FDA]  DEFAULT ((0)) FOR [Status]
GO
ALTER TABLE [dbo].[Strategies] ADD  CONSTRAINT [DF_Strategies_is_portfolio]  DEFAULT ((0)) FOR [is_portfolio]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF__Users__create_da__3D5E1FD2]  DEFAULT (getdate()) FOR [create_date]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_is_deleted]  DEFAULT ((0)) FOR [is_deleted]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF__Users__draft_pas__3E52440B]  DEFAULT ((0)) FOR [draft_password]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_unsuccessfull_logins]  DEFAULT ((0)) FOR [unsuccessfull_logins]
GO
ALTER TABLE [dbo].[CalcTypeHistory]  WITH CHECK ADD  CONSTRAINT [FK_CalcTypeHistory_Strategies] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[Strategies] ([id])
GO
ALTER TABLE [dbo].[CalcTypeHistory] CHECK CONSTRAINT [FK_CalcTypeHistory_Strategies]
GO
