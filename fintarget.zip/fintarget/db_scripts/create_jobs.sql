USE [msdb]
GO

/****** Object:  Job [Backup_all_user_Databases]    Script Date: 20.04.2022 15:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 20.04.2022 15:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Backup_all_user_Databases', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'MYBROKER\VvedenskiySA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup]    Script Date: 20.04.2022 15:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'BACKUP DATABASE [CabinetDB] TO DISK = N''D:\MSSQL\backup\CabinetDB.bak'' WITH NOFORMAT, INIT, NAME = N''CabinetDB.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [ClientService] TO DISK = N''D:\MSSQL\backup\ClientService.bak'' WITH NOFORMAT, INIT, NAME = N''ClientService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [ExternalService] TO DISK = N''D:\MSSQL\backup\ExternalService.bak'' WITH NOFORMAT, INIT, NAME = N''ExternalService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [fintarget] TO DISK = N''D:\MSSQL\backup\fintarget.bak'' WITH NOFORMAT, INIT, NAME = N''fintarget.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [HistoryService] TO DISK = N''D:\MSSQL\backup\HistoryService.bak'' WITH NOFORMAT, INIT, NAME = N''HistoryService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [LifecycleService] TO DISK = N''D:\MSSQL\backup\LifecycleService.bak'' WITH NOFORMAT, INIT, NAME = N''LifecycleService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [MonitoringService] TO DISK = N''D:\MSSQL\backup\MonitoringService.bak'' WITH NOFORMAT, INIT, NAME = N''MonitoringService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [PortfolioService] TO DISK = N''D:\MSSQL\backup\PortfolioService.bak'' WITH NOFORMAT, INIT, NAME = N''PortfolioService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [QuikExport] TO DISK = N''D:\MSSQL\backup\QuikExport.bak'' WITH NOFORMAT, INIT, NAME = N''QuikExport.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [QuikExportOrders] TO DISK = N''D:\MSSQL\backup\QuikExportOrders.bak'' WITH NOFORMAT, INIT, NAME = N''QuikExportOrders.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [RiskAnalysis] TO DISK = N''D:\MSSQL\backup\RiskAnalysis.bak'' WITH NOFORMAT, INIT, NAME = N''RiskAnalysis.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [Sandbox] TO DISK = N''D:\MSSQL\backup\Sandbox.bak'' WITH NOFORMAT, INIT, NAME = N''Sandbox.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [SMSService] TO DISK = N''D:\MSSQL\backup\SMSService.bak'' WITH NOFORMAT, INIT, NAME = N''SMSService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [StatService] TO DISK = N''D:\MSSQL\backup\StatService.bak'' WITH NOFORMAT, INIT, NAME = N''StatService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [TradeService] TO DISK = N''D:\MSSQL\backup\TradeService.bak'' WITH NOFORMAT, INIT, NAME = N''TradeService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;
BACKUP DATABASE [MetrixService] TO DISK = N''D:\MSSQL\backup\MetrixService.bak'' WITH NOFORMAT, INIT, NAME = N''MetrixService.bak'', SKIP, REWIND, NOUNLOAD, CHECKSUM, COMPRESSION;', 
		@database_name=N'ServiceDB', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Every day', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20210128, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'10b8b2e5-d87b-4663-b2ed-fcbb8cae084e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO



USE [msdb]
GO

/****** Object:  Job [LabelStrategiesIIS]    Script Date: 20.04.2022 15:47:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 20.04.2022 15:47:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'LabelStrategiesIIS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'pugv', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Main]    Script Date: 20.04.2022 15:47:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Main', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'begin transaction;
declare iir_strats cursor for 
select s.id
  from [Fintarget].[dbo].[strategies] s,
	   [CabinetDB].[dbo].[strategies] cs
 where (
	((s.currency_id = ''RUB'' or s.currency_id = ''SUR'') and s.subscription_threshold <= 400000)
	or
	(s.currency_id = ''USD'' and 
	(s.subscription_threshold * (select lastprice from [HistoryService].[dbo].[Securities] where SecurityKey = ''USD000000TOD CETS QUIK'')) <= 400000
	)
	)
   and s.for_qualified_investors_only = 0
   and cs.id = s.id
   and cs.securities not like ''%SPBFUT QUIK%'' 
   and cs.securities not like ''%NASDAQ QUIK%''
   and cs.securities not like ''%NASDAQ_BEST QUIK%''
   and cs.securities not like ''%NYSE QUIK%''
   and cs.securities not like ''%NYSE_BEST QUIK%''
   and cs.securities not like ''%NYSE_ARCA QUIK%''
   and cs.securities not like ''%NYSE_MKT QUIK%'';
open iir_strats;
declare @strat uniqueidentifier;
delete 
  from [Fintarget].[dbo].[strategy_labels]
 where label_id = 1;
fetch next from iir_strats into @strat;
while @@FETCH_STATUS = 0
begin
  fetch next from iir_strats into @strat;
  insert 
    into [Fintarget].[dbo].[strategy_labels]
	     (strategy_id, label_id)
  values (@strat, 1);
end;
close iir_strats;
deallocate iir_strats;
commit;', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'EveryDay', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20200803, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'c8dc80c8-dcf4-4522-bc4d-964822c2b368'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO



USE [msdb]
GO

/****** Object:  Job [ReplicateForRiskAnalysis]    Script Date: 20.04.2022 15:48:02 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 20.04.2022 15:48:02 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ReplicateForRiskAnalysis', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Репликация данных в БД RiskAnalysis', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'pugv', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Clear]    Script Date: 20.04.2022 15:48:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Clear', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from [RiskAnalysis].[dbo].[Strategies];
delete from [RiskAnalysis].[dbo].[Signals];
delete from [RiskAnalysis].[dbo].[strategy_pl];
delete from [RiskAnalysis].[dbo].[indexes];
delete from [RiskAnalysis].[dbo].[index_history];
delete from [RiskAnalysis].[dbo].[portfolio_positions];
delete from [RiskAnalysis].[dbo].[portfolios];
delete from [RiskAnalysis].[dbo].[Securities];
delete from [RiskAnalysis].[dbo].[strategy_stats];
delete from [RiskAnalysis].[dbo].[strategy_pl_period];
delete from [RiskAnalysis].[dbo].[security_forecasts_sources]; 
delete from [RiskAnalysis].[dbo].[security_forecasts];', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CabinetDB]    Script Date: 20.04.2022 15:48:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CabinetDB', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=3, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into [RiskAnalysis].[dbo].[Strategies] 
select * from [CabinetDB].[dbo].[Strategies]
where id not in (
''FD78926A-548C-42B6-A9EE-09A0C2E947F3'',
''44CBEDDC-91C3-43F7-AABC-BDC77F12AA5A'');', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Lifecycle]    Script Date: 20.04.2022 15:48:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Lifecycle', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into [RiskAnalysis].[dbo].[Signals] 
select * from [LifecycleService].[dbo].[Signals]
where strategy_id not in (
''FD78926A-548C-42B6-A9EE-09A0C2E947F3'',
''44CBEDDC-91C3-43F7-AABC-BDC77F12AA5A'');', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Fintarget]    Script Date: 20.04.2022 15:48:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Fintarget', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into [RiskAnalysis].[dbo].[strategy_pl] (strategy_id, history, mean_year)
select strategy_id, history, meanyear from [Fintarget].[dbo].[strategy_pl]
where strategy_id not in (
''FD78926A-548C-42B6-A9EE-09A0C2E947F3'',
''44CBEDDC-91C3-43F7-AABC-BDC77F12AA5A'');
insert into [RiskAnalysis].[dbo].[indexes] 
select * from [Fintarget].[dbo].[indexes];
insert into [RiskAnalysis].[dbo].[index_history] 
select * from [Fintarget].[dbo].[index_history];

UPDATE
    [RiskAnalysis].[dbo].[Strategies]
SET
    index_id = fts.index_id,
    is_active = isnull(fts.[open], 0)
FROM
    [RiskAnalysis].[dbo].[Strategies] ras
left JOIN
    [Fintarget].[dbo].[strategies] fts
ON 
    ras.id = fts.id;

UPDATE
    [RiskAnalysis].[dbo].[Strategies]
SET
    risk_profile_id = ftrp.profile_id,
    risk_profile_name = ftrp.name
FROM
    [RiskAnalysis].[dbo].[Strategies] ras
left JOIN
    [Fintarget].[dbo].[strategies] fts
ON 
    ras.id = fts.id
JOIN 
    [Fintarget].[dbo].[invest_profiles] ftrp
ON 
    ftrp.id = fts.min_invest_profile_id;', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Portfolios]    Script Date: 20.04.2022 15:48:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Portfolios', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into [RiskAnalysis].[dbo].[portfolios] 
select * from [PortfolioService].[dbo].[portfolios];

insert into [RiskAnalysis].[dbo].[portfolio_positions] 
select * from [PortfolioService].[dbo].[portfolio_positions];', 
		@database_name=N'RiskAnalysis', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [History]    Script Date: 20.04.2022 15:48:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'History', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into RiskAnalysis.dbo.Securities ([SecurityKey]
      ,[Symbol]
      ,[ClassCode]
      ,[Name]
      ,[ClassName]
      ,[Type]
      ,[ISINCode]
      ,[Currency]
      ,[LastPrice]
      ,[LastTime]
      ,[LotSize]
      ,[PriceStep]
      ,[BuyMargin]
      ,[SellMargin]
      ,[id]
      ,[updated]
      ,[FaceValue]
      ,[CouponValue]
      ,[MatDate]
      ,[SecAccruedint]
      ,[TradeDate]
      ,[CouponPeriod]
      ,[FaceUnit]
      ,[SubType]
      ,[ShortName]
      ,[UpdateTime]
      ,[Current]
      ,[volatility]
      ,[turnover]
      ,[curr_stepprice]
      ,[currency_id]
      ,[RealPriceStep]
      ,[realminstep])

SELECT [SecurityKey]
      ,[Symbol]
      ,[ClassCode]
      ,[Name]
      ,[ClassName]
      ,[Type]
      ,[ISINCode]
      ,[Currency]
      ,[LastPrice]
      ,[LastTime]
      ,[LotSize]
      ,[PriceStep]
      ,[BuyMargin]
      ,[SellMargin]
      ,[id]
      ,[updated]
      ,[FaceValue]
      ,[CouponValue]
      ,[MatDate]
      ,[SecAccruedint]
      ,[TradeDate]
      ,[CouponPeriod]
      ,[FaceUnit]
      ,[SubType]
      ,[ShortName]
      ,[UpdateTime]
      ,[Current]
      ,[volatility]
      ,[turnover]
      ,[curr_stepprice]
      ,[currency_id]
      ,[RealPriceStep]
      ,[realminstep]
  FROM [HistoryService].[dbo].[Securities];', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Stats]    Script Date: 20.04.2022 15:48:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Stats', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into [RiskAnalysis].[dbo].[strategy_stats] 
select * from [Fintarget].[dbo].[strategy_stats]
where StratId not in (
''FD78926A-548C-42B6-A9EE-09A0C2E947F3'',
''44CBEDDC-91C3-43F7-AABC-BDC77F12AA5A'');
insert into [RiskAnalysis].[dbo].[strategy_pl_period] 
select * from [Fintarget].[dbo].[strategy_pl_period]
where StratId not in (
''FD78926A-548C-42B6-A9EE-09A0C2E947F3'',
''44CBEDDC-91C3-43F7-AABC-BDC77F12AA5A'');', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Forecasts]    Script Date: 20.04.2022 15:48:02 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Forecasts', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into [RiskAnalysis].[dbo].[security_forecasts_sources] 
select * from [PortfolioService].[dbo].[security_forecasts_sources];
insert into [RiskAnalysis].[dbo].[security_forecasts] 
select * from [PortfolioService].[dbo].[security_forecasts];
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20200608, 
		@active_end_date=99991231, 
		@active_start_time=30000, 
		@active_end_time=235959, 
		@schedule_uid=N'd8178e7d-8225-42db-bf78-78e17eeee837'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO



USE [msdb]
GO

/****** Object:  Job [SendToShopfront_Strategies]    Script Date: 20.04.2022 15:48:16 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 20.04.2022 15:48:16 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SendToShopfront_Strategies', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Отправка продуктов в витрину', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'MYBROKER\VvedenskiySA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarkOpenStrategiesToSend]    Script Date: 20.04.2022 15:48:16 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarkOpenStrategiesToSend', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=5, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into Fintarget.dbo.shopfront (object_type, object_id) 
select ''strategy'', id 
from Fintarget.dbo.strategies where is_investbox <> 1;', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [MarkOpenInvestOffersToSend]    Script Date: 20.04.2022 15:48:16 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'MarkOpenInvestOffersToSend', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=5, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into Fintarget.dbo.shopfront (object_type, object_id) 
select ''investoffer'', id 
from Fintarget.dbo.invest_offers', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Everyday', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20210329, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'd10e434d-cc9e-4529-ba0b-6a9a4f3cf3aa'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

