﻿USE [Fintarget]
GO
/****** Object:  Table [dbo].[accept_docs]    Script Date: 24.11.2021 12:28:25 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[accept_docs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[account_id] [bigint] NOT NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[date] [datetime2](7) NOT NULL,
	[document_type] [int] NOT NULL,
	[document_body_base64] [varchar](max) NOT NULL,
	[is_signed] [bit] NOT NULL,
	[confirmation_code] [varchar](6) NULL,
 CONSTRAINT [PK_accept_docs] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[account_pl]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[account_pl](
	[account_id] [bigint] NOT NULL,
	[date] [bigint] NOT NULL,
	[pl] [decimal](20, 10) NOT NULL,
 CONSTRAINT [PK_account_pl] PRIMARY KEY CLUSTERED 
(
	[account_id] ASC,
	[date] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[account_portfolio]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[account_portfolio](
	[account_id] [bigint] NOT NULL,
	[currency] [varchar](8) NOT NULL,
	[free_funds] [decimal](30, 10) NULL,
	[portfolio_price] [decimal](30, 10) NULL,
	[liquid_price] [decimal](30, 10) NULL,
	[positions_cost] [decimal](30, 10) NULL,
	[pnl] [decimal](30, 10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[account_positions]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[account_positions](
	[account_id] [bigint] NOT NULL,
	[security_key] [varchar](64) NOT NULL,
	[avg_price] [decimal](20, 10) NOT NULL,
	[current_price] [decimal](20, 10) NULL,
	[quantity] [int] NOT NULL,
	[weight] [decimal](20, 10) NOT NULL,
	[currency] [varchar](8) NULL,
	[name] [nvarchar](256) NULL,
	[unrealizedPnL] [decimal](20, 10) NULL,
	[totalPnL] [decimal](20, 10) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[action_confirmations]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[action_confirmations](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[client_id] [uniqueidentifier] NOT NULL,
	[client_ip] [varchar](32) NULL,
	[action] [varchar](max) NOT NULL,
	[confirmation_code] [varchar](16) NOT NULL,
	[confirmed] [bit] NOT NULL,
	[confirm_limit] [datetime2](7) NOT NULL,
	[confirm_time] [datetime2](7) NULL,
	[create_time] [datetime2](7) NOT NULL,
	[confirm_phone] [varchar](64) NOT NULL,
 CONSTRAINT [PK_SmsConfirmations] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[friendly_url] [varchar](128) NULL,
	[author_id] [int] NOT NULL,
	[title] [nvarchar](512) NOT NULL,
	[cut_html] [nvarchar](2048) NOT NULL,
	[full_html] [nvarchar](max) NOT NULL,
	[date] [datetime2](0) NOT NULL,
	[picture] [varchar](256) NULL,
	[strategies_title] [nvarchar](128) NOT NULL,
	[small_picture] [varchar](256) NULL,
	[active] [bit] NOT NULL,
	[subscription] [bit] NOT NULL,
	[seo_title] [nvarchar](160) NULL,
	[seo_description] [nvarchar](max) NULL,
 CONSTRAINT [PK_analytics] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_categories]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_categories](
	[analytics_id] [bigint] NOT NULL,
	[category_id] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_strategies]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_strategies](
	[analytics_id] [bigint] NOT NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[show_in_strategy] [bit] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[analytics_subscribes]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[analytics_subscribes](
	[email] [varchar](128) NOT NULL,
	[date] [datetime2](7) NOT NULL,
	[uid] [uniqueidentifier] NULL,
	[code] [varchar](128) NOT NULL,
	[active] [bit] NOT NULL,
	[sent_version] [int] NOT NULL,
 CONSTRAINT [analytics_subscribesPK] PRIMARY KEY CLUSTERED 
(
	[email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[article_categories]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[article_categories](
	[id] [int] NOT NULL,
	[name] [nvarchar](64) NULL,
 CONSTRAINT [PK_article_categories] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[author_doc_groups]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[author_doc_groups](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](256) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[author_documents]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[author_documents](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](512) NOT NULL,
	[content_base64] [varchar](max) NOT NULL,
	[file_name] [nvarchar](512) NOT NULL,
	[order] [int] NOT NULL,
	[group] [int] NULL,
	[description] [nvarchar](512) NULL,
 CONSTRAINT [PK_author_document] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[author_request_file]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[author_request_file](
	[request_id] [bigint] NOT NULL,
	[file_id] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[author_request_new]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[author_request_new](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](128) NOT NULL,
	[phone] [nvarchar](32) NOT NULL,
	[description] [nvarchar](1024) NOT NULL,
	[accept] [bit] NOT NULL,
	[send_time] [datetime2](0) NULL,
	[email] [nvarchar](128) NULL,
 CONSTRAINT [PK_author_request_new] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[authors]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[authors](
	[id] [int] NOT NULL,
	[first_name] [nvarchar](64) NULL,
	[last_name] [nvarchar](64) NULL,
	[middle_name] [nvarchar](64) NULL,
	[company] [nvarchar](128) NULL,
	[position] [nvarchar](128) NULL,
	[photo_format] [varchar](8) NOT NULL,
	[photo] [varchar](max) NULL,
	[email] [nvarchar](128) NOT NULL,
	[info_html] [nvarchar](max) NOT NULL,
	[rating] [tinyint] NOT NULL,
	[shortinfo_html] [nvarchar](max) NULL,
	[friendly_url] [varchar](128) NULL,
	[photo_url] [varchar](255) NULL,
	[employee_id] [nvarchar](32) NULL,
	[passport_id] [nvarchar](16) NULL,
	[type] [smallint] NOT NULL,
	[info_text] [nvarchar](max) NULL,
	[shortinfo_text] [nvarchar](max) NULL,
	[passport_issued] [nvarchar](512) NULL,
	[issue_date] [date] NULL,
	[birth_date] [date] NULL,
	[agreement_num] [nvarchar](32) NULL,
	[org_inn] [nvarchar](16) NULL,
	[org_ogrn] [nvarchar](16) NULL,
	[commission] [tinyint] NULL,
	[updated] [smallint] NOT NULL,
	[update_time] [datetime2](7) NULL,
	[org_kpp] [nvarchar](16) NULL,
	[display_name] [nvarchar](256) NOT NULL,
	[master_id] [int] NULL,
 CONSTRAINT [PK_authors] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[banners]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[banners](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[title] [nvarchar](256) NOT NULL,
	[subtitle] [nvarchar](512) NULL,
	[button_text] [nvarchar](64) NOT NULL,
	[url] [varchar](256) NOT NULL,
	[utm] [varchar](32) NULL,
	[type] [varchar](64) NOT NULL,
	[active] [bit] NOT NULL,
	[order] [int] NULL,
	[show_on_landing] [bit] NOT NULL,
 CONSTRAINT [PK_banners] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[benchmarks_removeMe]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[benchmarks_removeMe](
	[id] [int] NOT NULL,
	[name] [nvarchar](64) NOT NULL,
 CONSTRAINT [PK_benchmarks] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[boards]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[boards](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](128) NOT NULL,
	[description] [nvarchar](512) NOT NULL,
	[code] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_boards] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[campaign_audit]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[campaign_audit](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[date] [datetime2](7) NOT NULL,
	[campaign_id] [int] NOT NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[strategy_id] [uniqueidentifier] NULL,
	[action] [int] NOT NULL,
	[action_data] [varchar](max) NULL,
 CONSTRAINT [PK_campaign_audit] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[campaigns]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[campaigns](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](50) NOT NULL,
	[start_date] [datetime2](7) NOT NULL,
	[end_date] [datetime2](7) NOT NULL,
	[strategies_list] [varchar](max) NULL,
	[service_kind] [int] NOT NULL,
	[client_conditions] [varchar](max) NULL,
	[priority] [int] NOT NULL,
	[white_list] [varchar](max) NULL,
	[black_list] [varchar](max) NULL,
	[action] [int] NOT NULL,
	[action_parameters] [varchar](max) NULL,
	[active] [bit] NOT NULL,
	[tariff_display_value] [varchar](100) NULL,
	[welcome_letter_template_name] [varchar](max) NULL,
	[tariff_description] [varchar](max) NULL,
	[tariff_info] [varchar](max) NULL,
	[wl_campaign_comission] [varchar](max) NULL,
	[wl_campaign_comment] [varchar](max) NULL,
	[strategy_condtions] [varchar](max) NULL,
 CONSTRAINT [PK_Campaigns] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[client_accounts]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[client_accounts](
	[id] [bigint] NOT NULL,
	[client_id] [uniqueidentifier] NULL,
	[client_code] [varchar](64) NOT NULL,
	[strategy_id] [uniqueidentifier] NULL,
	[realized_pnl] [decimal](25, 10) NULL,
	[realized_pnl_pct] [decimal](20, 10) NOT NULL,
	[status] [int] NULL,
	[diff_from_strategy] [decimal](20, 15) NULL,
	[agreement] [nvarchar](32) NULL,
	[profile] [nvarchar](64) NULL,
	[service] [nvarchar](64) NULL,
	[agreement_id] [uniqueidentifier] NULL,
	[profile_updated] [int] NOT NULL,
	[state] [nvarchar](256) NULL,
	[limits_time] [datetime2](7) NULL,
	[profile_date] [datetime2](0) NULL,
	[profile_id] [int] NULL,
	[progress_strategy_id] [uniqueidentifier] NULL,
	[service_date] [datetime2](7) NULL,
	[investment_advice_agreement_date] [datetime2](0) NULL,
	[client_tariff_id] [uniqueidentifier] NULL,
	[is_qualified_investor] [bit] NOT NULL,
	[close_date] [datetime2](7) NULL,
	[subscription_source] [int] NULL,
	[min_diff] [decimal](20, 15) NULL,
	[initial_upl] [decimal](20, 10) NULL,
	[initial_upl_prt] [decimal](20, 10) NULL,
	[send_iir_sms] [bit] NOT NULL,
	[is_marginal] [bit] NOT NULL,
	[subscription_request_date] [datetime] NULL,
	[binding_status] [int] NOT NULL,
	[agreement_start_date] [datetime2](7) NOT NULL,
	[partner_id] [uniqueidentifier] NULL,
 CONSTRAINT [PK_ClientAccounts] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[client_recomendations]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[client_recomendations](
	[account_id] [bigint] NOT NULL,
	[signal_id] [bigint] NOT NULL,
	[date] [datetime2](7) NOT NULL,
	[doc_id] [nvarchar](64) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[client_signals]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[client_signals](
	[account_id] [bigint] NOT NULL,
	[signal_id] [bigint] NOT NULL,
	[security_key] [varchar](64) NOT NULL,
	[count] [bigint] NOT NULL,
	[price] [decimal](20, 10) NOT NULL,
	[exec_count] [bigint] NOT NULL,
	[exec_price] [decimal](20, 10) NOT NULL,
	[realized_pnl] [decimal](20, 10) NOT NULL,
	[realized_pnl_pct] [decimal](20, 10) NOT NULL,
	[realized_pnl_pct_portfolio] [decimal](20, 10) NOT NULL,
	[state] [tinyint] NOT NULL,
	[date] [datetime2](7) NOT NULL,
	[error_description] [nvarchar](max) NULL,
	[currency] [varchar](8) NULL,
	[exec_value] [decimal](30, 10) NULL,
	[price_pct] [bit] NOT NULL,
	[is_exchange] [bit] NOT NULL,
	[is_hidden] [bit] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[clients]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[clients](
	[id] [uniqueidentifier] NOT NULL,
	[first_name] [nvarchar](164) NOT NULL,
	[last_name] [nvarchar](164) NOT NULL,
	[middle_name] [nvarchar](164) NULL,
	[phone] [varchar](164) NULL,
	[email] [nvarchar](512) NULL,
	[gender] [char](1) NULL,
	[close_date] [datetime2](7) NULL,
 CONSTRAINT [PK_clients] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[currencies]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[currencies](
	[id] [varchar](8) NOT NULL,
	[name] [nvarchar](64) NOT NULL,
	[symbol] [nvarchar](1) NULL,
 CONSTRAINT [PK_currencies] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[durations]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[durations](
	[id] [int] NOT NULL,
	[name] [nvarchar](64) NOT NULL,
	[duration] [int] NOT NULL,
 CONSTRAINT [PK_durations] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[external_signals]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[external_signals](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[manager] [varchar](64) NOT NULL,
	[symbol] [varchar](64) NOT NULL,
	[class_code] [varchar](64) NOT NULL,
	[weight] [decimal](20, 10) NOT NULL,
	[price] [decimal](20, 10) NULL,
	[received] [datetime2](7) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[faq]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[faq](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](1024) NOT NULL,
	[tag] [nvarchar](128) NOT NULL,
	[friendly_url] [varchar](128) NULL,
 CONSTRAINT [PK_faq] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[faq_questions]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[faq_questions](
	[faq_id] [int] NOT NULL,
	[title] [nvarchar](256) NOT NULL,
	[text] [nvarchar](max) NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
	[friendly_url] [varchar](128) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[index_history]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[index_history](
	[index_id] [int] NOT NULL,
	[date] [datetime] NOT NULL,
	[value] [decimal](20, 10) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[indexes]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[indexes](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[symbol] [varchar](64) NOT NULL,
	[name] [nvarchar](64) NOT NULL,
	[value] [decimal](20, 10) NOT NULL,
	[inc] [decimal](20, 2) NOT NULL,
	[inc_pct] [decimal](20, 2) NOT NULL,
	[date] [datetime2](7) NOT NULL,
	[prev_value] [decimal](20, 10) NOT NULL,
	[order] [int] NULL,
	[kind] [int] NOT NULL,
	[script] [varchar](max) NULL,
	[futures_period] [int] NULL,
	[security_class] [int] NOT NULL,
 CONSTRAINT [PK_indexes] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[invest_offer_positions]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[invest_offer_positions](
	[invest_offer_id] [uniqueidentifier] NOT NULL,
	[order_num] [int] NOT NULL,
	[security_key] [varchar](50) NOT NULL,
	[issuer_description] [varchar](max) NULL,
	[full_description] [varchar](max) NULL,
 CONSTRAINT [PK_invest_offer_positions_1] PRIMARY KEY CLUSTERED 
(
	[invest_offer_id] ASC,
	[order_num] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[invest_offer_purchase_positions]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[invest_offer_purchase_positions](
	[packet_order_id] [int] NOT NULL,
	[order_id] [int] NOT NULL,
	[security_key] [varchar](30) NOT NULL,
	[price] [decimal](18, 6) NOT NULL,
	[quantity] [int] NOT NULL,
	[initial_client_qty] [int] NOT NULL,
	[min_reported_qty] [int] NOT NULL,
	[order_price] [decimal](18, 6) NOT NULL,
 CONSTRAINT [PK_invest_offer_request_positions] PRIMARY KEY CLUSTERED 
(
	[packet_order_id] ASC,
	[order_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[invest_offers]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[invest_offers](
	[id] [uniqueidentifier] NOT NULL,
	[external_id] [int] NULL,
	[title] [varchar](100) NULL,
	[active] [bit] NOT NULL,
	[subtitle] [varchar](100) NULL,
	[description] [varchar](max) NULL,
	[comment] [varchar](max) NULL,
	[image] [varchar](300) NULL,
	[invest_offer_json] [varchar](max) NULL,
	[kind] [int] NOT NULL,
	[test_mode] [bit] NOT NULL,
 CONSTRAINT [PK_invest_offer] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[invest_offers_purchases]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[invest_offers_purchases](
	[packet_order_id] [int] IDENTITY(1,1) NOT NULL,
	[execution_request_id] [uniqueidentifier] NOT NULL,
	[created] [datetime2](7) NOT NULL,
	[invest_offer_id] [uniqueidentifier] NOT NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[purchased] [bit] NOT NULL,
	[is_reported_to_warehouse] [bit] NOT NULL,
	[sum_in_rubles] [decimal](20, 6) NULL,
	[is_sold_out] [bit] NOT NULL,
 CONSTRAINT [PK_invest_offers_purchases] PRIMARY KEY CLUSTERED 
(
	[packet_order_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[invest_profiles]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[invest_profiles](
	[id] [int] NOT NULL,
	[name] [nvarchar](64) NOT NULL,
	[description] [nvarchar](1024) NOT NULL,
	[profile_id] [uniqueidentifier] NULL,
	[estimated_drawdown] [decimal](18, 10) NULL,
 CONSTRAINT [PK_invest_profiles] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[investoffer_tests]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[investoffer_tests](
	[investoffer_id] [uniqueidentifier] NOT NULL,
	[test_id] [varchar](64) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[labels]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[labels](
	[id] [int] NOT NULL,
	[text] [nvarchar](64) NOT NULL,
	[tooltip] [nvarchar](256) NULL,
	[fore_color] [varchar](7) NOT NULL,
	[back_color] [varchar](7) NOT NULL,
 CONSTRAINT [PK_labels] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[markets]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[markets](
	[id] [int] NOT NULL,
	[name] [nvarchar](64) NOT NULL,
 CONSTRAINT [PK_markets] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[partners]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[partners](
	[id] [uniqueidentifier] NOT NULL,
	[name] [varchar](500) NOT NULL,
 CONSTRAINT [PK_partners] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[questionaries]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[questionaries](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[created] [datetime] NULL,
	[questionary_id] [uniqueidentifier] NOT NULL,
	[document_id] [uniqueidentifier] NOT NULL,
	[document] [varbinary](max) NOT NULL,
	[client_id] [uniqueidentifier] NOT NULL,
	[profile] [varchar](64) NULL,
 CONSTRAINT [PK_Tmp_questionaries] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[questionaries.old]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[questionaries.old](
	[questionary_id] [uniqueidentifier] NOT NULL,
	[document_id] [uniqueidentifier] NOT NULL,
	[document] [varbinary](max) NOT NULL,
	[client_id] [uniqueidentifier] NOT NULL,
	[profile] [varchar](64) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[questions]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[questions](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](64) NOT NULL,
	[phone] [nvarchar](64) NOT NULL,
	[description] [nvarchar](500) NULL,
	[send_time] [datetime2](7) NULL,
	[email_sent] [bit] NOT NULL,
	[cookies] [nvarchar](max) NULL,
	[utmz] [nvarchar](max) NULL,
	[email] [nvarchar](512) NULL,
	[refid] [int] NOT NULL,
	[referer] [nvarchar](1024) NULL,
 CONSTRAINT [PK_questions] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[services]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[services](
	[id] [int] NOT NULL,
	[name] [nvarchar](64) NOT NULL,
 CONSTRAINT [PK_services] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[shopfront]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[shopfront](
	[object_type] [varchar](32) NOT NULL,
	[object_id] [uniqueidentifier] NOT NULL,
	[message_id] [uniqueidentifier] NULL,
	[send_time] [datetime2](7) NULL,
	[json] [nvarchar](max) NULL,
	[force_delete] [bit] NOT NULL,
	[response_time] [datetime2](7) NULL,
	[status] [varchar](16) NULL,
	[response_json] [nvarchar](MAX) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategies]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategies](
	[id] [uniqueidentifier] NOT NULL,
	[author_id] [int] NOT NULL,
	[name] [nvarchar](256) NOT NULL,
	[tag] [nvarchar](512) NOT NULL,
	[info_html] [nvarchar](max) NOT NULL,
	[description_html] [nvarchar](max) NULL,
	[picture_format] [varchar](8) NOT NULL,
	[picture] [varchar](max) NULL,
	[currency_id] [varchar](8) NOT NULL,
	[min_invest_profile_id] [int] NOT NULL,
	[subscription_threshold] [decimal](18, 0) NOT NULL,
	[estimated_drawdown] [decimal](18, 10) NOT NULL,
	[estimated_profit] [decimal](18, 10) NOT NULL,
	[duration_id] [int] NOT NULL,
	[actual_drawdown] [decimal](18, 10) NULL,
	[actual_profit] [decimal](18, 10) NULL,
	[open] [bit] NOT NULL,
	[leverage] [decimal](18, 10) NOT NULL,
	[max_position_weight] [decimal](18, 10) NOT NULL,
	[max_industry_weight] [decimal](18, 10) NOT NULL,
	[is_algostrategy] [bit] NOT NULL,
	[capacity] [decimal](18, 0) NULL,
	[recommended] [bit] NOT NULL,
	[tool_drawndown] [decimal](18, 0) NULL,
	[min_invest_calculation] [decimal](18, 0) NOT NULL,
	[start_date] [datetime] NULL,
	[hide_portfolio] [bit] NOT NULL,
	[chart_comment] [nvarchar](max) NULL,
	[test_mode] [bit] NOT NULL,
	[price] [nvarchar](256) NULL,
	[pl_start_date] [datetime2](0) NULL,
	[rating] [float] NULL,
	[index_id] [int] NULL,
	[comissions] [nvarchar](max) NULL,
	[show_full_portfolio] [bit] NOT NULL,
	[iis] [tinyint] NULL,
	[autofollow] [tinyint] NULL,
	[trades_frequency] [varchar](32) NULL,
	[auto_consult] [tinyint] NULL,
	[max_instrument_fraq] [decimal](20, 10) NULL,
	[tarif] [int] NULL,
	[is_free] [bit] NOT NULL,
	[order] [int] NOT NULL,
	[api_key] [varchar](256) NULL,
	[for_qualified_investors_only] [bit] NOT NULL,
	[hide_recent_signals] [bit] NOT NULL,
	[category] [char](2) NULL,
	[is_restricted] [bit] NOT NULL,
	[goal] [varchar](max) NULL,
	[picture_url] [varchar](255) NULL,
	[back_color] [char](6) NULL,
	[parent_strategy] [uniqueidentifier] NULL,
	[test_rating] [float] NULL,
	[closed_for_binding] [bit] NOT NULL,
	[friendly_url] [nvarchar](128) NULL,
	[unbind_note] [nvarchar](1024) NULL,
	[status] [int] NOT NULL,
	[card_picture_url] [varchar](255) NULL,
	[video_url] [varchar](255) NULL,
	[isportfolio] [tinyint] NOT NULL,
	[info_parts] [nvarchar](max) NULL,
	[show_raw_pl] [bit] NOT NULL,
	[kind_id] [int] NOT NULL,
	[hide_in_ui] [int] NOT NULL,
	[seo_title] [nvarchar](160) NULL,
	[seo_description] [nvarchar](max) NULL,
	[updated] [smallint] NOT NULL,
	[mind_leverage_for_qual] [bit] NOT NULL,
	[sub_threshold_actual] [decimal](18, 10) NULL,
	[description_text] [nvarchar](max) NULL,
	[actual_threshold] [decimal](20, 10) NULL,
	[update_time] [datetime] NULL,
	[is_registered] [bit] NOT NULL,
	[hide_index_in_WL] [bit] NOT NULL,
	[hide_index_on_chart] [bit] NOT NULL,
	[partner_id] [uniqueidentifier] NULL,
	[is_investbox] [tinyint] NULL,
	[lasting_order_code] [varchar](50) NULL,
 CONSTRAINT [PK_strategies] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_boards]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_boards](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[board_id] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_categories]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_categories](
	[id] [char](2) NOT NULL,
	[mf] [decimal](20, 10) NOT NULL,
	[sf] [decimal](20, 10) NOT NULL,
 CONSTRAINT [PK_strategy_categories] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_clients]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_clients](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[client_id] [uniqueidentifier] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_comments]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_comments](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[date] [datetime2](0) NOT NULL,
	[comment_html] [nvarchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_kinds]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_kinds](
	[id] [int] NOT NULL,
	[name] [varchar](50) NOT NULL,
	[description] [varchar](300) NULL,
 CONSTRAINT [PK_strategy_kinds] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_labels]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_labels](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[label_id] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_markets]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_markets](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[market_id] [int] NOT NULL,
 CONSTRAINT [PK_strategy_markets] PRIMARY KEY CLUSTERED 
(
	[strategy_id] ASC,
	[market_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_parameters]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_parameters](
	[strategy_id] [uniqueidentifier] NULL,
	[name] [nvarchar](64) NOT NULL,
	[parameter] [nvarchar](64) NOT NULL,
	[value] [varchar](32) NULL,
	[unit] [nvarchar](16) NULL,
	[precision] [int] NULL,
	[tooltip] [nvarchar](max) NULL,
	[order] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_pl]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_pl](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[history] [varchar](max) NOT NULL,
	[MeanYear] [decimal](20, 10) NULL,
	[FromStart] [decimal](20, 10) NULL,
	[Reduced_History_Small] [varchar](max) NULL,
	[Reduced_History_Large] [varchar](max) NULL,
	[MeanYear_noc] [decimal](20, 10) NULL,
	[FromStart_noc] [decimal](20, 10) NULL,
	[LastWeek] [decimal](20, 10) NULL,
 CONSTRAINT [PK_strategy_pl] PRIMARY KEY CLUSTERED 
(
	[strategy_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_pl_period]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_pl_period](
	[StratId] [uniqueidentifier] NOT NULL,
	[Date] [datetime] NULL,
	[Period] [char](1) NOT NULL,
	[PL] [decimal](18, 6) NULL,
	[Drawdown] [decimal](18, 6) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_positions]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_positions](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[symbol] [varchar](32) NOT NULL,
	[name] [varchar](256) NULL,
	[entry_time] [datetime2](7) NOT NULL,
	[avg_price] [decimal](20, 10) NOT NULL,
	[weight] [decimal](20, 10) NOT NULL,
	[last_price] [decimal](20, 10) NULL,
	[upl] [decimal](20, 10) NULL,
	[isin] [varchar](32) NULL,
	[type_name] [nvarchar](64) NULL,
	[class_code] [varchar](16) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_salespoints]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_salespoints](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[title] [nvarchar](max) NOT NULL,
	[text] [nvarchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_services]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_services](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[service_id] [int] NOT NULL,
 CONSTRAINT [PK_strategy_services] PRIMARY KEY CLUSTERED 
(
	[strategy_id] ASC,
	[service_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_signals]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_signals](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[time] [datetime2](7) NOT NULL,
	[symbol] [nvarchar](64) NOT NULL,
	[name] [nvarchar](256) NOT NULL,
	[comment] [nvarchar](2048) NULL,
	[realized_pl] [decimal](20, 10) NOT NULL,
	[id] [bigint] NOT NULL,
	[isin] [varchar](32) NULL,
 CONSTRAINT [PK_strategy_signals] PRIMARY KEY NONCLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_stats]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_stats](
	[StratId] [uniqueidentifier] NOT NULL,
	[Risk] [float] NULL,
	[Sharp] [float] NULL,
	[Info] [float] NULL,
	[Drawdown] [decimal](20, 10) NULL,
	[Volatility] [decimal](20, 10) NULL,
	[BechmarkPL] [decimal](20, 10) NULL,
	[Alpha] [decimal](20, 10) NULL,
	[Beta] [decimal](20, 10) NULL,
	[R2] [decimal](20, 10) NULL,
	[Trades] [int] NULL,
	[TradesPerWeek] [float] NULL,
	[MeanTradeValue] [decimal](20, 5) NULL,
	[PercentProfitTrades] [float] NULL,
	[MeanPorfitOnTrade] [decimal](20, 5) NULL,
	[MeanLossOnTrade] [decimal](20, 5) NULL,
	[PercentLossTrades] [float] NULL,
	[DrawdownY] [decimal](20, 10) NULL,
	[TradesPerWeekLastYear] [float] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_subscription_attempts]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_subscription_attempts](
	[id] [uniqueidentifier] NOT NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[created] [datetime2](7) NOT NULL,
	[confirmation_time] [datetime2](7) NULL,
	[template_kind] [varchar](50) NULL,
	[document_data] [nvarchar](max) NULL,
	[activation_time] [datetime2](7) NULL,
	[retries_count] [int] NOT NULL,
	[accept_doc_id] [int] NULL,
	[pending_actions] [int] NOT NULL,
	[next_retry_time] [datetime2](7) NULL,
	[eva_error] [varchar](max) NULL,
 CONSTRAINT [PK_strategy_subscription_attempt] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_subscriptions]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_subscriptions](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[agreement_id] [uniqueidentifier] NOT NULL,
	[strategy_id] [uniqueidentifier] NULL,
	[status] [int] NOT NULL,
	[date] [datetime] NOT NULL,
	[subscription_source] [int] NULL,
	[pending_email_types] [int] NOT NULL,
	[is_subscribing] [bit] NOT NULL,
	[campaign_id] [int] NULL,
	[timed_portfolio_id] [int] NULL,
	[client_profile_id] [int] NULL,
	[liquid_price] [decimal](20, 10) NULL,
 CONSTRAINT [PK_strategy_activations] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_tests]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_tests](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[test_id] [varchar](64) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[strategy_tools]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[strategy_tools](
	[strategy_id] [uniqueidentifier] NOT NULL,
	[tool_id] [int] NOT NULL,
 CONSTRAINT [PK_strategy_tools] PRIMARY KEY CLUSTERED 
(
	[strategy_id] ASC,
	[tool_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tariff_clients]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tariff_clients](
	[client_tariff_id] [uniqueidentifier] NOT NULL,
	[strategy_tariff_id] [int] NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tariff_strategies]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tariff_strategies](
	[id] [int] NOT NULL,
	[strategy_id] [uniqueidentifier] NOT NULL,
	[tariff_id] [int] NOT NULL,
	[strategy_type] [int] NOT NULL,
	[update_time] [smalldatetime] NOT NULL,
 CONSTRAINT [PK_strategy_tariff] PRIMARY KEY CLUSTERED 
(
	[id] ASC,
	[strategy_id] ASC,
	[strategy_type] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tariffs]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tariffs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[tariff_id] [uniqueidentifier] NOT NULL,
	[description] [nvarchar](1024) NOT NULL,
	[eva_id] [int] NOT NULL,
	[order] [int] NULL,
	[category_id] [char](2) NULL,
	[kind] [int] NULL,
 CONSTRAINT [PK_tariff_id] PRIMARY KEY NONCLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[term_portfolio_positions]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[term_portfolio_positions](
	[portfolio_id] [uniqueidentifier] NOT NULL,
	[key] [varchar](32) NOT NULL,
	[isin] [varchar](32) NOT NULL,
	[name] [nvarchar](128) NOT NULL,
	[weight] [decimal](20, 10) NOT NULL,
 CONSTRAINT [PK_term_portfolio_positions] PRIMARY KEY CLUSTERED 
(
	[portfolio_id] ASC,
	[key] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[term_portfolios]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[term_portfolios](
	[id] [uniqueidentifier] NOT NULL,
	[name] [nvarchar](256) NOT NULL,
	[description] [nvarchar](max) NOT NULL,
	[min_sum] [decimal](20, 10) NOT NULL,
	[min_sl] [decimal](20, 10) NOT NULL,
	[default_sl] [decimal](20, 10) NOT NULL,
	[max_sl] [decimal](20, 10) NOT NULL,
	[min_tp] [decimal](20, 10) NOT NULL,
	[default_tp] [decimal](20, 10) NOT NULL,
	[max_tp] [decimal](20, 10) NOT NULL,
	[open] [bit] NOT NULL,
	[order] [int] NOT NULL,
	[short_description] [nvarchar](max) NULL,
	[stop_date] [date] NOT NULL,
	[currency] [varchar](8) NOT NULL,
	[friendly_url] [varchar](64) NOT NULL,
	[min_invest_profile_id] [int] NOT NULL,
	[category] [char](2) NULL,
	[forecast_source_id] [int] NULL,
	[salespoints] [nvarchar](max) NULL,
	[modification_date] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_term_portfolios] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[test_clients]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[test_clients](
	[master_id] [uniqueidentifier] NOT NULL,
	[comment] [varchar](100) NULL,
 CONSTRAINT [PK_test_clients] PRIMARY KEY CLUSTERED 
(
	[master_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tests]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tests](
	[id] [varchar](64) NOT NULL,
	[name] [nvarchar](max) NOT NULL,
	[id_moex] [varchar](64) NULL,
	[id_spb] [varchar](64) NULL,
	[id_interfax] [varchar](64) NULL,
	[comment] [nvarchar](max) NULL,
 CONSTRAINT [PK_tests] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[timed_portfolio_positions]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[timed_portfolio_positions](
	[account_id] [bigint] NOT NULL,
	[portf_id] [bigint] NOT NULL,
	[security_key] [varchar](64) NOT NULL,
	[avg_price] [decimal](20, 10) NOT NULL,
	[current_price] [decimal](20, 10) NULL,
	[quantity] [int] NOT NULL,
	[weight] [decimal](20, 10) NOT NULL,
	[currency] [varchar](8) NULL,
	[name] [nvarchar](256) NULL,
	[unrealizedPnL] [decimal](20, 10) NULL,
	[totalPnL] [decimal](20, 10) NULL,
 CONSTRAINT [Pktimed_portfolio_positions] PRIMARY KEY CLUSTERED 
(
	[account_id] ASC,
	[security_key] ASC,
	[portf_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[timed_portfolios]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[timed_portfolios](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[AccountId] [bigint] NOT NULL,
	[Date] [datetime2](7) NULL,
	[Positions] [varchar](max) NULL,
	[SL] [decimal](18, 10) NULL,
	[TP] [decimal](18, 10) NULL,
	[CurrentPL] [decimal](18, 10) NULL,
	[S] [decimal](18, 6) NULL,
	[ParentId] [uniqueidentifier] NULL,
	[CloseDate] [datetime2](7) NULL,
	[IsPending] [bit] NOT NULL,
 CONSTRAINT [PkTimedPortfolios] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TimedPortfoliosHistory]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TimedPortfoliosHistory](
	[PortId] [int] NOT NULL,
	[t] [datetime] NOT NULL,
	[v] [decimal](18, 12) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tools]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tools](
	[id] [int] NOT NULL,
	[name] [nvarchar](64) NOT NULL,
 CONSTRAINT [PK_tools] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[uploaded_files]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[uploaded_files](
	[id] [uniqueidentifier] NOT NULL,
	[file_name] [nvarchar](512) NOT NULL,
	[content] [varbinary](max) NOT NULL,
 CONSTRAINT [PK_uploaded_file] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[utms]    Script Date: 24.11.2021 12:28:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[utms](
	[id] [varchar](32) NOT NULL,
	[name] [nvarchar](64) NOT NULL
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[accept_docs] ADD  CONSTRAINT [DF__accept_do__is_si__4D2A7347]  DEFAULT ((0)) FOR [is_signed]
GO
ALTER TABLE [dbo].[analytics] ADD  CONSTRAINT [DF_analytics_active]  DEFAULT ((1)) FOR [active]
GO
ALTER TABLE [dbo].[analytics] ADD  CONSTRAINT [DF_analytics_subscription]  DEFAULT ((0)) FOR [subscription]
GO
ALTER TABLE [dbo].[analytics_strategies] ADD  CONSTRAINT [DF_analytics_strategies_show_in_strategy]  DEFAULT ((1)) FOR [show_in_strategy]
GO
ALTER TABLE [dbo].[analytics_subscribes] ADD  CONSTRAINT [DF_analytics_subscribes_active]  DEFAULT ((1)) FOR [active]
GO
ALTER TABLE [dbo].[analytics_subscribes] ADD  CONSTRAINT [DF_analytics_subscribes_sent_version]  DEFAULT ((0)) FOR [sent_version]
GO
ALTER TABLE [dbo].[authors] ADD  CONSTRAINT [def_author_photo_format]  DEFAULT ('jpeg') FOR [photo_format]
GO
ALTER TABLE [dbo].[authors] ADD  DEFAULT ((10)) FOR [rating]
GO
ALTER TABLE [dbo].[banners] ADD  CONSTRAINT [DF_banners_active]  DEFAULT ((0)) FOR [active]
GO
ALTER TABLE [dbo].[banners] ADD  CONSTRAINT [DF_banners_show_on_landing]  DEFAULT ((0)) FOR [show_on_landing]
GO
ALTER TABLE [dbo].[boards] ADD  CONSTRAINT [DF_boards_code]  DEFAULT ('') FOR [code]
GO
ALTER TABLE [dbo].[client_accounts] ADD  CONSTRAINT [DF_client_accounts_profile_updated]  DEFAULT ((1)) FOR [profile_updated]
GO
ALTER TABLE [dbo].[client_accounts] ADD  DEFAULT ((0)) FOR [is_qualified_investor]
GO
ALTER TABLE [dbo].[client_accounts] ADD  DEFAULT ((0)) FOR [min_diff]
GO
ALTER TABLE [dbo].[client_accounts] ADD  CONSTRAINT [DF_client_accounts_send_iir_sms]  DEFAULT ((1)) FOR [send_iir_sms]
GO
ALTER TABLE [dbo].[client_accounts] ADD  CONSTRAINT [DF_client_accounts_binding_status]  DEFAULT ((0)) FOR [binding_status]
GO
ALTER TABLE [dbo].[client_accounts] ADD  CONSTRAINT [DF_client_accounts_agreement_start_date]  DEFAULT ('2000-01-01') FOR [agreement_start_date]
GO
ALTER TABLE [dbo].[client_signals] ADD  CONSTRAINT [DF_client_signals_price_pct]  DEFAULT ((0)) FOR [price_pct]
GO
ALTER TABLE [dbo].[client_signals] ADD  CONSTRAINT [DF_client_signals_is_exchange]  DEFAULT ((0)) FOR [is_exchange]
GO
ALTER TABLE [dbo].[client_signals] ADD  CONSTRAINT [DF_client_signals_is_hidden]  DEFAULT ((0)) FOR [is_hidden]
GO
ALTER TABLE [dbo].[external_signals] ADD  CONSTRAINT [DF_external_signals_received]  DEFAULT (getdate()) FOR [received]
GO
ALTER TABLE [dbo].[indexes] ADD  CONSTRAINT [DF_indexes_kind]  DEFAULT ((0)) FOR [kind]
GO
ALTER TABLE [dbo].[indexes] ADD  CONSTRAINT [DF_indexes_security_class]  DEFAULT ((0)) FOR [security_class]
GO
ALTER TABLE [dbo].[invest_offer_purchase_positions] ADD  CONSTRAINT [DF_invest_offer_purchase_positions_order_price]  DEFAULT ((0)) FOR [order_price]
GO
ALTER TABLE [dbo].[invest_offers] ADD  CONSTRAINT [DF_invest_offers_kind]  DEFAULT ((1)) FOR [kind]
GO
ALTER TABLE [dbo].[invest_offers] ADD  CONSTRAINT [DF_invest_offers_test_mode]  DEFAULT ((0)) FOR [test_mode]
GO
ALTER TABLE [dbo].[questions] ADD  CONSTRAINT [DF_questions_email_sent]  DEFAULT ((0)) FOR [email_sent]
GO
ALTER TABLE [dbo].[questions] ADD  CONSTRAINT [DF_questions_refid]  DEFAULT ((0)) FOR [refid]
GO
ALTER TABLE [dbo].[shopfront] ADD  CONSTRAINT [DF_shopfront_force_delete]  DEFAULT ((0)) FOR [force_delete]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [def_strategy_picture_format]  DEFAULT ('jpeg') FOR [picture_format]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_show_weights_unauthorized]  DEFAULT ((0)) FOR [hide_portfolio]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_test_mode]  DEFAULT ((0)) FOR [test_mode]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_show_full_portfolio]  DEFAULT ((0)) FOR [show_full_portfolio]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_is_free]  DEFAULT ((0)) FOR [is_free]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_order]  DEFAULT ((1000)) FOR [order]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF__strategie__for_q__7755B73D]  DEFAULT ((0)) FOR [for_qualified_investors_only]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_hide_recent_signals]  DEFAULT ((0)) FOR [hide_recent_signals]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_is_restricted]  DEFAULT ((0)) FOR [is_restricted]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_closed_for_binding]  DEFAULT ((0)) FOR [closed_for_binding]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_status]  DEFAULT ((0)) FOR [status]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF__strategie__ispor__39AD8A7F]  DEFAULT ((0)) FOR [isportfolio]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_show_raw_pl]  DEFAULT ((0)) FOR [show_raw_pl]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_kind]  DEFAULT ((0)) FOR [kind_id]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_hide_in_ui]  DEFAULT ((0)) FOR [hide_in_ui]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [df_strategies_updated]  DEFAULT ((1)) FOR [updated]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF__strategie__mind___636EBA21]  DEFAULT ((0)) FOR [mind_leverage_for_qual]
GO
ALTER TABLE [dbo].[strategies] ADD  DEFAULT ((0)) FOR [is_registered]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_hide_index_in_WL]  DEFAULT ((0)) FOR [hide_index_in_WL]
GO
ALTER TABLE [dbo].[strategies] ADD  CONSTRAINT [DF_strategies_hide_index_on_chart]  DEFAULT ((0)) FOR [hide_index_on_chart]
GO
ALTER TABLE [dbo].[strategy_pl] ADD  DEFAULT ((0)) FOR [FromStart]
GO
ALTER TABLE [dbo].[strategy_pl] ADD  DEFAULT ((0)) FOR [FromStart_noc]
GO
ALTER TABLE [dbo].[strategy_subscription_attempts] ADD  CONSTRAINT [DF_strategy_subscription_attempts_retries_count]  DEFAULT ((0)) FOR [retries_count]
GO
ALTER TABLE [dbo].[strategy_subscription_attempts] ADD  CONSTRAINT [DF_strategy_subscription_attempts_pending_actions]  DEFAULT ((0)) FOR [pending_actions]
GO
ALTER TABLE [dbo].[strategy_subscriptions] ADD  CONSTRAINT [DF_strategy_subscriptions_pending_email_types]  DEFAULT ((0)) FOR [pending_email_types]
GO
ALTER TABLE [dbo].[strategy_subscriptions] ADD  CONSTRAINT [DF_strategy_subscriptions_is_subscribing]  DEFAULT ((0)) FOR [is_subscribing]
GO
ALTER TABLE [dbo].[tariff_strategies] ADD  DEFAULT ((0)) FOR [id]
GO
ALTER TABLE [dbo].[term_portfolios] ADD  CONSTRAINT [DF_term_portfolios_default_sl]  DEFAULT ((0)) FOR [default_sl]
GO
ALTER TABLE [dbo].[term_portfolios] ADD  CONSTRAINT [DF_term_portfolios_default_tp]  DEFAULT ((0)) FOR [default_tp]
GO
ALTER TABLE [dbo].[term_portfolios] ADD  CONSTRAINT [DF_term_portfolios_open]  DEFAULT ((0)) FOR [open]
GO
ALTER TABLE [dbo].[term_portfolios] ADD  CONSTRAINT [DF_term_portfolios_order]  DEFAULT ((1000)) FOR [order]
GO
ALTER TABLE [dbo].[term_portfolios] ADD  CONSTRAINT [DF_term_portfolios_min_invest_profile_id]  DEFAULT ((0)) FOR [min_invest_profile_id]
GO
ALTER TABLE [dbo].[term_portfolios] ADD  CONSTRAINT [DF_term_portfolios_modification_date]  DEFAULT (getdate()) FOR [modification_date]
GO
ALTER TABLE [dbo].[timed_portfolios] ADD  CONSTRAINT [DF_timed_portfolios_IsPending]  DEFAULT ((0)) FOR [IsPending]
GO
ALTER TABLE [dbo].[account_pl]  WITH CHECK ADD  CONSTRAINT [fk_accountpl_account] FOREIGN KEY([account_id])
REFERENCES [dbo].[client_accounts] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[account_pl] CHECK CONSTRAINT [fk_accountpl_account]
GO
ALTER TABLE [dbo].[account_portfolio]  WITH CHECK ADD  CONSTRAINT [fk_account_portfolio_account] FOREIGN KEY([account_id])
REFERENCES [dbo].[client_accounts] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[account_portfolio] CHECK CONSTRAINT [fk_account_portfolio_account]
GO
ALTER TABLE [dbo].[account_positions]  WITH CHECK ADD  CONSTRAINT [FK_accountpositions_accounts] FOREIGN KEY([account_id])
REFERENCES [dbo].[client_accounts] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[account_positions] CHECK CONSTRAINT [FK_accountpositions_accounts]
GO
ALTER TABLE [dbo].[analytics_strategies]  WITH CHECK ADD  CONSTRAINT [FK_analyticsstrategies_analytics] FOREIGN KEY([analytics_id])
REFERENCES [dbo].[analytics] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[analytics_strategies] CHECK CONSTRAINT [FK_analyticsstrategies_analytics]
GO
ALTER TABLE [dbo].[analytics_strategies]  WITH CHECK ADD  CONSTRAINT [FK_analyticsstrategies_strategies] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[strategies] ([id])
GO
ALTER TABLE [dbo].[analytics_strategies] CHECK CONSTRAINT [FK_analyticsstrategies_strategies]
GO
ALTER TABLE [dbo].[author_request_file]  WITH CHECK ADD  CONSTRAINT [fk_ar_file_file] FOREIGN KEY([file_id])
REFERENCES [dbo].[uploaded_files] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[author_request_file] CHECK CONSTRAINT [fk_ar_file_file]
GO
ALTER TABLE [dbo].[author_request_file]  WITH CHECK ADD  CONSTRAINT [fk_arfile_request] FOREIGN KEY([request_id])
REFERENCES [dbo].[author_request_new] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[author_request_file] CHECK CONSTRAINT [fk_arfile_request]
GO
ALTER TABLE [dbo].[client_accounts]  WITH CHECK ADD  CONSTRAINT [FK_ClientAccount_Client] FOREIGN KEY([client_id])
REFERENCES [dbo].[clients] ([id])
GO
ALTER TABLE [dbo].[client_accounts] CHECK CONSTRAINT [FK_ClientAccount_Client]
GO
ALTER TABLE [dbo].[client_recomendations]  WITH CHECK ADD  CONSTRAINT [fk_clientrecom_account] FOREIGN KEY([account_id])
REFERENCES [dbo].[client_accounts] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[client_recomendations] CHECK CONSTRAINT [fk_clientrecom_account]
GO
ALTER TABLE [dbo].[client_signals]  WITH CHECK ADD  CONSTRAINT [FK__client_si__accou__6383C8BA] FOREIGN KEY([account_id])
REFERENCES [dbo].[client_accounts] ([id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[client_signals] CHECK CONSTRAINT [FK__client_si__accou__6383C8BA]
GO
ALTER TABLE [dbo].[faq_questions]  WITH CHECK ADD  CONSTRAINT [FK_faq_id] FOREIGN KEY([faq_id])
REFERENCES [dbo].[faq] ([id])
GO
ALTER TABLE [dbo].[faq_questions] CHECK CONSTRAINT [FK_faq_id]
GO
ALTER TABLE [dbo].[index_history]  WITH CHECK ADD  CONSTRAINT [fk_idx_history_idx] FOREIGN KEY([index_id])
REFERENCES [dbo].[indexes] ([id])
GO
ALTER TABLE [dbo].[index_history] CHECK CONSTRAINT [fk_idx_history_idx]
GO
ALTER TABLE [dbo].[strategy_clients]  WITH CHECK ADD  CONSTRAINT [fk_strategyclients_client] FOREIGN KEY([client_id])
REFERENCES [dbo].[clients] ([id])
GO
ALTER TABLE [dbo].[strategy_clients] CHECK CONSTRAINT [fk_strategyclients_client]
GO
ALTER TABLE [dbo].[strategy_clients]  WITH CHECK ADD  CONSTRAINT [fk_strategyclients_strategy] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[strategies] ([id])
GO
ALTER TABLE [dbo].[strategy_clients] CHECK CONSTRAINT [fk_strategyclients_strategy]
GO
ALTER TABLE [dbo].[strategy_markets]  WITH CHECK ADD  CONSTRAINT [fk_strategymarket_market] FOREIGN KEY([market_id])
REFERENCES [dbo].[markets] ([id])
GO
ALTER TABLE [dbo].[strategy_markets] CHECK CONSTRAINT [fk_strategymarket_market]
GO
ALTER TABLE [dbo].[strategy_markets]  WITH CHECK ADD  CONSTRAINT [fk_strategymarket_strategy] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[strategies] ([id])
ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[strategy_markets] CHECK CONSTRAINT [fk_strategymarket_strategy]
GO
ALTER TABLE [dbo].[strategy_positions]  WITH CHECK ADD  CONSTRAINT [fk_strategypos_strategy] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[strategies] ([id])
ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[strategy_positions] CHECK CONSTRAINT [fk_strategypos_strategy]
GO
ALTER TABLE [dbo].[strategy_services]  WITH CHECK ADD  CONSTRAINT [fk_strategyservice_service] FOREIGN KEY([service_id])
REFERENCES [dbo].[services] ([id])
GO
ALTER TABLE [dbo].[strategy_services] CHECK CONSTRAINT [fk_strategyservice_service]
GO
ALTER TABLE [dbo].[strategy_services]  WITH CHECK ADD  CONSTRAINT [fk_strategyservice_strategy] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[strategies] ([id])
ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[strategy_services] CHECK CONSTRAINT [fk_strategyservice_strategy]
GO
ALTER TABLE [dbo].[strategy_tools]  WITH CHECK ADD  CONSTRAINT [fk_strategytool_strategy] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[strategies] ([id])
ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[strategy_tools] CHECK CONSTRAINT [fk_strategytool_strategy]
GO
ALTER TABLE [dbo].[strategy_tools]  WITH CHECK ADD  CONSTRAINT [fk_strategytool_tool] FOREIGN KEY([tool_id])
REFERENCES [dbo].[tools] ([id])
GO
ALTER TABLE [dbo].[strategy_tools] CHECK CONSTRAINT [fk_strategytool_tool]
GO
ALTER TABLE [dbo].[tariff_strategies]  WITH CHECK ADD  CONSTRAINT [FK_TariffStrategies_Strategies] FOREIGN KEY([strategy_id])
REFERENCES [dbo].[strategies] ([id])
ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[tariff_strategies] CHECK CONSTRAINT [FK_TariffStrategies_Strategies]
GO
ALTER TABLE [dbo].[tariff_strategies]  WITH CHECK ADD  CONSTRAINT [FK_TariffStrategies_Tariff] FOREIGN KEY([tariff_id])
REFERENCES [dbo].[tariffs] ([id])
GO
ALTER TABLE [dbo].[tariff_strategies] CHECK CONSTRAINT [FK_TariffStrategies_Tariff]
GO
ALTER TABLE [dbo].[tariffs]  WITH CHECK ADD  CONSTRAINT [FK_tariffs_strategy_categories] FOREIGN KEY([category_id])
REFERENCES [dbo].[strategy_categories] ([id])
GO
ALTER TABLE [dbo].[tariffs] CHECK CONSTRAINT [FK_tariffs_strategy_categories]
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор счёта' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'accept_docs', @level2type=N'COLUMN',@level2name=N'account_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'accept_docs', @level2type=N'COLUMN',@level2name=N'strategy_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Дата подключения/отключения' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'accept_docs', @level2type=N'COLUMN',@level2name=N'date'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Тип документа' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'accept_docs', @level2type=N'COLUMN',@level2name=N'document_type'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Тело документа в base64' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'accept_docs', @level2type=N'COLUMN',@level2name=N'document_body_base64'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Документы акцептов подключения/отключения услуги' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'accept_docs'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор клиентского счёта' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'account_pl', @level2type=N'COLUMN',@level2name=N'account_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'История доходности в JSON' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'account_pl', @level2type=N'COLUMN',@level2name=N'date'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'История доходности по клиентскому счёту' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'account_pl'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ссылка на счёт' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'account_pl', @level2type=N'CONSTRAINT',@level2name=N'fk_accountpl_account'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор счёта' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'account_positions', @level2type=N'COLUMN',@level2name=N'account_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор актива' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'account_positions', @level2type=N'COLUMN',@level2name=N'security_key'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Средневзвешенная цена входа' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'account_positions', @level2type=N'COLUMN',@level2name=N'avg_price'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Количество актива (шт)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'account_positions', @level2type=N'COLUMN',@level2name=N'quantity'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Открытые позиции по клиентским счетам' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'account_positions'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Справочник категорий статей' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'article_categories'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор автора' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Имя' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'first_name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Фамилия' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'last_name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Отчество' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'middle_name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Компания' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'company'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Должность' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'position'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'photo_format - формат данных фото (''jpeg'', ''png'')' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'photo_format'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Фото (png, base64)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'photo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Контактный email' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'email'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Информация об авторе (HTML-разметка)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors', @level2type=N'COLUMN',@level2name=N'info_html'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Авторы стратегий' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'authors'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор benchmark' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'benchmarks_removeMe', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Наименование benchmark' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'benchmarks_removeMe', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Бенчмарки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'benchmarks_removeMe'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор счёта' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор клиента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'client_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Брокерский счёт' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'client_code'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'strategy_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Реализованная доходность' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'realized_pnl'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Тип подключения' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'status'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ошибка следования' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'diff_from_strategy'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Генеральное соглашение' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'agreement'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Инвестиционный профиль' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'profile'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Услуга' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts', @level2type=N'COLUMN',@level2name=N'service'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Клиентские счета' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_accounts'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор счёта' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_recomendations', @level2type=N'COLUMN',@level2name=N'account_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор сигнала' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_recomendations', @level2type=N'COLUMN',@level2name=N'signal_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Дата/время рекомендации' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_recomendations', @level2type=N'COLUMN',@level2name=N'date'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Список бумаг в рекомендации' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_recomendations', @level2type=N'COLUMN',@level2name=N'doc_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Рекомендации по автоконсультированию' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_recomendations'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ссылка на счёт клиента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_recomendations', @level2type=N'CONSTRAINT',@level2name=N'fk_clientrecom_account'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор счёта' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'account_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор сигнала клиента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'signal_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор актива' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'security_key'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Количество бумаг к исполнению по сделке (шт)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'count'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Цена к исполнению' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'price'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Исполненное количество ценных бумаг (шт)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'exec_count'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Цена исполненной сделки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'exec_price'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Реализованная доходность' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'realized_pnl'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Состояние сделки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'state'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Дата сделки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'date'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Сообщение об ошибке в случае неудачного исполнения' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'client_signals', @level2type=N'COLUMN',@level2name=N'error_description'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор клиента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'clients', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Имя' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'clients', @level2type=N'COLUMN',@level2name=N'first_name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Фамилия' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'clients', @level2type=N'COLUMN',@level2name=N'last_name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Отчество' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'clients', @level2type=N'COLUMN',@level2name=N'middle_name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Телефон' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'clients', @level2type=N'COLUMN',@level2name=N'phone'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Email' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'clients', @level2type=N'COLUMN',@level2name=N'email'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Пол' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'clients', @level2type=N'COLUMN',@level2name=N'gender'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Клиенты' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'clients'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор валюты (код ISO 4217)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'currencies', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Наименование валюты' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'currencies', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Валюты' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'currencies'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор периода' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'durations', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Наименование периода' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'durations', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Длительность в днях' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'durations', @level2type=N'COLUMN',@level2name=N'duration'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Горизонты инвестирования' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'durations'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор профиля' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'invest_profiles', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Наименование профиля' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'invest_profiles', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Инвестиционные профили' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'invest_profiles'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Бирки на стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'labels'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор рынка' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'markets', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Наименование рынка' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'markets', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Рынки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'markets'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор инструмента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'questions', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Наименование инструмента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'questions', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Инструменты' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'questions'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор услуги' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'services', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Наименование услуги' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'services', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Услуги' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'services'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор автора' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'author_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Название стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Слоган' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'tag'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Краткое описание (HTML-разметка)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'info_html'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Подробное описание (HTML-разметка)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'description_html'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Формат данных пиктограммы (''jpeg'', ''png'')' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'picture_format'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Пиктограмма (png, base64)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'picture'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор валюты' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'currency_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор инвестиционного профиля стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'min_invest_profile_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Минимальный уровень инвестиций' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'subscription_threshold'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Допустимый уровень просадки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'estimated_drawdown'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Прогнозная доходность' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'estimated_profit'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ГИдентификатор горизонта инвестирования' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'duration_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Фактический уровень просадки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'actual_drawdown'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Фактическая доходность' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'actual_profit'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Доступность для подписки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'open'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Размер плеча' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'leverage'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Максимальная доля одного инструмента в портфеле' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'max_position_weight'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Максимальная совокупная доля одной отраслевой группы в портфеле' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'max_industry_weight'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Признак алгоритмической стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'is_algostrategy'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ёмкость стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'capacity'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Рекомендуется пользователю' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'recommended'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Просадка по инструменту' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'tool_drawndown'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Расчетный минимум инвестиций' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'min_invest_calculation'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Дата начала' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'start_date'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Закрыта для подключения новых клиентов' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'closed_for_binding'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Битовая маска флагов скрытия а некоторых фронтах' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies', @level2type=N'COLUMN',@level2name=N'hide_in_ui'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategies'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Разрешенные клиенты по закрытым стратегиям' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_clients'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_markets', @level2type=N'COLUMN',@level2name=N'strategy_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор рынка' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_markets', @level2type=N'COLUMN',@level2name=N'market_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Доступные по стратегиям рынки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_markets'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ссылка на рынок' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_markets', @level2type=N'CONSTRAINT',@level2name=N'fk_strategymarket_market'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ссылка на стратегию' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_markets', @level2type=N'CONSTRAINT',@level2name=N'fk_strategymarket_strategy'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_pl', @level2type=N'COLUMN',@level2name=N'strategy_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'График доходности в JSON' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_pl', @level2type=N'COLUMN',@level2name=N'history'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'История доходности по стратегиям' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_pl'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_positions', @level2type=N'COLUMN',@level2name=N'strategy_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Тикер инструмента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_positions', @level2type=N'COLUMN',@level2name=N'symbol'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Название инструмента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_positions', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Время первого открытия позиции' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_positions', @level2type=N'COLUMN',@level2name=N'entry_time'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Средневзвешенная цена входа' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_positions', @level2type=N'COLUMN',@level2name=N'avg_price'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Текущий вес в портфеле' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_positions', @level2type=N'COLUMN',@level2name=N'weight'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Открытые позиции по стратегиям' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_positions'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ссылка на стратегию' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_positions', @level2type=N'CONSTRAINT',@level2name=N'fk_strategypos_strategy'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_services', @level2type=N'COLUMN',@level2name=N'strategy_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор услуги' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_services', @level2type=N'COLUMN',@level2name=N'service_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Доступные по стратегиям услуги' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_services'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ссылка на услугу' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_services', @level2type=N'CONSTRAINT',@level2name=N'fk_strategyservice_service'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ссылка на стратегию' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_services', @level2type=N'CONSTRAINT',@level2name=N'fk_strategyservice_strategy'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор стратегии' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_tools', @level2type=N'COLUMN',@level2name=N'strategy_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Идентификатор рынка' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_tools', @level2type=N'COLUMN',@level2name=N'tool_id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Доступные по стратегиям рынки' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_tools'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ссылка на стратегию' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_tools', @level2type=N'CONSTRAINT',@level2name=N'fk_strategytool_strategy'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Ссылка на рынок' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'strategy_tools', @level2type=N'CONSTRAINT',@level2name=N'fk_strategytool_tool'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Уникальный идентификатор инструмента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tools', @level2type=N'COLUMN',@level2name=N'id'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Наименование инструмента' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tools', @level2type=N'COLUMN',@level2name=N'name'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Инструменты' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'tools'
GO
