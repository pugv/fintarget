using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Mb.Kafka.Abstractions.Serialization;

namespace KafkaSampleService;

public class XmlKafkaSerializer : IKafkaSerializer
{
    private readonly XmlWriterSettings _xmlSettings;

    public XmlKafkaSerializer()
    {
        _xmlSettings = new XmlWriterSettings
        {
            Indent = true,
            Encoding = Encoding.UTF8
        };
    }
    
    public byte[] Serialize<TMessage>(TMessage data)
    {
        var serializer = new XmlSerializer(typeof(TMessage));

        using var ms = new MemoryStream();
        using var writer = XmlWriter.Create(ms, _xmlSettings);
        
        serializer.Serialize(writer, data);
        return ms.ToArray();
    }
}