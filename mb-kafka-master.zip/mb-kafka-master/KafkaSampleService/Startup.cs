using KafkaSampleService.ConsumerMiddlewares;
using KafkaSampleService.Consumers;
using Mb.Kafka;
using KafkaSampleService.Models;
using KafkaSampleService.ProducerMiddlewares;
using KafkaSampleService.Producers;
using Mb.Kafka.Abstractions;

namespace KafkaSampleService;

public class Startup
{
    private readonly IConfiguration _configuration;

    public Startup(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    private const string TopicForTestMessages = "test-topic-json";
    private const string TopicForMessageXml = "test-topic-xml";
    private const string TopicForTestMessagesWithKey = "test-topic-with-key";

    private const int BatchSize = 10;

    public void ConfigureServices(IServiceCollection services)
    {
        services.AddKafka(conf =>
        {
            //Для переопределения сериализации, используй IKafkaSerializer
            //conf.SetProducerSerializer(new DefaultJsonSerializer());

            //Расширенные настройки продюсинга
            conf.SetGlobalProducersSettings(set =>
            {
                set.Compression = MessageCompression.Snappy;
                set.ProduceTimeout = TimeSpan.FromSeconds(10);
                set.QueueBufferingMaxMessages = 1_000_000;
            });

            var xmlSerializer = new XmlKafkaSerializer();

            conf.AddProducer<TestMessage>(TopicForTestMessages);
            // conf.AddProducer<TestMessageWithKey>(TopicForTestMessagesWithKey, message => message.KeyPartOne + message.KeyPartTwo);
            conf.AddProducer<TestMessageXml>(TopicForMessageXml)
                .UseCustomSerializer(xmlSerializer); // добавить свою сериализацию для данного продюсера
            
            conf.AddProducerMiddleware<ErrorHandlerMiddleware>();
            conf.AddProducerMiddleware<LoggingMiddleware>();

            var xmlDeserializer = new XmlKafkaDeserializer();
            
            conf.SetConsumersGroupId("foo");
            conf.AddConsumer<TestMessageConsumer, TestMessage>(TopicForTestMessages, 10);
            // conf.AddConsumer<TestMessageWithKeyConsumer, TestMessageWithKey>(set =>
            // {
            //     set.TopicName = TopicForTestMessagesWithKey;
            //     //set.GroupId = "foo1"; //переопределить GroupId для консьюмера
            //     set.BatchSize = BatchSize;
            //     set.ConsumersCount = 1; // Задать количество консьюмеров, если нужно в несклько потоков обрабатывать партиции (ConsumersCount = кол партиций)
            //     //set.EofConsumeDelayInMls = 1000;
            //     //set.MaxPollIntervalMs = 300_000;
            // });

            conf.AddConsumer<TestMessageXmlConsumer, TestMessageXml>(TopicForMessageXml, 10)
                .UseCustomDeserializer(xmlDeserializer);
            
            conf.AddConsumerMiddleware<ConsumerErrorHandlerMiddleware>();
        }, _configuration);

        // Background service по отправке в цикле с интервалом
        services.AddHostedService<KafkaProducerTestMessagesWorker>(); //TestMessage
        // services.AddHostedService<KafkaProducerTestMessagesWithKeyWorker>(); //TestMessageWithKey
        services.AddHostedService<KafkaProducerTestMessagesXmlWorker>(); // TestMessageXml
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IServiceProvider sp)
    {
    }
}