using KafkaSampleService.Models;
using Mb.Kafka.Abstractions.Consumer;

namespace KafkaSampleService.Consumers;

public class TestMessageConsumer : IKafkaConsumer<TestMessage>
{
    private readonly ILogger<TestMessageConsumer> _logger;

    public TestMessageConsumer(ILogger<TestMessageConsumer> logger)
    {
        _logger = logger;
    }

    public Task Consume(IConsumeContext<TestMessage> context, CancellationToken token)
    {
        foreach (var message in context.Messages)
        {
            _logger.LogInformation("Message received: {Message}",message.TestValue);
        }
        return Task.CompletedTask;
    }
}