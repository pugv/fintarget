using KafkaSampleService.Models;
using Mb.Kafka.Abstractions.Consumer;

namespace KafkaSampleService.Consumers;

public class TestMessageXmlConsumer : IKafkaConsumer<TestMessageXml>
{
    private readonly ILogger<TestMessageXmlConsumer> _logger;

    public TestMessageXmlConsumer(ILogger<TestMessageXmlConsumer> logger)
    {
        _logger = logger;
    }

    public Task Consume(IConsumeContext<TestMessageXml> context, CancellationToken token)
    {
        foreach (var message in context.Messages)
        {
            _logger.LogInformation("Message received: {Message}",message.Value);
        }
        return Task.CompletedTask;
    }
}