using Mb.Kafka.Abstractions;

namespace KafkaSampleService.Models;

public class TestMessageXml : IKafkaMessage
{
    public string Value { get; set; }
}