using System.Xml;
using System.Xml.Serialization;
using Mb.Kafka.Abstractions;
using Mb.Kafka.Abstractions.Serialization;

namespace KafkaSampleService;

public class XmlKafkaDeserializer : IKafkaDeserializer
{
    private readonly XmlReaderSettings _xmlSettings;

    public XmlKafkaDeserializer()
    {
        _xmlSettings = new XmlReaderSettings
        {
            CheckCharacters = false,
            IgnoreWhitespace = true,
            IgnoreComments = true,
            IgnoreProcessingInstructions = true,
        };
    }

    public TMessage Deserialize<TMessage>(byte[] data) where TMessage : class, IKafkaMessage
    {
        var serializer = new XmlSerializer(typeof(TMessage));

        using var stream = new MemoryStream(data);
        using var xmlReader = XmlReader.Create(stream, _xmlSettings);

        return (TMessage) serializer.Deserialize(xmlReader);
    }
}