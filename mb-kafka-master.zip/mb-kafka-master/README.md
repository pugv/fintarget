Confluent.Kafka wrapper

# MB.Kafka
Библиотека для интеграции с kafka, реализующая упрощенную обертку над Confluent.Kafka
### Features
- Возможность переопределения сериализации сообщения
##### Producer
- Отправка сообщения по одному
- Отправка сообщений батчем, с гарантией доставки
- Отправка сообщений с ключом партиционирования
- Добавлениe middleware для продюсера
##### Consumer
- Чтение сообщений из кафки - батчами (сообщения в батче, гарантированно из одной партиции)
- Добавление middleware для консьюмера
----
> **Оффтоп!**: Смотри Samples c примерами использования
### Настройка продюсера

```csharp
public IServiceCollection services

services.AddKafka(conf =>
{
    //Для переопределения сериализации, используй IKafkaSerializer
    //conf.SetProducerSerializer(new DefaultJsonSerializer());
    
    //Добавить продюсер для TestMessage, отправка в топик 'test-topic'         
    conf.AddProducer<TestMessage>("test-topic");
    
    //Добавить продюсер с ключом партиционирования для TestMessage, отправка в топик 'test-topic' 
    conf.AddProducer<TestMessageWithKey>("test-topic-with-key", m => m.Key");
}, _configuration);
```
Для добавления продюсера в проект, необходимо добавить `conf.AddProducer<{тип сообщения}>({имя топика})`, где тип сообщения унаследован от `IKafkaMessage`.
Если необходимо отправлять сообщение с ключом партиционарвания, то нужно указать свойство самого сообщения, которое будет являться этим ключом. При этом ключ может являться составным, например: `m=>$"{m.Key}:{m.AnotherKey}"`.
#### Пример использования продюсера
```csharp
private readonly IKafkaProducer<TestMessage> _producer;
...
await _producer.Produce(messages, stoppingToken);
```
#### Расширенные настройки для продюсеров
```csharp
conf.SetGlobalProducersSettings(set =>
{
   set.Compression = MessageCompression.Snappy;
   set.ProduceTimeout = TimeSpan.FromSeconds(10);
   set.QueueBufferingMaxMessagesInMls = 1_000_000;
});
```
Описание настроек:
- **Compression** - Задает тип компрессии при отправке сообщений (Default: None)
- **ProduceTimeout** - Интервал времени на отправку одного батча (Default: 0, бесконечно ожидаем отправки)
- **QueueBufferingMaxMessages** - Максимальное общее количесвто сообщений в продюсерах на отправку (Default: 100к и меньше быть не может)>
  >**Важно!**: Менять QueueBufferingMaxMessages только в том случае если понимаешь за что отвечает эта настройка в Confluent kafka. Может потребоваться если разом отправляются большого размера батчи, например больше 100к
#### Добавление middleware для producer-a

```csharp
conf.AddProducerMiddleware<ErrorHandlerMiddleware>(); //пример добавления middleware
conf.AddProducerMiddleware<LoggingMiddleware>();
```
Для логирования ошибок, метрик и тд, можно добавить middleware в рамках которого будет будет реализован нужный функционал. Для этого используй `KafkaMiddleware`
>**Важно**: middleware вызываются в той последовательности, в которой они были добавлены в DI

Пример реализации middleware:
```csharp
public class MyMiddleware : KafkaMiddleware
{
    public override async Task Handle<TMessage>(TMessage message)
    {
        //До отправки сообщения
        await Next(message);
        //После отправки сообщения
    }
}
```
---
### Настройка консьюмера
```csharp
services.AddKafka(conf =>
{
    conf.SetConsumersGroupId("foo");
    conf.AddConsumer<TestMessageConsumer, TestMessage>(TopicForTestMessages, BatchSize);
    conf.AddConsumer<TestMessageWithKeyConsumer, TestMessageWithKey>(set =>
    {
        set.TopicName = TopicForTestMessagesWithKey;
        set.GroupId = "foo1"; //переопределить GroupId для консьюмера
        set.BatchSize = BatchSize;
        set.ConsumersCount = 1; // Задать количество консьюмеров, если нужно в несклько потоков обрабатывать партиции (ConsumersCount = кол партиций)
        set.EofConsumeDelayInMls = 1000;
    });
}, _configuration);
```
Для добавления консьюмера в проект, необходимо добавить`conf.AddConsumer<{тип консьюмер},{тип сообщения}>({имя топика}, {Размер батча})`. При этом размер батча лишь говорит о том, что это максимальное количество сообщений, которые может вернуть консьюмер. Если батч дошел до конца партиции, то может вернуться меньше.

При добавлении консьюмеров, необходимо задать общую группу `conf.SetConsumersGroupId("foo");`
>**Важно!**: в случае ошибки серриализации консьюмера, он останавливает чтение. Контракт не должен отличаться
#### Пример использования консюмера
```csharp
public class TestMessageConsumer : IKafkaConsumer<TestMessage>
{
    private readonly ILogger<TestMessageConsumer> _logger;

    public TestMessageConsumer(ILogger<TestMessageConsumer> logger)
    {
    }

    public Task Consume(IConsumeContext<TestMessage> context, CancellationToken token)
    {
        _logger.LogInformation("Messages received: {Count}", context.Messages.Count());
    }
}
```
`IConsumeContext` содержит в себе метаинформацию по пришедшему батчу
- TopicName
- Partition - номер партиции
- Offset - номер последнего оффсета в партиции
#### Добавление middleware для consumer-a
```csharp
conf.AddConsumerMiddleware<ConsumerErrorHandlerMiddleware>();
```
---
#### Настройки для подключения к kafka
Самый простой способ, добавить секцию `KafkaConnectionSettings` в appsettings.json, настройки автоматически подтянутся. Если необходимы более _изащренные_ способы добавления настроек для kafka, то воспользуйся IConfigurationRoot для определения настроек KafkaConnectionSettings
```json
  "KafkaConnectionSettings": {
    "Servers" : "localhost:9092",
    "SecurityProtocol" : Plaintext,
    "SaslMechanism" : Plain,
    "SaslUsername" : "test_user",
    "SaslPassword" : "test_user_password"
  }
```
Если нужно подключение без пароля, то поля отвечающие за подключение по паролю заполнять не требуется
```json
  "KafkaConnectionSettings": {
"Servers" : "localhost:9092"
}
```
Или через метод расширения:
```csharp
services.AddKafka(conf =>
{
    //...
}, set =>
{
    set.Servers = "localhost:9092";
    ...
});
```