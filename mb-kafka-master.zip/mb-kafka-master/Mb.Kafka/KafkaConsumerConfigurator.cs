using Mb.Kafka.Abstractions;
using Mb.Kafka.Abstractions.Serialization;

namespace Mb.Kafka;

internal class KafkaConsumerConfigurator<TMessage> : IKafkaConsumerConfigurator<TMessage>
    where TMessage : class, IKafkaMessage
{
    private readonly KafkaConfigurator _configurator;

    public KafkaConsumerConfigurator(KafkaConfigurator configurator)
    {
        _configurator = configurator;
    }

    public IKafkaConsumerConfigurator<TMessage> UseCustomDeserializer(IKafkaDeserializer deserializer)
    {
        if (_configurator.CustomConsumerDeserializers.ContainsKey(typeof(TMessage)))
            throw new ArgumentException($"Deserializer for message type {typeof(TMessage)} already added");

        _configurator.CustomConsumerDeserializers.Add(typeof(TMessage), deserializer);

        return this;
    }
}