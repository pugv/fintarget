using Mb.Kafka.Abstractions;
using Mb.Kafka.Abstractions.Serialization;

namespace Mb.Kafka;

internal class KafkaProducerConfigurator<TMessage> : IKafkaProducerConfigurator<TMessage> where TMessage : class , IKafkaMessage
{
    private readonly KafkaConfigurator _configurator;
    
    public KafkaProducerConfigurator(KafkaConfigurator configurator)
    {
        _configurator = configurator;
    }
    
    public IKafkaProducerConfigurator<TMessage> UseCustomSerializer(IKafkaSerializer serializer)
    {
        if (_configurator.CustomProducerSerializers.ContainsKey(typeof(TMessage)))
            throw new ArgumentException($"Serializer for message type {typeof(TMessage)} already added");

        _configurator.CustomProducerSerializers.Add(typeof(TMessage), serializer);
        
        return this;
    }
}