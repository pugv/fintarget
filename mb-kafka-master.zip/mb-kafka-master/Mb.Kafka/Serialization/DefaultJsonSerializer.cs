using Mb.Kafka.Abstractions.Serialization;

namespace Mb.Kafka.Serialization;

/// <inheritdoc />
public class DefaultJsonSerializer : IKafkaSerializer 
{
    /// <inheritdoc />
    public byte[] Serialize<TMessage>(TMessage data)
    {
        return Utf8Json.JsonSerializer.Serialize(data);
    }
}