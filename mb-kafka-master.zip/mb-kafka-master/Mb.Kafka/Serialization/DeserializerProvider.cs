using Mb.Kafka.Abstractions;
using Mb.Kafka.Abstractions.Serialization;

namespace Mb.Kafka.Serialization;

internal class DeserializerProvider
{
    private readonly IKafkaDeserializer _defaultDeserializer;
    private readonly Dictionary<Type, IKafkaDeserializer> _customDeserializers;

    public DeserializerProvider(IKafkaDeserializer defaultDeserializer,
        Dictionary<Type, IKafkaDeserializer> customDeserializer)
    {
        _customDeserializers = customDeserializer;
        _defaultDeserializer = defaultDeserializer;
    }

    public IKafkaDeserializer GetInstance<TMessage>() where TMessage : class, IKafkaMessage
    {
        if (_customDeserializers.TryGetValue(typeof(TMessage), out var customDeserializer))
            return customDeserializer;
        
        return _defaultDeserializer;
    }
}