using Mb.Kafka.Abstractions;
using Mb.Kafka.Abstractions.Serialization;

namespace Mb.Kafka.Serialization;

/// <inheritdoc />
public class DefaultJsonDeserializer : IKafkaDeserializer
{
    /// <inheritdoc />
    public TMessage Deserialize<TMessage>(byte[] data) where TMessage : class, IKafkaMessage
    {
        return Utf8Json.JsonSerializer.Deserialize<TMessage>(data);
    }
}