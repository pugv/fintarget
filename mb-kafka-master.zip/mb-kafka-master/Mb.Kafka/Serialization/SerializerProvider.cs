using Mb.Kafka.Abstractions;
using Mb.Kafka.Abstractions.Serialization;

namespace Mb.Kafka.Serialization;

internal class SerializerProvider
{
    private readonly IKafkaSerializer _defaultSerializer;
    private readonly Dictionary<Type, IKafkaSerializer> _customSerializers;
    
    public SerializerProvider(IKafkaSerializer defaultSerializer, Dictionary<Type, IKafkaSerializer> customSerializers)
    {
        _customSerializers = customSerializers;
        _defaultSerializer = defaultSerializer;
    }

    public IKafkaSerializer GetInstance<TMessage>() where TMessage : IKafkaMessage
    {
        if (_customSerializers.TryGetValue(typeof(TMessage), out var customSerializer))
            return customSerializer;
        
        return _defaultSerializer;
    }
}