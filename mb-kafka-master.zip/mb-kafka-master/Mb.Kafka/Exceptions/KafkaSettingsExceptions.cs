namespace Mb.Kafka.Exceptions;

/// <summary>
/// Ошибка при отсутвии или невалидных конфигураций для подключения к kafka
/// </summary>
public class KafkaSettingsExceptions : Exception
{
    /// <summary>
    /// ctor
    /// </summary>
    /// <param name="message"></param>
    public KafkaSettingsExceptions (string message) 
        : base(message)
    {}
}