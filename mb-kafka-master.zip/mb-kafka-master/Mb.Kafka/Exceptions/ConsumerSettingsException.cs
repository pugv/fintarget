namespace Mb.Kafka.Exceptions;

/// <summary>
/// Ошибка при неверной конфигурации консьюмера
/// </summary>
public class ConsumerSettingsException : Exception
{
    /// <summary>
    /// ctor
    /// </summary>
    /// <param name="message"></param>
    public ConsumerSettingsException (string message) 
        : base(message)
    {}
}