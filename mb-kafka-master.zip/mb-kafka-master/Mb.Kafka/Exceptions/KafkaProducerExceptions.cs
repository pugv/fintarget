namespace Mb.Kafka.Exceptions;

/// <summary>
/// Ошибка возникающая при отправке сообщений
/// </summary>
public class KafkaProducerExceptions : Exception
{
    /// <summary>
    /// ctor
    /// </summary>
    /// <param name="message"></param>
    public KafkaProducerExceptions (string message) 
        : base(message)
    {}
}