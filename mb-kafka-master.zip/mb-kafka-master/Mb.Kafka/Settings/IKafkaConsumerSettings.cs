using Mb.Kafka.Abstractions;

namespace Mb.Kafka.Settings;

/// <summary>
/// Расширенные настройки для консьюмера
/// </summary>
/// <typeparam name="TMessage"></typeparam>
public interface IKafkaConsumerSettings<TMessage> where TMessage : class, IKafkaMessage
{
    /// <summary>
    /// Имя топика
    /// </summary>
    public string TopicName { get; set; }
        
    /// <summary>
    /// имя консьюмер группы
    /// </summary>
    public string GroupId { get; set; }
        
    /// <summary>
    /// Размер батча
    /// </summary>
    public int BatchSize { get; set; }

    /// <summary>
    /// Количество консьюмеров, должно быть равно количесвту партиций, в случае если нет горизонтального масштабирования
    /// (Default = 1)
    /// </summary>
    public int ConsumersCount { get; set; }
        
    /// <summary>
    /// Интервал между концом партции и следующием прочтением
    /// (Default = 1000)
    /// </summary>
    public int EofConsumeDelayInMls { get; set; }
    
    /// <summary>
    /// Интевал времени на обработку сообщений, в случае если вышли за пределы, то консьюмеры входят в ребаланс 
    /// (Default = 300_000, Max = 86400000 // 24h )
    /// </summary>
    public int MaxPollIntervalMs { get; set; }
}