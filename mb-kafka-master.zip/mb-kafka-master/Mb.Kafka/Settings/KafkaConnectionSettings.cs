using Confluent.Kafka;

namespace Mb.Kafka.Settings;

/// <summary>
/// Настройки подключения кафки
/// </summary>
public class KafkaConnectionSettings 
{
    /// <summary>
    /// Список брокеров для подключения (в виде хоста брокера или хоста:порта)
    /// </summary>
    public string Servers { get; set; }

    /// <summary>
    /// Протокол безопасности (по умолчанию Plaintext)
    /// </summary>
    public SecurityProtocol? SecurityProtocol { get; set; } = null;

    /// <summary>
    /// Механизм аутентификации
    /// </summary>
    public SaslMechanism? SaslMechanism { get; set; } = null;

    /// <summary>
    /// Имя пользователя для аутентификации
    /// </summary>
    public string SaslUsername { get; set; } = null;

    /// <summary>
    /// Пароль для аутентификации
    /// </summary>
    public string SaslPassword { get; set; } = null;
}