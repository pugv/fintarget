namespace Mb.Kafka.Abstractions.Serialization;

/// <summary>
/// Десериализатор сообщений, используется для консьюмера
/// </summary>
public interface IKafkaDeserializer
{
    /// <summary>
    /// Десериализовать
    /// </summary>
    /// <param name="data"></param>
    /// <typeparam name="TMessage"></typeparam>
    /// <returns></returns>
    TMessage Deserialize<TMessage>(byte[] data) where TMessage : class, IKafkaMessage;
}