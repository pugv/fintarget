using Mb.Kafka.Abstractions.Serialization;

namespace Mb.Kafka.Abstractions;

/// <summary>
/// Расширенная конфигурация для конкретного потребителя
/// </summary>
public interface IKafkaConsumerConfigurator<TMessage> where TMessage : class, IKafkaMessage
{
    /// <summary>
    /// Использовать отдельный десериализатор для заданного потребителя
    /// </summary>
    /// <param name="deserializer"></param>
    /// <returns></returns>
    public IKafkaConsumerConfigurator<TMessage> UseCustomDeserializer(IKafkaDeserializer deserializer);
}