namespace Mb.Kafka.Abstractions.Consumer;

/// <summary>
/// Сообщения вместе с мета информацией
/// </summary>
/// <typeparam name="TMessage"></typeparam>
public interface IConsumeContext<out TMessage> where TMessage : class, IKafkaMessage
{
    /// <summary>
    /// Имя топика
    /// </summary>
    public string TopicName { get; }
    
    /// <summary>
    /// Номер партиции из которой был вычитан батч
    /// </summary>
    public int Partition { get; }
    
    /// <summary>
    /// Последний оффсет батча
    /// </summary>
    public long Offset { get; }
    
    /// <summary>
    /// Батч сообщений
    /// </summary>
    public IEnumerable<TMessage> Messages { get; }
}