namespace Mb.Kafka.Abstractions.Consumer;

/// <summary>
/// Абстрактный класс для создания собственных middleware консьюмера
/// </summary>
public abstract class KafkaConsumerMiddleware
{
    private KafkaConsumerMiddleware _next;
    
    internal KafkaConsumerMiddleware AddNext(KafkaConsumerMiddleware middleware)
    {
        _next = middleware;
        return this;
    }

    /// <summary>
    /// Метод для добавления логики в middleware
    /// </summary>
    /// <param name="context"></param>
    /// <param name="token"></param>
    /// <typeparam name="TMessage"></typeparam>
    /// <returns></returns>
    public abstract Task Handle<TMessage>(IConsumeContext<TMessage> context, CancellationToken token) where TMessage : class, IKafkaMessage;


    /// <summary>
    /// Перейти дальше по жизненному циклу middleware
    /// </summary>
    /// <param name="context"></param>
    /// <param name="token"></param>
    /// <typeparam name="TMessage"></typeparam>
    protected async Task Next<TMessage>(IConsumeContext<TMessage> context, CancellationToken token) where TMessage : class, IKafkaMessage
    {
        await _next.Handle(context, token);
    }
}