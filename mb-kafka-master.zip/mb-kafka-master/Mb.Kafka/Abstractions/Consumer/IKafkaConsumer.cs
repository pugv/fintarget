namespace Mb.Kafka.Abstractions.Consumer;

/// <summary>
/// Интерфейс консьюмера для чтения сообщений батчами
/// </summary>
/// <typeparam name="TMessage"></typeparam>
public interface IKafkaConsumer<TMessage> where TMessage : class, IKafkaMessage
{
    /// <summary>
    /// Вызывается при постеплении новых сообщений, количество сообщений может быть меньше чем размер батча
    /// </summary>
    /// <param name="context"></param>
    /// <param name="token"></param>
    /// <returns></returns>
    public Task Consume(IConsumeContext<TMessage> context, CancellationToken token);
}



