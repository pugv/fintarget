namespace Mb.Kafka.Abstractions.Producer;

/// <summary>
/// Абстрактный класс для создания собственных middleware продюсера
/// </summary>
public abstract class KafkaProducerMiddleware
{
    private KafkaProducerMiddleware _next;

    internal KafkaProducerMiddleware AddNext(KafkaProducerMiddleware middleware)
    {
        _next = middleware;
        return this;
    }

    /// <summary>
    /// Метод для добавления логики в middleware
    /// </summary>
    /// <param name="messages"></param>
    /// <param name="token"></param>
    /// <typeparam name="TMessage"></typeparam>
    /// <returns></returns>
    public abstract Task Handle<TMessage>(TMessage[] messages, CancellationToken token) where TMessage : IKafkaMessage;

    /// <summary>
    /// Перейти дальше по жизненному циклу middleware
    /// </summary>
    /// <param name="messages"></param>
    /// <param name="token"></param>
    /// <typeparam name="TMessage"></typeparam>
    protected async Task Next<TMessage>(TMessage[] messages, CancellationToken token) where TMessage : IKafkaMessage
    {
        await _next.Handle(messages, token);
    }
}