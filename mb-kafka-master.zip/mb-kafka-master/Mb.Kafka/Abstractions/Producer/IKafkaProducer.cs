namespace Mb.Kafka.Abstractions.Producer;

/// <summary>
/// Интерфейс для отправки сообщений в kafka 
/// </summary>
/// <typeparam name="TMessage"></typeparam>
public interface IKafkaProducer<in TMessage> where TMessage : IKafkaMessage
{
    /// <summary>
    /// Отправить сообщение
    /// </summary>
    /// <param name="messages"></param>
    /// <param name="token"></param>
    /// <returns></returns>
    Task Produce(TMessage messages, CancellationToken token = default);

    /// <summary>
    /// Отправить сообщения
    /// </summary>
    /// <param name="messages">сообщение</param>
    /// <param name="token"></param>
    /// <returns></returns>
    Task Produce(TMessage[] messages, CancellationToken token = default);
}