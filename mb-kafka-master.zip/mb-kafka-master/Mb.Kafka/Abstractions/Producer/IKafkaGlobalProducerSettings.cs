namespace Mb.Kafka.Abstractions.Producer;

/// <summary>
/// Глобальные настройки для всех продюсеров
/// </summary>
public interface IKafkaGlobalProducerSettings
{
    /// <summary>
    /// Интервал времени на отправку batch сообщений в kafka
    /// (Default 0) Бесконечно ожидаем отправки
    /// </summary>
    public TimeSpan ProduceTimeout { get; set; }
        
    /// <summary>
    /// Тип сжатия
    /// (Default None)
    /// </summary>
    public MessageCompression Compression { get; set; }
        
    /// <summary>
    /// Сколько со всех продюсеров одновременно может быть подано сообщений
    /// (Должно быть больше 100K) 
    /// </summary>
    public int QueueBufferingMaxMessages { get; set; }
}