using Mb.Kafka.Abstractions.Serialization;

namespace Mb.Kafka.Abstractions;

/// <summary>
/// Расширенная конфигурация для конкретного продюсера
/// </summary>
public interface IKafkaProducerConfigurator<TMessage> where TMessage : class, IKafkaMessage
{
    /// <summary>
    /// Использовать отдельный сериализатор для заданного продюсера
    /// </summary>
    /// <returns></returns>
    public IKafkaProducerConfigurator<TMessage> UseCustomSerializer(IKafkaSerializer serializer);
}