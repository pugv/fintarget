namespace Mb.Kafka.Abstractions;

/// <summary>
/// Сжатие сообщений
/// </summary>
public enum MessageCompression
{
    /// <summary>
    /// Без сжатия
    /// </summary>
    None,
    
    /// <summary>
    /// Gzip
    /// </summary>
    Gzip,
    
    /// <summary>
    /// Snappy
    /// </summary>
    Snappy
}