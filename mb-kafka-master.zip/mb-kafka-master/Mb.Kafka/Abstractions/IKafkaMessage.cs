namespace Mb.Kafka.Abstractions;

/// <summary>
/// Сообщение для kafka
/// </summary>
public interface IKafkaMessage
{
}