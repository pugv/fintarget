using Mb.Kafka.Abstractions.Consumer;
using Mb.Kafka.Abstractions.Producer;
using Mb.Kafka.Abstractions.Serialization;
using Mb.Kafka.Settings;

namespace Mb.Kafka.Abstractions;

/// <summary>
/// Конфигуратор для producer-a и consumer-a
/// </summary>
public interface IKafkaConfigurator
{
    #region Consumer
    /// <summary>
    /// Установить имя консьюмер группы для всех консьюмеров (может быть перепределено в настройках при добавлении консьюмера)
    /// </summary>
    /// <param name="groupId"></param>
    /// <returns></returns>
    public IKafkaConfigurator SetConsumersGroupId(string groupId);
    
    /// <summary>
    /// Добавить консьюмер (добавляет на одну партицию)
    /// </summary>
    /// <param name="topic">топик который будет читаться</param>
    /// <param name="batchSize">размер батча (Приходящие сообщения могут быть меньше чем батч)</param>
    /// <typeparam name="TConsumer"></typeparam>
    /// <typeparam name="TMessage"></typeparam>
    /// <returns></returns>
    public IKafkaConsumerConfigurator<TMessage> AddConsumer<TConsumer, TMessage>(string topic, int batchSize)
        where TConsumer : class, IKafkaConsumer<TMessage>
        where TMessage : class, IKafkaMessage;
    
    /// <summary>
    /// Добавить консьюмер с расширенными настройками
    /// </summary>
    /// <param name="settings"></param>
    /// <typeparam name="TConsumer"></typeparam>
    /// <typeparam name="TMessage"></typeparam>
    /// <returns></returns>
    public IKafkaConsumerConfigurator<TMessage> AddConsumer<TConsumer, TMessage>(Action<IKafkaConsumerSettings<TMessage>> settings)
        where TConsumer : class, IKafkaConsumer<TMessage>
        where TMessage : class, IKafkaMessage;
    
    /// <summary>
    /// Переопределить серриализацию сообщений для консьюмера
    /// </summary>
    /// <param name="deserializer">Десериализатор, default = DefaultJsonDeserializer (Utf8Json)</param>
    /// <returns></returns>
    public IKafkaConfigurator SetConsumerDeserializer(IKafkaDeserializer deserializer = null);
    
    /// <summary>
    /// Добавить middleware для консьюмеров
    /// </summary>
    /// <typeparam name="TMiddleware"></typeparam>
    /// <returns></returns>
    IKafkaConfigurator AddConsumerMiddleware<TMiddleware>() where TMiddleware : KafkaConsumerMiddleware;
    #endregion

    #region Producer

    /// <summary>
    /// Задать глобальные настройки для всех консьюмеров
    /// </summary>
    /// <param name="settings"></param>
    /// <returns></returns>
    public IKafkaConfigurator SetGlobalProducersSettings(Action<IKafkaGlobalProducerSettings> settings);
    
    /// <summary>
    /// Добавить обычный producer
    /// </summary>
    /// <param name="topic">топик</param>
    /// <typeparam name="TMessage">тип сообщения</typeparam>
    /// <returns></returns>
    public IKafkaProducerConfigurator<TMessage> AddProducer<TMessage>(string topic) where TMessage : class, IKafkaMessage;

    /// <summary>
    /// Добавить producer, который отправляет сообщения по ключу партиционирования
    /// </summary>
    /// <param name="topic">топик</param>
    /// <param name="getKey">ключ партиционирования объекта</param>
    /// <typeparam name="TMessage">тип сообщения</typeparam>
    /// <returns></returns>
    public IKafkaProducerConfigurator<TMessage> AddProducer<TMessage>(string topic, Func<TMessage, object> getKey) where TMessage : class, IKafkaMessage;
    
    /// <summary>
    /// Переопределить серриализацию сообщений для продюсера
    /// </summary>
    /// <param name="serializer">Сериализатор, default = DefaultJsonSerializer (Utf8Json)</param>
    /// <returns></returns>
    public IKafkaConfigurator SetProducerSerializer(IKafkaSerializer serializer = null);

    /// <summary>
    /// Добавить middleware для продюсеров
    /// </summary>
    /// <typeparam name="TMiddleware">тип middleware</typeparam>
    /// <returns></returns>
    public IKafkaConfigurator AddProducerMiddleware<TMiddleware>() where TMiddleware : KafkaProducerMiddleware;
    #endregion
}