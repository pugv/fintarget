﻿using Mb.Kafka.Settings;
using Mb.Kafka.Exceptions;
using Mb.Kafka.Abstractions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Mb.Kafka
{
    /// <summary>
    /// Расширения для использования кафки
    /// </summary>
    public static class KafkaExtension
    {
        /// <summary>
        /// Подключить kafka для настройки producer-ов и consumer-ов
        /// </summary>
        /// <param name="services"></param>
        /// <param name="conf"></param>
        /// <param name="configuration"></param>
        /// <exception cref="KafkaSettingsExceptions">Если секция настроек не задана</exception>
        public static void AddKafka(this IServiceCollection services, Action<IKafkaConfigurator> conf, IConfiguration configuration)
        {
            services.AddOptions<KafkaConnectionSettings>().Bind(GetConfigurationSection(configuration));
            services.ConfigureKafka(conf);
        }

        /// <summary>
        /// Подключить kafka для настройки producer-ов и consumer-ов
        /// </summary>
        /// <param name="services"></param>
        /// <param name="conf">настройка с провайдером</param>
        /// <param name="configuration"></param>
        /// <exception cref="KafkaSettingsExceptions">Если секция настроек не задана</exception>
        public static void AddKafka(this IServiceCollection services, Action<IServiceProvider, IKafkaConfigurator> conf, IConfiguration configuration)
        {
            services.AddOptions<KafkaConnectionSettings>().Bind(GetConfigurationSection(configuration));
            services.ConfigureKafkaWithBuilder(conf);
        }
        
        /// <summary>
        /// Подключить kafka для настройки producer-ов и consumer-ов
        /// </summary>
        /// <param name="services"></param>
        /// <param name="conf">настройка с провайдером</param>
        /// <param name="settingsConfiguration"></param>
        /// <exception cref="KafkaSettingsExceptions">Если секция настроек не задана</exception>
        public static void AddKafka(this IServiceCollection services, Action<IKafkaConfigurator> conf, Action<KafkaConnectionSettings> settingsConfiguration)
        {
            services.AddSingleton(Options.Create(GetConnectionSettings(settingsConfiguration)));
            services.ConfigureKafka(conf);
        }
        
        /// <summary>
        /// Подключить kafka для настройки producer-ов и consumer-ов
        /// </summary>
        /// <param name="services"></param>
        /// <param name="conf"></param>
        /// <param name="settingsConfiguration"></param>
        /// <exception cref="KafkaSettingsExceptions">Если секция настроек не задана</exception>
        public static void AddKafka(this IServiceCollection services, Action<IServiceProvider,IKafkaConfigurator> conf,
            Action<KafkaConnectionSettings> settingsConfiguration)
        {
            services.AddSingleton(Options.Create(GetConnectionSettings(settingsConfiguration)));
            services.ConfigureKafkaWithBuilder(conf);
        }

        private static IConfigurationSection GetConfigurationSection(IConfiguration configuration)
        {
            var configurationSection = configuration.GetSection(nameof(KafkaConnectionSettings));
            var kafkaSettings = configurationSection.Get<KafkaConnectionSettings>();
            if (kafkaSettings is null)
                throw new KafkaSettingsExceptions($"{nameof(KafkaConnectionSettings)} section is not defined");
            
            if (string.IsNullOrEmpty(kafkaSettings.Servers))
                throw new KafkaSettingsExceptions($" Servers in {nameof(KafkaConnectionSettings)} is not defined");
            return configurationSection;
        }
        
        private static KafkaConnectionSettings GetConnectionSettings(Action<KafkaConnectionSettings> settingsConfiguration)
        {
            var kafkaSettings = new KafkaConnectionSettings();
            settingsConfiguration.Invoke(kafkaSettings);
            if (string.IsNullOrEmpty(kafkaSettings.Servers))
                throw new KafkaSettingsExceptions($" Servers in {nameof(KafkaConnectionSettings)} is not defined");
            return kafkaSettings;
        }
        
        private static void ConfigureKafkaWithBuilder(this IServiceCollection services, Action<IServiceProvider, IKafkaConfigurator> conf)
        {
            var configurator = new KafkaConfigurator(services);
            
            conf.Invoke(services.BuildServiceProvider() ,configurator);
            configurator.ConfigureSerializerProvider();
            configurator.AddExecutorMiddlewares();
            configurator.SetGlobalConsumersSettings();
        }
        
        private static void ConfigureKafka(this IServiceCollection services, Action<IKafkaConfigurator> conf)
        {
            var configurator = new KafkaConfigurator(services);
            
            conf.Invoke(configurator);
            configurator.ConfigureSerializerProvider();
            configurator.ConfigureDeserializerProvider();
            configurator.AddExecutorMiddlewares();
            configurator.SetGlobalConsumersSettings();
        }
    }
}