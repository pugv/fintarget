using Confluent.Kafka;
using Mb.Kafka.Abstractions.Consumer;

namespace Mb.Kafka.Consumer.Middleware;

internal class CommitConsumerMiddleware : KafkaConsumerMiddleware
{
    private readonly IConsumer<byte[], byte[]> _consumer;
    public CommitConsumerMiddleware(IConsumer<byte[], byte[]> consumer)
    {
        _consumer = consumer;
    }

    public override Task Handle<TMessage>(IConsumeContext<TMessage> context, CancellationToken token)
    {
        _consumer.Commit(new []
        {
            new TopicPartitionOffset(context.TopicName,
                new Partition(context.Partition),
                new Offset(context.Offset + 1))
        });
        return Task.CompletedTask;
    }
}