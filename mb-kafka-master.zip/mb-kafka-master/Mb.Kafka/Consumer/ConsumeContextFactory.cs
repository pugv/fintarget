using Confluent.Kafka;
using Mb.Kafka.Abstractions;
using Mb.Kafka.Abstractions.Serialization;
using Mb.Kafka.Exceptions;
using Mb.Kafka.Serialization;

namespace Mb.Kafka.Consumer;

internal class ConsumeContextFactory<TMessage>  where TMessage : class, IKafkaMessage
{
    private readonly IKafkaDeserializer _deserializer;
    public ConsumeContextFactory(DeserializerProvider provider)
    {
        _deserializer = provider.GetInstance<TMessage>();
    }

    public ConsumeContext<TMessage> Create(ConsumeResult<byte[], byte[]>[] rawMessages)
    {
        var lastOffset = rawMessages.Max(o => o.Offset.Value);
        var topicName = rawMessages.First().Topic;
        var partition = rawMessages.First().Partition;
        return new ConsumeContext<TMessage>(topicName, partition, lastOffset, rawMessages.Select(Deserializers));
    }
    
    private TMessage Deserializers(ConsumeResult<byte[], byte[]> result)
    {
        try
        {
            return _deserializer.Deserialize<TMessage>(result.Message.Value);
        }
        catch (Exception e)
        {
            throw new KafkaDeserializationExceptions(result.Topic, result.Offset.Value, e);
        }
    }
}