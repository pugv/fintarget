using Mb.Kafka.Settings;
using Mb.Kafka.Producer;
using Mb.Kafka.Abstractions;
using Mb.Kafka.Abstractions.Consumer;
using Mb.Kafka.Producer.Middleware;
using Mb.Kafka.Abstractions.Producer;
using Mb.Kafka.Abstractions.Serialization;
using Mb.Kafka.Consumer;
using Mb.Kafka.Consumer.Middleware;
using Mb.Kafka.Serialization;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Mb.Kafka;

internal class KafkaConfigurator : IKafkaConfigurator
{
    public KafkaConfigurator(IServiceCollection serviceCollection)
    {
        ServiceCollection = serviceCollection;
        serviceCollection.AddSingleton<KafkaReadinessClient>();
        ServiceCollection.AddSingleton<ProducerInstanceProvider>();
        CustomProducerSerializers = new Dictionary<Type, IKafkaSerializer>();
        CustomConsumerDeserializers = new Dictionary<Type, IKafkaDeserializer>();
    }

    private string _groupId;
    
    public IServiceCollection ServiceCollection { get; }
    public IKafkaSerializer DefaultSerializer = new DefaultJsonSerializer();
    public IKafkaDeserializer DefaultDeserializer = new DefaultJsonDeserializer();
    public Dictionary<Type, IKafkaSerializer> CustomProducerSerializers { get; }
    public Dictionary<Type, IKafkaDeserializer> CustomConsumerDeserializers { get; }

    public IKafkaConfigurator SetConsumersGroupId(string groupId)
    {
        _groupId = groupId;
        return this;
    }
    
    public IKafkaConsumerConfigurator<TMessage> AddConsumer<TConsumer, TMessage>(string topic, int batchSize) 
        where TConsumer : class, IKafkaConsumer<TMessage>
        where TMessage : class, IKafkaMessage
    {
         var consumerSettings = new KafkaConsumerSettings<TMessage>
         {
             TopicName = topic,
             BatchSize = batchSize,
             GroupId = _groupId
         };
         consumerSettings.Validate();
         AddConsumer<TConsumer, TMessage>(consumerSettings);
         return new KafkaConsumerConfigurator<TMessage>(this);
    }
    
    public IKafkaConsumerConfigurator<TMessage> AddConsumer<TConsumer, TMessage>(Action<IKafkaConsumerSettings<TMessage>> settings) 
        where TConsumer : class, IKafkaConsumer<TMessage>
        where TMessage : class, IKafkaMessage
    {
        var consumerSettings = new KafkaConsumerSettings<TMessage>();
        settings.Invoke(consumerSettings);
        if (string.IsNullOrEmpty(consumerSettings.GroupId))
            consumerSettings.GroupId = _groupId;
           
        consumerSettings.Validate();
        AddConsumer<TConsumer, TMessage>(consumerSettings);
        return new KafkaConsumerConfigurator<TMessage>(this);
    }
    
    public IKafkaConfigurator SetConsumerDeserializer(IKafkaDeserializer deserializer = null)
    {
        DefaultDeserializer = deserializer ?? throw new ArgumentNullException(nameof(deserializer));
        return this;
    }

    public IKafkaConfigurator SetGlobalProducersSettings(Action<IKafkaGlobalProducerSettings> settings)
    {
        var consumerSettings = new KafkaGlobalProducerSettings();
        settings.Invoke(consumerSettings);
        ServiceCollection.TryAddSingleton<IKafkaGlobalProducerSettings>(consumerSettings);
        return this;
    }
    
    public void SetGlobalConsumersSettings()
    {
        var consumerSettings = new KafkaGlobalProducerSettings();
        consumerSettings.Validate();
        ServiceCollection.TryAddSingleton<IKafkaGlobalProducerSettings>(consumerSettings);
    }
    
    public IKafkaProducerConfigurator<TMessage> AddProducer<TMessage>(string topic) where TMessage : class, IKafkaMessage
    {
        AddProducer(new KafkaProducerSettings<TMessage>(topic));
        return new KafkaProducerConfigurator<TMessage>(this);
    }
    
    public IKafkaProducerConfigurator<TMessage> AddProducer<TMessage>(string topic, Func<TMessage, object> getKey) where TMessage : class, IKafkaMessage
    {
        AddProducer(new KafkaProducerSettings<TMessage>(topic, getKey));
        return new KafkaProducerConfigurator<TMessage>(this);
    }
    
    public IKafkaConfigurator AddConsumerMiddleware<TMiddleware>() where TMiddleware : KafkaConsumerMiddleware
    {
        ServiceCollection.AddSingleton<KafkaConsumerMiddleware, TMiddleware>();
        return this;
    }
    
    public IKafkaConfigurator AddProducerMiddleware<TMiddleware>() where TMiddleware : KafkaProducerMiddleware
    {
        ServiceCollection.AddSingleton<KafkaProducerMiddleware, TMiddleware>();
        return this;
    }
    
    public IKafkaConfigurator SetProducerSerializer(IKafkaSerializer serializer)
    {
        DefaultSerializer = serializer ?? throw new ArgumentNullException(nameof(serializer));
        return this;
    }
    
    internal void AddExecutorMiddlewares()
    {
        ServiceCollection.AddSingleton<KafkaProducerMiddleware, ProducerMiddleware>();

        ServiceCollection
            .AddSingleton<KafkaProducerMiddlewareExecutor>()
            .AddSingleton<KafkaProducerMiddleware>(provider => provider.GetRequiredService<KafkaProducerMiddlewareExecutor>());
        
        ServiceCollection.AddSingleton<KafkaConsumerMiddleware, ConsumerMiddleware>();

        ServiceCollection.AddSingleton<KafkaConsumerMiddlewareExecutor>();
    }

    internal void ConfigureSerializerProvider()
    {
        ServiceCollection.AddSingleton(new SerializerProvider(DefaultSerializer, CustomProducerSerializers));
    }

    internal void ConfigureDeserializerProvider()
    {
        ServiceCollection.AddSingleton(new DeserializerProvider(DefaultDeserializer, CustomConsumerDeserializers));
    }

    private void AddProducer<TMessage>(KafkaProducerSettings<TMessage> settings) where TMessage : class, IKafkaMessage
    {
        ServiceCollection.AddSingleton(settings);
        ServiceCollection.AddSingleton<ProducerWrapper<TMessage>>();
        ServiceCollection.AddSingleton<IKafkaProducer<TMessage>, KafkaProducer<TMessage>>();
    }
    
    private void AddConsumer<TConsumer,TMessage>(KafkaConsumerSettings<TMessage> settings) 
        where TConsumer : class, IKafkaConsumer<TMessage>
        where TMessage : class, IKafkaMessage
    {
        ServiceCollection.AddSingleton(settings);
        ServiceCollection.AddSingleton<ConsumeContextFactory<TMessage>>();
        ServiceCollection.AddSingleton<ConsumerFactory<TMessage>>();
        ServiceCollection.AddSingleton<IKafkaConsumer<TMessage>, TConsumer>();
        ServiceCollection.AddHostedService<KafkaConsumerService<TMessage>>();
    }
}