﻿using Xunit;

namespace Mb.Kafka.UnitTests;

public class Test
{
    [Fact]
    public void TestStub()
    {
        Assert.True(true);
    }
}