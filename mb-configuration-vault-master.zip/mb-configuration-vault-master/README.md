Package for Vault Configuration.
Read configuration from Vault if USE_VAULT environment set as true
