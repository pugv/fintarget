namespace Mb.Configuration.Vault.UnitTests
{
    public static class VaultConfigurationGenerator
    {
        internal static VaultConfiguration CreateWithTokenAuth()
        {
            var conf = CreateWithoutAuth();

            conf.TokenAuth = new VaultTokenAuthConfiguration()
            {
                RootToken = "token"
            };
            return conf;
        }

        internal static VaultConfiguration CreateWithK8SAuth()
        {
            var conf = CreateWithoutAuth();

            conf.K8SAuth = new VaultTokenK8SConfiguration()
            {
                Role = "mb",
                JwtTokenPath = "./token_file.txt"
            };
            return conf;
        }

        internal static VaultConfiguration CreateWithK8SAuthTokenAndTokenFileNotExists()
        {
            var conf = CreateWithoutAuth();

            conf.K8SAuth = new VaultTokenK8SConfiguration()
            {
                Role = "mb",
                JwtTokenPath = "tokenPath"
            };
            return conf;
        }


        internal static VaultConfiguration CreateWithoutAuth()
        {
            return new VaultConfiguration()
            {
                Url = "http://localhost/vault",
                MountPoint = "mb",
                SecretPath = "service_name"
            };
        }
    }
}