using FluentAssertions;
using Xunit;

namespace Mb.Configuration.Vault.UnitTests
{
    using Externals;

    public class VaultConfigurationProviderTests
    {
        [Theory]
        [InlineData("Key", "KEY", "value")]
        [InlineData("KEY", "Key", "value")]
        [InlineData("KEY", "Key", 1234)]
        public void Load_PlainSecret_ProviderHasValues(string expectedKey, string vaultKey, object value)
        {
            //arrange
            var provider = CreateVaultConfigurationProvider(vaultKey, value);

            //act
            provider.Load();

            var hasKey = provider.TryGet(expectedKey, out var actualValue);

            
            //assert
            hasKey.Should().BeTrue();
            actualValue.Should().BeEquivalentTo(value?.ToString());
        }


        [Theory]
        [InlineData("KEY:SUBKEY", "key", "subkey")]
        [InlineData("key:subkey1:subkey2", "Key", "SUBKEY1", "SUBKEY2")]
        public void Load_NestedSecret_ProviderHasValues(string expectedKey, params string[] keySegments)
        {
            //arrange
            var expectedValue = "value";
            var provider = CreateVaultConfigurationProvider(string.Join("__", keySegments), expectedValue);

            //act
            provider.Load();

            var hasKey = provider.TryGet(expectedKey, out var actualValue);


            //assert
            hasKey.Should().BeTrue();
            actualValue.Should().BeEquivalentTo(expectedValue);
        }

        private VaultConfigurationProvider CreateVaultConfigurationProvider(string key, object value)
        {
            return new VaultConfigurationProvider(
                VaultClientFakes
                    .CreateDefault()
                    .WithData(key, value)
                    .Object,
                VaultConfigurationGenerator.CreateWithK8SAuth());
        }
    }
}