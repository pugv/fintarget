using System.Collections.Generic;
using Moq;
using VaultSharp;
using VaultSharp.V1.Commons;

namespace Mb.Configuration.Vault.UnitTests.Externals
{
    public static class VaultClientFakes
    {
        public static Mock<IVaultClient> CreateDefault()
        {
            return new Mock<IVaultClient>();
        }

        public static Mock<IVaultClient> WithData(this Mock<IVaultClient> mock, string key, object value)
        {
            mock.Setup(client => client.V1.Secrets.KeyValue.V1.ReadSecretAsync(
                    It.IsAny<string>(),
                    It.IsAny<string>(),
                    It.IsAny<string>()))
                .ReturnsAsync(new Secret<Dictionary<string, object>>
                {
                    Data = new Dictionary<string, object> {{key, value}}
                });

            return mock;
        }
    }
}