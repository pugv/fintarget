using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace Mb.Configuration.Vault.UnitTests
{
    public class VaultConfigurationExtensionTests
    {
        [Theory]
        [InlineData(false)]
        [InlineData(true)]
        public void AddVaultConfiguration_DefaultVaultEnvs_Ok(bool useVaultEnvironment)
        {
            //arrange
            var confBuilder = new ConfigurationBuilder()
                .AddInMemoryCollection(new[] {new KeyValuePair<string, string>("USE_VAULT", useVaultEnvironment.ToString())});

            //act
            VaultConfigurationExtension.AddVaultConfiguration(confBuilder);


            //assert
            var isUsingVault = IsUsingVault(confBuilder);
            isUsingVault.Should().Be(useVaultEnvironment);
        }
        
        [Fact]
        public void AddVaultConfiguration_WithoutUseVaultEnvironment_Ok()
        {
            //arrange
            var confBuilder = new ConfigurationBuilder();
            
            //act
            VaultConfigurationExtension.AddVaultConfiguration(confBuilder);


            //assert
            var isUsingVault = IsUsingVault(confBuilder);
            isUsingVault.Should().Be(false);
        }
        

        private bool IsUsingVault(IConfigurationBuilder builder)
        {
            return builder.Sources.Any(s => s.GetType() == typeof(VaultConfigurationSource));
        }
    }
}