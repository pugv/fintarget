using System;
using System.Configuration;
using System.IO;
using FluentAssertions;
using Xunit;

namespace Mb.Configuration.Vault.UnitTests
{
    public class VaultClientFactoryTests
    {
        [Fact]
        public void CreateVaultClient_WithTokenAuth_ClientCreated()
        {
            //arrange
            var configuration = VaultConfigurationGenerator.CreateWithTokenAuth();

            //act
            var client = VaultClientFactory.Create(configuration);

            //assert
            client.Should().NotBeNull();
        }

        [Fact]
        public void CreateVaultClient_WithK8SAuthTokenFileNotExists_FileNotFoundExceptionThrown()
        {
            //arrange
            var configuration = VaultConfigurationGenerator.CreateWithK8SAuthTokenAndTokenFileNotExists();

            //act
            Action act = () => VaultClientFactory.Create(configuration);

            //assert
            act.Should().Throw<FileNotFoundException>();
        }

        [Fact]
        public void CreateVaultClient_WithK8SAuthTokenFileExists_FileNotFoundExceptionThrown()
        {
            //arrange
            var configuration = VaultConfigurationGenerator.CreateWithK8SAuth();

            //act
            var client = VaultClientFactory.Create(configuration);

            //assert
            client.Should().NotBeNull();
        }


        [Fact]
        public void CreateVaultClient_WithoutAuth_ConfigurationExceptionThrown()
        {
            //arrange
            var configuration = VaultConfigurationGenerator.CreateWithoutAuth();

            //act
            Action act = () => VaultClientFactory.Create(configuration);

            //assert
            act.Should().Throw<ConfigurationErrorsException>();
        }
    }
}