using System;
using System.Net.Http;
using System.Runtime.CompilerServices;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

[assembly: InternalsVisibleTo("Mb.Configuration.Vault.UnitTests")]

namespace Mb.Configuration.Vault
{
    /// <summary>
    /// Extension методы для хранения секретов
    /// </summary>
    public static class VaultConfigurationExtension
    {
        /// <summary>
        /// Используем vault для хранения секретов
        /// Для того чтобы использовать vault необходима переменная USE_VAULT : true
        /// </summary>
        /// <param name="hostBuilder"></param>
        /// <param name="handler">Делегат фабрики для предоставления собственного http-client</param>
        /// <returns></returns>
        public static IWebHostBuilder UseVaultSecrets(this IWebHostBuilder hostBuilder, Func<HttpMessageHandler, HttpClient> handler = null)
        {
            return hostBuilder.ConfigureAppConfiguration(builder => AddVaultConfiguration(builder, handler));
        }
        
        internal static void AddVaultConfiguration(IConfigurationBuilder builder, Func<HttpMessageHandler, HttpClient> handler = null)
        {
            var config = builder.Build();
            var isUseVault = config.GetValue<bool>("USE_VAULT");
          
            if (isUseVault)
            {
                builder.Add(new VaultConfigurationSource(config, handler));
            }
        }
    }
}