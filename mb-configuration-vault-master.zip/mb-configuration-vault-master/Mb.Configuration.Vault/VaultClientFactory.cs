using System;
using System.Configuration;
using System.IO;
using System.Net.Http;
using VaultSharp;
using VaultSharp.V1.AuthMethods;
using VaultSharp.V1.AuthMethods.Kubernetes;
using VaultSharp.V1.AuthMethods.Token;

namespace Mb.Configuration.Vault
{
    internal static class VaultClientFactory
    {
        /// <summary>
        /// Создаем VaultClient. Необходима секция Vault в конфигурации
        /// </summary>
        /// <param name="config">Конфигурация Vault</param>
        /// <param name="handler">Конфигурация Vault</param>
        /// <returns></returns>
        internal static IVaultClient Create(VaultConfiguration config, Func<HttpMessageHandler, HttpClient> handler = null)
        {
            var authMethod = GetAuthInfo(config);
            VaultClientSettings vaultClientSettings = new VaultClientSettings(config.Url, authMethod);
            vaultClientSettings.UseVaultTokenHeaderInsteadOfAuthorizationHeader = config.UseVaultTokenHeaderInsteadOfAuthorizationHeader;
            
            if(handler != null)
                vaultClientSettings.MyHttpClientProviderFunc = handler;

            return new VaultClient(vaultClientSettings);
        }

        private static IAuthMethodInfo GetAuthInfo(VaultConfiguration config)
        {
            if (config.TokenAuth != null)
                return new TokenAuthMethodInfo(config.TokenAuth.RootToken);

            if (config.K8SAuth != null)
            {
                if (!File.Exists(config.K8SAuth.JwtTokenPath))
                    throw new FileNotFoundException("Token file not found", config.K8SAuth.JwtTokenPath);

                var token = File.ReadAllText(config.K8SAuth.JwtTokenPath);
                return new KubernetesAuthMethodInfo(config.K8SAuth.Role, token);
            }
            
            throw new ConfigurationErrorsException(
                "Missing vault authorization configuration section. Only root token and k8s auth allowed");
        }
    }
}