using System;
using System.Linq;
using Microsoft.Extensions.Configuration;
using VaultSharp;

namespace Mb.Configuration.Vault
{
    internal class VaultConfigurationProvider : ConfigurationProvider
    {
        private readonly IVaultClient _client;
        private readonly VaultConfiguration _vaultSettings;

        public VaultConfigurationProvider(IVaultClient client, VaultConfiguration vaultSettings)
        {
            _client = client;
            _vaultSettings = vaultSettings;
        }


        public override void Load()
        {
            var secrets = _client.V1.Secrets.KeyValue.V1
                .ReadSecretAsync(_vaultSettings.SecretPath, mountPoint: _vaultSettings.MountPoint)
                .GetAwaiter()
                .GetResult();

            Data = secrets.Data.ToDictionary(
                s => NormalizeKey(s.Key),
                s => s.Value?.ToString(),
                StringComparer.OrdinalIgnoreCase);
        }

        private static string NormalizeKey(string key)
        {
            return key.Replace("__", ConfigurationPath.KeyDelimiter);
        }
    }
}