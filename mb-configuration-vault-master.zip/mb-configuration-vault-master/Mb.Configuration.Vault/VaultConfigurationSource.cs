using System;
using System.Configuration;
using System.Net.Http;
using Microsoft.Extensions.Configuration;

namespace Mb.Configuration.Vault
{
    internal class VaultConfigurationSource : IConfigurationSource
    {
        private readonly IConfiguration _configuration;
        private readonly Func<HttpMessageHandler, HttpClient> _handler;

        private const string VaultSectionName = "Vault";

        public VaultConfigurationSource(IConfiguration configuration, Func<HttpMessageHandler, HttpClient> handler)
        {
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            _handler = handler;
        }


        public IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            var section = _configuration.GetSection(VaultSectionName);

            if (section == null)
                throw new ConfigurationErrorsException($"Missing {VaultSectionName} configuration section");

            var vaultSettings = section.Get<VaultConfiguration>();

            var client = VaultClientFactory.Create(vaultSettings, _handler);

            return new VaultConfigurationProvider(client, vaultSettings);
        }
    }
}