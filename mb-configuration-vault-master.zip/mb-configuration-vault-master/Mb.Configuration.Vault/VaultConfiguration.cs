using System.ComponentModel.DataAnnotations;

namespace Mb.Configuration.Vault
{
    /// <summary>
    /// Конфигурация Vault
    /// </summary>
    internal class VaultConfiguration
    {
        /// <summary>
        /// Адрес Vault
        /// </summary>
        [Required] 
        public string Url { get; set; }
        
        /// <summary>
        /// Путь к секрету
        /// </summary>
        [Required] 
        public string SecretPath { get; set; }
        
        /// <summary>
        /// Точка монтирования
        /// </summary>
        [Required]
        public string MountPoint { get; set; }
        
        /// <summary>
        /// Секция авториации по root токену, работает только для TEST
        /// </summary>
        public VaultTokenAuthConfiguration TokenAuth { get; set; }
        
        /// <summary>
        /// Секция авторизации через кубернейтс 
        /// </summary>
        public VaultTokenK8SConfiguration K8SAuth { get; set; }
        
        /// <summary>
        /// Указывает как токен хранилища должен быть передан в API.
        /// Default Bearer &lt;vault-token&gt;.
        /// </summary>
        public bool UseVaultTokenHeaderInsteadOfAuthorizationHeader { get; set; }
    }

    internal class VaultTokenAuthConfiguration
    {
        /// <summary>
        /// Root токен
        /// </summary>
        [Required]
        public string RootToken { get; set; }
    }
    
    internal class VaultTokenK8SConfiguration
    {
        /// <summary>
        /// Путь к jwt токену в файловой системе
        /// </summary>
        [Required]
        public string JwtTokenPath { get; set; }
        
        /// <summary>
        /// Роль в Vault
        /// </summary>
        [Required]
        public string Role { get; set; }

    }
}